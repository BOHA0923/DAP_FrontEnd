export declare class DwAffixModule {
}
