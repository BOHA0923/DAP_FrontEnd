/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwScrollService } from 'ng-quicksilver/core/services';
import { NumberInput, DwSafeAny } from 'ng-quicksilver/core/types';
import { SimpleRect } from './utils';
export declare class DwAffixComponent implements AfterViewInit, OnChanges, OnDestroy {
    dwConfigService: DwConfigService;
    private scrollSrv;
    private ngZone;
    private platform;
    private renderer;
    static ngAcceptInputType_dwOffsetTop: NumberInput;
    static ngAcceptInputType_dwOffsetBottom: NumberInput;
    private fixedEl;
    dwTarget?: string | Element | Window;
    dwOffsetTop?: null | number;
    dwOffsetBottom?: null | number;
    readonly dwChange: EventEmitter<boolean>;
    private readonly placeholderNode;
    private affixStyle?;
    private placeholderStyle?;
    private positionChangeSubscription;
    private offsetChanged$;
    private destroy$;
    private timeout?;
    private document;
    private get target();
    constructor(el: ElementRef, doc: DwSafeAny, dwConfigService: DwConfigService, scrollSrv: DwScrollService, ngZone: NgZone, platform: Platform, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private registerListeners;
    private removeListeners;
    getOffset(element: Element, target: Element | Window | undefined): SimpleRect;
    private setAffixStyle;
    private setPlaceholderStyle;
    private syncPlaceholderStyle;
    updatePosition(e: Event): void;
}
