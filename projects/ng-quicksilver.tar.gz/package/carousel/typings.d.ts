/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { InjectionToken, QueryList } from '@angular/core';
import { DwCarouselContentDirective } from './carousel-content.directive';
import { DwCarouselBaseStrategy } from './strategies/base-strategy';
export declare type DwCarouselEffects = 'fade' | 'scrollx' | string;
export declare type DwCarouselDotPosition = 'top' | 'bottom' | 'left' | 'right' | string;
export interface DwCarouselComponentAsSource {
    carouselContents: QueryList<DwCarouselContentDirective>;
    el: HTMLElement;
    dwTransitionSpeed: number;
    vertical: boolean;
    slickListEl: HTMLElement;
    slickTrackEl: HTMLElement;
    activeIndex: number;
}
export interface DwCarouselStrategyRegistryItem {
    name: string;
    strategy: DwCarouselBaseStrategy;
}
export declare const DW_CAROUSEL_CUSTOM_STRATEGIES: InjectionToken<DwCarouselStrategyRegistryItem[]>;
export interface PointerVector {
    x: number;
    y: number;
}
export interface FromToInterface {
    from: number;
    to: number;
}
