/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, OnDestroy, QueryList, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwDragService, DwResizeService } from 'ng-quicksilver/core/services';
import { BooleanInput, NumberInput } from 'ng-quicksilver/core/types';
import { DwCarouselContentDirective } from './carousel-content.directive';
import { DwCarouselBaseStrategy } from './strategies/base-strategy';
import { FromToInterface, DwCarouselDotPosition, DwCarouselEffects, DwCarouselStrategyRegistryItem } from './typings';
export declare class DwCarouselComponent implements AfterContentInit, AfterViewInit, OnDestroy, OnChanges {
    readonly dwConfigService: DwConfigService;
    private readonly renderer;
    private readonly cdr;
    private readonly platform;
    private readonly resizeService;
    private readonly dwDragService;
    private customStrategies;
    static ngAcceptInputType_dwEnableSwipe: BooleanInput;
    static ngAcceptInputType_dwDots: BooleanInput;
    static ngAcceptInputType_dwAutoPlay: BooleanInput;
    static ngAcceptInputType_dwAutoPlaySpeed: NumberInput;
    static ngAcceptInputType_dwTransitionSpeed: NumberInput;
    carouselContents: QueryList<DwCarouselContentDirective>;
    slickList?: ElementRef;
    slickTrack?: ElementRef;
    dwDotRender?: TemplateRef<{
        $implicit: number;
    }>;
    dwEffect: DwCarouselEffects;
    dwEnableSwipe: boolean;
    dwDots: boolean;
    dwAutoPlay: boolean;
    dwAutoPlaySpeed: number;
    dwTransitionSpeed: number;
    set dwDotPosition(value: DwCarouselDotPosition);
    get dwDotPosition(): DwCarouselDotPosition;
    private _dotPosition;
    readonly dwBeforeChange: EventEmitter<FromToInterface>;
    readonly dwAfterChange: EventEmitter<number>;
    activeIndex: number;
    el: HTMLElement;
    slickListEl: HTMLElement;
    slickTrackEl: HTMLElement;
    strategy?: DwCarouselBaseStrategy;
    vertical: boolean;
    transitionInProgress: number | null;
    private destroy$;
    private gestureRect;
    private pointerDelta;
    private isTransiting;
    private isDragging;
    constructor(elementRef: ElementRef, dwConfigService: DwConfigService, renderer: Renderer2, cdr: ChangeDetectorRef, platform: Platform, resizeService: DwResizeService, dwDragService: DwDragService, customStrategies: DwCarouselStrategyRegistryItem[]);
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onKeyDown(e: KeyboardEvent): void;
    next(): void;
    pre(): void;
    goTo(index: number): void;
    private switchStrategy;
    private scheduleNextTransition;
    private clearScheduledTransition;
    private markContentActive;
    /**
     * Drag carousel.
     */
    pointerDown: (event: TouchEvent | MouseEvent) => void;
    private syncStrategy;
}
