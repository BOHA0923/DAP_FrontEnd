export declare class DwCarouselModule {
}
