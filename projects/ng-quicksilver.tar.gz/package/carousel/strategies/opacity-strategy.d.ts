/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { QueryList } from '@angular/core';
import { Observable } from 'rxjs';
import { DwCarouselContentDirective } from '../carousel-content.directive';
import { DwCarouselBaseStrategy } from './base-strategy';
export declare class DwCarouselOpacityStrategy extends DwCarouselBaseStrategy {
    withCarouselContents(contents: QueryList<DwCarouselContentDirective> | null): void;
    switch(_f: number, _t: number): Observable<void>;
    dispose(): void;
}
