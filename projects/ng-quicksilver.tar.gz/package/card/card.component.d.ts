/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, OnDestroy, QueryList, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput, NgStyleInterface, DwSizeDSType } from 'ng-quicksilver/core/types';
import { DwCardGridDirective } from './card-grid.directive';
import { DwCardTabComponent } from './card-tab.component';
export declare class DwCardComponent implements OnDestroy {
    dwConfigService: DwConfigService;
    private cdr;
    static ngAcceptInputType_dwBordered: BooleanInput;
    static ngAcceptInputType_dwLoading: BooleanInput;
    static ngAcceptInputType_dwHoverable: BooleanInput;
    dwBordered: boolean;
    dwLoading: boolean;
    dwHoverable: boolean;
    dwBodyStyle: NgStyleInterface | null;
    dwCover?: TemplateRef<void>;
    dwActions: Array<TemplateRef<void>>;
    dwType: string | 'inner' | null;
    dwSize: DwSizeDSType;
    dwTitle?: string | TemplateRef<void>;
    dwExtra?: string | TemplateRef<void>;
    listOfDwCardTabComponent?: DwCardTabComponent;
    listOfDwCardGridDirective: QueryList<DwCardGridDirective>;
    private destroy$;
    constructor(dwConfigService: DwConfigService, cdr: ChangeDetectorRef);
    ngOnDestroy(): void;
}
