/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ContentObserver } from '@angular/cdk/observers';
import { AfterViewInit, ChangeDetectorRef, ElementRef, NgZone, OnChanges, OnDestroy, OnInit, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput, DwSafeAny } from 'ng-quicksilver/core/types';
import { DwBadgeStatusType } from './types';
export declare class DwBadgeComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    dwConfigService: DwConfigService;
    private renderer;
    private elementRef;
    private contentObserver;
    private cdr;
    private ngZone;
    static ngAcceptInputType_dwShowZero: BooleanInput;
    static ngAcceptInputType_dwShowDot: BooleanInput;
    static ngAcceptInputType_dwDot: BooleanInput;
    private destroy$;
    notWrapper: boolean;
    viewInit: boolean;
    maxNumberArray: string[];
    countArray: number[];
    countSingleArray: number[];
    presetColor: string | null;
    count: number;
    contentElement?: ElementRef;
    dwShowZero: boolean;
    dwShowDot: boolean;
    dwDot: boolean;
    dwOverflowCount: number;
    dwColor?: string;
    dwStyle: {
        [key: string]: string;
    } | null;
    dwText?: string;
    dwTitle?: string | null | undefined;
    dwStatus?: DwBadgeStatusType | string;
    dwCount?: number | TemplateRef<DwSafeAny>;
    dwOffset?: [number, number];
    checkContent(): void;
    get showSup(): boolean;
    generateMaxNumberArray(): void;
    constructor(dwConfigService: DwConfigService, renderer: Renderer2, elementRef: ElementRef, contentObserver: ContentObserver, cdr: ChangeDetectorRef, ngZone: NgZone);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
}
