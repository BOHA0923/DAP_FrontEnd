/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { AfterViewInit, ChangeDetectorRef, EventEmitter, NgZone, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwScrollService } from 'ng-quicksilver/core/services';
import { BooleanInput, NgStyleInterface, NumberInput, DwSafeAny } from 'ng-quicksilver/core/types';
import { DwAnchorLinkComponent } from './anchor-link.component';
export declare class DwAnchorComponent implements OnDestroy, AfterViewInit, OnChanges {
    private doc;
    dwConfigService: DwConfigService;
    private scrollSrv;
    private cdr;
    private platform;
    private zone;
    private renderer;
    static ngAcceptInputType_dwAffix: BooleanInput;
    static ngAcceptInputType_dwShowInkInFixed: BooleanInput;
    static ngAcceptInputType_dwBounds: NumberInput;
    static ngAcceptInputType_dwOffsetTop: NumberInput;
    private ink;
    dwAffix: boolean;
    dwShowInkInFixed: boolean;
    dwBounds: number;
    dwOffsetTop?: number;
    dwContainer?: string | HTMLElement;
    dwTarget: string | HTMLElement;
    readonly dwClick: EventEmitter<string>;
    readonly dwScroll: EventEmitter<DwAnchorLinkComponent>;
    visible: boolean;
    wrapperStyle: NgStyleInterface;
    container?: HTMLElement | Window;
    private links;
    private animating;
    private destroy$;
    private handleScrollTimeoutID;
    constructor(doc: DwSafeAny, dwConfigService: DwConfigService, scrollSrv: DwScrollService, cdr: ChangeDetectorRef, platform: Platform, zone: NgZone, renderer: Renderer2);
    registerLink(link: DwAnchorLinkComponent): void;
    unregisterLink(link: DwAnchorLinkComponent): void;
    private getContainer;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private registerScrollEvent;
    handleScroll(): void;
    private clearActive;
    private handleActive;
    private setVisible;
    handleScrollTo(linkComp: DwAnchorLinkComponent): void;
    ngOnChanges(changes: SimpleChanges): void;
}
