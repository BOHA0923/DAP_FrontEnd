export declare class DwAnchorModule {
}
