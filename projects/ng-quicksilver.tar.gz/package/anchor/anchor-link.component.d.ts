/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { ElementRef, OnDestroy, OnInit, Renderer2, TemplateRef } from '@angular/core';
import { DwSafeAny } from 'ng-quicksilver/core/types';
import { DwAnchorComponent } from './anchor.component';
export declare class DwAnchorLinkComponent implements OnInit, OnDestroy {
    elementRef: ElementRef;
    private anchorComp;
    private platform;
    private renderer;
    dwHref: string;
    titleStr: string | null;
    titleTpl?: TemplateRef<DwSafeAny>;
    set dwTitle(value: string | TemplateRef<void>);
    dwTemplate: TemplateRef<void>;
    linkTitle: ElementRef<HTMLAnchorElement>;
    constructor(elementRef: ElementRef, anchorComp: DwAnchorComponent, platform: Platform, renderer: Renderer2);
    ngOnInit(): void;
    getLinkTitleElement(): HTMLAnchorElement;
    setActive(): void;
    unsetActive(): void;
    goToClick(e: Event): void;
    ngOnDestroy(): void;
}
