/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { ChangeDetectorRef, EventEmitter, NgZone, OnChanges, OnDestroy, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwScrollService } from 'ng-quicksilver/core/services';
import { NumberInput, DwSafeAny } from 'ng-quicksilver/core/types';
export declare class DwBackTopComponent implements OnInit, OnDestroy, OnChanges {
    private doc;
    dwConfigService: DwConfigService;
    private scrollSrv;
    private platform;
    private cd;
    private zone;
    static ngAcceptInputType_dwVisibilityHeight: NumberInput;
    private scrollListenerDestroy$;
    private target;
    visible: boolean;
    dwTemplate?: TemplateRef<void>;
    dwVisibilityHeight: number;
    dwTarget?: string | HTMLElement;
    readonly dwClick: EventEmitter<boolean>;
    constructor(doc: DwSafeAny, dwConfigService: DwConfigService, scrollSrv: DwScrollService, platform: Platform, cd: ChangeDetectorRef, zone: NgZone);
    ngOnInit(): void;
    clickBackTop(): void;
    private getTarget;
    private handleScroll;
    private registerScrollEvent;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
