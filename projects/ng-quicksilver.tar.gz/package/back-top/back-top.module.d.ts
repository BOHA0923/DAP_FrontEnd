export declare class DwBackTopModule {
}
