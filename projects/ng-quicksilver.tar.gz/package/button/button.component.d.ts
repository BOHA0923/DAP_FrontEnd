/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, ElementRef, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput } from 'ng-quicksilver/core/types';
export declare type DwButtonType = 'primary' | 'default' | 'dashed' | 'danger' | 'link' | null;
export declare type DwButtonShape = 'circle' | 'round' | null;
export declare type DwButtonSize = 'large' | 'default' | 'small';
export declare class DwButtonComponent implements OnDestroy, OnChanges, AfterViewInit, AfterContentInit {
    private elementRef;
    private cdr;
    private renderer;
    dwConfigService: DwConfigService;
    static ngAcceptInputType_dwBlock: BooleanInput;
    static ngAcceptInputType_dwGhost: BooleanInput;
    static ngAcceptInputType_dwSearch: BooleanInput;
    static ngAcceptInputType_dwLoading: BooleanInput;
    static ngAcceptInputType_dwDanger: BooleanInput;
    static ngAcceptInputType_disabled: BooleanInput;
    dwIconDirectiveElement: ElementRef;
    dwBlock: boolean;
    dwGhost: boolean;
    dwSearch: boolean;
    dwLoading: boolean;
    dwDanger: boolean;
    disabled: boolean;
    tabIndex: number | string | null;
    dwType: DwButtonType;
    dwShape: DwButtonShape;
    dwSize: DwButtonSize;
    private destroy$;
    private loading$;
    haltDisabledEvents(event: Event): void;
    insertSpan(nodes: NodeList, renderer: Renderer2): void;
    assertIconOnly(element: HTMLButtonElement, renderer: Renderer2): void;
    constructor(elementRef: ElementRef, cdr: ChangeDetectorRef, renderer: Renderer2, dwConfigService: DwConfigService);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
}
