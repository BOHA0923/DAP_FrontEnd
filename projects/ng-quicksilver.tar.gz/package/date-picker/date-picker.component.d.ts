/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { DwNoAnimationDirective } from 'ng-quicksilver/core/no-animation';
import { CompatibleValue } from 'ng-quicksilver/core/time';
import { BooleanInput, DwSafeAny, FunctionProp, OnChangeType, OnTouchedType } from 'ng-quicksilver/core/types';
import { DateHelperService, DwDatePickerI18nInterface, DwI18nService } from 'ng-quicksilver/i18n';
import { Subject } from 'rxjs';
import { DatePickerService } from './date-picker.service';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwPickerComponent } from './picker.component';
import { CompatibleDate, DisabledTimeFn, DwDateMode, PresetRanges, SupportTimeOptions } from './standard-types';
/**
 * The base picker for all common APIs
 */
export declare class DwDatePickerComponent implements OnInit, OnChanges, OnDestroy, ControlValueAccessor {
    dwConfigService: DwConfigService;
    datePickerService: DatePickerService;
    protected i18n: DwI18nService;
    protected cdr: ChangeDetectorRef;
    private renderer;
    private elementRef;
    protected dateHelper: DateHelperService;
    noAnimation?: DwNoAnimationDirective | undefined;
    static ngAcceptInputType_dwAllowClear: BooleanInput;
    static ngAcceptInputType_dwAutoFocus: BooleanInput;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    static ngAcceptInputType_dwInputReadOnly: BooleanInput;
    static ngAcceptInputType_dwOpen: BooleanInput;
    static ngAcceptInputType_dwShowToday: BooleanInput;
    static ngAcceptInputType_dwMode: DwDateMode | DwDateMode[] | string | string[] | null | undefined;
    static ngAcceptInputType_dwShowTime: BooleanInput | SupportTimeOptions | null | undefined;
    isRange: boolean;
    showWeek: boolean;
    focused: boolean;
    extraFooter?: TemplateRef<DwSafeAny> | string;
    protected destroyed$: Subject<void>;
    protected isCustomPlaceHolder: boolean;
    private showTime;
    dwAllowClear: boolean;
    dwAutoFocus: boolean;
    dwDisabled: boolean;
    dwInputReadOnly: boolean;
    dwOpen?: boolean;
    /**
     * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
     */
    dwClassName: string;
    dwDisabledDate?: (d: Date) => boolean;
    dwLocale: DwDatePickerI18nInterface;
    dwPlaceHolder: string | [string, string];
    dwPopupStyle: object;
    dwDropdownClassName?: string;
    dwSize: 'large' | 'small' | 'default';
    /**
     * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
     */
    dwStyle: object | null;
    dwFormat: string;
    dwDateRender?: TemplateRef<DwSafeAny> | string | FunctionProp<TemplateRef<Date> | string>;
    dwDisabledTime?: DisabledTimeFn;
    dwRenderExtraFooter?: TemplateRef<DwSafeAny> | string | FunctionProp<TemplateRef<DwSafeAny> | string>;
    dwShowToday: boolean;
    dwMode: DwDateMode | DwDateMode[];
    dwRanges?: PresetRanges;
    dwDefaultPickerValue: CompatibleDate | null;
    dwSeparator?: string;
    dwSuffixIcon: string | TemplateRef<DwSafeAny>;
    readonly dwOnPanelChange: EventEmitter<string | string[] | DwDateMode[]>;
    readonly dwOnCalendarChange: EventEmitter<(Date | null)[]>;
    readonly dwOnOk: EventEmitter<Date | Date[] | null>;
    readonly dwOnOpenChange: EventEmitter<boolean>;
    picker: DwPickerComponent;
    get dwShowTime(): SupportTimeOptions | boolean;
    set dwShowTime(value: SupportTimeOptions | boolean);
    get realOpenState(): boolean;
    constructor(dwConfigService: DwConfigService, datePickerService: DatePickerService, i18n: DwI18nService, cdr: ChangeDetectorRef, renderer: Renderer2, elementRef: ElementRef, dateHelper: DateHelperService, noAnimation?: DwNoAnimationDirective | undefined);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    setPanelMode(): void;
    /**
     * Triggered when overlayOpen changes (different with realOpenState)
     * @param open The overlayOpen in picker component
     */
    onOpenChange(open: boolean): void;
    onChangeFn: OnChangeType;
    onTouchedFn: OnTouchedType;
    writeValue(value: CompatibleDate): void;
    registerOnChange(fn: OnChangeType): void;
    registerOnTouched(fn: OnTouchedType): void;
    setDisabledState(isDisabled: boolean): void;
    private setLocale;
    private setDefaultPlaceHolder;
    private setValue;
    get realShowToday(): boolean;
    onFocusChange(value: boolean): void;
    onPanelModeChange(panelMode: DwDateMode | DwDateMode[]): void;
    onCalendarChange(value: CompatibleValue): void;
    onResultOk(): void;
}
