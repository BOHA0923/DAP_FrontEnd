/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { CandyDate } from 'ng-quicksilver/core/time';
import { FunctionProp } from 'ng-quicksilver/core/types';
import { DwCalendarI18nInterface } from 'ng-quicksilver/i18n';
import { DisabledDateFn, DwDateMode, RangePartType, SupportTimeOptions } from './standard-types';
export declare class InnerPopupComponent implements OnChanges {
    activeDate: CandyDate;
    endPanelMode: DwDateMode;
    panelMode: DwDateMode;
    showWeek: boolean;
    locale: DwCalendarI18nInterface;
    showTimePicker: boolean;
    timeOptions: SupportTimeOptions | null;
    disabledDate?: DisabledDateFn;
    dateRender?: string | TemplateRef<Date> | FunctionProp<TemplateRef<Date> | string>;
    selectedValue: CandyDate[];
    hoverValue: CandyDate[];
    value: CandyDate;
    partType: RangePartType;
    readonly panelModeChange: EventEmitter<DwDateMode>;
    readonly headerChange: EventEmitter<CandyDate>;
    readonly selectDate: EventEmitter<CandyDate>;
    readonly selectTime: EventEmitter<CandyDate>;
    readonly dayHover: EventEmitter<CandyDate>;
    prefixCls: string;
    /**
     * Hide "next" arrow in left panel,
     * hide "prev" arrow in right panel
     * @param direction
     * @param panelMode
     */
    enablePrevNext(direction: 'prev' | 'next', panelMode: DwDateMode): boolean;
    onSelectTime(date: Date): void;
    onSelectDate(date: CandyDate | Date): void;
    onChooseMonth(value: CandyDate): void;
    onChooseYear(value: CandyDate): void;
    onChooseDecade(value: CandyDate): void;
    ngOnChanges(changes: SimpleChanges): void;
}
