/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { CandyDate, CompatibleValue, SingleValue } from 'ng-quicksilver/core/time';
import { FunctionProp } from 'ng-quicksilver/core/types';
import { DwCalendarI18nInterface } from 'ng-quicksilver/i18n';
import { Subject } from 'rxjs';
import { DatePickerService } from './date-picker.service';
import { CompatibleDate, DisabledDateFn, DisabledTimeFn, DwDateMode, PresetRanges, RangePartType, SupportTimeOptions } from './standard-types';
export declare class DateRangePopupComponent implements OnInit, OnChanges, OnDestroy {
    datePickerService: DatePickerService;
    cdr: ChangeDetectorRef;
    isRange: boolean;
    showWeek: boolean;
    locale: DwCalendarI18nInterface | undefined;
    format: string;
    placeholder: string | string[];
    disabledDate?: DisabledDateFn;
    disabledTime?: DisabledTimeFn;
    showToday: boolean;
    showTime: SupportTimeOptions | boolean;
    extraFooter?: TemplateRef<void> | string;
    ranges?: PresetRanges;
    dateRender?: string | TemplateRef<Date> | FunctionProp<TemplateRef<Date> | string>;
    panelMode: DwDateMode | DwDateMode[];
    defaultPickerValue: CompatibleDate | undefined | null;
    readonly panelModeChange: EventEmitter<"decade" | "year" | "month" | "week" | "date" | "time" | DwDateMode[]>;
    readonly calendarChange: EventEmitter<CompatibleValue>;
    readonly resultOk: EventEmitter<void>;
    prefixCls: string;
    endPanelMode: DwDateMode | DwDateMode[];
    timeOptions: SupportTimeOptions | SupportTimeOptions[] | null;
    hoverValue: SingleValue[];
    destroy$: Subject<unknown>;
    get hasTimePicker(): boolean;
    get hasFooter(): boolean;
    constructor(datePickerService: DatePickerService, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    initActiveDate(): void;
    onClickOk(): void;
    onClickToday(value: CandyDate): void;
    onDayHover(value: CandyDate): void;
    onPanelModeChange(mode: DwDateMode, partType?: RangePartType): void;
    onActiveDateChange(value: CandyDate, partType: RangePartType): void;
    onSelectTime(value: CandyDate, partType?: RangePartType): void;
    changeValueFromSelect(value: CandyDate, emitValue?: boolean): void;
    getPanelMode(panelMode: DwDateMode | DwDateMode[], partType?: RangePartType): DwDateMode;
    getValue(partType?: RangePartType): CandyDate;
    getActiveDate(partType?: RangePartType): CandyDate;
    disabledStartTime: DisabledTimeFn;
    disabledEndTime: DisabledTimeFn;
    isOneAllowed(selectedValue: SingleValue[]): boolean;
    isBothAllowed(selectedValue: SingleValue[]): boolean;
    isAllowed(value: CompatibleValue, isBoth?: boolean): boolean;
    getTimeOptions(partType?: RangePartType): SupportTimeOptions | null;
    onClickPresetRange(val: PresetRanges[keyof PresetRanges]): void;
    onPresetRangeMouseLeave(): void;
    onHoverPresetRange(val: PresetRanges[keyof PresetRanges]): void;
    getObjectKeys(obj?: PresetRanges): string[];
    show(partType: RangePartType): boolean;
    private clearHoverValue;
    private buildTimeOptions;
    private overrideTimeOptions;
    private overrideHms;
}
