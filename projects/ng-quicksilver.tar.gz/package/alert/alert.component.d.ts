/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput } from 'ng-quicksilver/core/types';
export declare class DwAlertComponent implements OnChanges, OnDestroy {
    dwConfigService: DwConfigService;
    private cdr;
    static ngAcceptInputType_dwCloseable: BooleanInput;
    static ngAcceptInputType_dwShowIcon: BooleanInput;
    static ngAcceptInputType_dwBanner: BooleanInput;
    static ngAcceptInputType_dwNoAnimation: BooleanInput;
    dwCloseText: string | TemplateRef<void> | null;
    dwIconType: string | null;
    dwMessage: string | TemplateRef<void> | null;
    dwDescription: string | TemplateRef<void> | null;
    dwType: 'success' | 'info' | 'warning' | 'error';
    dwCloseable: boolean;
    dwShowIcon: boolean;
    dwBanner: boolean;
    dwNoAnimation: boolean;
    readonly dwOnClose: EventEmitter<boolean>;
    closed: boolean;
    iconTheme: 'outline' | 'fill';
    inferredIconType: string;
    private isTypeSet;
    private isShowIconSet;
    private destroy$;
    constructor(dwConfigService: DwConfigService, cdr: ChangeDetectorRef);
    closeAlert(): void;
    onFadeAnimationDone(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
}
