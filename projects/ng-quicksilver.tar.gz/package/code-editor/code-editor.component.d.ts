/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnDestroy, TemplateRef } from '@angular/core';
import { editor } from 'monaco-editor';
import { BooleanInput, DwSafeAny, OnChangeType, OnTouchedType } from 'ng-quicksilver/core/types';
import { DwCodeEditorService } from './code-editor.service';
import { JoinedEditorOptions, DwEditorMode } from './typings';
export declare class DwCodeEditorComponent implements OnDestroy, AfterViewInit {
    private dwCodeEditorService;
    private ngZone;
    static ngAcceptInputType_dwLoading: BooleanInput;
    static ngAcceptInputType_dwFullControl: BooleanInput;
    dwEditorMode: DwEditorMode;
    dwOriginalText: string;
    dwLoading: boolean;
    dwFullControl: boolean;
    dwToolkit?: TemplateRef<void>;
    set dwEditorOption(value: JoinedEditorOptions);
    readonly dwEditorInitialized: EventEmitter<editor.IStandaloneCodeEditor | editor.IStandaloneDiffEditor>;
    editorOptionCached: JoinedEditorOptions;
    private readonly el;
    private destroy$;
    private resize$;
    private editorOption$;
    private editorInstance?;
    private value;
    private modelSet;
    constructor(dwCodeEditorService: DwCodeEditorService, ngZone: NgZone, elementRef: ElementRef);
    /**
     * Initialize a monaco editor instance.
     */
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    writeValue(value: string): void;
    registerOnChange(fn: OnChangeType): DwSafeAny;
    registerOnTouched(fn: OnTouchedType): void;
    onChange: OnChangeType;
    onTouch: OnTouchedType;
    layout(): void;
    private setup;
    private registerOptionChanges;
    private initMonacoEditorInstance;
    private registerResizeChange;
    private setValue;
    private setValueEmitter;
    private emitValue;
    private updateOptionToMonaco;
}
