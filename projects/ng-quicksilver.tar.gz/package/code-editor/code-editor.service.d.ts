/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwSafeAny } from 'ng-quicksilver/core/types';
import { BehaviorSubject, Observable } from 'rxjs';
import { DwCodeEditorConfig, JoinedEditorOptions } from './typings';
export declare class DwCodeEditorService {
    private readonly dwConfigService;
    private document;
    private firstEditorInitialized;
    private loaded$;
    private loadingStatus;
    private option;
    private config;
    option$: BehaviorSubject<JoinedEditorOptions>;
    constructor(dwConfigService: DwConfigService, _document: DwSafeAny, config?: DwCodeEditorConfig);
    updateDefaultOption(option: JoinedEditorOptions): void;
    private _updateDefaultOption;
    requestToInit(): Observable<JoinedEditorOptions>;
    private loadMonacoScript;
    private onLoad;
    private onInit;
    private getLatestOption;
}
