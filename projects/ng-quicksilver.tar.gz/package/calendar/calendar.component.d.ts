/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, EventEmitter, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { CandyDate } from 'ng-quicksilver/core/time';
import { BooleanInput } from 'ng-quicksilver/core/types';
export declare type DwCalendarMode = 'month' | 'year';
declare type DwCalendarDateTemplate = TemplateRef<{
    $implicit: Date;
}>;
export declare class DwCalendarComponent implements ControlValueAccessor, OnChanges {
    private cdr;
    static ngAcceptInputType_dwFullscreen: BooleanInput;
    activeDate: CandyDate;
    prefixCls: string;
    private onChangeFn;
    private onTouchFn;
    dwMode: DwCalendarMode;
    dwValue?: Date;
    dwDisabledDate?: (date: Date) => boolean;
    readonly dwModeChange: EventEmitter<DwCalendarMode>;
    readonly dwPanelChange: EventEmitter<{
        date: Date;
        mode: DwCalendarMode;
    }>;
    readonly dwSelectChange: EventEmitter<Date>;
    readonly dwValueChange: EventEmitter<Date>;
    /**
     * Cannot use @Input and @ContentChild on one variable
     * because { static: false } will make @Input property get delayed
     **/
    dwDateCell?: DwCalendarDateTemplate;
    dwDateCellChild?: DwCalendarDateTemplate;
    get dateCell(): DwCalendarDateTemplate;
    dwDateFullCell?: DwCalendarDateTemplate;
    dwDateFullCellChild?: DwCalendarDateTemplate;
    get dateFullCell(): DwCalendarDateTemplate;
    dwMonthCell?: DwCalendarDateTemplate;
    dwMonthCellChild?: DwCalendarDateTemplate;
    get monthCell(): DwCalendarDateTemplate;
    dwMonthFullCell?: DwCalendarDateTemplate;
    dwMonthFullCellChild?: DwCalendarDateTemplate;
    get monthFullCell(): DwCalendarDateTemplate;
    dwFullscreen: boolean;
    constructor(cdr: ChangeDetectorRef);
    onModeChange(mode: DwCalendarMode): void;
    onYearSelect(year: number): void;
    onMonthSelect(month: number): void;
    onDateSelect(date: CandyDate): void;
    writeValue(value: Date | null): void;
    registerOnChange(fn: (date: Date) => void): void;
    registerOnTouched(fn: () => void): void;
    private updateDate;
    ngOnChanges(changes: SimpleChanges): void;
}
export {};
