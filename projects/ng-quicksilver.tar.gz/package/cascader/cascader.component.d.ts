/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { CdkConnectedOverlay, ConnectionPositionPair } from '@angular/cdk/overlay';
import { ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, OnInit, QueryList, Renderer2, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { DwNoAnimationDirective } from 'ng-quicksilver/core/no-animation';
import { BooleanInput, NgClassType, NgStyleInterface, DwSafeAny } from 'ng-quicksilver/core/types';
import { DwCascaderI18nInterface, DwI18nService } from 'ng-quicksilver/i18n';
import { DwCascaderOptionComponent } from './cascader-li.component';
import { DwCascaderService } from './cascader.service';
import { DwCascaderComponentAsSource, DwCascaderExpandTrigger, DwCascaderOption, DwCascaderSize, DwCascaderTriggerType, DwShowSearchOptions } from './typings';
export declare class DwCascaderComponent implements DwCascaderComponentAsSource, OnInit, OnDestroy, ControlValueAccessor {
    cascaderService: DwCascaderService;
    private i18nService;
    dwConfigService: DwConfigService;
    private cdr;
    noAnimation?: DwNoAnimationDirective | undefined;
    static ngAcceptInputType_dwShowInput: BooleanInput;
    static ngAcceptInputType_dwShowArrow: BooleanInput;
    static ngAcceptInputType_dwAllowClear: BooleanInput;
    static ngAcceptInputType_dwAutoFocus: BooleanInput;
    static ngAcceptInputType_dwChangeOnSelect: BooleanInput;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    input: ElementRef;
    menu: ElementRef;
    overlay: CdkConnectedOverlay;
    cascaderItems: QueryList<DwCascaderOptionComponent>;
    dwOptionRender: TemplateRef<{
        $implicit: DwCascaderOption;
        index: number;
    }> | null;
    dwShowInput: boolean;
    dwShowArrow: boolean;
    dwAllowClear: boolean;
    dwAutoFocus: boolean;
    dwChangeOnSelect: boolean;
    dwDisabled: boolean;
    dwColumnClassName?: string;
    dwExpandTrigger: DwCascaderExpandTrigger;
    dwValueProperty: string;
    dwLabelRender: TemplateRef<void> | null;
    dwLabelProperty: string;
    dwNotFoundContent?: string | TemplateRef<void>;
    dwSize: DwCascaderSize;
    dwShowSearch: boolean | DwShowSearchOptions;
    dwPlaceHolder: string;
    dwMenuClassName?: string;
    dwMenuStyle: NgStyleInterface | null;
    dwMouseEnterDelay: number;
    dwMouseLeaveDelay: number;
    dwTriggerAction: DwCascaderTriggerType | DwCascaderTriggerType[];
    dwChangeOn?: (option: DwCascaderOption, level: number) => boolean;
    dwLoadData?: (node: DwCascaderOption, index: number) => PromiseLike<DwSafeAny>;
    get dwOptions(): DwCascaderOption[] | null;
    set dwOptions(options: DwCascaderOption[] | null);
    readonly dwVisibleChange: EventEmitter<boolean>;
    readonly dwSelectionChange: EventEmitter<import("./typings").CascaderOption[]>;
    readonly dwSelect: EventEmitter<{
        option: import("./typings").CascaderOption;
        index: number;
    } | null>;
    readonly dwClear: EventEmitter<void>;
    /**
     * If the dropdown should show the empty content.
     * `true` if there's no options.
     */
    shouldShowEmpty: boolean;
    el: HTMLElement;
    menuVisible: boolean;
    isLoading: boolean;
    labelRenderText?: string;
    labelRenderContext: {};
    onChange: Function;
    onTouched: Function;
    positions: ConnectionPositionPair[];
    /**
     * Dropdown's with in pixel.
     */
    dropdownWidthStyle?: string;
    dropdownHeightStyle: 'auto' | '';
    isFocused: boolean;
    locale: DwCascaderI18nInterface;
    private destroy$;
    private inputString;
    private isOpening;
    private delayMenuTimer;
    private delaySelectTimer;
    get inSearchingMode(): boolean;
    set inputValue(inputValue: string);
    get inputValue(): string;
    get menuCls(): NgClassType;
    get menuColumnCls(): NgClassType;
    private get hasInput();
    private get hasValue();
    get showPlaceholder(): boolean;
    get clearIconVisible(): boolean;
    get isLabelRenderTemplate(): boolean;
    constructor(cascaderService: DwCascaderService, i18nService: DwI18nService, dwConfigService: DwConfigService, cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2, noAnimation?: DwNoAnimationDirective | undefined);
    ngOnInit(): void;
    ngOnDestroy(): void;
    registerOnChange(fn: () => {}): void;
    registerOnTouched(fn: () => {}): void;
    writeValue(value: DwSafeAny): void;
    delaySetMenuVisible(visible: boolean, delay?: number, setOpening?: boolean): void;
    setMenuVisible(visible: boolean): void;
    private clearDelayMenuTimer;
    clearSelection(event?: Event): void;
    getSubmitValue(): DwSafeAny[];
    focus(): void;
    blur(): void;
    handleInputBlur(): void;
    handleInputFocus(): void;
    onKeyDown(event: KeyboardEvent): void;
    onTriggerClick(): void;
    onTriggerMouseEnter(): void;
    onTriggerMouseLeave(event: MouseEvent): void;
    onOptionMouseEnter(option: DwCascaderOption, columnIndex: number, event: Event): void;
    onOptionMouseLeave(option: DwCascaderOption, _columnIndex: number, event: Event): void;
    onOptionClick(option: DwCascaderOption, columnIndex: number, event: Event): void;
    private isActionTrigger;
    private onEnter;
    private moveUpOrDown;
    private moveLeft;
    private moveRight;
    private clearDelaySelectTimer;
    private delaySetOptionActivated;
    private toggleSearchingMode;
    isOptionActivated(option: DwCascaderOption, index: number): boolean;
    setDisabledState(isDisabled: boolean): void;
    closeMenu(): void;
    /**
     * Reposition the cascader panel. When a menu opens, the cascader expands
     * and may exceed the boundary of browser's window.
     */
    private reposition;
    /**
     * When a cascader options is changed, a child needs to know that it should re-render.
     */
    private checkChildren;
    private setDisplayLabel;
    private setDropdownStyles;
    private setLocale;
}
