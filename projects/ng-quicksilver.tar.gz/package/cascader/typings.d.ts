/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwSafeAny } from 'ng-quicksilver/core/types';
export declare type DwCascaderExpandTrigger = 'click' | 'hover';
export declare type DwCascaderTriggerType = 'click' | 'hover';
export declare type DwCascaderSize = 'small' | 'large' | 'default';
export declare type DwCascaderFilter = (searchValue: string, path: DwCascaderOption[]) => boolean;
export declare type DwCascaderSorter = (a: DwCascaderOption[], b: DwCascaderOption[], inputValue: string) => number;
/**
 * @deprecated Use the prefixed version.
 */
export interface CascaderOption {
    value?: DwSafeAny;
    label?: string;
    title?: string;
    disabled?: boolean;
    loading?: boolean;
    isLeaf?: boolean;
    parent?: DwCascaderOption;
    children?: DwCascaderOption[];
    [key: string]: DwSafeAny;
}
export declare type DwCascaderOption = CascaderOption;
/**
 * @deprecated Use the prefixed version.
 */
export interface CascaderSearchOption extends DwCascaderOption {
    path: DwCascaderOption[];
}
export declare type DwCascaderSearchOption = CascaderSearchOption;
export interface DwShowSearchOptions {
    filter?: DwCascaderFilter;
    sorter?: DwCascaderSorter;
}
export declare function isShowSearchObject(options: DwShowSearchOptions | boolean): options is DwShowSearchOptions;
/**
 * To avoid circular dependency, provide an interface of `DwCascaderComponent`
 * for `DwCascaderService`.
 */
export interface DwCascaderComponentAsSource {
    inputValue: string;
    dwShowSearch: DwShowSearchOptions | boolean;
    dwLabelProperty: string;
    dwValueProperty: string;
    dwChangeOnSelect: boolean;
    dwChangeOn?(option: DwCascaderOption, level: number): boolean;
    dwLoadData?(node: DwCascaderOption, index: number): PromiseLike<DwSafeAny>;
}
