/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, ElementRef, Renderer2, TemplateRef } from '@angular/core';
import { DwCascaderOption } from './typings';
export declare class DwCascaderOptionComponent {
    private cdr;
    optionTemplate: TemplateRef<DwCascaderOption> | null;
    option: DwCascaderOption;
    activated: boolean;
    highlightText: string;
    dwLabelProperty: string;
    columnIndex: number;
    constructor(cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2);
    get optionLabel(): string;
    markForCheck(): void;
}
