/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, EventEmitter, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput } from 'ng-quicksilver/core/types';
import { DwCollapseComponent } from './collapse.component';
export declare class DwCollapsePanelComponent implements OnInit, OnDestroy {
    dwConfigService: DwConfigService;
    private cdr;
    private dwCollapseComponent;
    static ngAcceptInputType_dwActive: BooleanInput;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    static ngAcceptInputType_dwShowArrow: BooleanInput;
    dwActive: boolean;
    dwDisabled: boolean;
    dwShowArrow: boolean;
    dwExtra?: string | TemplateRef<void>;
    dwHeader?: string | TemplateRef<void>;
    dwExpandedIcon?: string | TemplateRef<void>;
    readonly dwActiveChange: EventEmitter<boolean>;
    private destroy$;
    clickHeader(): void;
    markForCheck(): void;
    constructor(dwConfigService: DwConfigService, cdr: ChangeDetectorRef, dwCollapseComponent: DwCollapseComponent);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
