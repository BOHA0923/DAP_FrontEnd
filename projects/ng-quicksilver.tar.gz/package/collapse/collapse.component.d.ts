/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, OnDestroy } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { BooleanInput } from 'ng-quicksilver/core/types';
import { DwCollapsePanelComponent } from './collapse-panel.component';
export declare class DwCollapseComponent implements OnDestroy {
    dwConfigService: DwConfigService;
    private cdr;
    static ngAcceptInputType_dwAccordion: BooleanInput;
    static ngAcceptInputType_dwBordered: BooleanInput;
    dwAccordion: boolean;
    dwBordered: boolean;
    dwExpandIconPosition: 'left' | 'right';
    private listOfDwCollapsePanelComponent;
    private destroy$;
    constructor(dwConfigService: DwConfigService, cdr: ChangeDetectorRef);
    addPanel(value: DwCollapsePanelComponent): void;
    removePanel(value: DwCollapsePanelComponent): void;
    click(collapse: DwCollapsePanelComponent): void;
    ngOnDestroy(): void;
}
