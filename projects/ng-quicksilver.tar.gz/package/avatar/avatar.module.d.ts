export declare class DwAvatarModule {
}
