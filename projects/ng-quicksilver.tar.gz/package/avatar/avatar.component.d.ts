/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { ChangeDetectorRef, ElementRef, EventEmitter, OnChanges } from '@angular/core';
import { DwConfigService } from 'ng-quicksilver/core/config';
import { NgClassInterface, NgStyleInterface, DwShapeSCType, DwSizeLDSType } from 'ng-quicksilver/core/types';
export declare class DwAvatarComponent implements OnChanges {
    dwConfigService: DwConfigService;
    private elementRef;
    private cdr;
    private platform;
    dwShape: DwShapeSCType;
    dwSize: DwSizeLDSType | number;
    dwText?: string;
    dwSrc?: string;
    dwSrcSet?: string;
    dwAlt?: string;
    dwIcon?: string;
    readonly dwError: EventEmitter<Event>;
    hasText: boolean;
    hasSrc: boolean;
    hasIcon: boolean;
    textStyles: NgStyleInterface;
    classMap: NgClassInterface;
    customSize: string | null;
    textEl?: ElementRef;
    private el;
    constructor(dwConfigService: DwConfigService, elementRef: ElementRef, cdr: ChangeDetectorRef, platform: Platform);
    imgError($event: Event): void;
    ngOnChanges(): void;
    private calcStringSize;
    private notifyCalc;
    private setSizeStyle;
}
