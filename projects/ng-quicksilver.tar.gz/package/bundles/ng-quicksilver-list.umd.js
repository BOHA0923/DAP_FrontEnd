(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('ng-quicksilver/avatar'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/empty'), require('ng-quicksilver/grid'), require('ng-quicksilver/spin')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/list', ['exports', '@angular/core', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/common', 'ng-quicksilver/avatar', 'ng-quicksilver/core/outlet', 'ng-quicksilver/empty', 'ng-quicksilver/grid', 'ng-quicksilver/spin'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].list = {}), global.ng.core, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.common, global['ng-quicksilver'].avatar, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].empty, global['ng-quicksilver'].grid, global['ng-quicksilver'].spin));
}(this, (function (exports, core, util, rxjs, operators, common, avatar, outlet, empty, grid, spin) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: interface.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function DwListGrid() { }
    if (false) {
        /** @type {?|undefined} */
        DwListGrid.prototype.gutter;
        /** @type {?|undefined} */
        DwListGrid.prototype.span;
        /** @type {?|undefined} */
        DwListGrid.prototype.column;
        /** @type {?|undefined} */
        DwListGrid.prototype.xs;
        /** @type {?|undefined} */
        DwListGrid.prototype.sm;
        /** @type {?|undefined} */
        DwListGrid.prototype.md;
        /** @type {?|undefined} */
        DwListGrid.prototype.lg;
        /** @type {?|undefined} */
        DwListGrid.prototype.xl;
        /** @type {?|undefined} */
        DwListGrid.prototype.xxl;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list-item-meta-cell.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListItemMetaTitleComponent = /** @class */ (function () {
        function DwListItemMetaTitleComponent() {
        }
        DwListItemMetaTitleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-meta-title',
                        exportAs: 'dwListItemMetaTitle',
                        template: "\n    <h4 class=\"ant-list-item-meta-title\">\n      <ng-content></ng-content>\n    </h4>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        return DwListItemMetaTitleComponent;
    }());
    var DwListItemMetaDescriptionComponent = /** @class */ (function () {
        function DwListItemMetaDescriptionComponent() {
        }
        DwListItemMetaDescriptionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-meta-description',
                        exportAs: 'dwListItemMetaDescription',
                        template: "\n    <div class=\"ant-list-item-meta-description\">\n      <ng-content></ng-content>\n    </div>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        return DwListItemMetaDescriptionComponent;
    }());
    var DwListItemMetaAvatarComponent = /** @class */ (function () {
        function DwListItemMetaAvatarComponent() {
        }
        DwListItemMetaAvatarComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-meta-avatar',
                        exportAs: 'dwListItemMetaAvatar',
                        template: "\n    <div class=\"ant-list-item-meta-avatar\">\n      <dw-avatar *ngIf=\"dwSrc\" [dwSrc]=\"dwSrc\"></dw-avatar>\n      <ng-content *ngIf=\"!dwSrc\"></ng-content>\n    </div>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        DwListItemMetaAvatarComponent.propDecorators = {
            dwSrc: [{ type: core.Input }]
        };
        return DwListItemMetaAvatarComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListItemMetaAvatarComponent.prototype.dwSrc;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list-item-meta.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListItemMetaComponent = /** @class */ (function () {
        function DwListItemMetaComponent(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.avatarStr = '';
            this.renderer.addClass(elementRef.nativeElement, 'ant-list-item-meta');
        }
        Object.defineProperty(DwListItemMetaComponent.prototype, "dwAvatar", {
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (value instanceof core.TemplateRef) {
                    this.avatarStr = '';
                    this.avatarTpl = value;
                }
                else {
                    this.avatarStr = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        DwListItemMetaComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-meta, [dw-list-item-meta]',
                        exportAs: 'dwListItemMeta',
                        template: "\n    <!--Old API Start-->\n    <dw-list-item-meta-avatar *ngIf=\"avatarStr\" [dwSrc]=\"avatarStr\"></dw-list-item-meta-avatar>\n    <dw-list-item-meta-avatar *ngIf=\"avatarTpl\">\n      <ng-container [ngTemplateOutlet]=\"avatarTpl\"></ng-container>\n    </dw-list-item-meta-avatar>\n    <!--Old API End-->\n\n    <ng-content select=\"dw-list-item-meta-avatar\"></ng-content>\n\n    <div *ngIf=\"dwTitle || dwDescription || descriptionComponent || titleComponent\" class=\"ant-list-item-meta-content\">\n      <!--Old API Start-->\n      <dw-list-item-meta-title *ngIf=\"dwTitle && !titleComponent\">\n        <ng-container *dwStringTemplateOutlet=\"dwTitle\">{{ dwTitle }}</ng-container>\n      </dw-list-item-meta-title>\n      <dw-list-item-meta-description *ngIf=\"dwDescription && !descriptionComponent\">\n        <ng-container *dwStringTemplateOutlet=\"dwDescription\">{{ dwDescription }}</ng-container>\n      </dw-list-item-meta-description>\n      <!--Old API End-->\n\n      <ng-content select=\"dw-list-item-meta-title\"></ng-content>\n      <ng-content select=\"dw-list-item-meta-description\"></ng-content>\n    </div>\n  ",
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None
                    }] }
        ];
        /** @nocollapse */
        DwListItemMetaComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        DwListItemMetaComponent.propDecorators = {
            dwAvatar: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            dwDescription: [{ type: core.Input }],
            descriptionComponent: [{ type: core.ContentChild, args: [DwListItemMetaDescriptionComponent,] }],
            titleComponent: [{ type: core.ContentChild, args: [DwListItemMetaTitleComponent,] }]
        };
        return DwListItemMetaComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListItemMetaComponent.prototype.avatarStr;
        /** @type {?} */
        DwListItemMetaComponent.prototype.avatarTpl;
        /** @type {?} */
        DwListItemMetaComponent.prototype.dwTitle;
        /** @type {?} */
        DwListItemMetaComponent.prototype.dwDescription;
        /** @type {?} */
        DwListItemMetaComponent.prototype.descriptionComponent;
        /** @type {?} */
        DwListItemMetaComponent.prototype.titleComponent;
        /** @type {?} */
        DwListItemMetaComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwListItemMetaComponent.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list-item-cell.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListItemExtraComponent = /** @class */ (function () {
        function DwListItemExtraComponent() {
        }
        DwListItemExtraComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-extra, [dw-list-item-extra]',
                        exportAs: 'dwListItemExtra',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-content></ng-content> ",
                        host: {
                            class: 'ant-list-item-extra'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwListItemExtraComponent.ctorParameters = function () { return []; };
        return DwListItemExtraComponent;
    }());
    var DwListItemActionComponent = /** @class */ (function () {
        function DwListItemActionComponent() {
        }
        DwListItemActionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item-action',
                        exportAs: 'dwListItemAction',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-template><ng-content></ng-content></ng-template> "
                    }] }
        ];
        /** @nocollapse */
        DwListItemActionComponent.ctorParameters = function () { return []; };
        DwListItemActionComponent.propDecorators = {
            templateRef: [{ type: core.ViewChild, args: [core.TemplateRef,] }]
        };
        return DwListItemActionComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListItemActionComponent.prototype.templateRef;
    }
    var DwListItemActionsComponent = /** @class */ (function () {
        function DwListItemActionsComponent(ngZone, cdr) {
            var _this = this;
            this.ngZone = ngZone;
            this.cdr = cdr;
            this.dwActions = [];
            this.actions = [];
            this.destroy$ = new rxjs.Subject();
            this.inputActionChanges$ = new rxjs.Subject();
            this.contentChildrenChanges$ = rxjs.defer((/**
             * @return {?}
             */
            function () {
                if (_this.dwListItemActions) {
                    return rxjs.of(null);
                }
                return _this.ngZone.onStable.asObservable().pipe(operators.take(1), operators.switchMap((/**
                 * @return {?}
                 */
                function () { return _this.contentChildrenChanges$; })));
            }));
            rxjs.merge(this.contentChildrenChanges$, this.inputActionChanges$)
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @return {?}
             */
            function () {
                if (_this.dwActions.length) {
                    _this.actions = _this.dwActions;
                }
                else {
                    _this.actions = _this.dwListItemActions.map((/**
                     * @param {?} action
                     * @return {?}
                     */
                    function (action) { return (/** @type {?} */ (action.templateRef)); }));
                }
                _this.cdr.detectChanges();
            }));
        }
        /**
         * @return {?}
         */
        DwListItemActionsComponent.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            this.inputActionChanges$.next(null);
        };
        /**
         * @return {?}
         */
        DwListItemActionsComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwListItemActionsComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'ul[dw-list-item-actions]',
                        exportAs: 'dwListItemActions',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <li *ngFor=\"let i of actions; let last = last\">\n      <ng-template [ngTemplateOutlet]=\"i\"></ng-template>\n      <em *ngIf=\"!last\" class=\"ant-list-item-action-split\"></em>\n    </li>\n  ",
                        host: {
                            class: 'ant-list-item-action'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwListItemActionsComponent.ctorParameters = function () { return [
            { type: core.NgZone },
            { type: core.ChangeDetectorRef }
        ]; };
        DwListItemActionsComponent.propDecorators = {
            dwActions: [{ type: core.Input }],
            dwListItemActions: [{ type: core.ContentChildren, args: [DwListItemActionComponent,] }]
        };
        return DwListItemActionsComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListItemActionsComponent.prototype.dwActions;
        /** @type {?} */
        DwListItemActionsComponent.prototype.dwListItemActions;
        /** @type {?} */
        DwListItemActionsComponent.prototype.actions;
        /**
         * @type {?}
         * @private
         */
        DwListItemActionsComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwListItemActionsComponent.prototype.inputActionChanges$;
        /**
         * @type {?}
         * @private
         */
        DwListItemActionsComponent.prototype.contentChildrenChanges$;
        /**
         * @type {?}
         * @private
         */
        DwListItemActionsComponent.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwListItemActionsComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list-cell.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListEmptyComponent = /** @class */ (function () {
        function DwListEmptyComponent() {
        }
        DwListEmptyComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-empty',
                        exportAs: 'dwListHeader',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <dw-embed-empty [dwComponentName]=\"'list'\" [specificContent]=\"dwNoResult\"></dw-embed-empty> ",
                        host: {
                            class: 'ant-list-empty-text'
                        }
                    }] }
        ];
        DwListEmptyComponent.propDecorators = {
            dwNoResult: [{ type: core.Input }]
        };
        return DwListEmptyComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListEmptyComponent.prototype.dwNoResult;
    }
    var DwListHeaderComponent = /** @class */ (function () {
        function DwListHeaderComponent() {
        }
        DwListHeaderComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-header',
                        exportAs: 'dwListHeader',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-content></ng-content> ",
                        host: {
                            class: 'ant-list-header'
                        }
                    }] }
        ];
        return DwListHeaderComponent;
    }());
    var DwListFooterComponent = /** @class */ (function () {
        function DwListFooterComponent() {
        }
        DwListFooterComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-footer',
                        exportAs: 'dwListFooter',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-content></ng-content> ",
                        host: {
                            class: 'ant-list-footer'
                        }
                    }] }
        ];
        return DwListFooterComponent;
    }());
    var DwListPaginationComponent = /** @class */ (function () {
        function DwListPaginationComponent() {
        }
        DwListPaginationComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-pagination',
                        exportAs: 'dwListPagination',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-content></ng-content> ",
                        host: {
                            class: 'ant-list-pagination'
                        }
                    }] }
        ];
        return DwListPaginationComponent;
    }());
    var DwListLoadMoreDirective = /** @class */ (function () {
        function DwListLoadMoreDirective() {
        }
        DwListLoadMoreDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-list-load-more',
                        exportAs: 'dwListLoadMoreDirective'
                    },] }
        ];
        return DwListLoadMoreDirective;
    }());
    var DwListGridDirective = /** @class */ (function () {
        function DwListGridDirective() {
        }
        DwListGridDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-list[dwGrid]',
                        host: {
                            class: 'ant-list-grid'
                        }
                    },] }
        ];
        return DwListGridDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: list.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListComponent = /** @class */ (function () {
        function DwListComponent() {
            this.dwBordered = false;
            this.dwGrid = '';
            this.dwItemLayout = 'horizontal';
            this.dwRenderItem = null;
            this.dwLoading = false;
            this.dwLoadMore = null;
            this.dwSize = 'default';
            this.dwSplit = true;
            this.hasSomethingAfterLastItem = false;
            this.itemLayoutNotifySource = new rxjs.BehaviorSubject(this.dwItemLayout);
        }
        Object.defineProperty(DwListComponent.prototype, "itemLayoutNotify$", {
            get: /**
             * @return {?}
             */
            function () {
                return this.itemLayoutNotifySource.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwListComponent.prototype.getSomethingAfterLastItem = /**
         * @return {?}
         */
        function () {
            return !!(this.dwLoadMore ||
                this.dwPagination ||
                this.dwFooter ||
                this.dwListFooterComponent ||
                this.dwListPaginationComponent ||
                this.dwListLoadMoreDirective);
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwListComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwItemLayout) {
                this.itemLayoutNotifySource.next(this.dwItemLayout);
            }
        };
        /**
         * @return {?}
         */
        DwListComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.itemLayoutNotifySource.unsubscribe();
        };
        /**
         * @return {?}
         */
        DwListComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            this.hasSomethingAfterLastItem = this.getSomethingAfterLastItem();
        };
        DwListComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list, [dw-list]',
                        exportAs: 'dwList',
                        template: "\n    <ng-template #itemsTpl>\n      <div class=\"ant-list-items\">\n        <ng-container *ngFor=\"let item of dwDataSource; let index = index\">\n          <ng-template [ngTemplateOutlet]=\"dwRenderItem\" [ngTemplateOutletContext]=\"{ $implicit: item, index: index }\"></ng-template>\n        </ng-container>\n        <ng-content select=\"dw-list-item, [dw-list-item]\"></ng-content>\n      </div>\n    </ng-template>\n\n    <dw-list-header *ngIf=\"dwHeader\">\n      <ng-container *dwStringTemplateOutlet=\"dwHeader\">{{ dwHeader }}</ng-container>\n    </dw-list-header>\n    <ng-content select=\"dw-list-header\"></ng-content>\n\n    <dw-spin [dwSpinning]=\"dwLoading\">\n      <ng-container>\n        <div *ngIf=\"dwLoading && dwDataSource && dwDataSource.length === 0\" [style.min-height.px]=\"53\"></div>\n        <div *ngIf=\"dwGrid && dwDataSource; else itemsTpl\" dw-row [dwGutter]=\"dwGrid.gutter || null\">\n          <div\n            dw-col\n            [dwSpan]=\"dwGrid.span || null\"\n            [dwXs]=\"dwGrid.xs || null\"\n            [dwSm]=\"dwGrid.sm || null\"\n            [dwMd]=\"dwGrid.md || null\"\n            [dwLg]=\"dwGrid.lg || null\"\n            [dwXl]=\"dwGrid.xl || null\"\n            [dwXXl]=\"dwGrid.xxl || null\"\n            *ngFor=\"let item of dwDataSource; let index = index\"\n          >\n            <ng-template [ngTemplateOutlet]=\"dwRenderItem\" [ngTemplateOutletContext]=\"{ $implicit: item, index: index }\"></ng-template>\n          </div>\n        </div>\n        <dw-list-empty *ngIf=\"!dwLoading && dwDataSource && dwDataSource.length === 0\" [dwNoResult]=\"dwNoResult\"></dw-list-empty>\n      </ng-container>\n      <ng-content></ng-content>\n    </dw-spin>\n\n    <dw-list-footer *ngIf=\"dwFooter\">\n      <ng-container *dwStringTemplateOutlet=\"dwFooter\">{{ dwFooter }}</ng-container>\n    </dw-list-footer>\n    <ng-content select=\"dw-list-footer, [dw-list-footer]\"></ng-content>\n\n    <ng-template [ngTemplateOutlet]=\"dwLoadMore\"></ng-template>\n    <ng-content select=\"dw-list-load-more, [dw-list-load-more]\"></ng-content>\n\n    <dw-list-pagination *ngIf=\"dwPagination\">\n      <ng-template [ngTemplateOutlet]=\"dwPagination\"></ng-template>\n    </dw-list-pagination>\n    <ng-content select=\"dw-list-pagination, [dw-list-pagination]\"></ng-content>\n  ",
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        host: {
                            '[class.ant-list]': 'true',
                            '[class.ant-list-vertical]': 'dwItemLayout === "vertical"',
                            '[class.ant-list-lg]': 'dwSize === "large"',
                            '[class.ant-list-sm]': 'dwSize === "small"',
                            '[class.ant-list-split]': 'dwSplit',
                            '[class.ant-list-bordered]': 'dwBordered',
                            '[class.ant-list-loading]': 'dwLoading',
                            '[class.ant-list-something-after-last-item]': 'hasSomethingAfterLastItem'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwListComponent.ctorParameters = function () { return []; };
        DwListComponent.propDecorators = {
            dwDataSource: [{ type: core.Input }],
            dwBordered: [{ type: core.Input }],
            dwGrid: [{ type: core.Input }],
            dwHeader: [{ type: core.Input }],
            dwFooter: [{ type: core.Input }],
            dwItemLayout: [{ type: core.Input }],
            dwRenderItem: [{ type: core.Input }],
            dwLoading: [{ type: core.Input }],
            dwLoadMore: [{ type: core.Input }],
            dwPagination: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwSplit: [{ type: core.Input }],
            dwNoResult: [{ type: core.Input }],
            dwListFooterComponent: [{ type: core.ContentChild, args: [DwListFooterComponent,] }],
            dwListPaginationComponent: [{ type: core.ContentChild, args: [DwListPaginationComponent,] }],
            dwListLoadMoreDirective: [{ type: core.ContentChild, args: [DwListLoadMoreDirective,] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwListComponent.prototype, "dwBordered", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwListComponent.prototype, "dwLoading", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwListComponent.prototype, "dwSplit", void 0);
        return DwListComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListComponent.ngAcceptInputType_dwBordered;
        /** @type {?} */
        DwListComponent.ngAcceptInputType_dwLoading;
        /** @type {?} */
        DwListComponent.ngAcceptInputType_dwSplit;
        /** @type {?} */
        DwListComponent.ngAcceptInputType_dwGrid;
        /** @type {?} */
        DwListComponent.prototype.dwDataSource;
        /** @type {?} */
        DwListComponent.prototype.dwBordered;
        /** @type {?} */
        DwListComponent.prototype.dwGrid;
        /** @type {?} */
        DwListComponent.prototype.dwHeader;
        /** @type {?} */
        DwListComponent.prototype.dwFooter;
        /** @type {?} */
        DwListComponent.prototype.dwItemLayout;
        /** @type {?} */
        DwListComponent.prototype.dwRenderItem;
        /** @type {?} */
        DwListComponent.prototype.dwLoading;
        /** @type {?} */
        DwListComponent.prototype.dwLoadMore;
        /** @type {?} */
        DwListComponent.prototype.dwPagination;
        /** @type {?} */
        DwListComponent.prototype.dwSize;
        /** @type {?} */
        DwListComponent.prototype.dwSplit;
        /** @type {?} */
        DwListComponent.prototype.dwNoResult;
        /** @type {?} */
        DwListComponent.prototype.dwListFooterComponent;
        /** @type {?} */
        DwListComponent.prototype.dwListPaginationComponent;
        /** @type {?} */
        DwListComponent.prototype.dwListLoadMoreDirective;
        /** @type {?} */
        DwListComponent.prototype.hasSomethingAfterLastItem;
        /**
         * @type {?}
         * @private
         */
        DwListComponent.prototype.itemLayoutNotifySource;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list-item.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwListItemComponent = /** @class */ (function () {
        function DwListItemComponent(elementRef, renderer, parentComp, cdr) {
            this.parentComp = parentComp;
            this.cdr = cdr;
            this.dwActions = [];
            this.dwExtra = null;
            this.dwNoFlex = false;
            renderer.addClass(elementRef.nativeElement, 'ant-list-item');
        }
        Object.defineProperty(DwListItemComponent.prototype, "isVerticalAndExtra", {
            get: /**
             * @return {?}
             */
            function () {
                return this.itemLayout === 'vertical' && (!!this.listItemExtraDirective || !!this.dwExtra);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwListItemComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.itemLayout$ = this.parentComp.itemLayoutNotify$.subscribe((/**
             * @param {?} val
             * @return {?}
             */
            function (val) {
                _this.itemLayout = val;
                _this.cdr.detectChanges();
            }));
        };
        /**
         * @return {?}
         */
        DwListItemComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            if (this.itemLayout$) {
                this.itemLayout$.unsubscribe();
            }
        };
        DwListItemComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-list-item, [dw-list-item]',
                        exportAs: 'dwListItem',
                        template: "\n    <ng-template #actionsTpl>\n      <ul dw-list-item-actions *ngIf=\"dwActions && dwActions.length > 0\" [dwActions]=\"dwActions\"></ul>\n      <ng-content select=\"dw-list-item-actions, [dw-list-item-actions]\"></ng-content>\n    </ng-template>\n    <ng-template #contentTpl>\n      <ng-content select=\"dw-list-item-meta, [dw-list-item-meta]\"></ng-content>\n      <ng-content></ng-content>\n      <ng-container *ngIf=\"dwContent\">\n        <ng-container *dwStringTemplateOutlet=\"dwContent\">{{ dwContent }}</ng-container>\n      </ng-container>\n    </ng-template>\n    <ng-template #extraTpl>\n      <ng-content select=\"dw-list-item-extra, [dw-list-item-extra]\"></ng-content>\n    </ng-template>\n    <ng-template #simpleTpl>\n      <ng-template [ngTemplateOutlet]=\"contentTpl\"></ng-template>\n      <ng-template [ngTemplateOutlet]=\"dwExtra\"></ng-template>\n      <ng-template [ngTemplateOutlet]=\"extraTpl\"></ng-template>\n      <ng-template [ngTemplateOutlet]=\"actionsTpl\"></ng-template>\n    </ng-template>\n\n    <ng-container *ngIf=\"isVerticalAndExtra; else simpleTpl\">\n      <div class=\"ant-list-item-main\">\n        <ng-template [ngTemplateOutlet]=\"contentTpl\"></ng-template>\n        <ng-template [ngTemplateOutlet]=\"actionsTpl\"></ng-template>\n      </div>\n      <dw-list-item-extra *ngIf=\"dwExtra\">\n        <ng-template [ngTemplateOutlet]=\"dwExtra\"></ng-template>\n      </dw-list-item-extra>\n      <ng-template [ngTemplateOutlet]=\"extraTpl\"></ng-template>\n    </ng-container>\n  ",
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwListItemComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: DwListComponent },
            { type: core.ChangeDetectorRef }
        ]; };
        DwListItemComponent.propDecorators = {
            dwActions: [{ type: core.Input }],
            dwContent: [{ type: core.Input }],
            dwExtra: [{ type: core.Input }],
            dwNoFlex: [{ type: core.Input }, { type: core.HostBinding, args: ['class.ant-list-item-no-flex',] }],
            listItemExtraDirective: [{ type: core.ContentChild, args: [DwListItemExtraComponent,] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwListItemComponent.prototype, "dwNoFlex", void 0);
        return DwListItemComponent;
    }());
    if (false) {
        /** @type {?} */
        DwListItemComponent.ngAcceptInputType_dwNoFlex;
        /** @type {?} */
        DwListItemComponent.prototype.dwActions;
        /** @type {?} */
        DwListItemComponent.prototype.dwContent;
        /** @type {?} */
        DwListItemComponent.prototype.dwExtra;
        /** @type {?} */
        DwListItemComponent.prototype.dwNoFlex;
        /** @type {?} */
        DwListItemComponent.prototype.listItemExtraDirective;
        /**
         * @type {?}
         * @private
         */
        DwListItemComponent.prototype.itemLayout;
        /**
         * @type {?}
         * @private
         */
        DwListItemComponent.prototype.itemLayout$;
        /**
         * @type {?}
         * @private
         */
        DwListItemComponent.prototype.parentComp;
        /**
         * @type {?}
         * @private
         */
        DwListItemComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: list.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DIRECTIVES = [
        DwListComponent,
        DwListHeaderComponent,
        DwListFooterComponent,
        DwListPaginationComponent,
        DwListEmptyComponent,
        DwListItemComponent,
        DwListItemMetaComponent,
        DwListItemMetaTitleComponent,
        DwListItemMetaDescriptionComponent,
        DwListItemMetaAvatarComponent,
        DwListItemActionsComponent,
        DwListItemActionComponent,
        DwListItemExtraComponent,
        DwListLoadMoreDirective,
        DwListGridDirective
    ];
    var DwListModule = /** @class */ (function () {
        function DwListModule() {
        }
        DwListModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, spin.DwSpinModule, grid.DwGridModule, avatar.DwAvatarModule, outlet.DwOutletModule, empty.DwEmptyModule],
                        declarations: [DIRECTIVES],
                        exports: [DIRECTIVES]
                    },] }
        ];
        return DwListModule;
    }());

    exports.DwListComponent = DwListComponent;
    exports.DwListEmptyComponent = DwListEmptyComponent;
    exports.DwListFooterComponent = DwListFooterComponent;
    exports.DwListGridDirective = DwListGridDirective;
    exports.DwListHeaderComponent = DwListHeaderComponent;
    exports.DwListItemActionComponent = DwListItemActionComponent;
    exports.DwListItemActionsComponent = DwListItemActionsComponent;
    exports.DwListItemComponent = DwListItemComponent;
    exports.DwListItemExtraComponent = DwListItemExtraComponent;
    exports.DwListItemMetaAvatarComponent = DwListItemMetaAvatarComponent;
    exports.DwListItemMetaComponent = DwListItemMetaComponent;
    exports.DwListItemMetaDescriptionComponent = DwListItemMetaDescriptionComponent;
    exports.DwListItemMetaTitleComponent = DwListItemMetaTitleComponent;
    exports.DwListLoadMoreDirective = DwListLoadMoreDirective;
    exports.DwListModule = DwListModule;
    exports.DwListPaginationComponent = DwListPaginationComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-list.umd.js.map
