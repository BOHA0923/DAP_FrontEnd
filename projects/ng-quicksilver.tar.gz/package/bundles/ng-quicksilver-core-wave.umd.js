(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/platform'), require('@angular/core'), require('@angular/platform-browser/animations')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/wave', ['exports', '@angular/cdk/platform', '@angular/core', '@angular/platform-browser/animations'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core.wave = {}), global.ng.cdk.platform, global.ng.core, global.ng.platformBrowser.animations));
}(this, (function (exports, platform, core, animations) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-wave-renderer.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwWaveRenderer = /** @class */ (function () {
        function DwWaveRenderer(triggerElement, ngZone, insertExtraNode) {
            var _this = this;
            this.triggerElement = triggerElement;
            this.ngZone = ngZone;
            this.insertExtraNode = insertExtraNode;
            this.waveTransitionDuration = 400;
            this.styleForPseudo = null;
            this.extraNode = null;
            this.lastTime = 0;
            this.platform = new platform.Platform();
            this.onClick = (/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                if (!_this.triggerElement ||
                    !_this.triggerElement.getAttribute ||
                    _this.triggerElement.getAttribute('disabled') ||
                    ((/** @type {?} */ (event.target))).tagName === 'INPUT' ||
                    _this.triggerElement.className.indexOf('disabled') >= 0) {
                    return;
                }
                _this.fadeOutWave();
            });
            this.clickHandler = this.onClick.bind(this);
            this.bindTriggerEvent();
        }
        Object.defineProperty(DwWaveRenderer.prototype, "waveAttributeName", {
            get: /**
             * @return {?}
             */
            function () {
                return this.insertExtraNode ? 'ant-click-animating' : 'ant-click-animating-without-extra-node';
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwWaveRenderer.prototype.bindTriggerEvent = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.platform.isBrowser) {
                this.ngZone.runOutsideAngular((/**
                 * @return {?}
                 */
                function () {
                    _this.removeTriggerEvent();
                    if (_this.triggerElement) {
                        _this.triggerElement.addEventListener('click', _this.clickHandler, true);
                    }
                }));
            }
        };
        /**
         * @return {?}
         */
        DwWaveRenderer.prototype.removeTriggerEvent = /**
         * @return {?}
         */
        function () {
            if (this.triggerElement) {
                this.triggerElement.removeEventListener('click', this.clickHandler, true);
            }
        };
        /**
         * @return {?}
         */
        DwWaveRenderer.prototype.removeStyleAndExtraNode = /**
         * @return {?}
         */
        function () {
            if (this.styleForPseudo && document.body.contains(this.styleForPseudo)) {
                document.body.removeChild(this.styleForPseudo);
                this.styleForPseudo = null;
            }
            if (this.insertExtraNode && this.triggerElement.contains(this.extraNode)) {
                this.triggerElement.removeChild((/** @type {?} */ (this.extraNode)));
            }
        };
        /**
         * @return {?}
         */
        DwWaveRenderer.prototype.destroy = /**
         * @return {?}
         */
        function () {
            this.removeTriggerEvent();
            this.removeStyleAndExtraNode();
        };
        /**
         * @private
         * @return {?}
         */
        DwWaveRenderer.prototype.fadeOutWave = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var node = this.triggerElement;
            /** @type {?} */
            var waveColor = this.getWaveColor(node);
            node.setAttribute(this.waveAttributeName, 'true');
            if (Date.now() < this.lastTime + this.waveTransitionDuration) {
                return;
            }
            if (this.isValidColor(waveColor)) {
                if (!this.styleForPseudo) {
                    this.styleForPseudo = document.createElement('style');
                }
                this.styleForPseudo.innerHTML = "\n      [ant-click-animating-without-extra-node='true']::after, .ant-click-animating-node {\n        --antd-wave-shadow-color: " + waveColor + ";\n      }";
                document.body.appendChild(this.styleForPseudo);
            }
            if (this.insertExtraNode) {
                if (!this.extraNode) {
                    this.extraNode = document.createElement('div');
                }
                this.extraNode.className = 'ant-click-animating-node';
                node.appendChild(this.extraNode);
            }
            this.lastTime = Date.now();
            this.runTimeoutOutsideZone((/**
             * @return {?}
             */
            function () {
                node.removeAttribute(_this.waveAttributeName);
                _this.removeStyleAndExtraNode();
            }), this.waveTransitionDuration);
        };
        /**
         * @private
         * @param {?} color
         * @return {?}
         */
        DwWaveRenderer.prototype.isValidColor = /**
         * @private
         * @param {?} color
         * @return {?}
         */
        function (color) {
            return (!!color &&
                color !== '#ffffff' &&
                color !== 'rgb(255, 255, 255)' &&
                this.isNotGrey(color) &&
                !/rgba\(\d*, \d*, \d*, 0\)/.test(color) &&
                color !== 'transparent');
        };
        /**
         * @private
         * @param {?} color
         * @return {?}
         */
        DwWaveRenderer.prototype.isNotGrey = /**
         * @private
         * @param {?} color
         * @return {?}
         */
        function (color) {
            /** @type {?} */
            var match = color.match(/rgba?\((\d*), (\d*), (\d*)(, [\.\d]*)?\)/);
            if (match && match[1] && match[2] && match[3]) {
                return !(match[1] === match[2] && match[2] === match[3]);
            }
            return true;
        };
        /**
         * @private
         * @param {?} node
         * @return {?}
         */
        DwWaveRenderer.prototype.getWaveColor = /**
         * @private
         * @param {?} node
         * @return {?}
         */
        function (node) {
            /** @type {?} */
            var nodeStyle = getComputedStyle(node);
            return (nodeStyle.getPropertyValue('border-top-color') || // Firefox Compatible
                nodeStyle.getPropertyValue('border-color') ||
                nodeStyle.getPropertyValue('background-color'));
        };
        /**
         * @private
         * @param {?} fn
         * @param {?} delay
         * @return {?}
         */
        DwWaveRenderer.prototype.runTimeoutOutsideZone = /**
         * @private
         * @param {?} fn
         * @param {?} delay
         * @return {?}
         */
        function (fn, delay) {
            this.ngZone.runOutsideAngular((/**
             * @return {?}
             */
            function () { return setTimeout(fn, delay); }));
        };
        return DwWaveRenderer;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.waveTransitionDuration;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.styleForPseudo;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.extraNode;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.lastTime;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.platform;
        /** @type {?} */
        DwWaveRenderer.prototype.clickHandler;
        /** @type {?} */
        DwWaveRenderer.prototype.onClick;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.triggerElement;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwWaveRenderer.prototype.insertExtraNode;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-wave.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwWaveConfig() { }
    if (false) {
        /** @type {?|undefined} */
        DwWaveConfig.prototype.disabled;
    }
    /** @type {?} */
    var DW_WAVE_GLOBAL_DEFAULT_CONFIG = {
        disabled: false
    };
    /** @type {?} */
    var DW_WAVE_GLOBAL_CONFIG = new core.InjectionToken('dw-wave-global-options', {
        providedIn: 'root',
        factory: DW_WAVE_GLOBAL_CONFIG_FACTORY
    });
    /**
     * @return {?}
     */
    function DW_WAVE_GLOBAL_CONFIG_FACTORY() {
        return DW_WAVE_GLOBAL_DEFAULT_CONFIG;
    }
    var DwWaveDirective = /** @class */ (function () {
        function DwWaveDirective(ngZone, elementRef, config, animationType) {
            this.ngZone = ngZone;
            this.elementRef = elementRef;
            this.config = config;
            this.animationType = animationType;
            this.dwWaveExtraNode = false;
            this.waveDisabled = false;
            this.waveDisabled = this.isConfigDisabled();
        }
        Object.defineProperty(DwWaveDirective.prototype, "disabled", {
            get: /**
             * @return {?}
             */
            function () {
                return this.waveDisabled;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwWaveDirective.prototype, "rendererRef", {
            get: /**
             * @return {?}
             */
            function () {
                return this.waveRenderer;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.isConfigDisabled = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var disabled = false;
            if (this.config && typeof this.config.disabled === 'boolean') {
                disabled = this.config.disabled;
            }
            if (this.animationType === 'NoopAnimations') {
                disabled = true;
            }
            return disabled;
        };
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            if (this.waveRenderer) {
                this.waveRenderer.destroy();
            }
        };
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.renderWaveIfEnabled();
        };
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.renderWaveIfEnabled = /**
         * @return {?}
         */
        function () {
            if (!this.waveDisabled && this.elementRef.nativeElement) {
                this.waveRenderer = new DwWaveRenderer(this.elementRef.nativeElement, this.ngZone, this.dwWaveExtraNode);
            }
        };
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.disable = /**
         * @return {?}
         */
        function () {
            this.waveDisabled = true;
            if (this.waveRenderer) {
                this.waveRenderer.removeTriggerEvent();
                this.waveRenderer.removeStyleAndExtraNode();
            }
        };
        /**
         * @return {?}
         */
        DwWaveDirective.prototype.enable = /**
         * @return {?}
         */
        function () {
            // config priority
            this.waveDisabled = this.isConfigDisabled() || false;
            if (this.waveRenderer) {
                this.waveRenderer.bindTriggerEvent();
            }
        };
        DwWaveDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-wave],button[dw-button]:not([dwType="link"])',
                        exportAs: 'dwWave'
                    },] }
        ];
        /** @nocollapse */
        DwWaveDirective.ctorParameters = function () { return [
            { type: core.NgZone },
            { type: core.ElementRef },
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [DW_WAVE_GLOBAL_CONFIG,] }] },
            { type: String, decorators: [{ type: core.Optional }, { type: core.Inject, args: [animations.ANIMATION_MODULE_TYPE,] }] }
        ]; };
        DwWaveDirective.propDecorators = {
            dwWaveExtraNode: [{ type: core.Input }]
        };
        return DwWaveDirective;
    }());
    if (false) {
        /** @type {?} */
        DwWaveDirective.prototype.dwWaveExtraNode;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.waveRenderer;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.waveDisabled;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.config;
        /**
         * @type {?}
         * @private
         */
        DwWaveDirective.prototype.animationType;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-wave.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwWaveModule = /** @class */ (function () {
        function DwWaveModule() {
        }
        DwWaveModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [platform.PlatformModule],
                        exports: [DwWaveDirective],
                        declarations: [DwWaveDirective]
                    },] }
        ];
        return DwWaveModule;
    }());

    exports.DW_WAVE_GLOBAL_CONFIG = DW_WAVE_GLOBAL_CONFIG;
    exports.DW_WAVE_GLOBAL_CONFIG_FACTORY = DW_WAVE_GLOBAL_CONFIG_FACTORY;
    exports.DW_WAVE_GLOBAL_DEFAULT_CONFIG = DW_WAVE_GLOBAL_DEFAULT_CONFIG;
    exports.DwWaveDirective = DwWaveDirective;
    exports.DwWaveModule = DwWaveModule;
    exports.DwWaveRenderer = DwWaveRenderer;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-wave.umd.js.map
