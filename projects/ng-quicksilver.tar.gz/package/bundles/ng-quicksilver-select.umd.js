(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('rxjs'), require('@angular/cdk/scrolling'), require('ng-quicksilver/core/util'), require('rxjs/operators'), require('@angular/cdk/a11y'), require('@angular/cdk/keycodes'), require('@angular/cdk/overlay'), require('@angular/cdk/platform'), require('@angular/forms'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/no-animation'), require('@angular/common'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/core/transition-patch'), require('ng-quicksilver/empty'), require('ng-quicksilver/i18n'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/select', ['exports', '@angular/core', 'rxjs', '@angular/cdk/scrolling', 'ng-quicksilver/core/util', 'rxjs/operators', '@angular/cdk/a11y', '@angular/cdk/keycodes', '@angular/cdk/overlay', '@angular/cdk/platform', '@angular/forms', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/config', 'ng-quicksilver/core/no-animation', '@angular/common', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/overlay', 'ng-quicksilver/core/transition-patch', 'ng-quicksilver/empty', 'ng-quicksilver/i18n', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].select = {}), global.ng.core, global.rxjs, global.ng.cdk.scrolling, global['ng-quicksilver'].core.util, global.rxjs.operators, global.ng.cdk.a11y, global.ng.cdk.keycodes, global.ng.cdk.overlay, global.ng.cdk.platform, global.ng.forms, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core['no-animation'], global.ng.common, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].core['transition-patch'], global['ng-quicksilver'].empty, global['ng-quicksilver'].i18n, global['ng-quicksilver'].icon));
}(this, (function (exports, core, rxjs, scrolling, util, operators, a11y, keycodes, overlay, platform, forms, animation, config, noAnimation, common, outlet, overlay$1, transitionPatch, empty, i18n, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: option-group.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionGroupComponent = /** @class */ (function () {
        function DwOptionGroupComponent() {
            this.dwLabel = null;
            this.changes = new rxjs.Subject();
        }
        /**
         * @return {?}
         */
        DwOptionGroupComponent.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            this.changes.next();
        };
        DwOptionGroupComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-option-group',
                        exportAs: 'dwOptionGroup',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-content></ng-content> "
                    }] }
        ];
        DwOptionGroupComponent.propDecorators = {
            dwLabel: [{ type: core.Input }]
        };
        return DwOptionGroupComponent;
    }());
    if (false) {
        /** @type {?} */
        DwOptionGroupComponent.prototype.dwLabel;
        /** @type {?} */
        DwOptionGroupComponent.prototype.changes;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: option-container.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionContainerComponent = /** @class */ (function () {
        function DwOptionContainerComponent() {
            this.notFoundContent = undefined;
            this.menuItemSelectedIcon = null;
            this.dropdownRender = null;
            this.activatedValue = null;
            this.listOfSelectedValue = [];
            this.mode = 'default';
            this.matchWidth = true;
            this.itemSize = 32;
            this.maxItemLength = 8;
            this.listOfContainerItem = [];
            this.itemClick = new core.EventEmitter();
            this.scrollToBottom = new core.EventEmitter();
            this.scrolledIndex = 0;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        DwOptionContainerComponent.prototype.onItemClick = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.itemClick.emit(value);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwOptionContainerComponent.prototype.onItemHover = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            // TODO: keydown.enter won't activate this value
            this.activatedValue = value;
        };
        /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        DwOptionContainerComponent.prototype.trackValue = /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        function (_index, option) {
            return option.key;
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwOptionContainerComponent.prototype.onScrolledIndexChange = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.scrolledIndex = index;
            if (index === this.listOfContainerItem.length - this.maxItemLength) {
                this.scrollToBottom.emit();
            }
        };
        /**
         * @return {?}
         */
        DwOptionContainerComponent.prototype.scrollToActivatedValue = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var index = this.listOfContainerItem.findIndex((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return _this.compareWith(item.key, _this.activatedValue); }));
            if (index < this.scrolledIndex || index >= this.scrolledIndex + this.maxItemLength) {
                this.cdkVirtualScrollViewport.scrollToIndex(index || 0);
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwOptionContainerComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var listOfContainerItem = changes.listOfContainerItem, activatedValue = changes.activatedValue;
            if (listOfContainerItem || activatedValue) {
                this.scrollToActivatedValue();
            }
        };
        /**
         * @return {?}
         */
        DwOptionContainerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            setTimeout((/**
             * @return {?}
             */
            function () { return _this.scrollToActivatedValue(); }));
        };
        DwOptionContainerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-option-container',
                        exportAs: 'dwOptionContainer',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        preserveWhitespaces: false,
                        template: "\n    <div>\n      <div *ngIf=\"listOfContainerItem.length === 0\" class=\"ant-select-item-empty\">\n        <dw-embed-empty dwComponentName=\"select\" [specificContent]=\"notFoundContent!\"></dw-embed-empty>\n      </div>\n      <cdk-virtual-scroll-viewport\n        [class.full-width]=\"!matchWidth\"\n        [itemSize]=\"itemSize\"\n        [maxBufferPx]=\"itemSize * maxItemLength\"\n        [minBufferPx]=\"itemSize * maxItemLength\"\n        (scrolledIndexChange)=\"onScrolledIndexChange($event)\"\n        [style.height.px]=\"listOfContainerItem.length * itemSize\"\n        [style.max-height.px]=\"itemSize * maxItemLength\"\n      >\n        <ng-template\n          cdkVirtualFor\n          [cdkVirtualForOf]=\"listOfContainerItem\"\n          [cdkVirtualForTrackBy]=\"trackValue\"\n          [cdkVirtualForTemplateCacheSize]=\"0\"\n          let-item\n        >\n          <ng-container [ngSwitch]=\"item.type\">\n            <dw-option-item-group *ngSwitchCase=\"'group'\" [dwLabel]=\"item.groupLabel\"></dw-option-item-group>\n            <dw-option-item\n              *ngSwitchCase=\"'item'\"\n              [icon]=\"menuItemSelectedIcon\"\n              [customContent]=\"item.dwCustomContent\"\n              [template]=\"item.template\"\n              [grouped]=\"!!item.groupLabel\"\n              [disabled]=\"item.dwDisabled\"\n              [showState]=\"mode === 'tags' || mode === 'multiple'\"\n              [label]=\"item.dwLabel\"\n              [compareWith]=\"compareWith\"\n              [activatedValue]=\"activatedValue\"\n              [listOfSelectedValue]=\"listOfSelectedValue\"\n              [value]=\"item.dwValue\"\n              (itemHover)=\"onItemHover($event)\"\n              (itemClick)=\"onItemClick($event)\"\n            ></dw-option-item>\n          </ng-container>\n        </ng-template>\n      </cdk-virtual-scroll-viewport>\n      <ng-template [ngTemplateOutlet]=\"dropdownRender\"></ng-template>\n    </div>\n  ",
                        host: {
                            '[class.ant-select-dropdown]': 'true'
                        }
                    }] }
        ];
        DwOptionContainerComponent.propDecorators = {
            notFoundContent: [{ type: core.Input }],
            menuItemSelectedIcon: [{ type: core.Input }],
            dropdownRender: [{ type: core.Input }],
            activatedValue: [{ type: core.Input }],
            listOfSelectedValue: [{ type: core.Input }],
            compareWith: [{ type: core.Input }],
            mode: [{ type: core.Input }],
            matchWidth: [{ type: core.Input }],
            itemSize: [{ type: core.Input }],
            maxItemLength: [{ type: core.Input }],
            listOfContainerItem: [{ type: core.Input }],
            itemClick: [{ type: core.Output }],
            scrollToBottom: [{ type: core.Output }],
            cdkVirtualScrollViewport: [{ type: core.ViewChild, args: [scrolling.CdkVirtualScrollViewport, { static: true },] }]
        };
        return DwOptionContainerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwOptionContainerComponent.prototype.notFoundContent;
        /** @type {?} */
        DwOptionContainerComponent.prototype.menuItemSelectedIcon;
        /** @type {?} */
        DwOptionContainerComponent.prototype.dropdownRender;
        /** @type {?} */
        DwOptionContainerComponent.prototype.activatedValue;
        /** @type {?} */
        DwOptionContainerComponent.prototype.listOfSelectedValue;
        /** @type {?} */
        DwOptionContainerComponent.prototype.compareWith;
        /** @type {?} */
        DwOptionContainerComponent.prototype.mode;
        /** @type {?} */
        DwOptionContainerComponent.prototype.matchWidth;
        /** @type {?} */
        DwOptionContainerComponent.prototype.itemSize;
        /** @type {?} */
        DwOptionContainerComponent.prototype.maxItemLength;
        /** @type {?} */
        DwOptionContainerComponent.prototype.listOfContainerItem;
        /** @type {?} */
        DwOptionContainerComponent.prototype.itemClick;
        /** @type {?} */
        DwOptionContainerComponent.prototype.scrollToBottom;
        /** @type {?} */
        DwOptionContainerComponent.prototype.cdkVirtualScrollViewport;
        /**
         * @type {?}
         * @private
         */
        DwOptionContainerComponent.prototype.scrolledIndex;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: option.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionComponent = /** @class */ (function () {
        function DwOptionComponent(dwOptionGroupComponent) {
            this.dwOptionGroupComponent = dwOptionGroupComponent;
            this.destroy$ = new rxjs.Subject();
            this.changes = new rxjs.Subject();
            this.groupLabel = null;
            this.dwLabel = null;
            this.dwValue = null;
            this.dwDisabled = false;
            this.dwHide = false;
            this.dwCustomContent = false;
        }
        /**
         * @return {?}
         */
        DwOptionComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.dwOptionGroupComponent) {
                this.dwOptionGroupComponent.changes.pipe(operators.startWith(true), operators.takeUntil(this.destroy$)).subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.groupLabel = _this.dwOptionGroupComponent.dwLabel;
                }));
            }
        };
        /**
         * @return {?}
         */
        DwOptionComponent.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            this.changes.next();
        };
        /**
         * @return {?}
         */
        DwOptionComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwOptionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-option',
                        exportAs: 'dwOption',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-template>\n      <ng-content></ng-content>\n    </ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwOptionComponent.ctorParameters = function () { return [
            { type: DwOptionGroupComponent, decorators: [{ type: core.Optional }] }
        ]; };
        DwOptionComponent.propDecorators = {
            template: [{ type: core.ViewChild, args: [core.TemplateRef, { static: true },] }],
            dwLabel: [{ type: core.Input }],
            dwValue: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwHide: [{ type: core.Input }],
            dwCustomContent: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwOptionComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwOptionComponent.prototype, "dwHide", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwOptionComponent.prototype, "dwCustomContent", void 0);
        return DwOptionComponent;
    }());
    if (false) {
        /** @type {?} */
        DwOptionComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwOptionComponent.ngAcceptInputType_dwHide;
        /** @type {?} */
        DwOptionComponent.ngAcceptInputType_dwCustomContent;
        /**
         * @type {?}
         * @private
         */
        DwOptionComponent.prototype.destroy$;
        /** @type {?} */
        DwOptionComponent.prototype.changes;
        /** @type {?} */
        DwOptionComponent.prototype.groupLabel;
        /** @type {?} */
        DwOptionComponent.prototype.template;
        /** @type {?} */
        DwOptionComponent.prototype.dwLabel;
        /** @type {?} */
        DwOptionComponent.prototype.dwValue;
        /** @type {?} */
        DwOptionComponent.prototype.dwDisabled;
        /** @type {?} */
        DwOptionComponent.prototype.dwHide;
        /** @type {?} */
        DwOptionComponent.prototype.dwCustomContent;
        /**
         * @type {?}
         * @private
         */
        DwOptionComponent.prototype.dwOptionGroupComponent;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-search.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectSearchComponent = /** @class */ (function () {
        function DwSelectSearchComponent(elementRef, renderer, focusMonitor) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.focusMonitor = focusMonitor;
            this.disabled = false;
            this.mirrorSync = false;
            this.showInput = true;
            this.focusTrigger = false;
            this.value = '';
            this.autofocus = false;
            this.valueChange = new core.EventEmitter();
            this.isComposingChange = new core.EventEmitter();
        }
        /**
         * @param {?} isComposing
         * @return {?}
         */
        DwSelectSearchComponent.prototype.setCompositionState = /**
         * @param {?} isComposing
         * @return {?}
         */
        function (isComposing) {
            this.isComposingChange.next(isComposing);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectSearchComponent.prototype.onValueChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            /** @type {?} */
            var inputDOM = this.inputElement.nativeElement;
            inputDOM.value = value;
            this.value = value;
            this.valueChange.next(value);
            if (this.mirrorSync) {
                this.syncMirrorWidth();
            }
        };
        /**
         * @return {?}
         */
        DwSelectSearchComponent.prototype.clearInputValue = /**
         * @return {?}
         */
        function () {
            this.onValueChange('');
        };
        /**
         * @return {?}
         */
        DwSelectSearchComponent.prototype.syncMirrorWidth = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var mirrorDOM = (/** @type {?} */ (this.mirrorElement)).nativeElement;
            /** @type {?} */
            var hostDOM = this.elementRef.nativeElement;
            /** @type {?} */
            var inputDOM = this.inputElement.nativeElement;
            this.renderer.removeStyle(hostDOM, 'width');
            mirrorDOM.innerHTML = inputDOM.value + "&nbsp;";
            this.renderer.setStyle(hostDOM, 'width', mirrorDOM.scrollWidth + "px");
        };
        /**
         * @return {?}
         */
        DwSelectSearchComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            this.focusMonitor.focusVia(this.inputElement, 'keyboard');
        };
        /**
         * @return {?}
         */
        DwSelectSearchComponent.prototype.blur = /**
         * @return {?}
         */
        function () {
            this.inputElement.nativeElement.blur();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSelectSearchComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            /** @type {?} */
            var inputDOM = this.inputElement.nativeElement;
            var focusTrigger = changes.focusTrigger, showInput = changes.showInput;
            if (focusTrigger && focusTrigger.currentValue === true && focusTrigger.previousValue === false) {
                inputDOM.focus();
            }
            if (showInput) {
                if (this.showInput) {
                    this.renderer.removeAttribute(inputDOM, 'readonly');
                }
                else {
                    this.renderer.setAttribute(inputDOM, 'readonly', 'readonly');
                }
            }
        };
        /**
         * @return {?}
         */
        DwSelectSearchComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            if (this.mirrorSync) {
                this.syncMirrorWidth();
            }
            if (this.autofocus) {
                this.focus();
            }
        };
        DwSelectSearchComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-search',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <input\n      #inputElement\n      autocomplete=\"off\"\n      class=\"ant-select-selection-search-input\"\n      [ngModel]=\"value\"\n      [attr.autofocus]=\"autofocus ? 'autofocus' : null\"\n      [disabled]=\"disabled\"\n      [style.opacity]=\"showInput ? null : 0\"\n      (ngModelChange)=\"onValueChange($event)\"\n      (compositionstart)=\"setCompositionState(true)\"\n      (compositionend)=\"setCompositionState(false)\"\n    />\n    <span #mirrorElement *ngIf=\"mirrorSync\" class=\"ant-select-selection-search-mirror\"></span>\n  ",
                        host: {
                            '[class.ant-select-selection-search]': 'true'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSelectSearchComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: a11y.FocusMonitor }
        ]; };
        DwSelectSearchComponent.propDecorators = {
            disabled: [{ type: core.Input }],
            mirrorSync: [{ type: core.Input }],
            showInput: [{ type: core.Input }],
            focusTrigger: [{ type: core.Input }],
            value: [{ type: core.Input }],
            autofocus: [{ type: core.Input }],
            valueChange: [{ type: core.Output }],
            isComposingChange: [{ type: core.Output }],
            inputElement: [{ type: core.ViewChild, args: ['inputElement', { static: true },] }],
            mirrorElement: [{ type: core.ViewChild, args: ['mirrorElement', { static: false },] }]
        };
        return DwSelectSearchComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectSearchComponent.prototype.disabled;
        /** @type {?} */
        DwSelectSearchComponent.prototype.mirrorSync;
        /** @type {?} */
        DwSelectSearchComponent.prototype.showInput;
        /** @type {?} */
        DwSelectSearchComponent.prototype.focusTrigger;
        /** @type {?} */
        DwSelectSearchComponent.prototype.value;
        /** @type {?} */
        DwSelectSearchComponent.prototype.autofocus;
        /** @type {?} */
        DwSelectSearchComponent.prototype.valueChange;
        /** @type {?} */
        DwSelectSearchComponent.prototype.isComposingChange;
        /** @type {?} */
        DwSelectSearchComponent.prototype.inputElement;
        /** @type {?} */
        DwSelectSearchComponent.prototype.mirrorElement;
        /**
         * @type {?}
         * @private
         */
        DwSelectSearchComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwSelectSearchComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwSelectSearchComponent.prototype.focusMonitor;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-top-control.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectTopControlComponent = /** @class */ (function () {
        function DwSelectTopControlComponent(noAnimation) {
            this.noAnimation = noAnimation;
            this.showSearch = false;
            this.placeHolder = null;
            this.open = false;
            this.maxTagCount = Infinity;
            this.autofocus = false;
            this.disabled = false;
            this.mode = 'default';
            this.customTemplate = null;
            this.maxTagPlaceholder = null;
            this.removeIcon = null;
            this.listOfTopItem = [];
            this.tokenSeparators = [];
            this.tokenize = new core.EventEmitter();
            this.inputValueChange = new core.EventEmitter();
            this.animationEnd = new core.EventEmitter();
            this.deleteItem = new core.EventEmitter();
            this.openChange = new core.EventEmitter();
            this.listOfSlicedItem = [];
            this.isShowPlaceholder = true;
            this.isShowSingleLabel = false;
            this.isComposing = false;
            this.inputValue = null;
        }
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.onHostClick = /**
         * @return {?}
         */
        function () {
            if (!this.disabled) {
                this.openChange.next(!this.open);
            }
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.onHostKeydown = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            /** @type {?} */
            var inputValue = ((/** @type {?} */ (e.target))).value;
            if (e.keyCode === keycodes.BACKSPACE && this.mode !== 'default' && !inputValue && this.listOfTopItem.length > 0) {
                e.preventDefault();
                this.onDeleteItem(this.listOfTopItem[this.listOfTopItem.length - 1]);
            }
        };
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.updateTemplateVariable = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var isSelectedValueEmpty = this.listOfTopItem.length === 0;
            this.isShowPlaceholder = isSelectedValueEmpty && !this.isComposing && !this.inputValue;
            this.isShowSingleLabel = !isSelectedValueEmpty && !this.isComposing && !this.inputValue;
        };
        /**
         * @param {?} isComposing
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.isComposingChange = /**
         * @param {?} isComposing
         * @return {?}
         */
        function (isComposing) {
            this.isComposing = isComposing;
            this.updateTemplateVariable();
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.onInputValueChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (value !== this.inputValue) {
                this.inputValue = value;
                this.updateTemplateVariable();
                this.inputValueChange.emit(value);
                this.tokenSeparate(value, this.tokenSeparators);
            }
        };
        /**
         * @param {?} inputValue
         * @param {?} tokenSeparators
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.tokenSeparate = /**
         * @param {?} inputValue
         * @param {?} tokenSeparators
         * @return {?}
         */
        function (inputValue, tokenSeparators) {
            /** @type {?} */
            var includesSeparators = (/**
             * @param {?} str
             * @param {?} separators
             * @return {?}
             */
            function (str, separators) {
                // tslint:disable-next-line:prefer-for-of
                for (var i = 0; i < separators.length; ++i) {
                    if (str.lastIndexOf(separators[i]) > 0) {
                        return true;
                    }
                }
                return false;
            });
            /** @type {?} */
            var splitBySeparators = (/**
             * @param {?} str
             * @param {?} separators
             * @return {?}
             */
            function (str, separators) {
                /** @type {?} */
                var reg = new RegExp("[" + separators.join() + "]");
                /** @type {?} */
                var array = ((/** @type {?} */ (str))).split(reg).filter((/**
                 * @param {?} token
                 * @return {?}
                 */
                function (token) { return token; }));
                return __spread(new Set(array));
            });
            if (inputValue &&
                inputValue.length &&
                tokenSeparators.length &&
                this.mode !== 'default' &&
                includesSeparators(inputValue, tokenSeparators)) {
                /** @type {?} */
                var listOfLabel = splitBySeparators(inputValue, tokenSeparators);
                this.tokenize.next(listOfLabel);
            }
        };
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.clearInputValue = /**
         * @return {?}
         */
        function () {
            if (this.dwSelectSearchComponent) {
                this.dwSelectSearchComponent.clearInputValue();
            }
        };
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            if (this.dwSelectSearchComponent) {
                this.dwSelectSearchComponent.focus();
            }
        };
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.blur = /**
         * @return {?}
         */
        function () {
            if (this.dwSelectSearchComponent) {
                this.dwSelectSearchComponent.blur();
            }
        };
        /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.trackValue = /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        function (_index, option) {
            return option.dwValue;
        };
        /**
         * @param {?} item
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.onDeleteItem = /**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            if (!this.disabled && !item.dwDisabled) {
                this.deleteItem.next(item);
            }
        };
        /**
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.onAnimationEnd = /**
         * @return {?}
         */
        function () {
            this.animationEnd.next();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSelectTopControlComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            var listOfTopItem = changes.listOfTopItem, maxTagCount = changes.maxTagCount, customTemplate = changes.customTemplate, maxTagPlaceholder = changes.maxTagPlaceholder;
            if (listOfTopItem) {
                this.updateTemplateVariable();
            }
            if (listOfTopItem || maxTagCount || customTemplate || maxTagPlaceholder) {
                /** @type {?} */
                var listOfSlicedItem = this.listOfTopItem.slice(0, this.maxTagCount).map((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) {
                    return {
                        dwLabel: o.dwLabel,
                        dwValue: o.dwValue,
                        dwDisabled: o.dwDisabled,
                        contentTemplateOutlet: _this.customTemplate,
                        contentTemplateOutletContext: o
                    };
                }));
                if (this.listOfTopItem.length > this.maxTagCount) {
                    /** @type {?} */
                    var exceededLabel = "+ " + (this.listOfTopItem.length - this.maxTagCount) + " ...";
                    /** @type {?} */
                    var listOfSelectedValue = this.listOfTopItem.map((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return item.dwValue; }));
                    /** @type {?} */
                    var exceededItem = {
                        dwLabel: exceededLabel,
                        dwValue: '$$__dw_exceeded_item',
                        dwDisabled: true,
                        contentTemplateOutlet: this.maxTagPlaceholder,
                        contentTemplateOutletContext: listOfSelectedValue.slice(this.maxTagCount)
                    };
                    listOfSlicedItem.push(exceededItem);
                }
                this.listOfSlicedItem = listOfSlicedItem;
            }
        };
        DwSelectTopControlComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-top-control',
                        exportAs: 'dwSelectTopControl',
                        preserveWhitespaces: false,
                        animations: [animation.zoomMotion],
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <!--single mode-->\n    <ng-container [ngSwitch]=\"mode\">\n      <ng-container *ngSwitchCase=\"'default'\">\n        <dw-select-item\n          *ngIf=\"isShowSingleLabel\"\n          [deletable]=\"false\"\n          [disabled]=\"false\"\n          [removeIcon]=\"removeIcon\"\n          [label]=\"listOfTopItem[0].dwLabel\"\n          [contentTemplateOutlet]=\"customTemplate\"\n          [contentTemplateOutletContext]=\"listOfTopItem[0]\"\n        ></dw-select-item>\n        <dw-select-search\n          [disabled]=\"disabled\"\n          [value]=\"inputValue!\"\n          [showInput]=\"open && showSearch\"\n          [mirrorSync]=\"false\"\n          [autofocus]=\"autofocus\"\n          [focusTrigger]=\"open\"\n          (isComposingChange)=\"isComposingChange($event)\"\n          (valueChange)=\"onInputValueChange($event)\"\n        ></dw-select-search>\n      </ng-container>\n      <ng-container *ngSwitchDefault>\n        <!--multiple or tags mode-->\n        <dw-select-item\n          *ngFor=\"let item of listOfSlicedItem; trackBy: trackValue\"\n          [@zoomMotion]\n          [@.disabled]=\"noAnimation?.dwNoAnimation\"\n          [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n          [removeIcon]=\"removeIcon\"\n          [label]=\"item.dwLabel\"\n          [disabled]=\"item.dwDisabled || disabled\"\n          [contentTemplateOutlet]=\"item.contentTemplateOutlet\"\n          [deletable]=\"true\"\n          [contentTemplateOutletContext]=\"item.contentTemplateOutletContext\"\n          (@zoomMotion.done)=\"onAnimationEnd()\"\n          (delete)=\"onDeleteItem(item.contentTemplateOutletContext)\"\n        >\n        </dw-select-item>\n        <dw-select-search\n          [disabled]=\"disabled\"\n          [value]=\"inputValue!\"\n          [autofocus]=\"autofocus\"\n          [showInput]=\"true\"\n          [mirrorSync]=\"true\"\n          [focusTrigger]=\"open\"\n          (isComposingChange)=\"isComposingChange($event)\"\n          (valueChange)=\"onInputValueChange($event)\"\n        ></dw-select-search>\n      </ng-container>\n    </ng-container>\n    <dw-select-placeholder *ngIf=\"isShowPlaceholder\" [placeholder]=\"placeHolder\"></dw-select-placeholder>\n  ",
                        host: {
                            '[class.ant-select-selector]': 'true',
                            '(click)': 'onHostClick()',
                            '(keydown)': 'onHostKeydown($event)'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSelectTopControlComponent.ctorParameters = function () { return [
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwSelectTopControlComponent.propDecorators = {
            showSearch: [{ type: core.Input }],
            placeHolder: [{ type: core.Input }],
            open: [{ type: core.Input }],
            maxTagCount: [{ type: core.Input }],
            autofocus: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            mode: [{ type: core.Input }],
            customTemplate: [{ type: core.Input }],
            maxTagPlaceholder: [{ type: core.Input }],
            removeIcon: [{ type: core.Input }],
            listOfTopItem: [{ type: core.Input }],
            tokenSeparators: [{ type: core.Input }],
            tokenize: [{ type: core.Output }],
            inputValueChange: [{ type: core.Output }],
            animationEnd: [{ type: core.Output }],
            deleteItem: [{ type: core.Output }],
            openChange: [{ type: core.Output }],
            dwSelectSearchComponent: [{ type: core.ViewChild, args: [DwSelectSearchComponent,] }]
        };
        return DwSelectTopControlComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectTopControlComponent.prototype.showSearch;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.placeHolder;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.open;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.maxTagCount;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.autofocus;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.disabled;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.mode;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.customTemplate;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.maxTagPlaceholder;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.removeIcon;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.listOfTopItem;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.tokenSeparators;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.tokenize;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.inputValueChange;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.animationEnd;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.deleteItem;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.openChange;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.dwSelectSearchComponent;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.listOfSlicedItem;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.isShowPlaceholder;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.isShowSingleLabel;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.isComposing;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.inputValue;
        /** @type {?} */
        DwSelectTopControlComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var defaultFilterOption = (/**
     * @param {?} searchValue
     * @param {?} item
     * @return {?}
     */
    function (searchValue, item) {
        if (item && item.dwLabel) {
            return item.dwLabel.toLowerCase().indexOf(searchValue.toLowerCase()) > -1;
        }
        else {
            return false;
        }
    });
    var ɵ0 = defaultFilterOption;
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'select';
    var DwSelectComponent = /** @class */ (function () {
        function DwSelectComponent(dwConfigService, cdr, elementRef, platform, focusMonitor, noAnimation) {
            this.dwConfigService = dwConfigService;
            this.cdr = cdr;
            this.elementRef = elementRef;
            this.platform = platform;
            this.focusMonitor = focusMonitor;
            this.noAnimation = noAnimation;
            this.dwSize = 'default';
            this.dwOptionHeightPx = 32;
            this.dwOptionOverflowSize = 8;
            this.dwDropdownClassName = null;
            this.dwDropdownMatchSelectWidth = true;
            this.dwDropdownStyle = null;
            this.dwNotFoundContent = undefined;
            this.dwPlaceHolder = null;
            this.dwMaxTagCount = Infinity;
            this.dwDropdownRender = null;
            this.dwCustomTemplate = null;
            this.dwSuffixIcon = null;
            this.dwClearIcon = null;
            this.dwRemoveIcon = null;
            this.dwMenuItemSelectedIcon = null;
            this.dwShowArrow = true;
            this.dwTokenSeparators = [];
            this.dwMaxTagPlaceholder = null;
            this.dwMaxMultipleCount = Infinity;
            this.dwMode = 'default';
            this.dwFilterOption = defaultFilterOption;
            this.compareWith = (/**
             * @param {?} o1
             * @param {?} o2
             * @return {?}
             */
            function (o1, o2) { return o1 === o2; });
            this.dwAllowClear = false;
            this.dwBorderless = false;
            this.dwShowSearch = false;
            this.dwLoading = false;
            this.dwAutoFocus = false;
            this.dwAutoClearSearchValue = true;
            this.dwServerSearch = false;
            this.dwDisabled = false;
            this.dwOpen = false;
            this.dwOptions = [];
            this.dwOnSearch = new core.EventEmitter();
            this.dwScrollToBottom = new core.EventEmitter();
            this.dwOpenChange = new core.EventEmitter();
            this.dwBlur = new core.EventEmitter();
            this.dwFocus = new core.EventEmitter();
            this.listOfValue$ = new rxjs.BehaviorSubject([]);
            this.listOfTemplateItem$ = new rxjs.BehaviorSubject([]);
            this.listOfTagAndTemplateItem = [];
            this.searchValue = '';
            this.isReactiveDriven = false;
            this.destroy$ = new rxjs.Subject();
            this.onChange = (/**
             * @return {?}
             */
            function () { });
            this.onTouched = (/**
             * @return {?}
             */
            function () { });
            this.dropDownPosition = 'bottom';
            this.triggerWidth = null;
            this.listOfContainerItem = [];
            this.listOfTopItem = [];
            this.activatedValue = null;
            this.listOfValue = [];
            this.focused = false;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectComponent.prototype.generateTagItem = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return {
                dwValue: value,
                dwLabel: value,
                type: 'item'
            };
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectComponent.prototype.onItemClick = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            this.activatedValue = value;
            if (this.dwMode === 'default') {
                if (this.listOfValue.length === 0 || !this.compareWith(this.listOfValue[0], value)) {
                    this.updateListOfValue([value]);
                }
                this.setOpenState(false);
            }
            else {
                /** @type {?} */
                var targetIndex_1 = this.listOfValue.findIndex((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) { return _this.compareWith(o, value); }));
                if (targetIndex_1 !== -1) {
                    /** @type {?} */
                    var listOfValueAfterRemoved = this.listOfValue.filter((/**
                     * @param {?} _
                     * @param {?} i
                     * @return {?}
                     */
                    function (_, i) { return i !== targetIndex_1; }));
                    this.updateListOfValue(listOfValueAfterRemoved);
                }
                else if (this.listOfValue.length < this.dwMaxMultipleCount) {
                    /** @type {?} */
                    var listOfValueAfterAdded = __spread(this.listOfValue, [value]);
                    this.updateListOfValue(listOfValueAfterAdded);
                }
                this.focus();
                if (this.dwAutoClearSearchValue) {
                    this.clearInput();
                }
            }
        };
        /**
         * @param {?} item
         * @return {?}
         */
        DwSelectComponent.prototype.onItemDelete = /**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            var _this = this;
            /** @type {?} */
            var listOfSelectedValue = this.listOfValue.filter((/**
             * @param {?} v
             * @return {?}
             */
            function (v) { return !_this.compareWith(v, item.dwValue); }));
            this.updateListOfValue(listOfSelectedValue);
            this.clearInput();
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.updateListOfContainerItem = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var listOfContainerItem = this.listOfTagAndTemplateItem
                .filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return !item.dwHide; }))
                .filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) {
                if (!_this.dwServerSearch && _this.searchValue) {
                    return _this.dwFilterOption(_this.searchValue, item);
                }
                else {
                    return true;
                }
            }));
            if (this.dwMode === 'tags' && this.searchValue) {
                /** @type {?} */
                var matchedItem = this.listOfTagAndTemplateItem.find((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.dwLabel === _this.searchValue; }));
                if (!matchedItem) {
                    /** @type {?} */
                    var tagItem = this.generateTagItem(this.searchValue);
                    listOfContainerItem = __spread([tagItem], listOfContainerItem);
                    this.activatedValue = tagItem.dwValue;
                }
                else {
                    this.activatedValue = matchedItem.dwValue;
                }
            }
            if (this.listOfValue.length !== 0 &&
                listOfContainerItem.findIndex((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return _this.compareWith(item.dwValue, _this.activatedValue); })) === -1) {
                /** @type {?} */
                var activatedItem = listOfContainerItem.find((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return _this.compareWith(item.dwValue, _this.listOfValue[0]); })) || listOfContainerItem[0];
                this.activatedValue = (activatedItem && activatedItem.dwValue) || null;
            }
            /** @type {?} */
            var listOfGroupLabel = [];
            if (this.isReactiveDriven) {
                listOfGroupLabel = __spread(new Set(this.dwOptions.filter((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) { return o.groupLabel; })).map((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) { return (/** @type {?} */ (o.groupLabel)); }))));
            }
            else {
                if (this.listOfDwOptionGroupComponent) {
                    listOfGroupLabel = this.listOfDwOptionGroupComponent.map((/**
                     * @param {?} o
                     * @return {?}
                     */
                    function (o) { return o.dwLabel; }));
                }
            }
            /** insert group item **/
            listOfGroupLabel.forEach((/**
             * @param {?} label
             * @return {?}
             */
            function (label) {
                /** @type {?} */
                var index = listOfContainerItem.findIndex((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return label === item.groupLabel; }));
                if (index > -1) {
                    /** @type {?} */
                    var groupItem = (/** @type {?} */ ({ groupLabel: label, type: 'group', key: label }));
                    listOfContainerItem.splice(index, 0, groupItem);
                }
            }));
            this.listOfContainerItem = __spread(listOfContainerItem);
            this.updateCdkConnectedOverlayPositions();
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.clearInput = /**
         * @return {?}
         */
        function () {
            this.dwSelectTopControlComponent.clearInputValue();
        };
        /**
         * @param {?} listOfValue
         * @return {?}
         */
        DwSelectComponent.prototype.updateListOfValue = /**
         * @param {?} listOfValue
         * @return {?}
         */
        function (listOfValue) {
            /** @type {?} */
            var covertListToModel = (/**
             * @param {?} list
             * @param {?} mode
             * @return {?}
             */
            function (list, mode) {
                if (mode === 'default') {
                    if (list.length > 0) {
                        return list[0];
                    }
                    else {
                        return null;
                    }
                }
                else {
                    return list;
                }
            });
            /** @type {?} */
            var model = covertListToModel(listOfValue, this.dwMode);
            if (this.value !== model) {
                this.listOfValue = listOfValue;
                this.listOfValue$.next(listOfValue);
                this.value = model;
                this.onChange(this.value);
            }
        };
        /**
         * @param {?} listOfLabel
         * @return {?}
         */
        DwSelectComponent.prototype.onTokenSeparate = /**
         * @param {?} listOfLabel
         * @return {?}
         */
        function (listOfLabel) {
            var _this = this;
            /** @type {?} */
            var listOfMatchedValue = this.listOfTagAndTemplateItem
                .filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return listOfLabel.findIndex((/**
             * @param {?} label
             * @return {?}
             */
            function (label) { return label === item.dwLabel; })) !== -1; }))
                .map((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.dwValue; }))
                .filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return _this.listOfValue.findIndex((/**
             * @param {?} v
             * @return {?}
             */
            function (v) { return _this.compareWith(v, item); })) === -1; }));
            if (this.dwMode === 'multiple') {
                this.updateListOfValue(__spread(this.listOfValue, listOfMatchedValue));
            }
            else if (this.dwMode === 'tags') {
                /** @type {?} */
                var listOfUnMatchedLabel = listOfLabel.filter((/**
                 * @param {?} label
                 * @return {?}
                 */
                function (label) { return _this.listOfTagAndTemplateItem.findIndex((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.dwLabel === label; })) === -1; }));
                this.updateListOfValue(__spread(this.listOfValue, listOfMatchedValue, listOfUnMatchedLabel));
            }
            this.clearInput();
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwSelectComponent.prototype.onKeyDown = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            var _this = this;
            if (this.dwDisabled) {
                return;
            }
            /** @type {?} */
            var listOfFilteredOptionNotDisabled = this.listOfContainerItem.filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.type === 'item'; })).filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return !item.dwDisabled; }));
            /** @type {?} */
            var activatedIndex = listOfFilteredOptionNotDisabled.findIndex((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return _this.compareWith(item.dwValue, _this.activatedValue); }));
            switch (e.keyCode) {
                case keycodes.UP_ARROW:
                    e.preventDefault();
                    if (this.dwOpen) {
                        /** @type {?} */
                        var preIndex = activatedIndex > 0 ? activatedIndex - 1 : listOfFilteredOptionNotDisabled.length - 1;
                        this.activatedValue = listOfFilteredOptionNotDisabled[preIndex].dwValue;
                    }
                    break;
                case keycodes.DOWN_ARROW:
                    e.preventDefault();
                    if (this.dwOpen) {
                        /** @type {?} */
                        var nextIndex = activatedIndex < listOfFilteredOptionNotDisabled.length - 1 ? activatedIndex + 1 : 0;
                        this.activatedValue = listOfFilteredOptionNotDisabled[nextIndex].dwValue;
                    }
                    else {
                        this.setOpenState(true);
                    }
                    break;
                case keycodes.ENTER:
                    e.preventDefault();
                    if (this.dwOpen) {
                        if (this.activatedValue) {
                            this.onItemClick(this.activatedValue);
                        }
                    }
                    else {
                        this.setOpenState(true);
                    }
                    break;
                case keycodes.SPACE:
                    if (!this.dwOpen) {
                        this.setOpenState(true);
                        e.preventDefault();
                    }
                    break;
                case keycodes.TAB:
                    this.setOpenState(false);
                    break;
                case keycodes.ESCAPE:
                    this.setOpenState(false);
                    break;
                default:
                    if (!this.dwOpen) {
                        this.setOpenState(true);
                    }
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectComponent.prototype.setOpenState = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (this.dwOpen !== value) {
                this.dwOpen = value;
                this.dwOpenChange.emit(value);
                this.onOpenChange();
                this.cdr.markForCheck();
            }
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.onOpenChange = /**
         * @return {?}
         */
        function () {
            this.updateCdkConnectedOverlayStatus();
            this.clearInput();
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSelectComponent.prototype.onInputValueChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.searchValue = value;
            this.updateListOfContainerItem();
            this.dwOnSearch.emit(value);
            this.updateCdkConnectedOverlayPositions();
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.onClearSelection = /**
         * @return {?}
         */
        function () {
            this.updateListOfValue([]);
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            this.dwSelectTopControlComponent.focus();
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.blur = /**
         * @return {?}
         */
        function () {
            this.dwSelectTopControlComponent.blur();
        };
        /**
         * @param {?} position
         * @return {?}
         */
        DwSelectComponent.prototype.onPositionChange = /**
         * @param {?} position
         * @return {?}
         */
        function (position) {
            this.dropDownPosition = position.connectionPair.originY;
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.updateCdkConnectedOverlayStatus = /**
         * @return {?}
         */
        function () {
            if (this.platform.isBrowser && this.originElement.nativeElement) {
                this.triggerWidth = this.originElement.nativeElement.getBoundingClientRect().width;
            }
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.updateCdkConnectedOverlayPositions = /**
         * @return {?}
         */
        function () {
            if (this.cdkConnectedOverlay.overlayRef) {
                this.cdkConnectedOverlay.overlayRef.updatePosition();
            }
        };
        /**
         * @param {?} modelValue
         * @return {?}
         */
        DwSelectComponent.prototype.writeValue = /**
         * @param {?} modelValue
         * @return {?}
         */
        function (modelValue) {
            /** https://github.com/angular/angular/issues/14988 **/
            if (this.value !== modelValue) {
                this.value = modelValue;
                /** @type {?} */
                var covertModelToList = (/**
                 * @param {?} model
                 * @param {?} mode
                 * @return {?}
                 */
                function (model, mode) {
                    if (model === null || model === undefined) {
                        return [];
                    }
                    else if (mode === 'default') {
                        return [model];
                    }
                    else {
                        return model;
                    }
                });
                /** @type {?} */
                var listOfValue = covertModelToList(modelValue, this.dwMode);
                this.listOfValue = listOfValue;
                this.listOfValue$.next(listOfValue);
                this.cdr.markForCheck();
            }
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwSelectComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwSelectComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        /**
         * @param {?} disabled
         * @return {?}
         */
        DwSelectComponent.prototype.setDisabledState = /**
         * @param {?} disabled
         * @return {?}
         */
        function (disabled) {
            this.dwDisabled = disabled;
            if (disabled) {
                this.setOpenState(false);
            }
            this.cdr.markForCheck();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSelectComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwOpen = changes.dwOpen, dwDisabled = changes.dwDisabled, dwOptions = changes.dwOptions;
            if (dwOpen) {
                this.onOpenChange();
            }
            if (dwDisabled && this.dwDisabled) {
                this.setOpenState(false);
            }
            if (dwOptions) {
                this.isReactiveDriven = true;
                /** @type {?} */
                var listOfOptions = this.dwOptions || [];
                /** @type {?} */
                var listOfTransformedItem = listOfOptions.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    return {
                        template: item.label instanceof core.TemplateRef ? item.label : null,
                        dwLabel: typeof item.label === 'string' ? item.label : null,
                        dwValue: item.value,
                        dwDisabled: item.disabled || false,
                        dwHide: item.hide || false,
                        dwCustomContent: item.label instanceof core.TemplateRef,
                        groupLabel: item.groupLabel || null,
                        type: 'item',
                        key: item.value
                    };
                }));
                this.listOfTemplateItem$.next(listOfTransformedItem);
            }
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.focusMonitor
                .monitor(this.elementRef, true)
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} focusOrigin
             * @return {?}
             */
            function (focusOrigin) {
                if (!focusOrigin) {
                    _this.focused = false;
                    _this.cdr.markForCheck();
                    _this.dwBlur.emit();
                    Promise.resolve().then((/**
                     * @return {?}
                     */
                    function () {
                        _this.onTouched();
                    }));
                }
                else {
                    _this.focused = true;
                    _this.cdr.markForCheck();
                    _this.dwFocus.emit();
                }
            }));
            rxjs.combineLatest([this.listOfValue$, this.listOfTemplateItem$])
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), listOfSelectedValue = _b[0], listOfTemplateItem = _b[1];
                /** @type {?} */
                var listOfTagItem = listOfSelectedValue
                    .filter((/**
                 * @return {?}
                 */
                function () { return _this.dwMode === 'tags'; }))
                    .filter((/**
                 * @param {?} value
                 * @return {?}
                 */
                function (value) { return listOfTemplateItem.findIndex((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) { return _this.compareWith(o.dwValue, value); })) === -1; }))
                    .map((/**
                 * @param {?} value
                 * @return {?}
                 */
                function (value) { return _this.listOfTopItem.find((/**
                 * @param {?} o
                 * @return {?}
                 */
                function (o) { return _this.compareWith(o.dwValue, value); })) || _this.generateTagItem(value); }));
                _this.listOfTagAndTemplateItem = __spread(listOfTemplateItem, listOfTagItem);
                _this.listOfTopItem = _this.listOfValue
                    .map((/**
                 * @param {?} v
                 * @return {?}
                 */
                function (v) { return (/** @type {?} */ (__spread(_this.listOfTagAndTemplateItem, _this.listOfTopItem).find((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return _this.compareWith(v, item.dwValue); })))); }))
                    .filter((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return !!item; }));
                _this.updateListOfContainerItem();
            }));
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            this.updateCdkConnectedOverlayStatus();
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.isReactiveDriven) {
                rxjs.merge(this.listOfDwOptionGroupComponent.changes, this.listOfDwOptionComponent.changes)
                    .pipe(operators.startWith(true), operators.switchMap((/**
                 * @return {?}
                 */
                function () {
                    return rxjs.merge.apply(void 0, __spread([
                        _this.listOfDwOptionComponent.changes,
                        _this.listOfDwOptionGroupComponent.changes
                    ], _this.listOfDwOptionComponent.map((/**
                     * @param {?} option
                     * @return {?}
                     */
                    function (option) { return option.changes; })), _this.listOfDwOptionGroupComponent.map((/**
                     * @param {?} option
                     * @return {?}
                     */
                    function (option) { return option.changes; })))).pipe(operators.startWith(true));
                })), operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    /** @type {?} */
                    var listOfOptionInterface = _this.listOfDwOptionComponent.toArray().map((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) {
                        var template = item.template, dwLabel = item.dwLabel, dwValue = item.dwValue, dwDisabled = item.dwDisabled, dwHide = item.dwHide, dwCustomContent = item.dwCustomContent, groupLabel = item.groupLabel;
                        return { template: template, dwLabel: dwLabel, dwValue: dwValue, dwDisabled: dwDisabled, dwHide: dwHide, dwCustomContent: dwCustomContent, groupLabel: groupLabel, type: 'item', key: dwValue };
                    }));
                    _this.listOfTemplateItem$.next(listOfOptionInterface);
                    _this.cdr.markForCheck();
                }));
            }
        };
        /**
         * @return {?}
         */
        DwSelectComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwSelectComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select',
                        exportAs: 'dwSelect',
                        preserveWhitespaces: false,
                        providers: [
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwSelectComponent; })),
                                multi: true
                            }
                        ],
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        animations: [animation.slideMotion],
                        template: "\n    <dw-select-top-control\n      cdkOverlayOrigin\n      #origin=\"cdkOverlayOrigin\"\n      [open]=\"dwOpen\"\n      [disabled]=\"dwDisabled\"\n      [mode]=\"dwMode\"\n      [@.disabled]=\"noAnimation?.dwNoAnimation\"\n      [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n      [maxTagPlaceholder]=\"dwMaxTagPlaceholder\"\n      [removeIcon]=\"dwRemoveIcon\"\n      [placeHolder]=\"dwPlaceHolder\"\n      [maxTagCount]=\"dwMaxTagCount\"\n      [customTemplate]=\"dwCustomTemplate\"\n      [tokenSeparators]=\"dwTokenSeparators\"\n      [showSearch]=\"dwShowSearch\"\n      [autofocus]=\"dwAutoFocus\"\n      [listOfTopItem]=\"listOfTopItem\"\n      (inputValueChange)=\"onInputValueChange($event)\"\n      (tokenize)=\"onTokenSeparate($event)\"\n      (animationEnd)=\"updateCdkConnectedOverlayPositions()\"\n      (deleteItem)=\"onItemDelete($event)\"\n      (keydown)=\"onKeyDown($event)\"\n      (openChange)=\"setOpenState($event)\"\n    ></dw-select-top-control>\n    <dw-select-clear\n      *ngIf=\"dwAllowClear && !dwDisabled && listOfValue.length\"\n      [clearIcon]=\"dwClearIcon\"\n      (clear)=\"onClearSelection()\"\n    ></dw-select-clear>\n    <dw-select-arrow\n      *ngIf=\"dwShowArrow && dwMode === 'default'\"\n      [loading]=\"dwLoading\"\n      [search]=\"dwOpen && dwShowSearch\"\n      [suffixIcon]=\"dwSuffixIcon\"\n    ></dw-select-arrow>\n    <ng-template\n      cdkConnectedOverlay\n      dwConnectedOverlay\n      [cdkConnectedOverlayHasBackdrop]=\"true\"\n      [cdkConnectedOverlayMinWidth]=\"$any(dwDropdownMatchSelectWidth ? null : triggerWidth)\"\n      [cdkConnectedOverlayWidth]=\"$any(dwDropdownMatchSelectWidth ? triggerWidth : null)\"\n      [cdkConnectedOverlayOrigin]=\"origin\"\n      [cdkConnectedOverlayTransformOriginOn]=\"'.ant-select-dropdown'\"\n      [cdkConnectedOverlayPanelClass]=\"dwDropdownClassName!\"\n      (backdropClick)=\"setOpenState(false)\"\n      (detach)=\"setOpenState(false)\"\n      (positionChange)=\"onPositionChange($event)\"\n      [cdkConnectedOverlayOpen]=\"dwOpen\"\n    >\n      <dw-option-container\n        [ngStyle]=\"dwDropdownStyle\"\n        [itemSize]=\"dwOptionHeightPx\"\n        [maxItemLength]=\"dwOptionOverflowSize\"\n        [matchWidth]=\"dwDropdownMatchSelectWidth\"\n        [class.ant-select-dropdown-placement-bottomLeft]=\"dropDownPosition === 'bottom'\"\n        [class.ant-select-dropdown-placement-topLeft]=\"dropDownPosition === 'top'\"\n        [@slideMotion]=\"'enter'\"\n        [@.disabled]=\"noAnimation?.dwNoAnimation\"\n        [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n        [listOfContainerItem]=\"listOfContainerItem\"\n        [menuItemSelectedIcon]=\"dwMenuItemSelectedIcon\"\n        [notFoundContent]=\"dwNotFoundContent\"\n        [activatedValue]=\"activatedValue\"\n        [listOfSelectedValue]=\"listOfValue\"\n        [dropdownRender]=\"dwDropdownRender\"\n        [compareWith]=\"compareWith\"\n        [mode]=\"dwMode\"\n        (keydown)=\"onKeyDown($event)\"\n        (itemClick)=\"onItemClick($event)\"\n        (scrollToBottom)=\"dwScrollToBottom.emit()\"\n      ></dw-option-container>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-select]': 'true',
                            '[class.ant-select-lg]': 'dwSize === "large"',
                            '[class.ant-select-sm]': 'dwSize === "small"',
                            '[class.ant-select-show-arrow]': "dwShowArrow && dwMode === 'default'",
                            '[class.ant-select-disabled]': 'dwDisabled',
                            '[class.ant-select-show-search]': "dwShowSearch || dwMode !== 'default'",
                            '[class.ant-select-allow-clear]': 'dwAllowClear',
                            '[class.ant-select-borderless]': 'dwBorderless',
                            '[class.ant-select-open]': 'dwOpen',
                            '[class.ant-select-focused]': 'dwOpen || focused',
                            '[class.ant-select-single]': "dwMode === 'default'",
                            '[class.ant-select-multiple]': "dwMode !== 'default'"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSelectComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: core.ChangeDetectorRef },
            { type: core.ElementRef },
            { type: platform.Platform },
            { type: a11y.FocusMonitor },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwSelectComponent.propDecorators = {
            dwSize: [{ type: core.Input }],
            dwOptionHeightPx: [{ type: core.Input }],
            dwOptionOverflowSize: [{ type: core.Input }],
            dwDropdownClassName: [{ type: core.Input }],
            dwDropdownMatchSelectWidth: [{ type: core.Input }],
            dwDropdownStyle: [{ type: core.Input }],
            dwNotFoundContent: [{ type: core.Input }],
            dwPlaceHolder: [{ type: core.Input }],
            dwMaxTagCount: [{ type: core.Input }],
            dwDropdownRender: [{ type: core.Input }],
            dwCustomTemplate: [{ type: core.Input }],
            dwSuffixIcon: [{ type: core.Input }],
            dwClearIcon: [{ type: core.Input }],
            dwRemoveIcon: [{ type: core.Input }],
            dwMenuItemSelectedIcon: [{ type: core.Input }],
            dwShowArrow: [{ type: core.Input }],
            dwTokenSeparators: [{ type: core.Input }],
            dwMaxTagPlaceholder: [{ type: core.Input }],
            dwMaxMultipleCount: [{ type: core.Input }],
            dwMode: [{ type: core.Input }],
            dwFilterOption: [{ type: core.Input }],
            compareWith: [{ type: core.Input }],
            dwAllowClear: [{ type: core.Input }],
            dwBorderless: [{ type: core.Input }],
            dwShowSearch: [{ type: core.Input }],
            dwLoading: [{ type: core.Input }],
            dwAutoFocus: [{ type: core.Input }],
            dwAutoClearSearchValue: [{ type: core.Input }],
            dwServerSearch: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            dwOptions: [{ type: core.Input }],
            dwOnSearch: [{ type: core.Output }],
            dwScrollToBottom: [{ type: core.Output }],
            dwOpenChange: [{ type: core.Output }],
            dwBlur: [{ type: core.Output }],
            dwFocus: [{ type: core.Output }],
            originElement: [{ type: core.ViewChild, args: [overlay.CdkOverlayOrigin, { static: true, read: core.ElementRef },] }],
            cdkConnectedOverlay: [{ type: core.ViewChild, args: [overlay.CdkConnectedOverlay, { static: true },] }],
            dwSelectTopControlComponent: [{ type: core.ViewChild, args: [DwSelectTopControlComponent, { static: true },] }],
            listOfDwOptionComponent: [{ type: core.ContentChildren, args: [DwOptionComponent, { descendants: true },] }],
            listOfDwOptionGroupComponent: [{ type: core.ContentChildren, args: [DwOptionGroupComponent, { descendants: true },] }],
            dwOptionGroupComponentElement: [{ type: core.ViewChild, args: [DwOptionGroupComponent, { static: true, read: core.ElementRef },] }],
            dwSelectTopControlComponentElement: [{ type: core.ViewChild, args: [DwSelectTopControlComponent, { static: true, read: core.ElementRef },] }]
        };
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwSuffixIcon", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwAllowClear", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwBorderless", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwShowSearch", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwLoading", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwAutoFocus", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwAutoClearSearchValue", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwServerSearch", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSelectComponent.prototype, "dwOpen", void 0);
        return DwSelectComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwAllowClear;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwBorderless;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwShowSearch;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwLoading;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwAutoFocus;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwAutoClearSearchValue;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwServerSearch;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwSelectComponent.ngAcceptInputType_dwOpen;
        /** @type {?} */
        DwSelectComponent.prototype.dwSize;
        /** @type {?} */
        DwSelectComponent.prototype.dwOptionHeightPx;
        /** @type {?} */
        DwSelectComponent.prototype.dwOptionOverflowSize;
        /** @type {?} */
        DwSelectComponent.prototype.dwDropdownClassName;
        /** @type {?} */
        DwSelectComponent.prototype.dwDropdownMatchSelectWidth;
        /** @type {?} */
        DwSelectComponent.prototype.dwDropdownStyle;
        /** @type {?} */
        DwSelectComponent.prototype.dwNotFoundContent;
        /** @type {?} */
        DwSelectComponent.prototype.dwPlaceHolder;
        /** @type {?} */
        DwSelectComponent.prototype.dwMaxTagCount;
        /** @type {?} */
        DwSelectComponent.prototype.dwDropdownRender;
        /** @type {?} */
        DwSelectComponent.prototype.dwCustomTemplate;
        /** @type {?} */
        DwSelectComponent.prototype.dwSuffixIcon;
        /** @type {?} */
        DwSelectComponent.prototype.dwClearIcon;
        /** @type {?} */
        DwSelectComponent.prototype.dwRemoveIcon;
        /** @type {?} */
        DwSelectComponent.prototype.dwMenuItemSelectedIcon;
        /** @type {?} */
        DwSelectComponent.prototype.dwShowArrow;
        /** @type {?} */
        DwSelectComponent.prototype.dwTokenSeparators;
        /** @type {?} */
        DwSelectComponent.prototype.dwMaxTagPlaceholder;
        /** @type {?} */
        DwSelectComponent.prototype.dwMaxMultipleCount;
        /** @type {?} */
        DwSelectComponent.prototype.dwMode;
        /** @type {?} */
        DwSelectComponent.prototype.dwFilterOption;
        /** @type {?} */
        DwSelectComponent.prototype.compareWith;
        /** @type {?} */
        DwSelectComponent.prototype.dwAllowClear;
        /** @type {?} */
        DwSelectComponent.prototype.dwBorderless;
        /** @type {?} */
        DwSelectComponent.prototype.dwShowSearch;
        /** @type {?} */
        DwSelectComponent.prototype.dwLoading;
        /** @type {?} */
        DwSelectComponent.prototype.dwAutoFocus;
        /** @type {?} */
        DwSelectComponent.prototype.dwAutoClearSearchValue;
        /** @type {?} */
        DwSelectComponent.prototype.dwServerSearch;
        /** @type {?} */
        DwSelectComponent.prototype.dwDisabled;
        /** @type {?} */
        DwSelectComponent.prototype.dwOpen;
        /** @type {?} */
        DwSelectComponent.prototype.dwOptions;
        /** @type {?} */
        DwSelectComponent.prototype.dwOnSearch;
        /** @type {?} */
        DwSelectComponent.prototype.dwScrollToBottom;
        /** @type {?} */
        DwSelectComponent.prototype.dwOpenChange;
        /** @type {?} */
        DwSelectComponent.prototype.dwBlur;
        /** @type {?} */
        DwSelectComponent.prototype.dwFocus;
        /** @type {?} */
        DwSelectComponent.prototype.originElement;
        /** @type {?} */
        DwSelectComponent.prototype.cdkConnectedOverlay;
        /** @type {?} */
        DwSelectComponent.prototype.dwSelectTopControlComponent;
        /** @type {?} */
        DwSelectComponent.prototype.listOfDwOptionComponent;
        /** @type {?} */
        DwSelectComponent.prototype.listOfDwOptionGroupComponent;
        /** @type {?} */
        DwSelectComponent.prototype.dwOptionGroupComponentElement;
        /** @type {?} */
        DwSelectComponent.prototype.dwSelectTopControlComponentElement;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.listOfValue$;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.listOfTemplateItem$;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.listOfTagAndTemplateItem;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.searchValue;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.isReactiveDriven;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.value;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.destroy$;
        /** @type {?} */
        DwSelectComponent.prototype.onChange;
        /** @type {?} */
        DwSelectComponent.prototype.onTouched;
        /** @type {?} */
        DwSelectComponent.prototype.dropDownPosition;
        /** @type {?} */
        DwSelectComponent.prototype.triggerWidth;
        /** @type {?} */
        DwSelectComponent.prototype.listOfContainerItem;
        /** @type {?} */
        DwSelectComponent.prototype.listOfTopItem;
        /** @type {?} */
        DwSelectComponent.prototype.activatedValue;
        /** @type {?} */
        DwSelectComponent.prototype.listOfValue;
        /** @type {?} */
        DwSelectComponent.prototype.focused;
        /** @type {?} */
        DwSelectComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.platform;
        /**
         * @type {?}
         * @private
         */
        DwSelectComponent.prototype.focusMonitor;
        /** @type {?} */
        DwSelectComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: option-item-group.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionItemGroupComponent = /** @class */ (function () {
        function DwOptionItemGroupComponent() {
            this.dwLabel = null;
        }
        DwOptionItemGroupComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-option-item-group',
                        template: " <ng-container *dwStringTemplateOutlet=\"dwLabel\">{{ dwLabel }}</ng-container> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        host: {
                            '[class.ant-select-item]': 'true',
                            '[class.ant-select-item-group]': 'true'
                        }
                    }] }
        ];
        DwOptionItemGroupComponent.propDecorators = {
            dwLabel: [{ type: core.Input }]
        };
        return DwOptionItemGroupComponent;
    }());
    if (false) {
        /** @type {?} */
        DwOptionItemGroupComponent.prototype.dwLabel;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: option-item.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionItemComponent = /** @class */ (function () {
        function DwOptionItemComponent() {
            this.selected = false;
            this.activated = false;
            this.grouped = false;
            this.customContent = false;
            this.template = null;
            this.disabled = false;
            this.showState = false;
            this.label = null;
            this.value = null;
            this.activatedValue = null;
            this.listOfSelectedValue = [];
            this.icon = null;
            this.itemClick = new core.EventEmitter();
            this.itemHover = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        DwOptionItemComponent.prototype.onHostMouseEnter = /**
         * @return {?}
         */
        function () {
            if (!this.disabled) {
                this.itemHover.next(this.value);
            }
        };
        /**
         * @return {?}
         */
        DwOptionItemComponent.prototype.onHostClick = /**
         * @return {?}
         */
        function () {
            if (!this.disabled) {
                this.itemClick.next(this.value);
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwOptionItemComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            var value = changes.value, activatedValue = changes.activatedValue, listOfSelectedValue = changes.listOfSelectedValue;
            if (value || listOfSelectedValue) {
                this.selected = this.listOfSelectedValue.some((/**
                 * @param {?} v
                 * @return {?}
                 */
                function (v) { return _this.compareWith(v, _this.value); }));
            }
            if (value || activatedValue) {
                this.activated = this.compareWith(this.activatedValue, this.value);
            }
        };
        DwOptionItemComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-option-item',
                        template: "\n    <div class=\"ant-select-item-option-content\">\n      <ng-container *ngIf=\"!customContent\">{{ label }}</ng-container>\n      <ng-container *ngIf=\"customContent\">\n        <ng-template [ngTemplateOutlet]=\"template\"></ng-template>\n      </ng-container>\n    </div>\n    <div *ngIf=\"showState && selected\" class=\"ant-select-item-option-state\" style=\"user-select: none\" unselectable=\"on\">\n      <i dw-icon dwType=\"check\" class=\"ant-select-selected-icon\" *ngIf=\"!icon; else icon\"></i>\n    </div>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        host: {
                            '[class.ant-select-item]': 'true',
                            '[class.ant-select-item-option]': 'true',
                            '[class.ant-select-item-option-grouped]': 'grouped',
                            '[class.ant-select-item-option-selected]': 'selected && !disabled',
                            '[class.ant-select-item-option-disabled]': 'disabled',
                            '[class.ant-select-item-option-active]': 'activated && !disabled',
                            '(mouseenter)': 'onHostMouseEnter()',
                            '(click)': 'onHostClick()'
                        }
                    }] }
        ];
        DwOptionItemComponent.propDecorators = {
            grouped: [{ type: core.Input }],
            customContent: [{ type: core.Input }],
            template: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            showState: [{ type: core.Input }],
            label: [{ type: core.Input }],
            value: [{ type: core.Input }],
            activatedValue: [{ type: core.Input }],
            listOfSelectedValue: [{ type: core.Input }],
            icon: [{ type: core.Input }],
            compareWith: [{ type: core.Input }],
            itemClick: [{ type: core.Output }],
            itemHover: [{ type: core.Output }]
        };
        return DwOptionItemComponent;
    }());
    if (false) {
        /** @type {?} */
        DwOptionItemComponent.prototype.selected;
        /** @type {?} */
        DwOptionItemComponent.prototype.activated;
        /** @type {?} */
        DwOptionItemComponent.prototype.grouped;
        /** @type {?} */
        DwOptionItemComponent.prototype.customContent;
        /** @type {?} */
        DwOptionItemComponent.prototype.template;
        /** @type {?} */
        DwOptionItemComponent.prototype.disabled;
        /** @type {?} */
        DwOptionItemComponent.prototype.showState;
        /** @type {?} */
        DwOptionItemComponent.prototype.label;
        /** @type {?} */
        DwOptionItemComponent.prototype.value;
        /** @type {?} */
        DwOptionItemComponent.prototype.activatedValue;
        /** @type {?} */
        DwOptionItemComponent.prototype.listOfSelectedValue;
        /** @type {?} */
        DwOptionItemComponent.prototype.icon;
        /** @type {?} */
        DwOptionItemComponent.prototype.compareWith;
        /** @type {?} */
        DwOptionItemComponent.prototype.itemClick;
        /** @type {?} */
        DwOptionItemComponent.prototype.itemHover;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-arrow.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectArrowComponent = /** @class */ (function () {
        function DwSelectArrowComponent() {
            this.loading = false;
            this.search = false;
            this.suffixIcon = null;
        }
        DwSelectArrowComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-arrow',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <i dw-icon dwType=\"loading\" *ngIf=\"loading; else defaultArrow\"></i>\n    <ng-template #defaultArrow>\n      <ng-container *ngIf=\"!suffixIcon; else suffixTemplate\">\n        <i dw-icon dwType=\"down\" *ngIf=\"!search\"></i>\n        <i dw-icon dwType=\"search\" *ngIf=\"search\"></i>\n      </ng-container>\n      <ng-template #suffixTemplate>\n        <ng-container *dwStringTemplateOutlet=\"suffixIcon; let suffixIcon\">\n          <i dw-icon [dwType]=\"suffixIcon\"></i>\n        </ng-container>\n      </ng-template>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-select-arrow]': 'true',
                            '[class.ant-select-arrow-loading]': 'loading'
                        }
                    }] }
        ];
        DwSelectArrowComponent.propDecorators = {
            loading: [{ type: core.Input }],
            search: [{ type: core.Input }],
            suffixIcon: [{ type: core.Input }]
        };
        return DwSelectArrowComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectArrowComponent.prototype.loading;
        /** @type {?} */
        DwSelectArrowComponent.prototype.search;
        /** @type {?} */
        DwSelectArrowComponent.prototype.suffixIcon;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-clear.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectClearComponent = /** @class */ (function () {
        function DwSelectClearComponent() {
            this.clearIcon = null;
            this.clear = new core.EventEmitter();
        }
        /**
         * @param {?} e
         * @return {?}
         */
        DwSelectClearComponent.prototype.onClick = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            e.preventDefault();
            e.stopPropagation();
            this.clear.emit(e);
        };
        DwSelectClearComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-clear',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <i dw-icon dwType=\"close-circle\" dwTheme=\"fill\" *ngIf=\"!clearIcon; else clearIcon\" class=\"ant-select-close-icon\"></i> ",
                        host: {
                            '(click)': 'onClick($event)',
                            '[class.ant-select-clear]': 'true'
                        }
                    }] }
        ];
        DwSelectClearComponent.propDecorators = {
            clearIcon: [{ type: core.Input }],
            clear: [{ type: core.Output }]
        };
        return DwSelectClearComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectClearComponent.prototype.clearIcon;
        /** @type {?} */
        DwSelectClearComponent.prototype.clear;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-item.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectItemComponent = /** @class */ (function () {
        function DwSelectItemComponent() {
            this.disabled = false;
            this.label = null;
            this.deletable = false;
            this.removeIcon = null;
            this.contentTemplateOutletContext = null;
            this.contentTemplateOutlet = null;
            this.delete = new core.EventEmitter();
        }
        /**
         * @param {?} e
         * @return {?}
         */
        DwSelectItemComponent.prototype.onDelete = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (!this.disabled) {
                this.delete.next(e);
            }
        };
        DwSelectItemComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-item',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-container *dwStringTemplateOutlet=\"contentTemplateOutlet; context: { $implicit: contentTemplateOutletContext }\">\n      <div class=\"ant-select-selection-item-content\" *ngIf=\"deletable; else labelTemplate\">{{ label }}</div>\n      <ng-template #labelTemplate>{{ label }}</ng-template>\n    </ng-container>\n    <span *ngIf=\"deletable && !disabled\" class=\"ant-select-selection-item-remove\" (click)=\"onDelete($event)\">\n      <i dw-icon dwType=\"close\" *ngIf=\"!removeIcon; else removeIcon\"></i>\n    </span>\n  ",
                        host: {
                            '[attr.title]': 'label',
                            '[class.ant-select-selection-item]': 'true',
                            '[class.ant-select-selection-item-disabled]': 'disabled'
                        }
                    }] }
        ];
        DwSelectItemComponent.propDecorators = {
            disabled: [{ type: core.Input }],
            label: [{ type: core.Input }],
            deletable: [{ type: core.Input }],
            removeIcon: [{ type: core.Input }],
            contentTemplateOutletContext: [{ type: core.Input }],
            contentTemplateOutlet: [{ type: core.Input }],
            delete: [{ type: core.Output }]
        };
        return DwSelectItemComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectItemComponent.prototype.disabled;
        /** @type {?} */
        DwSelectItemComponent.prototype.label;
        /** @type {?} */
        DwSelectItemComponent.prototype.deletable;
        /** @type {?} */
        DwSelectItemComponent.prototype.removeIcon;
        /** @type {?} */
        DwSelectItemComponent.prototype.contentTemplateOutletContext;
        /** @type {?} */
        DwSelectItemComponent.prototype.contentTemplateOutlet;
        /** @type {?} */
        DwSelectItemComponent.prototype.delete;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select-placeholder.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectPlaceholderComponent = /** @class */ (function () {
        function DwSelectPlaceholderComponent() {
            this.placeholder = null;
        }
        DwSelectPlaceholderComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-select-placeholder',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-container *dwStringTemplateOutlet=\"placeholder\">\n      {{ placeholder }}\n    </ng-container>\n  ",
                        host: {
                            '[class.ant-select-selection-placeholder]': 'true'
                        }
                    }] }
        ];
        DwSelectPlaceholderComponent.propDecorators = {
            placeholder: [{ type: core.Input }]
        };
        return DwSelectPlaceholderComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSelectPlaceholderComponent.prototype.placeholder;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: select.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSelectModule = /** @class */ (function () {
        function DwSelectModule() {
        }
        DwSelectModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            i18n.DwI18nModule,
                            forms.FormsModule,
                            platform.PlatformModule,
                            overlay.OverlayModule,
                            icon.DwIconModule,
                            outlet.DwOutletModule,
                            empty.DwEmptyModule,
                            overlay$1.DwOverlayModule,
                            noAnimation.DwNoAnimationModule,
                            transitionPatch.ɵDwTransitionPatchModule,
                            scrolling.ScrollingModule,
                            a11y.A11yModule
                        ],
                        declarations: [
                            DwOptionComponent,
                            DwSelectComponent,
                            DwOptionContainerComponent,
                            DwOptionGroupComponent,
                            DwOptionItemComponent,
                            DwSelectTopControlComponent,
                            DwSelectSearchComponent,
                            DwSelectItemComponent,
                            DwSelectClearComponent,
                            DwSelectArrowComponent,
                            DwSelectPlaceholderComponent,
                            DwOptionItemGroupComponent
                        ],
                        exports: [
                            DwOptionComponent,
                            DwSelectComponent,
                            DwOptionGroupComponent,
                            DwSelectArrowComponent,
                            DwSelectClearComponent,
                            DwSelectItemComponent,
                            DwSelectPlaceholderComponent,
                            DwSelectSearchComponent
                        ]
                    },] }
        ];
        return DwSelectModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: select.types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function DwSelectItemInterface() { }
    if (false) {
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.template;
        /** @type {?} */
        DwSelectItemInterface.prototype.dwLabel;
        /** @type {?} */
        DwSelectItemInterface.prototype.dwValue;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.dwDisabled;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.dwHide;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.dwCustomContent;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.groupLabel;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.type;
        /** @type {?|undefined} */
        DwSelectItemInterface.prototype.key;
    }
    /**
     * @record
     */
    function DwSelectOptionInterface() { }
    if (false) {
        /** @type {?} */
        DwSelectOptionInterface.prototype.label;
        /** @type {?} */
        DwSelectOptionInterface.prototype.value;
        /** @type {?|undefined} */
        DwSelectOptionInterface.prototype.disabled;
        /** @type {?|undefined} */
        DwSelectOptionInterface.prototype.hide;
        /** @type {?|undefined} */
        DwSelectOptionInterface.prototype.groupLabel;
    }

    exports.DwOptionComponent = DwOptionComponent;
    exports.DwOptionContainerComponent = DwOptionContainerComponent;
    exports.DwOptionGroupComponent = DwOptionGroupComponent;
    exports.DwOptionItemComponent = DwOptionItemComponent;
    exports.DwOptionItemGroupComponent = DwOptionItemGroupComponent;
    exports.DwSelectArrowComponent = DwSelectArrowComponent;
    exports.DwSelectClearComponent = DwSelectClearComponent;
    exports.DwSelectComponent = DwSelectComponent;
    exports.DwSelectItemComponent = DwSelectItemComponent;
    exports.DwSelectModule = DwSelectModule;
    exports.DwSelectPlaceholderComponent = DwSelectPlaceholderComponent;
    exports.DwSelectSearchComponent = DwSelectSearchComponent;
    exports.DwSelectTopControlComponent = DwSelectTopControlComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-select.umd.js.map
