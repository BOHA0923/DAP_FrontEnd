(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/scrolling'), require('@angular/common'), require('@angular/core'), require('ng-quicksilver/core/highlight'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon'), require('ng-quicksilver/core/tree'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/forms'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/config')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/tree', ['exports', '@angular/cdk/scrolling', '@angular/common', '@angular/core', 'ng-quicksilver/core/highlight', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon', 'ng-quicksilver/core/tree', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/forms', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/config'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].tree = {}), global.ng.cdk.scrolling, global.ng.common, global.ng.core, global['ng-quicksilver'].core.highlight, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon, global['ng-quicksilver'].core.tree, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.forms, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core.config));
}(this, (function (exports, scrolling, common, core, highlight, noAnimation, outlet, icon, tree, util, rxjs, operators, forms, animation, config) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-indent.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeIndentComponent = /** @class */ (function () {
        function DwTreeIndentComponent() {
            this.dwSelectMode = false;
            this.listOfUnit = [];
        }
        /**
         * @param {?} index
         * @return {?}
         */
        DwTreeIndentComponent.prototype.unitMapOfClass = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            var _a;
            return _a = {},
                _a["ant-tree-indent-unit"] = !this.dwSelectMode,
                _a["ant-tree-indent-unit-start"] = !this.dwSelectMode && (/** @type {?} */ (this.dwIsStart))[index + 1],
                _a["ant-tree-indent-unit-end"] = !this.dwSelectMode && (/** @type {?} */ (this.dwIsEnd))[index + 1],
                _a["ant-select-tree-indent-unit"] = this.dwSelectMode,
                _a["ant-select-tree-indent-unit-start"] = this.dwSelectMode && (/** @type {?} */ (this.dwIsStart))[index + 1],
                _a["ant-select-tree-indent-unit-end"] = this.dwSelectMode && (/** @type {?} */ (this.dwIsEnd))[index + 1],
                _a;
        };
        /**
         * @return {?}
         */
        DwTreeIndentComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () { };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTreeIndentComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwTreeLevel = changes.dwTreeLevel;
            if (dwTreeLevel) {
                this.listOfUnit = __spread(new Array(dwTreeLevel.currentValue || 0));
            }
        };
        DwTreeIndentComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-indent',
                        exportAs: 'dwTreeIndent',
                        template: " <span *ngFor=\"let i of listOfUnit; let index = index\" [ngClass]=\"unitMapOfClass(index)\"></span> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        host: {
                            '[attr.aria-hidden]': 'true',
                            '[class.ant-tree-indent]': '!dwSelectMode',
                            '[class.ant-select-tree-indent]': 'dwSelectMode'
                        }
                    }] }
        ];
        DwTreeIndentComponent.propDecorators = {
            dwTreeLevel: [{ type: core.Input }],
            dwIsStart: [{ type: core.Input }],
            dwIsEnd: [{ type: core.Input }],
            dwSelectMode: [{ type: core.Input }]
        };
        return DwTreeIndentComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTreeIndentComponent.prototype.dwTreeLevel;
        /** @type {?} */
        DwTreeIndentComponent.prototype.dwIsStart;
        /** @type {?} */
        DwTreeIndentComponent.prototype.dwIsEnd;
        /** @type {?} */
        DwTreeIndentComponent.prototype.dwSelectMode;
        /** @type {?} */
        DwTreeIndentComponent.prototype.listOfUnit;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-node-checkbox.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeNodeCheckboxComponent = /** @class */ (function () {
        function DwTreeNodeCheckboxComponent() {
            this.dwSelectMode = false;
        }
        DwTreeNodeCheckboxComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-node-checkbox',
                        template: " <span [class.ant-tree-checkbox-inner]=\"!dwSelectMode\" [class.ant-select-tree-checkbox-inner]=\"dwSelectMode\"></span> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        host: {
                            '[class.ant-select-tree-checkbox]': "dwSelectMode",
                            '[class.ant-select-tree-checkbox-checked]': "dwSelectMode && isChecked",
                            '[class.ant-select-tree-checkbox-indeterminate]': "dwSelectMode && isHalfChecked",
                            '[class.ant-select-tree-checkbox-disabled]': "dwSelectMode && (isDisabled || isDisableCheckbox)",
                            '[class.ant-tree-checkbox]': "!dwSelectMode",
                            '[class.ant-tree-checkbox-checked]': "!dwSelectMode && isChecked",
                            '[class.ant-tree-checkbox-indeterminate]': "!dwSelectMode && isHalfChecked",
                            '[class.ant-tree-checkbox-disabled]': "!dwSelectMode && (isDisabled || isDisableCheckbox)"
                        }
                    }] }
        ];
        DwTreeNodeCheckboxComponent.propDecorators = {
            dwSelectMode: [{ type: core.Input }],
            isChecked: [{ type: core.Input }],
            isHalfChecked: [{ type: core.Input }],
            isDisabled: [{ type: core.Input }],
            isDisableCheckbox: [{ type: core.Input }]
        };
        return DwTreeNodeCheckboxComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTreeNodeCheckboxComponent.prototype.dwSelectMode;
        /** @type {?} */
        DwTreeNodeCheckboxComponent.prototype.isChecked;
        /** @type {?} */
        DwTreeNodeCheckboxComponent.prototype.isHalfChecked;
        /** @type {?} */
        DwTreeNodeCheckboxComponent.prototype.isDisabled;
        /** @type {?} */
        DwTreeNodeCheckboxComponent.prototype.isDisableCheckbox;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-node-switcher.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeNodeSwitcherComponent = /** @class */ (function () {
        function DwTreeNodeSwitcherComponent() {
            this.dwSelectMode = false;
        }
        Object.defineProperty(DwTreeNodeSwitcherComponent.prototype, "isShowLineIcon", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isLeaf && !!this.dwShowLine;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeSwitcherComponent.prototype, "isShowSwitchIcon", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isLeaf && !this.dwShowLine;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeSwitcherComponent.prototype, "isSwitcherOpen", {
            get: /**
             * @return {?}
             */
            function () {
                return !!this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeSwitcherComponent.prototype, "isSwitcherClose", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        DwTreeNodeSwitcherComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-node-switcher',
                        template: "\n    <ng-container *ngIf=\"isShowSwitchIcon\">\n      <ng-container *ngIf=\"!isLoading; else loadingTemplate\">\n        <ng-container *dwStringTemplateOutlet=\"dwExpandedIcon; context: { $implicit: context, origin: context.origin }\">\n          <i\n            dw-icon\n            dwType=\"caret-down\"\n            [class.ant-select-tree-switcher-icon]=\"dwSelectMode\"\n            [class.ant-tree-switcher-icon]=\"!dwSelectMode\"\n          ></i>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n    <ng-container *ngIf=\"dwShowLine\">\n      <ng-container *ngIf=\"!isLoading; else loadingTemplate\">\n        <ng-container *dwStringTemplateOutlet=\"dwExpandedIcon; context: { $implicit: context, origin: context.origin }\">\n          <i\n            *ngIf=\"isShowLineIcon\"\n            dw-icon\n            [dwType]=\"isSwitcherOpen ? 'minus-square' : 'plus-square'\"\n            class=\"ant-tree-switcher-line-icon\"\n          ></i>\n          <i *ngIf=\"!isShowLineIcon\" dw-icon dwType=\"file\" class=\"ant-tree-switcher-line-icon\"></i>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n    <ng-template #loadingTemplate>\n      <i dw-icon dwType=\"loading\" [dwSpin]=\"true\" class=\"ant-tree-switcher-loading-icon\"></i>\n    </ng-template>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        host: {
                            '[class.ant-select-tree-switcher]': 'dwSelectMode',
                            '[class.ant-select-tree-switcher-noop]': 'dwSelectMode && isLeaf',
                            '[class.ant-select-tree-switcher_open]': 'dwSelectMode && isSwitcherOpen',
                            '[class.ant-select-tree-switcher_close]': 'dwSelectMode && isSwitcherClose',
                            '[class.ant-tree-switcher]': '!dwSelectMode',
                            '[class.ant-tree-switcher-noop]': '!dwSelectMode && isLeaf',
                            '[class.ant-tree-switcher_open]': '!dwSelectMode && isSwitcherOpen',
                            '[class.ant-tree-switcher_close]': '!dwSelectMode && isSwitcherClose'
                        }
                    }] }
        ];
        DwTreeNodeSwitcherComponent.propDecorators = {
            dwShowExpand: [{ type: core.Input }],
            dwShowLine: [{ type: core.Input }],
            dwExpandedIcon: [{ type: core.Input }],
            dwSelectMode: [{ type: core.Input }],
            context: [{ type: core.Input }],
            isLeaf: [{ type: core.Input }],
            isLoading: [{ type: core.Input }],
            isExpanded: [{ type: core.Input }]
        };
        return DwTreeNodeSwitcherComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.dwShowExpand;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.dwShowLine;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.dwExpandedIcon;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.dwSelectMode;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.context;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.isLeaf;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.isLoading;
        /** @type {?} */
        DwTreeNodeSwitcherComponent.prototype.isExpanded;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-node-title.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeNodeTitleComponent = /** @class */ (function () {
        function DwTreeNodeTitleComponent() {
            this.treeTemplate = null;
            this.selectMode = false;
        }
        Object.defineProperty(DwTreeNodeTitleComponent.prototype, "canDraggable", {
            get: /**
             * @return {?}
             */
            function () {
                return this.draggable && !this.isDisabled ? true : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeTitleComponent.prototype, "matchedValue", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isMatched ? this.searchValue : '';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeTitleComponent.prototype, "isSwitcherOpen", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeTitleComponent.prototype, "isSwitcherClose", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        DwTreeNodeTitleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-node-title',
                        template: " <ng-template [ngTemplateOutlet]=\"treeTemplate\" [ngTemplateOutletContext]=\"{ $implicit: context, origin: context.origin }\">\n    </ng-template>\n    <ng-container *ngIf=\"!treeTemplate\">\n      <span\n        *ngIf=\"icon && showIcon\"\n        [class.ant-tree-icon__open]=\"isSwitcherOpen\"\n        [class.ant-tree-icon__close]=\"isSwitcherClose\"\n        [class.ant-tree-icon_loading]=\"isLoading\"\n        [class.ant-select-tree-iconEle]=\"selectMode\"\n        [class.ant-tree-iconEle]=\"!selectMode\"\n      >\n        <span\n          [class.ant-select-tree-iconEle]=\"selectMode\"\n          [class.ant-select-tree-icon__customize]=\"selectMode\"\n          [class.ant-tree-iconEle]=\"!selectMode\"\n          [class.ant-tree-icon__customize]=\"!selectMode\"\n        >\n          <i dw-icon *ngIf=\"icon\" [dwType]=\"icon\"></i>\n        </span>\n      </span>\n      <span class=\"ant-tree-title\" [innerHTML]=\"title | dwHighlight: matchedValue:'i':'font-highlight'\"> </span>\n    </ng-container>",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        host: {
                            '[attr.title]': 'title',
                            '[attr.draggable]': 'canDraggable',
                            '[attr.aria-grabbed]': 'canDraggable',
                            '[class.draggable]': 'canDraggable',
                            '[class.ant-select-tree-node-content-wrapper]': "selectMode",
                            '[class.ant-select-tree-node-content-wrapper-open]': "selectMode && isSwitcherOpen",
                            '[class.ant-select-tree-node-content-wrapper-close]': "selectMode && isSwitcherClose",
                            '[class.ant-select-tree-node-selected]': "selectMode && isSelected",
                            '[class.ant-tree-node-content-wrapper]': "!selectMode",
                            '[class.ant-tree-node-content-wrapper-open]': "!selectMode && isSwitcherOpen",
                            '[class.ant-tree-node-content-wrapper-close]': "!selectMode && isSwitcherClose",
                            '[class.ant-tree-node-selected]': "!selectMode && isSelected"
                        }
                    }] }
        ];
        DwTreeNodeTitleComponent.propDecorators = {
            searchValue: [{ type: core.Input }],
            treeTemplate: [{ type: core.Input }],
            draggable: [{ type: core.Input }],
            showIcon: [{ type: core.Input }],
            selectMode: [{ type: core.Input }],
            context: [{ type: core.Input }],
            icon: [{ type: core.Input }],
            title: [{ type: core.Input }],
            isLoading: [{ type: core.Input }],
            isSelected: [{ type: core.Input }],
            isDisabled: [{ type: core.Input }],
            isMatched: [{ type: core.Input }],
            isExpanded: [{ type: core.Input }],
            isLeaf: [{ type: core.Input }]
        };
        return DwTreeNodeTitleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.searchValue;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.treeTemplate;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.draggable;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.showIcon;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.selectMode;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.context;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.icon;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.title;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isLoading;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isSelected;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isDisabled;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isMatched;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isExpanded;
        /** @type {?} */
        DwTreeNodeTitleComponent.prototype.isLeaf;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-node.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeNodeComponent = /** @class */ (function () {
        function DwTreeNodeComponent(dwTreeService, ngZone, renderer, elementRef, cdr, noAnimation) {
            this.dwTreeService = dwTreeService;
            this.ngZone = ngZone;
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.cdr = cdr;
            this.noAnimation = noAnimation;
            /**
             * for global property
             */
            this.icon = '';
            this.title = '';
            this.isLoading = false;
            this.isSelected = false;
            this.isDisabled = false;
            this.isMatched = false;
            this.dwHideUnMatched = false;
            this.dwNoAnimation = false;
            this.dwSelectMode = false;
            this.dwShowIcon = false;
            this.dwTreeTemplate = null;
            this.dwSearchValue = '';
            this.dwDraggable = false;
            this.dwClick = new core.EventEmitter();
            this.dwDblClick = new core.EventEmitter();
            this.dwContextMenu = new core.EventEmitter();
            this.dwCheckBoxChange = new core.EventEmitter();
            this.dwExpandChange = new core.EventEmitter();
            this.dwOnDragStart = new core.EventEmitter();
            this.dwOnDragEnter = new core.EventEmitter();
            this.dwOnDragOver = new core.EventEmitter();
            this.dwOnDragLeave = new core.EventEmitter();
            this.dwOnDrop = new core.EventEmitter();
            this.dwOnDragEnd = new core.EventEmitter();
            /**
             * drag var
             */
            this.destroy$ = new rxjs.Subject();
            this.dragPos = 2;
            this.dragPosClass = {
                '0': 'drag-over',
                '1': 'drag-over-gap-bottom',
                '-1': 'drag-over-gap-top'
            };
        }
        Object.defineProperty(DwTreeNodeComponent.prototype, "displayStyle", {
            /**
             * default set
             */
            get: /**
             * default set
             * @return {?}
             */
            function () {
                // to hide unmatched nodes
                return this.dwSearchValue && this.dwHideUnMatched && !this.isMatched && !this.isExpanded && this.canHide ? 'none' : '';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeComponent.prototype, "isSwitcherOpen", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeNodeComponent.prototype, "isSwitcherClose", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isExpanded && !this.isLeaf;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.onMousedown = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            if (this.dwSelectMode) {
                event.preventDefault();
            }
        };
        /**
         * collapse node
         * @param event
         */
        /**
         * collapse node
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.clickExpand = /**
         * collapse node
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            if (!this.isLoading && !this.isLeaf) {
                // set async state
                if (this.dwAsyncData && this.dwTreeNode.children.length === 0 && !this.isExpanded) {
                    this.dwTreeNode.isLoading = true;
                }
                this.dwTreeNode.setExpanded(!this.isExpanded);
            }
            this.dwTreeService.setExpandedNodeList(this.dwTreeNode);
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('expand', this.dwTreeNode, event);
            this.dwExpandChange.emit(eventNext);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.clickSelect = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            if (this.isSelectable && !this.isDisabled) {
                this.dwTreeNode.isSelected = !this.dwTreeNode.isSelected;
            }
            this.dwTreeService.setSelectedNodeList(this.dwTreeNode);
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('click', this.dwTreeNode, event);
            this.dwClick.emit(eventNext);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.dblClick = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('dblclick', this.dwTreeNode, event);
            this.dwDblClick.emit(eventNext);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.contextMenu = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('contextmenu', this.dwTreeNode, event);
            this.dwContextMenu.emit(eventNext);
        };
        /**
         * check node
         * @param event
         */
        /**
         * check node
         * @param {?} event
         * @return {?}
         */
        DwTreeNodeComponent.prototype.clickCheckBox = /**
         * check node
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            // return if node is disabled
            if (this.isDisabled || this.isDisableCheckbox) {
                return;
            }
            this.dwTreeNode.isChecked = !this.dwTreeNode.isChecked;
            this.dwTreeNode.isHalfChecked = false;
            this.dwTreeService.setCheckedNodeList(this.dwTreeNode);
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('check', this.dwTreeNode, event);
            this.dwCheckBoxChange.emit(eventNext);
        };
        /**
         * @return {?}
         */
        DwTreeNodeComponent.prototype.clearDragClass = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var dragClass = ['drag-over-gap-top', 'drag-over-gap-bottom', 'drag-over'];
            dragClass.forEach((/**
             * @param {?} e
             * @return {?}
             */
            function (e) {
                _this.renderer.removeClass(_this.elementRef.nativeElement, e);
            }));
        };
        /**
         * drag event
         * @param e
         */
        /**
         * drag event
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragStart = /**
         * drag event
         * @param {?} e
         * @return {?}
         */
        function (e) {
            try {
                // ie throw error
                // firefox-need-it
                (/** @type {?} */ (e.dataTransfer)).setData('text/plain', (/** @type {?} */ (this.dwTreeNode.key)));
            }
            catch (error) {
                // empty
            }
            this.dwTreeService.setSelectedNode(this.dwTreeNode);
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('dragstart', this.dwTreeNode, e);
            this.dwOnDragStart.emit(eventNext);
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragEnter = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            var _this = this;
            e.preventDefault();
            // reset position
            this.dragPos = 2;
            this.ngZone.run((/**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var eventNext = _this.dwTreeService.formatEvent('dragenter', _this.dwTreeNode, e);
                _this.dwOnDragEnter.emit(eventNext);
            }));
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragOver = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            e.preventDefault();
            /** @type {?} */
            var dropPosition = this.dwTreeService.calcDropPosition(e);
            if (this.dragPos !== dropPosition) {
                this.clearDragClass();
                this.dragPos = dropPosition;
                // leaf node will pass
                if (!(this.dragPos === 0 && this.isLeaf)) {
                    this.renderer.addClass(this.elementRef.nativeElement, this.dragPosClass[this.dragPos]);
                }
            }
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('dragover', this.dwTreeNode, e);
            this.dwOnDragOver.emit(eventNext);
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragLeave = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            e.preventDefault();
            this.clearDragClass();
            /** @type {?} */
            var eventNext = this.dwTreeService.formatEvent('dragleave', this.dwTreeNode, e);
            this.dwOnDragLeave.emit(eventNext);
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragDrop = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            var _this = this;
            this.ngZone.run((/**
             * @return {?}
             */
            function () {
                _this.clearDragClass();
                /** @type {?} */
                var node = _this.dwTreeService.getSelectedNode();
                if (!node || (node && node.key === _this.dwTreeNode.key) || (_this.dragPos === 0 && _this.isLeaf)) {
                    return;
                }
                // pass if node is leafNo
                /** @type {?} */
                var dropEvent = _this.dwTreeService.formatEvent('drop', _this.dwTreeNode, e);
                /** @type {?} */
                var dragEndEvent = _this.dwTreeService.formatEvent('dragend', _this.dwTreeNode, e);
                if (_this.dwBeforeDrop) {
                    _this.dwBeforeDrop({
                        dragNode: (/** @type {?} */ (_this.dwTreeService.getSelectedNode())),
                        node: _this.dwTreeNode,
                        pos: _this.dragPos
                    }).subscribe((/**
                     * @param {?} canDrop
                     * @return {?}
                     */
                    function (canDrop) {
                        if (canDrop) {
                            _this.dwTreeService.dropAndApply(_this.dwTreeNode, _this.dragPos);
                        }
                        _this.dwOnDrop.emit(dropEvent);
                        _this.dwOnDragEnd.emit(dragEndEvent);
                    }));
                }
                else if (_this.dwTreeNode) {
                    _this.dwTreeService.dropAndApply(_this.dwTreeNode, _this.dragPos);
                    _this.dwOnDrop.emit(dropEvent);
                }
            }));
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handleDragEnd = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            var _this = this;
            e.preventDefault();
            this.ngZone.run((/**
             * @return {?}
             */
            function () {
                // if user do not custom beforeDrop
                if (!_this.dwBeforeDrop) {
                    /** @type {?} */
                    var eventNext = _this.dwTreeService.formatEvent('dragend', _this.dwTreeNode, e);
                    _this.dwOnDragEnd.emit(eventNext);
                }
            }));
        };
        /**
         * Listening to dragging events.
         */
        /**
         * Listening to dragging events.
         * @return {?}
         */
        DwTreeNodeComponent.prototype.handDragEvent = /**
         * Listening to dragging events.
         * @return {?}
         */
        function () {
            var _this = this;
            this.ngZone.runOutsideAngular((/**
             * @return {?}
             */
            function () {
                if (_this.dwDraggable) {
                    /** @type {?} */
                    var nativeElement = _this.elementRef.nativeElement;
                    _this.destroy$ = new rxjs.Subject();
                    rxjs.fromEvent(nativeElement, 'dragstart')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragStart(e); }));
                    rxjs.fromEvent(nativeElement, 'dragenter')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragEnter(e); }));
                    rxjs.fromEvent(nativeElement, 'dragover')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragOver(e); }));
                    rxjs.fromEvent(nativeElement, 'dragleave')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragLeave(e); }));
                    rxjs.fromEvent(nativeElement, 'drop')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragDrop(e); }));
                    rxjs.fromEvent(nativeElement, 'dragend')
                        .pipe(operators.takeUntil(_this.destroy$))
                        .subscribe((/**
                     * @param {?} e
                     * @return {?}
                     */
                    function (e) { return _this.handleDragEnd(e); }));
                }
                else {
                    _this.destroy$.next();
                    _this.destroy$.complete();
                }
            }));
        };
        /**
         * @return {?}
         */
        DwTreeNodeComponent.prototype.markForCheck = /**
         * @return {?}
         */
        function () {
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwTreeNodeComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.dwTreeNode.component = this;
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTreeNodeComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwDraggable = changes.dwDraggable;
            if (dwDraggable) {
                this.handDragEvent();
            }
        };
        /**
         * @return {?}
         */
        DwTreeNodeComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTreeNodeComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-node',
                        exportAs: 'dwTreeNode',
                        template: "\n    <dw-tree-indent [dwTreeLevel]=\"dwTreeNode.level\" [dwSelectMode]=\"dwSelectMode\" [dwIsStart]=\"isStart\" [dwIsEnd]=\"isEnd\"></dw-tree-indent>\n    <dw-tree-node-switcher\n      *ngIf=\"dwShowExpand\"\n      [dwShowExpand]=\"dwShowExpand\"\n      [dwShowLine]=\"dwShowLine\"\n      [dwExpandedIcon]=\"dwExpandedIcon\"\n      [dwSelectMode]=\"dwSelectMode\"\n      [context]=\"dwTreeNode\"\n      [isLeaf]=\"isLeaf\"\n      [isExpanded]=\"isExpanded\"\n      [isLoading]=\"isLoading\"\n      (click)=\"clickExpand($event)\"\n    ></dw-tree-node-switcher>\n    <dw-tree-node-checkbox\n      *ngIf=\"dwCheckable\"\n      (click)=\"clickCheckBox($event)\"\n      [dwSelectMode]=\"dwSelectMode\"\n      [isChecked]=\"isChecked\"\n      [isHalfChecked]=\"isHalfChecked\"\n      [isDisabled]=\"isDisabled\"\n      [isDisableCheckbox]=\"isDisableCheckbox\"\n    ></dw-tree-node-checkbox>\n    <dw-tree-node-title\n      [icon]=\"icon\"\n      [title]=\"title\"\n      [isLoading]=\"isLoading\"\n      [isSelected]=\"isSelected\"\n      [isDisabled]=\"isDisabled\"\n      [isMatched]=\"isMatched\"\n      [isExpanded]=\"isExpanded\"\n      [isLeaf]=\"isLeaf\"\n      [searchValue]=\"dwSearchValue\"\n      [treeTemplate]=\"dwTreeTemplate\"\n      [draggable]=\"dwDraggable\"\n      [showIcon]=\"dwShowIcon\"\n      [selectMode]=\"dwSelectMode\"\n      [context]=\"dwTreeNode\"\n      (dblclick)=\"dblClick($event)\"\n      (click)=\"clickSelect($event)\"\n      (contextmenu)=\"contextMenu($event)\"\n    ></dw-tree-node-title>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        host: {
                            '[class.ant-select-tree-treenode]': "dwSelectMode",
                            '[class.ant-select-tree-treenode-disabled]': "dwSelectMode && isDisabled",
                            '[class.ant-select-tree-treenode-switcher-open]': "dwSelectMode && isSwitcherOpen",
                            '[class.ant-select-tree-treenode-switcher-close]': "dwSelectMode && isSwitcherClose",
                            '[class.ant-select-tree-treenode-checkbox-checked]': "dwSelectMode && isChecked",
                            '[class.ant-select-tree-treenode-checkbox-indeterminate]': "dwSelectMode && isHalfChecked",
                            '[class.ant-select-tree-treenode-selected]': "dwSelectMode && isSelected",
                            '[class.ant-select-tree-treenode-loading]': "dwSelectMode && isLoading",
                            '[class.ant-tree-treenode]': "!dwSelectMode",
                            '[class.ant-tree-treenode-disabled]': "!dwSelectMode && isDisabled",
                            '[class.ant-tree-treenode-switcher-open]': "!dwSelectMode && isSwitcherOpen",
                            '[class.ant-tree-treenode-switcher-close]': "!dwSelectMode && isSwitcherClose",
                            '[class.ant-tree-treenode-checkbox-checked]': "!dwSelectMode && isChecked",
                            '[class.ant-tree-treenode-checkbox-indeterminate]': "!dwSelectMode && isHalfChecked",
                            '[class.ant-tree-treenode-selected]': "!dwSelectMode && isSelected",
                            '[class.ant-tree-treenode-loading]': "!dwSelectMode && isLoading",
                            '[style.display]': 'displayStyle',
                            '(mousedown)': 'onMousedown($event)'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTreeNodeComponent.ctorParameters = function () { return [
            { type: tree.DwTreeBaseService },
            { type: core.NgZone },
            { type: core.Renderer2 },
            { type: core.ElementRef },
            { type: core.ChangeDetectorRef },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwTreeNodeComponent.propDecorators = {
            icon: [{ type: core.Input }],
            title: [{ type: core.Input }],
            isLoading: [{ type: core.Input }],
            isSelected: [{ type: core.Input }],
            isDisabled: [{ type: core.Input }],
            isMatched: [{ type: core.Input }],
            isExpanded: [{ type: core.Input }],
            isLeaf: [{ type: core.Input }],
            isChecked: [{ type: core.Input }],
            isHalfChecked: [{ type: core.Input }],
            isDisableCheckbox: [{ type: core.Input }],
            isSelectable: [{ type: core.Input }],
            canHide: [{ type: core.Input }],
            isStart: [{ type: core.Input }],
            isEnd: [{ type: core.Input }],
            dwTreeNode: [{ type: core.Input }],
            dwShowLine: [{ type: core.Input }],
            dwShowExpand: [{ type: core.Input }],
            dwCheckable: [{ type: core.Input }],
            dwAsyncData: [{ type: core.Input }],
            dwHideUnMatched: [{ type: core.Input }],
            dwNoAnimation: [{ type: core.Input }],
            dwSelectMode: [{ type: core.Input }],
            dwShowIcon: [{ type: core.Input }],
            dwExpandedIcon: [{ type: core.Input }],
            dwTreeTemplate: [{ type: core.Input }],
            dwBeforeDrop: [{ type: core.Input }],
            dwSearchValue: [{ type: core.Input }],
            dwDraggable: [{ type: core.Input }],
            dwClick: [{ type: core.Output }],
            dwDblClick: [{ type: core.Output }],
            dwContextMenu: [{ type: core.Output }],
            dwCheckBoxChange: [{ type: core.Output }],
            dwExpandChange: [{ type: core.Output }],
            dwOnDragStart: [{ type: core.Output }],
            dwOnDragEnter: [{ type: core.Output }],
            dwOnDragOver: [{ type: core.Output }],
            dwOnDragLeave: [{ type: core.Output }],
            dwOnDrop: [{ type: core.Output }],
            dwOnDragEnd: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeNodeComponent.prototype, "dwShowLine", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeNodeComponent.prototype, "dwShowExpand", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeNodeComponent.prototype, "dwCheckable", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeNodeComponent.prototype, "dwAsyncData", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeNodeComponent.prototype, "dwHideUnMatched", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeNodeComponent.prototype, "dwNoAnimation", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeNodeComponent.prototype, "dwSelectMode", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeNodeComponent.prototype, "dwShowIcon", void 0);
        return DwTreeNodeComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwShowLine;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwShowExpand;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwCheckable;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwAsyncData;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwHideUnMatched;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwNoAnimation;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwSelectMode;
        /** @type {?} */
        DwTreeNodeComponent.ngAcceptInputType_dwShowIcon;
        /**
         * for global property
         * @type {?}
         */
        DwTreeNodeComponent.prototype.icon;
        /** @type {?} */
        DwTreeNodeComponent.prototype.title;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isLoading;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isSelected;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isDisabled;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isMatched;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isExpanded;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isLeaf;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isChecked;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isHalfChecked;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isDisableCheckbox;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isSelectable;
        /** @type {?} */
        DwTreeNodeComponent.prototype.canHide;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isStart;
        /** @type {?} */
        DwTreeNodeComponent.prototype.isEnd;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwTreeNode;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwShowLine;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwShowExpand;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwCheckable;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwAsyncData;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwHideUnMatched;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwNoAnimation;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwSelectMode;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwShowIcon;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwExpandedIcon;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwTreeTemplate;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwBeforeDrop;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwSearchValue;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwDraggable;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwClick;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwDblClick;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwContextMenu;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwCheckBoxChange;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwExpandChange;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDragStart;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDragEnter;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDragOver;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDragLeave;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDrop;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwOnDragEnd;
        /**
         * drag var
         * @type {?}
         */
        DwTreeNodeComponent.prototype.destroy$;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dragPos;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dragPosClass;
        /** @type {?} */
        DwTreeNodeComponent.prototype.dwTreeService;
        /**
         * @type {?}
         * @private
         */
        DwTreeNodeComponent.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwTreeNodeComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTreeNodeComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTreeNodeComponent.prototype.cdr;
        /** @type {?} */
        DwTreeNodeComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeService = /** @class */ (function (_super) {
        __extends(DwTreeService, _super);
        function DwTreeService() {
            return _super.call(this) || this;
        }
        DwTreeService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwTreeService.ctorParameters = function () { return []; };
        return DwTreeService;
    }(tree.DwTreeBaseService));

    /**
     * @fileoverview added by tsickle
     * Generated from: tree.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} higherOrderService
     * @param {?} treeService
     * @return {?}
     */
    function DwTreeServiceFactory(higherOrderService, treeService) {
        return higherOrderService ? higherOrderService : treeService;
    }
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'tree';
    var DwTreeComponent = /** @class */ (function (_super) {
        __extends(DwTreeComponent, _super);
        // Handle emit event end
        function DwTreeComponent(dwTreeService, dwConfigService, cdr, noAnimation) {
            var _this = _super.call(this, dwTreeService) || this;
            _this.dwConfigService = dwConfigService;
            _this.cdr = cdr;
            _this.noAnimation = noAnimation;
            _this.dwShowIcon = false;
            _this.dwHideUnMatched = false;
            _this.dwBlockNode = false;
            _this.dwExpandAll = false;
            _this.dwSelectMode = false;
            _this.dwCheckStrictly = false;
            _this.dwShowExpand = true;
            _this.dwShowLine = false;
            _this.dwCheckable = false;
            _this.dwAsyncData = false;
            _this.dwDraggable = false;
            _this.dwMultiple = false;
            _this.dwVirtualItemSize = 28;
            _this.dwVirtualMaxBufferPx = 500;
            _this.dwVirtualMinBufferPx = 28;
            _this.dwVirtualHeight = null;
            _this.dwData = [];
            _this.dwExpandedKeys = [];
            _this.dwSelectedKeys = [];
            _this.dwCheckedKeys = [];
            _this.dwFlattenNodes = [];
            _this.beforeInit = true;
            _this.dwExpandedKeysChange = new core.EventEmitter();
            _this.dwSelectedKeysChange = new core.EventEmitter();
            _this.dwCheckedKeysChange = new core.EventEmitter();
            _this.dwSearchValueChange = new core.EventEmitter();
            _this.dwClick = new core.EventEmitter();
            _this.dwDblClick = new core.EventEmitter();
            _this.dwContextMenu = new core.EventEmitter();
            _this.dwCheckBoxChange = new core.EventEmitter();
            _this.dwExpandChange = new core.EventEmitter();
            _this.dwOnDragStart = new core.EventEmitter();
            _this.dwOnDragEnter = new core.EventEmitter();
            _this.dwOnDragOver = new core.EventEmitter();
            _this.dwOnDragLeave = new core.EventEmitter();
            _this.dwOnDrop = new core.EventEmitter();
            _this.dwOnDragEnd = new core.EventEmitter();
            _this.HIDDEN_STYLE = {
                width: 0,
                height: 0,
                display: 'flex',
                overflow: 'hidden',
                opacity: 0,
                border: 0,
                padding: 0,
                margin: 0
            };
            _this.destroy$ = new rxjs.Subject();
            _this.onChange = (/**
             * @return {?}
             */
            function () { return null; });
            _this.onTouched = (/**
             * @return {?}
             */
            function () { return null; });
            return _this;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        DwTreeComponent.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.handleDwData(value);
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTreeComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTreeComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        /**
         * Render all properties of dwTree
         * @param changes: all changes from @Input
         */
        /**
         * Render all properties of dwTree
         * @param {?} changes
         * @return {?}
         */
        DwTreeComponent.prototype.renderTreeProperties = /**
         * Render all properties of dwTree
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            /** @type {?} */
            var useDefaultExpandedKeys = false;
            /** @type {?} */
            var expandAll = false;
            var dwData = changes.dwData, dwExpandedKeys = changes.dwExpandedKeys, dwSelectedKeys = changes.dwSelectedKeys, dwCheckedKeys = changes.dwCheckedKeys, dwCheckStrictly = changes.dwCheckStrictly, dwExpandAll = changes.dwExpandAll, dwMultiple = changes.dwMultiple, dwSearchValue = changes.dwSearchValue;
            if (dwExpandAll) {
                useDefaultExpandedKeys = true;
                expandAll = this.dwExpandAll;
            }
            if (dwMultiple) {
                this.dwTreeService.isMultiple = this.dwMultiple;
            }
            if (dwCheckStrictly) {
                this.dwTreeService.isCheckStrictly = this.dwCheckStrictly;
            }
            if (dwData) {
                this.handleDwData(this.dwData);
            }
            if (dwCheckedKeys) {
                this.handleCheckedKeys(this.dwCheckedKeys);
            }
            if (dwCheckStrictly) {
                this.handleCheckedKeys(null);
            }
            if (dwExpandedKeys || dwExpandAll) {
                useDefaultExpandedKeys = true;
                this.handleExpandedKeys(expandAll || this.dwExpandedKeys);
            }
            if (dwSelectedKeys) {
                this.handleSelectedKeys(this.dwSelectedKeys, this.dwMultiple);
            }
            if (dwSearchValue) {
                if (!(dwSearchValue.firstChange && !this.dwSearchValue)) {
                    useDefaultExpandedKeys = false;
                    this.handleSearchValue(dwSearchValue.currentValue, this.dwSearchFunc);
                    this.dwSearchValueChange.emit(this.dwTreeService.formatEvent('search', null, null));
                }
            }
            // flatten data
            /** @type {?} */
            var currentExpandedKeys = this.getExpandedNodeList().map((/**
             * @param {?} v
             * @return {?}
             */
            function (v) { return v.key; }));
            /** @type {?} */
            var newExpandedKeys = useDefaultExpandedKeys ? expandAll || this.dwExpandedKeys : currentExpandedKeys;
            this.handleFlattenNodes(this.dwTreeService.rootNodes, newExpandedKeys);
        };
        /**
         * @param {?} _
         * @param {?} node
         * @return {?}
         */
        DwTreeComponent.prototype.trackByFlattenNode = /**
         * @param {?} _
         * @param {?} node
         * @return {?}
         */
        function (_, node) {
            return node.key;
        };
        // Deal with properties
        /**
         * dwData
         * @param value
         */
        // Deal with properties
        /**
         * dwData
         * @param {?} value
         * @return {?}
         */
        DwTreeComponent.prototype.handleDwData = 
        // Deal with properties
        /**
         * dwData
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (Array.isArray(value)) {
                /** @type {?} */
                var data = this.coerceTreeNodes(value);
                this.dwTreeService.initTree(data);
            }
        };
        /**
         * @param {?} data
         * @param {?=} expandKeys
         * @return {?}
         */
        DwTreeComponent.prototype.handleFlattenNodes = /**
         * @param {?} data
         * @param {?=} expandKeys
         * @return {?}
         */
        function (data, expandKeys) {
            if (expandKeys === void 0) { expandKeys = []; }
            this.dwTreeService.flattenTreeData(data, expandKeys);
        };
        /**
         * @param {?} keys
         * @return {?}
         */
        DwTreeComponent.prototype.handleCheckedKeys = /**
         * @param {?} keys
         * @return {?}
         */
        function (keys) {
            this.dwTreeService.conductCheck(keys, this.dwCheckStrictly);
        };
        /**
         * @param {?=} keys
         * @return {?}
         */
        DwTreeComponent.prototype.handleExpandedKeys = /**
         * @param {?=} keys
         * @return {?}
         */
        function (keys) {
            if (keys === void 0) { keys = []; }
            this.dwTreeService.conductExpandedKeys(keys);
        };
        /**
         * @param {?} keys
         * @param {?} isMulti
         * @return {?}
         */
        DwTreeComponent.prototype.handleSelectedKeys = /**
         * @param {?} keys
         * @param {?} isMulti
         * @return {?}
         */
        function (keys, isMulti) {
            this.dwTreeService.conductSelectedKeys(keys, isMulti);
        };
        /**
         * @param {?} value
         * @param {?=} searchFunc
         * @return {?}
         */
        DwTreeComponent.prototype.handleSearchValue = /**
         * @param {?} value
         * @param {?=} searchFunc
         * @return {?}
         */
        function (value, searchFunc) {
            var _this = this;
            /** @type {?} */
            var dataList = tree.flattenTreeData(this.dwTreeService.rootNodes, true).map((/**
             * @param {?} v
             * @return {?}
             */
            function (v) { return v.data; }));
            /** @type {?} */
            var checkIfMatched = (/**
             * @param {?} node
             * @return {?}
             */
            function (node) {
                if (searchFunc) {
                    return searchFunc(node.origin);
                }
                return !value || !node.title.toLowerCase().includes(value.toLowerCase()) ? false : true;
            });
            dataList.forEach((/**
             * @param {?} v
             * @return {?}
             */
            function (v) {
                v.isMatched = checkIfMatched(v);
                v.canHide = !v.isMatched;
                if (!v.isMatched) {
                    v.setExpanded(false);
                    _this.dwTreeService.setExpandedNodeList(v);
                }
                else {
                    // expand
                    _this.dwTreeService.expandNodeAllParentBySearch(v);
                }
                _this.dwTreeService.setMatchedNodeList(v);
            }));
        };
        /**
         * Handle emit event
         * @param event
         * handle each event
         */
        /**
         * Handle emit event
         * @param {?} event
         * handle each event
         * @return {?}
         */
        DwTreeComponent.prototype.eventTriggerChanged = /**
         * Handle emit event
         * @param {?} event
         * handle each event
         * @return {?}
         */
        function (event) {
            /** @type {?} */
            var node = (/** @type {?} */ (event.node));
            switch (event.eventName) {
                case 'expand':
                    this.renderTree();
                    this.dwExpandChange.emit(event);
                    break;
                case 'click':
                    this.dwClick.emit(event);
                    break;
                case 'dblclick':
                    this.dwDblClick.emit(event);
                    break;
                case 'contextmenu':
                    this.dwContextMenu.emit(event);
                    break;
                case 'check':
                    // Render checked state with nodes' property `isChecked`
                    this.dwTreeService.setCheckedNodeList(node);
                    if (!this.dwCheckStrictly) {
                        this.dwTreeService.conduct(node);
                    }
                    // Cause check method will rerender list, so we need recover it and next the new event to user
                    /** @type {?} */
                    var eventNext = this.dwTreeService.formatEvent('check', node, (/** @type {?} */ (event.event)));
                    this.dwCheckBoxChange.emit(eventNext);
                    break;
                case 'dragstart':
                    // if node is expanded
                    if (node.isExpanded) {
                        node.setExpanded(!node.isExpanded);
                        this.renderTree();
                    }
                    this.dwOnDragStart.emit(event);
                    break;
                case 'dragenter':
                    /** @type {?} */
                    var selectedNode = this.dwTreeService.getSelectedNode();
                    if (selectedNode && selectedNode.key !== node.key && !node.isExpanded && !node.isLeaf) {
                        node.setExpanded(true);
                        this.renderTree();
                    }
                    this.dwOnDragEnter.emit(event);
                    break;
                case 'dragover':
                    this.dwOnDragOver.emit(event);
                    break;
                case 'dragleave':
                    this.dwOnDragLeave.emit(event);
                    break;
                case 'dragend':
                    this.dwOnDragEnd.emit(event);
                    break;
                case 'drop':
                    this.renderTree();
                    this.dwOnDrop.emit(event);
                    break;
            }
        };
        /**
         * Click expand icon
         */
        /**
         * Click expand icon
         * @return {?}
         */
        DwTreeComponent.prototype.renderTree = /**
         * Click expand icon
         * @return {?}
         */
        function () {
            this.handleFlattenNodes(this.dwTreeService.rootNodes, this.getExpandedNodeList().map((/**
             * @param {?} v
             * @return {?}
             */
            function (v) { return v.key; })));
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwTreeComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.dwTreeService.flattenNodes$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                _this.dwFlattenNodes = data;
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTreeComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            this.renderTreeProperties(changes);
        };
        /**
         * @return {?}
         */
        DwTreeComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            this.beforeInit = false;
        };
        /**
         * @return {?}
         */
        DwTreeComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTreeComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree',
                        exportAs: 'dwTree',
                        animations: [animation.treeCollapseMotion],
                        template: "\n    <div role=\"tree\">\n      <input [ngStyle]=\"HIDDEN_STYLE\" />\n    </div>\n    <div [class.ant-select-tree-list]=\"dwSelectMode\" [class.ant-tree-list]=\"dwSelectMode\">\n      <div>\n        <cdk-virtual-scroll-viewport\n          *ngIf=\"dwVirtualHeight\"\n          [class.ant-select-tree-list-holder-inner]=\"dwSelectMode\"\n          [class.ant-tree-list-holder-inner]=\"dwSelectMode\"\n          [itemSize]=\"dwVirtualItemSize\"\n          [minBufferPx]=\"dwVirtualMinBufferPx\"\n          [maxBufferPx]=\"dwVirtualMaxBufferPx\"\n          [style.height]=\"dwVirtualHeight\"\n        >\n          <ng-container *cdkVirtualFor=\"let node of dwFlattenNodes; trackBy: trackByFlattenNode\">\n            <ng-template [ngTemplateOutlet]=\"nodeTemplate\" [ngTemplateOutletContext]=\"{ $implicit: node }\"></ng-template>\n          </ng-container>\n        </cdk-virtual-scroll-viewport>\n\n        <div\n          *ngIf=\"!dwVirtualHeight\"\n          [class.ant-select-tree-list-holder-inner]=\"dwSelectMode\"\n          [class.ant-tree-list-holder-inner]=\"dwSelectMode\"\n          [@.disabled]=\"beforeInit || noAnimation?.dwNoAnimation\"\n          [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n          [@treeCollapseMotion]=\"dwFlattenNodes.length\"\n        >\n          <ng-container *ngFor=\"let node of dwFlattenNodes; trackBy: trackByFlattenNode\">\n            <ng-template [ngTemplateOutlet]=\"nodeTemplate\" [ngTemplateOutletContext]=\"{ $implicit: node }\"></ng-template>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n    <ng-template #nodeTemplate let-treeNode>\n      <dw-tree-node\n        [icon]=\"treeNode.icon\"\n        [title]=\"treeNode.title\"\n        [isLoading]=\"treeNode.isLoading\"\n        [isSelected]=\"treeNode.isSelected\"\n        [isDisabled]=\"treeNode.isDisabled\"\n        [isMatched]=\"treeNode.isMatched\"\n        [isExpanded]=\"treeNode.isExpanded\"\n        [isLeaf]=\"treeNode.isLeaf\"\n        [isStart]=\"treeNode.isStart\"\n        [isEnd]=\"treeNode.isEnd\"\n        [isChecked]=\"treeNode.isChecked\"\n        [isHalfChecked]=\"treeNode.isHalfChecked\"\n        [isDisableCheckbox]=\"treeNode.isDisableCheckbox\"\n        [isSelectable]=\"treeNode.isSelectable\"\n        [canHide]=\"treeNode.canHide\"\n        [dwTreeNode]=\"treeNode\"\n        [dwSelectMode]=\"dwSelectMode\"\n        [dwShowLine]=\"dwShowLine\"\n        [dwExpandedIcon]=\"dwExpandedIcon\"\n        [dwDraggable]=\"dwDraggable\"\n        [dwCheckable]=\"dwCheckable\"\n        [dwShowExpand]=\"dwShowExpand\"\n        [dwAsyncData]=\"dwAsyncData\"\n        [dwSearchValue]=\"dwSearchValue\"\n        [dwHideUnMatched]=\"dwHideUnMatched\"\n        [dwBeforeDrop]=\"dwBeforeDrop\"\n        [dwShowIcon]=\"dwShowIcon\"\n        [dwTreeTemplate]=\"dwTreeTemplate || dwTreeTemplateChild\"\n        (dwExpandChange)=\"eventTriggerChanged($event)\"\n        (dwClick)=\"eventTriggerChanged($event)\"\n        (dwDblClick)=\"eventTriggerChanged($event)\"\n        (dwContextMenu)=\"eventTriggerChanged($event)\"\n        (dwCheckBoxChange)=\"eventTriggerChanged($event)\"\n        (dwOnDragStart)=\"eventTriggerChanged($event)\"\n        (dwOnDragEnter)=\"eventTriggerChanged($event)\"\n        (dwOnDragOver)=\"eventTriggerChanged($event)\"\n        (dwOnDragLeave)=\"eventTriggerChanged($event)\"\n        (dwOnDragEnd)=\"eventTriggerChanged($event)\"\n        (dwOnDrop)=\"eventTriggerChanged($event)\"\n      >\n      </dw-tree-node>\n    </ng-template>\n  ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        providers: [
                            DwTreeService,
                            {
                                provide: tree.DwTreeBaseService,
                                useFactory: DwTreeServiceFactory,
                                deps: [[new core.SkipSelf(), new core.Optional(), tree.DwTreeHigherOrderServiceToken], DwTreeService]
                            },
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwTreeComponent; })),
                                multi: true
                            }
                        ],
                        host: {
                            '[class.ant-select-tree]': "dwSelectMode",
                            '[class.ant-select-tree-show-line]': "dwSelectMode && dwShowLine",
                            '[class.ant-select-tree-icon-hide]': "dwSelectMode && !dwShowIcon",
                            '[class.ant-select-tree-block-node]': "dwSelectMode && dwBlockNode",
                            '[class.ant-tree]': "!dwSelectMode",
                            '[class.ant-tree-show-line]': "!dwSelectMode && dwShowLine",
                            '[class.ant-tree-icon-hide]': "!dwSelectMode && !dwShowIcon",
                            '[class.ant-tree-block-node]': "!dwSelectMode && dwBlockNode",
                            '[class.draggable-tree]': "dwDraggable"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTreeComponent.ctorParameters = function () { return [
            { type: tree.DwTreeBaseService },
            { type: config.DwConfigService },
            { type: core.ChangeDetectorRef },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwTreeComponent.propDecorators = {
            dwShowIcon: [{ type: core.Input }],
            dwHideUnMatched: [{ type: core.Input }],
            dwBlockNode: [{ type: core.Input }],
            dwExpandAll: [{ type: core.Input }],
            dwSelectMode: [{ type: core.Input }],
            dwCheckStrictly: [{ type: core.Input }],
            dwShowExpand: [{ type: core.Input }],
            dwShowLine: [{ type: core.Input }],
            dwCheckable: [{ type: core.Input }],
            dwAsyncData: [{ type: core.Input }],
            dwDraggable: [{ type: core.Input }],
            dwMultiple: [{ type: core.Input }],
            dwExpandedIcon: [{ type: core.Input }],
            dwVirtualItemSize: [{ type: core.Input }],
            dwVirtualMaxBufferPx: [{ type: core.Input }],
            dwVirtualMinBufferPx: [{ type: core.Input }],
            dwVirtualHeight: [{ type: core.Input }],
            dwTreeTemplate: [{ type: core.Input }],
            dwBeforeDrop: [{ type: core.Input }],
            dwData: [{ type: core.Input }],
            dwExpandedKeys: [{ type: core.Input }],
            dwSelectedKeys: [{ type: core.Input }],
            dwCheckedKeys: [{ type: core.Input }],
            dwSearchValue: [{ type: core.Input }],
            dwSearchFunc: [{ type: core.Input }],
            dwTreeTemplateChild: [{ type: core.ContentChild, args: ['dwTreeTemplate', { static: true },] }],
            cdkVirtualScrollViewport: [{ type: core.ViewChild, args: [scrolling.CdkVirtualScrollViewport, { read: scrolling.CdkVirtualScrollViewport },] }],
            dwExpandedKeysChange: [{ type: core.Output }],
            dwSelectedKeysChange: [{ type: core.Output }],
            dwCheckedKeysChange: [{ type: core.Output }],
            dwSearchValueChange: [{ type: core.Output }],
            dwClick: [{ type: core.Output }],
            dwDblClick: [{ type: core.Output }],
            dwContextMenu: [{ type: core.Output }],
            dwCheckBoxChange: [{ type: core.Output }],
            dwExpandChange: [{ type: core.Output }],
            dwOnDragStart: [{ type: core.Output }],
            dwOnDragEnter: [{ type: core.Output }],
            dwOnDragOver: [{ type: core.Output }],
            dwOnDragLeave: [{ type: core.Output }],
            dwOnDrop: [{ type: core.Output }],
            dwOnDragEnd: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeComponent.prototype, "dwShowIcon", void 0);
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeComponent.prototype, "dwHideUnMatched", void 0);
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeComponent.prototype, "dwBlockNode", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwExpandAll", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwSelectMode", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwCheckStrictly", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeComponent.prototype, "dwShowExpand", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwShowLine", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwCheckable", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwAsyncData", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeComponent.prototype, "dwDraggable", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeComponent.prototype, "dwMultiple", void 0);
        return DwTreeComponent;
    }(tree.DwTreeBase));
    if (false) {
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwShowIcon;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwHideUnMatched;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwBlockNode;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwExpandAll;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwSelectMode;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwCheckStrictly;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwShowExpand;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwShowLine;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwCheckable;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwAsyncData;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwDraggable;
        /** @type {?} */
        DwTreeComponent.ngAcceptInputType_dwMultiple;
        /** @type {?} */
        DwTreeComponent.prototype.dwShowIcon;
        /** @type {?} */
        DwTreeComponent.prototype.dwHideUnMatched;
        /** @type {?} */
        DwTreeComponent.prototype.dwBlockNode;
        /** @type {?} */
        DwTreeComponent.prototype.dwExpandAll;
        /** @type {?} */
        DwTreeComponent.prototype.dwSelectMode;
        /** @type {?} */
        DwTreeComponent.prototype.dwCheckStrictly;
        /** @type {?} */
        DwTreeComponent.prototype.dwShowExpand;
        /** @type {?} */
        DwTreeComponent.prototype.dwShowLine;
        /** @type {?} */
        DwTreeComponent.prototype.dwCheckable;
        /** @type {?} */
        DwTreeComponent.prototype.dwAsyncData;
        /** @type {?} */
        DwTreeComponent.prototype.dwDraggable;
        /** @type {?} */
        DwTreeComponent.prototype.dwMultiple;
        /** @type {?} */
        DwTreeComponent.prototype.dwExpandedIcon;
        /** @type {?} */
        DwTreeComponent.prototype.dwVirtualItemSize;
        /** @type {?} */
        DwTreeComponent.prototype.dwVirtualMaxBufferPx;
        /** @type {?} */
        DwTreeComponent.prototype.dwVirtualMinBufferPx;
        /** @type {?} */
        DwTreeComponent.prototype.dwVirtualHeight;
        /** @type {?} */
        DwTreeComponent.prototype.dwTreeTemplate;
        /** @type {?} */
        DwTreeComponent.prototype.dwBeforeDrop;
        /** @type {?} */
        DwTreeComponent.prototype.dwData;
        /** @type {?} */
        DwTreeComponent.prototype.dwExpandedKeys;
        /** @type {?} */
        DwTreeComponent.prototype.dwSelectedKeys;
        /** @type {?} */
        DwTreeComponent.prototype.dwCheckedKeys;
        /** @type {?} */
        DwTreeComponent.prototype.dwSearchValue;
        /** @type {?} */
        DwTreeComponent.prototype.dwSearchFunc;
        /** @type {?} */
        DwTreeComponent.prototype.dwTreeTemplateChild;
        /** @type {?} */
        DwTreeComponent.prototype.cdkVirtualScrollViewport;
        /** @type {?} */
        DwTreeComponent.prototype.dwFlattenNodes;
        /** @type {?} */
        DwTreeComponent.prototype.beforeInit;
        /** @type {?} */
        DwTreeComponent.prototype.dwExpandedKeysChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwSelectedKeysChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwCheckedKeysChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwSearchValueChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwClick;
        /** @type {?} */
        DwTreeComponent.prototype.dwDblClick;
        /** @type {?} */
        DwTreeComponent.prototype.dwContextMenu;
        /** @type {?} */
        DwTreeComponent.prototype.dwCheckBoxChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwExpandChange;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDragStart;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDragEnter;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDragOver;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDragLeave;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDrop;
        /** @type {?} */
        DwTreeComponent.prototype.dwOnDragEnd;
        /** @type {?} */
        DwTreeComponent.prototype.HIDDEN_STYLE;
        /** @type {?} */
        DwTreeComponent.prototype.destroy$;
        /** @type {?} */
        DwTreeComponent.prototype.onChange;
        /** @type {?} */
        DwTreeComponent.prototype.onTouched;
        /** @type {?} */
        DwTreeComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwTreeComponent.prototype.cdr;
        /** @type {?} */
        DwTreeComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeModule = /** @class */ (function () {
        function DwTreeModule() {
        }
        DwTreeModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, outlet.DwOutletModule, icon.DwIconModule, noAnimation.DwNoAnimationModule, highlight.DwHighlightModule, scrolling.ScrollingModule],
                        declarations: [
                            DwTreeComponent,
                            DwTreeNodeComponent,
                            DwTreeIndentComponent,
                            DwTreeNodeSwitcherComponent,
                            DwTreeNodeCheckboxComponent,
                            DwTreeNodeTitleComponent
                        ],
                        exports: [DwTreeComponent, DwTreeNodeComponent, DwTreeIndentComponent]
                    },] }
        ];
        return DwTreeModule;
    }());

    Object.defineProperty(exports, 'DwTreeNode', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNode;
        }
    });
    exports.DwTreeComponent = DwTreeComponent;
    exports.DwTreeIndentComponent = DwTreeIndentComponent;
    exports.DwTreeModule = DwTreeModule;
    exports.DwTreeNodeCheckboxComponent = DwTreeNodeCheckboxComponent;
    exports.DwTreeNodeComponent = DwTreeNodeComponent;
    exports.DwTreeNodeSwitcherComponent = DwTreeNodeSwitcherComponent;
    exports.DwTreeNodeTitleComponent = DwTreeNodeTitleComponent;
    exports.DwTreeService = DwTreeService;
    exports.DwTreeServiceFactory = DwTreeServiceFactory;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-tree.umd.js.map
