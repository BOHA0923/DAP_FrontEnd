(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/services'), require('ng-quicksilver/core/util'), require('ng-quicksilver/i18n'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('@angular/forms'), require('ng-quicksilver/icon'), require('ng-quicksilver/select')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/pagination', ['exports', '@angular/core', 'ng-quicksilver/core/services', 'ng-quicksilver/core/util', 'ng-quicksilver/i18n', 'rxjs', 'rxjs/operators', '@angular/common', '@angular/forms', 'ng-quicksilver/icon', 'ng-quicksilver/select'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].pagination = {}), global.ng.core, global['ng-quicksilver'].core.services, global['ng-quicksilver'].core.util, global['ng-quicksilver'].i18n, global.rxjs, global.rxjs.operators, global.ng.common, global.ng.forms, global['ng-quicksilver'].icon, global['ng-quicksilver'].select));
}(this, (function (exports, core, services, util, i18n, rxjs, operators, common, forms, icon, select) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationComponent = /** @class */ (function () {
        function DwPaginationComponent(i18n, cdr, breakpointService) {
            this.i18n = i18n;
            this.cdr = cdr;
            this.breakpointService = breakpointService;
            this.dwPageSizeChange = new core.EventEmitter();
            this.dwPageIndexChange = new core.EventEmitter();
            this.dwShowTotal = null;
            this.dwSize = 'default';
            this.dwPageSizeOptions = [10, 20, 30, 40];
            this.dwItemRender = null;
            this.dwDisabled = false;
            this.dwShowSizeChanger = false;
            this.dwHideOnSinglePage = false;
            this.dwShowQuickJumper = false;
            this.dwSimple = false;
            this.dwResponsive = false;
            this.dwTotal = 0;
            this.dwPageIndex = 1;
            this.dwPageSize = 10;
            this.showPagination = true;
            this.size = 'default';
            this.destroy$ = new rxjs.Subject();
            this.total$ = new rxjs.ReplaySubject(1);
        }
        /**
         * @param {?} value
         * @param {?} lastIndex
         * @return {?}
         */
        DwPaginationComponent.prototype.validatePageIndex = /**
         * @param {?} value
         * @param {?} lastIndex
         * @return {?}
         */
        function (value, lastIndex) {
            if (value > lastIndex) {
                return lastIndex;
            }
            else if (value < 1) {
                return 1;
            }
            else {
                return value;
            }
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwPaginationComponent.prototype.onPageIndexChange = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            /** @type {?} */
            var lastIndex = this.getLastIndex(this.dwTotal, this.dwPageSize);
            /** @type {?} */
            var validIndex = this.validatePageIndex(index, lastIndex);
            if (validIndex !== this.dwPageIndex && !this.dwDisabled) {
                this.dwPageIndex = validIndex;
                this.dwPageIndexChange.emit(this.dwPageIndex);
            }
        };
        /**
         * @param {?} size
         * @return {?}
         */
        DwPaginationComponent.prototype.onPageSizeChange = /**
         * @param {?} size
         * @return {?}
         */
        function (size) {
            this.dwPageSize = size;
            this.dwPageSizeChange.emit(size);
            /** @type {?} */
            var lastIndex = this.getLastIndex(this.dwTotal, this.dwPageSize);
            if (this.dwPageIndex > lastIndex) {
                this.onPageIndexChange(lastIndex);
            }
        };
        /**
         * @param {?} total
         * @return {?}
         */
        DwPaginationComponent.prototype.onTotalChange = /**
         * @param {?} total
         * @return {?}
         */
        function (total) {
            var _this = this;
            /** @type {?} */
            var lastIndex = this.getLastIndex(total, this.dwPageSize);
            if (this.dwPageIndex > lastIndex) {
                Promise.resolve().then((/**
                 * @return {?}
                 */
                function () { return _this.onPageIndexChange(lastIndex); }));
            }
        };
        /**
         * @param {?} total
         * @param {?} pageSize
         * @return {?}
         */
        DwPaginationComponent.prototype.getLastIndex = /**
         * @param {?} total
         * @param {?} pageSize
         * @return {?}
         */
        function (total, pageSize) {
            return Math.ceil(total / pageSize);
        };
        /**
         * @return {?}
         */
        DwPaginationComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.i18n.localeChange.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.locale = _this.i18n.getLocaleData('Pagination');
                _this.cdr.markForCheck();
            }));
            this.total$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} total
             * @return {?}
             */
            function (total) {
                _this.onTotalChange(total);
            }));
            this.breakpointService
                .subscribe(services.gridResponsiveMap)
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} bp
             * @return {?}
             */
            function (bp) {
                if (_this.dwResponsive) {
                    _this.size = bp === services.DwBreakpointEnum.xs ? 'small' : 'default';
                    _this.cdr.markForCheck();
                }
            }));
        };
        /**
         * @return {?}
         */
        DwPaginationComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPaginationComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwHideOnSinglePage = changes.dwHideOnSinglePage, dwTotal = changes.dwTotal, dwPageSize = changes.dwPageSize, dwSize = changes.dwSize;
            if (dwTotal) {
                this.total$.next(this.dwTotal);
            }
            if (dwHideOnSinglePage || dwTotal || dwPageSize) {
                this.showPagination = (this.dwHideOnSinglePage && this.dwTotal > this.dwPageSize) || (this.dwTotal > 0 && !this.dwHideOnSinglePage);
            }
            if (dwSize) {
                this.size = dwSize.currentValue;
            }
        };
        DwPaginationComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-pagination',
                        exportAs: 'dwPagination',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-container *ngIf=\"showPagination\">\n      <ng-container *ngIf=\"dwSimple; else defaultPagination.template\">\n        <ng-template [ngTemplateOutlet]=\"simplePagination.template\"></ng-template>\n      </ng-container>\n    </ng-container>\n    <dw-pagination-simple\n      #simplePagination\n      [disabled]=\"dwDisabled\"\n      [itemRender]=\"dwItemRender\"\n      [locale]=\"locale\"\n      [pageSize]=\"dwPageSize\"\n      [total]=\"dwTotal\"\n      [pageIndex]=\"dwPageIndex\"\n      (pageIndexChange)=\"onPageIndexChange($event)\"\n    ></dw-pagination-simple>\n    <dw-pagination-default\n      #defaultPagination\n      [dwSize]=\"size\"\n      [itemRender]=\"dwItemRender\"\n      [showTotal]=\"dwShowTotal\"\n      [disabled]=\"dwDisabled\"\n      [locale]=\"locale\"\n      [showSizeChanger]=\"dwShowSizeChanger\"\n      [showQuickJumper]=\"dwShowQuickJumper\"\n      [total]=\"dwTotal\"\n      [pageIndex]=\"dwPageIndex\"\n      [pageSize]=\"dwPageSize\"\n      [pageSizeOptions]=\"dwPageSizeOptions\"\n      (pageIndexChange)=\"onPageIndexChange($event)\"\n      (pageSizeChange)=\"onPageSizeChange($event)\"\n    ></dw-pagination-default>\n  ",
                        host: {
                            '[class.ant-pagination]': 'true',
                            '[class.ant-pagination-simple]': 'dwSimple',
                            '[class.ant-pagination-disabled]': 'dwDisabled',
                            '[class.mini]': "!dwSimple && size === 'small'"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwPaginationComponent.ctorParameters = function () { return [
            { type: i18n.DwI18nService },
            { type: core.ChangeDetectorRef },
            { type: services.DwBreakpointService }
        ]; };
        DwPaginationComponent.propDecorators = {
            dwPageSizeChange: [{ type: core.Output }],
            dwPageIndexChange: [{ type: core.Output }],
            dwShowTotal: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwPageSizeOptions: [{ type: core.Input }],
            dwItemRender: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwShowSizeChanger: [{ type: core.Input }],
            dwHideOnSinglePage: [{ type: core.Input }],
            dwShowQuickJumper: [{ type: core.Input }],
            dwSimple: [{ type: core.Input }],
            dwResponsive: [{ type: core.Input }],
            dwTotal: [{ type: core.Input }],
            dwPageIndex: [{ type: core.Input }],
            dwPageSize: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwShowSizeChanger", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwHideOnSinglePage", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwShowQuickJumper", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwSimple", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwResponsive", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwTotal", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwPageIndex", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwPaginationComponent.prototype, "dwPageSize", void 0);
        return DwPaginationComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwShowSizeChanger;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwHideOnSinglePage;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwShowQuickJumper;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwSimple;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwResponsive;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwTotal;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwPageIndex;
        /** @type {?} */
        DwPaginationComponent.ngAcceptInputType_dwPageSize;
        /** @type {?} */
        DwPaginationComponent.prototype.dwPageSizeChange;
        /** @type {?} */
        DwPaginationComponent.prototype.dwPageIndexChange;
        /** @type {?} */
        DwPaginationComponent.prototype.dwShowTotal;
        /** @type {?} */
        DwPaginationComponent.prototype.dwSize;
        /** @type {?} */
        DwPaginationComponent.prototype.dwPageSizeOptions;
        /** @type {?} */
        DwPaginationComponent.prototype.dwItemRender;
        /** @type {?} */
        DwPaginationComponent.prototype.dwDisabled;
        /** @type {?} */
        DwPaginationComponent.prototype.dwShowSizeChanger;
        /** @type {?} */
        DwPaginationComponent.prototype.dwHideOnSinglePage;
        /** @type {?} */
        DwPaginationComponent.prototype.dwShowQuickJumper;
        /** @type {?} */
        DwPaginationComponent.prototype.dwSimple;
        /** @type {?} */
        DwPaginationComponent.prototype.dwResponsive;
        /** @type {?} */
        DwPaginationComponent.prototype.dwTotal;
        /** @type {?} */
        DwPaginationComponent.prototype.dwPageIndex;
        /** @type {?} */
        DwPaginationComponent.prototype.dwPageSize;
        /** @type {?} */
        DwPaginationComponent.prototype.showPagination;
        /** @type {?} */
        DwPaginationComponent.prototype.locale;
        /** @type {?} */
        DwPaginationComponent.prototype.size;
        /**
         * @type {?}
         * @private
         */
        DwPaginationComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwPaginationComponent.prototype.total$;
        /**
         * @type {?}
         * @private
         */
        DwPaginationComponent.prototype.i18n;
        /**
         * @type {?}
         * @private
         */
        DwPaginationComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwPaginationComponent.prototype.breakpointService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination-default.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationDefaultComponent = /** @class */ (function () {
        function DwPaginationDefaultComponent(renderer, elementRef) {
            this.dwSize = 'default';
            this.itemRender = null;
            this.showTotal = null;
            this.disabled = false;
            this.showSizeChanger = false;
            this.showQuickJumper = false;
            this.total = 0;
            this.pageIndex = 1;
            this.pageSize = 10;
            this.pageSizeOptions = [10, 20, 30, 40];
            this.pageIndexChange = new core.EventEmitter();
            this.pageSizeChange = new core.EventEmitter();
            this.ranges = [0, 0];
            this.listOfPageItem = [];
            renderer.removeChild(renderer.parentNode(elementRef.nativeElement), elementRef.nativeElement);
        }
        /**
         * @param {?} index
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.jumpPage = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.onPageIndexChange(index);
        };
        /**
         * @param {?} diff
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.jumpDiff = /**
         * @param {?} diff
         * @return {?}
         */
        function (diff) {
            this.jumpPage(this.pageIndex + diff);
        };
        /**
         * @param {?} _
         * @param {?} value
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.trackByPageItem = /**
         * @param {?} _
         * @param {?} value
         * @return {?}
         */
        function (_, value) {
            return value.type + "-" + value.index;
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.onPageIndexChange = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.pageIndexChange.next(index);
        };
        /**
         * @param {?} size
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.onPageSizeChange = /**
         * @param {?} size
         * @return {?}
         */
        function (size) {
            this.pageSizeChange.next(size);
        };
        /**
         * @param {?} total
         * @param {?} pageSize
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.getLastIndex = /**
         * @param {?} total
         * @param {?} pageSize
         * @return {?}
         */
        function (total, pageSize) {
            return Math.ceil(total / pageSize);
        };
        /**
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.buildIndexes = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var lastIndex = this.getLastIndex(this.total, this.pageSize);
            this.listOfPageItem = this.getListOfPageItem(this.pageIndex, lastIndex);
        };
        /**
         * @param {?} pageIndex
         * @param {?} lastIndex
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.getListOfPageItem = /**
         * @param {?} pageIndex
         * @param {?} lastIndex
         * @return {?}
         */
        function (pageIndex, lastIndex) {
            /** @type {?} */
            var concatWithPrevNext = (/**
             * @param {?} listOfPage
             * @return {?}
             */
            function (listOfPage) {
                /** @type {?} */
                var prevItem = {
                    type: 'prev',
                    disabled: pageIndex === 1
                };
                /** @type {?} */
                var nextItem = {
                    type: 'next',
                    disabled: pageIndex === lastIndex
                };
                return __spread([prevItem], listOfPage, [nextItem]);
            });
            /** @type {?} */
            var generatePage = (/**
             * @param {?} start
             * @param {?} end
             * @return {?}
             */
            function (start, end) {
                /** @type {?} */
                var list = [];
                for (var i = start; i <= end; i++) {
                    list.push({
                        index: i,
                        type: 'page'
                    });
                }
                return list;
            });
            if (lastIndex <= 9) {
                return concatWithPrevNext(generatePage(1, lastIndex));
            }
            else {
                /** @type {?} */
                var generateRangeItem = (/**
                 * @param {?} selected
                 * @param {?} last
                 * @return {?}
                 */
                function (selected, last) {
                    /** @type {?} */
                    var listOfRange = [];
                    /** @type {?} */
                    var prevFiveItem = {
                        type: 'prev_5'
                    };
                    /** @type {?} */
                    var nextFiveItem = {
                        type: 'next_5'
                    };
                    /** @type {?} */
                    var firstPageItem = generatePage(1, 1);
                    /** @type {?} */
                    var lastPageItem = generatePage(lastIndex, lastIndex);
                    if (selected < 4) {
                        listOfRange = __spread(generatePage(2, 5), [nextFiveItem]);
                    }
                    else if (selected < last - 3) {
                        listOfRange = __spread([prevFiveItem], generatePage(selected - 2, selected + 2), [nextFiveItem]);
                    }
                    else {
                        listOfRange = __spread([prevFiveItem], generatePage(last - 4, last - 1));
                    }
                    return __spread(firstPageItem, listOfRange, lastPageItem);
                });
                return concatWithPrevNext(generateRangeItem(pageIndex, lastIndex));
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPaginationDefaultComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var pageIndex = changes.pageIndex, pageSize = changes.pageSize, total = changes.total;
            if (pageIndex || pageSize || total) {
                this.ranges = [(this.pageIndex - 1) * this.pageSize + 1, Math.min(this.pageIndex * this.pageSize, this.total)];
                this.buildIndexes();
            }
        };
        DwPaginationDefaultComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-pagination-default',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-template #containerTemplate>\n      <li class=\"ant-pagination-total-text\" *ngIf=\"showTotal\">\n        <ng-template [ngTemplateOutlet]=\"showTotal\" [ngTemplateOutletContext]=\"{ $implicit: total, range: ranges }\"></ng-template>\n      </li>\n      <li\n        *ngFor=\"let page of listOfPageItem; trackBy: trackByPageItem\"\n        dw-pagination-item\n        [locale]=\"locale\"\n        [type]=\"page.type\"\n        [index]=\"page.index\"\n        [disabled]=\"!!page.disabled\"\n        [itemRender]=\"itemRender\"\n        [active]=\"pageIndex === page.index\"\n        (gotoIndex)=\"jumpPage($event)\"\n        (diffIndex)=\"jumpDiff($event)\"\n      ></li>\n      <div\n        dw-pagination-options\n        *ngIf=\"showQuickJumper || showSizeChanger\"\n        [total]=\"total\"\n        [locale]=\"locale\"\n        [disabled]=\"disabled\"\n        [dwSize]=\"dwSize\"\n        [showSizeChanger]=\"showSizeChanger\"\n        [showQuickJumper]=\"showQuickJumper\"\n        [pageIndex]=\"pageIndex\"\n        [pageSize]=\"pageSize\"\n        [pageSizeOptions]=\"pageSizeOptions\"\n        (pageIndexChange)=\"onPageIndexChange($event)\"\n        (pageSizeChange)=\"onPageSizeChange($event)\"\n      ></div>\n    </ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwPaginationDefaultComponent.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        DwPaginationDefaultComponent.propDecorators = {
            template: [{ type: core.ViewChild, args: ['containerTemplate', { static: true },] }],
            dwSize: [{ type: core.Input }],
            itemRender: [{ type: core.Input }],
            showTotal: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            showSizeChanger: [{ type: core.Input }],
            showQuickJumper: [{ type: core.Input }],
            total: [{ type: core.Input }],
            pageIndex: [{ type: core.Input }],
            pageSize: [{ type: core.Input }],
            pageSizeOptions: [{ type: core.Input }],
            pageIndexChange: [{ type: core.Output }],
            pageSizeChange: [{ type: core.Output }]
        };
        return DwPaginationDefaultComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.template;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.dwSize;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.itemRender;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.showTotal;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.disabled;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.locale;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.showSizeChanger;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.showQuickJumper;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.total;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.pageIndex;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.pageSize;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.pageSizeOptions;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.pageIndexChange;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.pageSizeChange;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.ranges;
        /** @type {?} */
        DwPaginationDefaultComponent.prototype.listOfPageItem;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination-item.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationItemComponent = /** @class */ (function () {
        function DwPaginationItemComponent() {
            this.active = false;
            this.index = null;
            this.disabled = false;
            this.type = null;
            this.itemRender = null;
            this.diffIndex = new core.EventEmitter();
            this.gotoIndex = new core.EventEmitter();
            this.title = null;
        }
        /**
         * @return {?}
         */
        DwPaginationItemComponent.prototype.clickItem = /**
         * @return {?}
         */
        function () {
            if (!this.disabled) {
                if (this.type === 'page') {
                    this.gotoIndex.emit((/** @type {?} */ (this.index)));
                }
                else {
                    this.diffIndex.emit(((/** @type {?} */ ({
                        next: 1,
                        prev: -1,
                        prev_5: -5,
                        next_5: 5
                    })))[(/** @type {?} */ (this.type))]);
                }
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPaginationItemComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _a, _b, _c, _d;
            var locale = changes.locale, index = changes.index, type = changes.type;
            if (locale || index || type) {
                this.title = ((/** @type {?} */ ({
                    page: "" + this.index,
                    next: (_a = this.locale) === null || _a === void 0 ? void 0 : _a.next_page,
                    prev: (_b = this.locale) === null || _b === void 0 ? void 0 : _b.prev_page,
                    prev_5: (_c = this.locale) === null || _c === void 0 ? void 0 : _c.prev_5,
                    next_5: (_d = this.locale) === null || _d === void 0 ? void 0 : _d.next_5
                })))[(/** @type {?} */ (this.type))];
            }
        };
        DwPaginationItemComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'li[dw-pagination-item]',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-template #renderItemTemplate let-type let-page=\"page\">\n      <ng-container [ngSwitch]=\"type\">\n        <a *ngSwitchCase=\"'page'\">{{ page }}</a>\n        <ng-container *ngSwitchDefault>\n          <a class=\"ant-pagination-item-link\" [ngSwitch]=\"type\">\n            <i dw-icon dwType=\"left\" *ngSwitchCase=\"'prev'\"></i>\n            <i dw-icon dwType=\"right\" *ngSwitchCase=\"'next'\"></i>\n            <div class=\"ant-pagination-item-container\" *ngSwitchDefault>\n              <ng-container [ngSwitch]=\"type\">\n                <i *ngSwitchCase=\"'prev_5'\" dw-icon dwType=\"double-left\" class=\"ant-pagination-item-link-icon\"></i>\n                <i *ngSwitchCase=\"'next_5'\" dw-icon dwType=\"double-right\" class=\"ant-pagination-item-link-icon\"></i>\n              </ng-container>\n              <span class=\"ant-pagination-item-ellipsis\">\u2022\u2022\u2022</span>\n            </div>\n          </a>\n        </ng-container>\n      </ng-container>\n    </ng-template>\n    <ng-template\n      [ngTemplateOutlet]=\"itemRender || renderItemTemplate\"\n      [ngTemplateOutletContext]=\"{ $implicit: type, page: index }\"\n    ></ng-template>\n  ",
                        host: {
                            '[class.ant-pagination-prev]': "type === 'prev'",
                            '[class.ant-pagination-next]': "type === 'next'",
                            '[class.ant-pagination-item]': "type === 'page'",
                            '[class.ant-pagination-jump-prev]': "type === 'prev_5'",
                            '[class.ant-pagination-jump-prev-custom-icon]': "type === 'prev_5'",
                            '[class.ant-pagination-jump-next]': "type === 'next_5'",
                            '[class.ant-pagination-jump-next-custom-icon]': "type === 'next_5'",
                            '[class.ant-pagination-disabled]': 'disabled',
                            '[class.ant-pagination-item-active]]': 'active',
                            '[attr.title]': 'title',
                            '(click)': 'clickItem()'
                        }
                    }] }
        ];
        DwPaginationItemComponent.propDecorators = {
            active: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            index: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            type: [{ type: core.Input }],
            itemRender: [{ type: core.Input }],
            diffIndex: [{ type: core.Output }],
            gotoIndex: [{ type: core.Output }]
        };
        return DwPaginationItemComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPaginationItemComponent.ngAcceptInputType_type;
        /** @type {?} */
        DwPaginationItemComponent.ngAcceptInputType_index;
        /** @type {?} */
        DwPaginationItemComponent.prototype.active;
        /** @type {?} */
        DwPaginationItemComponent.prototype.locale;
        /** @type {?} */
        DwPaginationItemComponent.prototype.index;
        /** @type {?} */
        DwPaginationItemComponent.prototype.disabled;
        /** @type {?} */
        DwPaginationItemComponent.prototype.type;
        /** @type {?} */
        DwPaginationItemComponent.prototype.itemRender;
        /** @type {?} */
        DwPaginationItemComponent.prototype.diffIndex;
        /** @type {?} */
        DwPaginationItemComponent.prototype.gotoIndex;
        /** @type {?} */
        DwPaginationItemComponent.prototype.title;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination-options.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationOptionsComponent = /** @class */ (function () {
        function DwPaginationOptionsComponent() {
            this.dwSize = 'default';
            this.disabled = false;
            this.showSizeChanger = false;
            this.showQuickJumper = false;
            this.total = 0;
            this.pageIndex = 1;
            this.pageSize = 10;
            this.pageSizeOptions = [];
            this.pageIndexChange = new core.EventEmitter();
            this.pageSizeChange = new core.EventEmitter();
            this.listOfPageSizeOption = [];
        }
        /**
         * @param {?} size
         * @return {?}
         */
        DwPaginationOptionsComponent.prototype.onPageSizeChange = /**
         * @param {?} size
         * @return {?}
         */
        function (size) {
            if (this.pageSize !== size) {
                this.pageSizeChange.next(size);
            }
        };
        /**
         * @param {?} $event
         * @return {?}
         */
        DwPaginationOptionsComponent.prototype.jumpToPageViaInput = /**
         * @param {?} $event
         * @return {?}
         */
        function ($event) {
            /** @type {?} */
            var target = (/** @type {?} */ ($event.target));
            /** @type {?} */
            var index = util.toNumber(target.value, this.pageIndex);
            this.pageIndexChange.next(index);
            target.value = '';
        };
        /**
         * @param {?} _
         * @param {?} option
         * @return {?}
         */
        DwPaginationOptionsComponent.prototype.trackByOption = /**
         * @param {?} _
         * @param {?} option
         * @return {?}
         */
        function (_, option) {
            return option.value;
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPaginationOptionsComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            var pageSize = changes.pageSize, pageSizeOptions = changes.pageSizeOptions, locale = changes.locale;
            if (pageSize || pageSizeOptions || locale) {
                this.listOfPageSizeOption = __spread(new Set(__spread(this.pageSizeOptions, [this.pageSize]))).map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    return {
                        value: item,
                        label: item + " " + _this.locale.items_per_page
                    };
                }));
            }
        };
        DwPaginationOptionsComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'div[dw-pagination-options]',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <dw-select\n      class=\"ant-pagination-options-size-changer\"\n      *ngIf=\"showSizeChanger\"\n      [dwDisabled]=\"disabled\"\n      [dwSize]=\"dwSize\"\n      [ngModel]=\"pageSize\"\n      (ngModelChange)=\"onPageSizeChange($event)\"\n    >\n      <dw-option\n        *ngFor=\"let option of listOfPageSizeOption; trackBy: trackByOption\"\n        [dwLabel]=\"option.label\"\n        [dwValue]=\"option.value\"\n      ></dw-option>\n    </dw-select>\n    <div class=\"ant-pagination-options-quick-jumper\" *ngIf=\"showQuickJumper\">\n      {{ locale.jump_to }}\n      <input [disabled]=\"disabled\" (keydown.enter)=\"jumpToPageViaInput($event)\" />\n      {{ locale.page }}\n    </div>\n  ",
                        host: {
                            '[class.ant-pagination-options]': 'true'
                        }
                    }] }
        ];
        DwPaginationOptionsComponent.propDecorators = {
            dwSize: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            showSizeChanger: [{ type: core.Input }],
            showQuickJumper: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            total: [{ type: core.Input }],
            pageIndex: [{ type: core.Input }],
            pageSize: [{ type: core.Input }],
            pageSizeOptions: [{ type: core.Input }],
            pageIndexChange: [{ type: core.Output }],
            pageSizeChange: [{ type: core.Output }]
        };
        return DwPaginationOptionsComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.dwSize;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.disabled;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.showSizeChanger;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.showQuickJumper;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.locale;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.total;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.pageIndex;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.pageSize;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.pageSizeOptions;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.pageIndexChange;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.pageSizeChange;
        /** @type {?} */
        DwPaginationOptionsComponent.prototype.listOfPageSizeOption;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination-simple.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationSimpleComponent = /** @class */ (function () {
        function DwPaginationSimpleComponent(renderer, elementRef) {
            this.itemRender = null;
            this.disabled = false;
            this.total = 0;
            this.pageIndex = 1;
            this.pageSize = 10;
            this.pageIndexChange = new core.EventEmitter();
            this.lastIndex = 0;
            this.isFirstIndex = false;
            this.isLastIndex = false;
            renderer.removeChild(renderer.parentNode(elementRef.nativeElement), elementRef.nativeElement);
        }
        /**
         * @param {?} $event
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.jumpToPageViaInput = /**
         * @param {?} $event
         * @return {?}
         */
        function ($event) {
            /** @type {?} */
            var target = (/** @type {?} */ ($event.target));
            /** @type {?} */
            var index = util.toNumber(target.value, this.pageIndex);
            this.onPageIndexChange(index);
            target.value = "" + this.pageIndex;
        };
        /**
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.prePage = /**
         * @return {?}
         */
        function () {
            this.onPageIndexChange(this.pageIndex - 1);
        };
        /**
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.nextPage = /**
         * @return {?}
         */
        function () {
            this.onPageIndexChange(this.pageIndex + 1);
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.onPageIndexChange = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.pageIndexChange.next(index);
        };
        /**
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.updateBindingValue = /**
         * @return {?}
         */
        function () {
            this.lastIndex = Math.ceil(this.total / this.pageSize);
            this.isFirstIndex = this.pageIndex === 1;
            this.isLastIndex = this.pageIndex === this.lastIndex;
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPaginationSimpleComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var pageIndex = changes.pageIndex, total = changes.total, pageSize = changes.pageSize;
            if (pageIndex || total || pageSize) {
                this.updateBindingValue();
            }
        };
        DwPaginationSimpleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-pagination-simple',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-template #containerTemplate>\n      <li\n        dw-pagination-item\n        [attr.title]=\"locale.prev_page\"\n        [disabled]=\"isFirstIndex\"\n        (click)=\"prePage()\"\n        type=\"prev\"\n        [itemRender]=\"itemRender\"\n      ></li>\n      <li [attr.title]=\"pageIndex + '/' + lastIndex\" class=\"ant-pagination-simple-pager\">\n        <input [disabled]=\"disabled\" [value]=\"pageIndex\" (keydown.enter)=\"jumpToPageViaInput($event)\" size=\"3\" />\n        <span class=\"ant-pagination-slash\">/</span>\n        {{ lastIndex }}\n      </li>\n      <li\n        dw-pagination-item\n        [attr.title]=\"locale?.next_page\"\n        [disabled]=\"isLastIndex\"\n        (click)=\"nextPage()\"\n        type=\"next\"\n        [itemRender]=\"itemRender\"\n      ></li>\n    </ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwPaginationSimpleComponent.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        DwPaginationSimpleComponent.propDecorators = {
            template: [{ type: core.ViewChild, args: ['containerTemplate', { static: true },] }],
            itemRender: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            total: [{ type: core.Input }],
            pageIndex: [{ type: core.Input }],
            pageSize: [{ type: core.Input }],
            pageIndexChange: [{ type: core.Output }]
        };
        return DwPaginationSimpleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.template;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.itemRender;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.disabled;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.locale;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.total;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.pageIndex;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.pageSize;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.pageIndexChange;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.lastIndex;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.isFirstIndex;
        /** @type {?} */
        DwPaginationSimpleComponent.prototype.isLastIndex;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPaginationModule = /** @class */ (function () {
        function DwPaginationModule() {
        }
        DwPaginationModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [
                            DwPaginationComponent,
                            DwPaginationSimpleComponent,
                            DwPaginationOptionsComponent,
                            DwPaginationItemComponent,
                            DwPaginationDefaultComponent
                        ],
                        exports: [DwPaginationComponent],
                        imports: [common.CommonModule, forms.FormsModule, select.DwSelectModule, i18n.DwI18nModule, icon.DwIconModule]
                    },] }
        ];
        return DwPaginationModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: pagination.types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function PaginationItemRenderContext() { }
    if (false) {
        /** @type {?} */
        PaginationItemRenderContext.prototype.$implicit;
        /** @type {?} */
        PaginationItemRenderContext.prototype.page;
    }

    exports.DwPaginationComponent = DwPaginationComponent;
    exports.DwPaginationDefaultComponent = DwPaginationDefaultComponent;
    exports.DwPaginationItemComponent = DwPaginationItemComponent;
    exports.DwPaginationModule = DwPaginationModule;
    exports.DwPaginationOptionsComponent = DwPaginationOptionsComponent;
    exports.DwPaginationSimpleComponent = DwPaginationSimpleComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-pagination.umd.js.map
