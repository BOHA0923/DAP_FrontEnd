(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/a11y'), require('@angular/cdk/keycodes'), require('@angular/cdk/overlay'), require('@angular/cdk/portal'), require('@angular/common'), require('@angular/core'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/drawer', ['exports', '@angular/cdk/a11y', '@angular/cdk/keycodes', '@angular/cdk/overlay', '@angular/cdk/portal', '@angular/common', '@angular/core', 'ng-quicksilver/core/config', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].drawer = {}), global.ng.cdk.a11y, global.ng.cdk.keycodes, global.ng.cdk.overlay, global.ng.cdk.portal, global.ng.common, global.ng.core, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon));
}(this, (function (exports, a11y, keycodes, overlay, portal, common, core, config, util, rxjs, operators, noAnimation, outlet, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer-ref.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @abstract
     * @template T, R
     */
    var   /**
     * @abstract
     * @template T, R
     */
    DwDrawerRef = /** @class */ (function () {
        function DwDrawerRef() {
        }
        return DwDrawerRef;
    }());
    if (false) {
        /** @type {?} */
        DwDrawerRef.prototype.afterClose;
        /** @type {?} */
        DwDrawerRef.prototype.afterOpen;
        /** @type {?} */
        DwDrawerRef.prototype.dwClosable;
        /** @type {?} */
        DwDrawerRef.prototype.dwNoAnimation;
        /** @type {?} */
        DwDrawerRef.prototype.dwMaskClosable;
        /** @type {?} */
        DwDrawerRef.prototype.dwKeyboard;
        /** @type {?} */
        DwDrawerRef.prototype.dwMask;
        /** @type {?} */
        DwDrawerRef.prototype.dwTitle;
        /** @type {?} */
        DwDrawerRef.prototype.dwPlacement;
        /** @type {?} */
        DwDrawerRef.prototype.dwMaskStyle;
        /** @type {?} */
        DwDrawerRef.prototype.dwBodyStyle;
        /** @type {?} */
        DwDrawerRef.prototype.dwWrapClassName;
        /** @type {?} */
        DwDrawerRef.prototype.dwWidth;
        /** @type {?} */
        DwDrawerRef.prototype.dwHeight;
        /** @type {?} */
        DwDrawerRef.prototype.dwZIndex;
        /** @type {?} */
        DwDrawerRef.prototype.dwOffsetX;
        /** @type {?} */
        DwDrawerRef.prototype.dwOffsetY;
        /**
         * @abstract
         * @param {?=} result
         * @return {?}
         */
        DwDrawerRef.prototype.close = function (result) { };
        /**
         * @abstract
         * @return {?}
         */
        DwDrawerRef.prototype.open = function () { };
        /**
         * @abstract
         * @return {?}
         */
        DwDrawerRef.prototype.getContentComponent = function () { };
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DRAWER_ANIMATE_DURATION = 300;
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'drawer';
    /**
     * @template T, R, D
     */
    var DwDrawerComponent = /** @class */ (function (_super) {
        __extends(DwDrawerComponent, _super);
        function DwDrawerComponent(document, dwConfigService, renderer, overlay, injector, changeDetectorRef, focusTrapFactory, viewContainerRef, overlayKeyboardDispatcher) {
            var _this = _super.call(this) || this;
            _this.document = document;
            _this.dwConfigService = dwConfigService;
            _this.renderer = renderer;
            _this.overlay = overlay;
            _this.injector = injector;
            _this.changeDetectorRef = changeDetectorRef;
            _this.focusTrapFactory = focusTrapFactory;
            _this.viewContainerRef = viewContainerRef;
            _this.overlayKeyboardDispatcher = overlayKeyboardDispatcher;
            _this.dwClosable = true;
            _this.dwMaskClosable = true;
            _this.dwMask = true;
            _this.dwCloseOnNavigation = true;
            _this.dwNoAnimation = false;
            _this.dwKeyboard = true;
            _this.dwPlacement = 'right';
            _this.dwMaskStyle = {};
            _this.dwBodyStyle = {};
            _this.dwWidth = 256;
            _this.dwHeight = 256;
            _this.dwZIndex = 1000;
            _this.dwOffsetX = 0;
            _this.dwOffsetY = 0;
            _this.componentInstance = null;
            _this.dwOnViewInit = new core.EventEmitter();
            _this.dwOnClose = new core.EventEmitter();
            _this.destroy$ = new rxjs.Subject();
            _this.placementChanging = false;
            _this.placementChangeTimeoutId = -1;
            _this.isOpen = false;
            _this.templateContext = {
                $implicit: undefined,
                drawerRef: (/** @type {?} */ (_this))
            };
            _this.dwAfterOpen = new rxjs.Subject();
            _this.dwAfterClose = new rxjs.Subject();
            return _this;
        }
        Object.defineProperty(DwDrawerComponent.prototype, "dwVisible", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isOpen;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.isOpen = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "offsetTransform", {
            get: /**
             * @return {?}
             */
            function () {
                if (!this.isOpen || this.dwOffsetX + this.dwOffsetY === 0) {
                    return null;
                }
                switch (this.dwPlacement) {
                    case 'left':
                        return "translateX(" + this.dwOffsetX + "px)";
                    case 'right':
                        return "translateX(-" + this.dwOffsetX + "px)";
                    case 'top':
                        return "translateY(" + this.dwOffsetY + "px)";
                    case 'bottom':
                        return "translateY(-" + this.dwOffsetY + "px)";
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "transform", {
            get: /**
             * @return {?}
             */
            function () {
                if (this.isOpen) {
                    return null;
                }
                switch (this.dwPlacement) {
                    case 'left':
                        return "translateX(-100%)";
                    case 'right':
                        return "translateX(100%)";
                    case 'top':
                        return "translateY(-100%)";
                    case 'bottom':
                        return "translateY(100%)";
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "width", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isLeftOrRight ? util.toCssPixel(this.dwWidth) : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "height", {
            get: /**
             * @return {?}
             */
            function () {
                return !this.isLeftOrRight ? util.toCssPixel(this.dwHeight) : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "isLeftOrRight", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwPlacement === 'left' || this.dwPlacement === 'right';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "afterOpen", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwAfterOpen.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDrawerComponent.prototype, "afterClose", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwAfterClose.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} value
         * @return {?}
         */
        DwDrawerComponent.prototype.isTemplateRef = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return value instanceof core.TemplateRef;
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.attachOverlay();
            this.updateOverlayStyle();
            this.updateBodyOverflow();
            this.templateContext = { $implicit: this.dwContentParams, drawerRef: (/** @type {?} */ (this)) };
            this.changeDetectorRef.detectChanges();
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.attachBodyContent();
            setTimeout((/**
             * @return {?}
             */
            function () {
                _this.dwOnViewInit.emit();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwDrawerComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwPlacement = changes.dwPlacement, dwVisible = changes.dwVisible;
            if (dwVisible) {
                /** @type {?} */
                var value = changes.dwVisible.currentValue;
                if (value) {
                    this.open();
                }
                else {
                    this.close();
                }
            }
            if (dwPlacement && !dwPlacement.isFirstChange()) {
                this.triggerPlacementChangeCycleOnce();
            }
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
            clearTimeout(this.placementChangeTimeoutId);
            this.disposeOverlay();
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.getAnimationDuration = /**
         * @private
         * @return {?}
         */
        function () {
            return this.dwNoAnimation ? 0 : DRAWER_ANIMATE_DURATION;
        };
        // Disable the transition animation temporarily when the placement changing
        // Disable the transition animation temporarily when the placement changing
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.triggerPlacementChangeCycleOnce = 
        // Disable the transition animation temporarily when the placement changing
        /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.dwNoAnimation) {
                this.placementChanging = true;
                this.changeDetectorRef.markForCheck();
                clearTimeout(this.placementChangeTimeoutId);
                this.placementChangeTimeoutId = setTimeout((/**
                 * @return {?}
                 */
                function () {
                    _this.placementChanging = false;
                    _this.changeDetectorRef.markForCheck();
                }), this.getAnimationDuration());
            }
        };
        /**
         * @param {?=} result
         * @return {?}
         */
        DwDrawerComponent.prototype.close = /**
         * @param {?=} result
         * @return {?}
         */
        function (result) {
            var _this = this;
            this.isOpen = false;
            this.updateOverlayStyle();
            this.overlayKeyboardDispatcher.remove((/** @type {?} */ (this.overlayRef)));
            this.changeDetectorRef.detectChanges();
            setTimeout((/**
             * @return {?}
             */
            function () {
                _this.updateBodyOverflow();
                _this.restoreFocus();
                _this.dwAfterClose.next(result);
                _this.dwAfterClose.complete();
                _this.componentInstance = null;
            }), this.getAnimationDuration());
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.open = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.attachOverlay();
            this.isOpen = true;
            this.overlayKeyboardDispatcher.add((/** @type {?} */ (this.overlayRef)));
            this.updateOverlayStyle();
            this.updateBodyOverflow();
            this.savePreviouslyFocusedElement();
            this.trapFocus();
            this.changeDetectorRef.detectChanges();
            setTimeout((/**
             * @return {?}
             */
            function () {
                _this.dwAfterOpen.next();
            }), this.getAnimationDuration());
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.getContentComponent = /**
         * @return {?}
         */
        function () {
            return this.componentInstance;
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.closeClick = /**
         * @return {?}
         */
        function () {
            this.dwOnClose.emit();
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.maskClick = /**
         * @return {?}
         */
        function () {
            if (this.dwMaskClosable && this.dwMask) {
                this.dwOnClose.emit();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.attachBodyContent = /**
         * @private
         * @return {?}
         */
        function () {
            (/** @type {?} */ (this.bodyPortalOutlet)).dispose();
            if (this.dwContent instanceof core.Type) {
                /** @type {?} */
                var childInjector = new portal.PortalInjector(this.injector, new WeakMap([[DwDrawerRef, this]]));
                /** @type {?} */
                var componentPortal = new portal.ComponentPortal(this.dwContent, null, childInjector);
                /** @type {?} */
                var componentRef = (/** @type {?} */ (this.bodyPortalOutlet)).attachComponentPortal(componentPortal);
                this.componentInstance = componentRef.instance;
                Object.assign(componentRef.instance, this.dwContentParams);
                componentRef.changeDetectorRef.detectChanges();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.attachOverlay = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.overlayRef) {
                this.portal = new portal.TemplatePortal(this.drawerTemplate, this.viewContainerRef);
                this.overlayRef = this.overlay.create(this.getOverlayConfig());
            }
            if (this.overlayRef && !this.overlayRef.hasAttached()) {
                this.overlayRef.attach(this.portal);
                (/** @type {?} */ (this.overlayRef)).keydownEvents()
                    .pipe(operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @param {?} event
                 * @return {?}
                 */
                function (event) {
                    if (event.keyCode === keycodes.ESCAPE && _this.isOpen && _this.dwKeyboard) {
                        _this.dwOnClose.emit();
                    }
                }));
                this.overlayRef
                    .detachments()
                    .pipe(operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.disposeOverlay();
                }));
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.disposeOverlay = /**
         * @private
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.overlayRef) === null || _a === void 0 ? void 0 : _a.dispose();
            this.overlayRef = null;
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.getOverlayConfig = /**
         * @private
         * @return {?}
         */
        function () {
            return new overlay.OverlayConfig({
                disposeOnNavigation: this.dwCloseOnNavigation,
                positionStrategy: this.overlay.position().global(),
                scrollStrategy: this.overlay.scrollStrategies.block()
            });
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.updateOverlayStyle = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.overlayRef && this.overlayRef.overlayElement) {
                this.renderer.setStyle(this.overlayRef.overlayElement, 'pointer-events', this.isOpen ? 'auto' : 'none');
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.updateBodyOverflow = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.overlayRef) {
                if (this.isOpen) {
                    (/** @type {?} */ (this.overlayRef.getConfig().scrollStrategy)).enable();
                }
                else {
                    (/** @type {?} */ (this.overlayRef.getConfig().scrollStrategy)).disable();
                }
            }
        };
        /**
         * @return {?}
         */
        DwDrawerComponent.prototype.savePreviouslyFocusedElement = /**
         * @return {?}
         */
        function () {
            if (this.document && !this.previouslyFocusedElement) {
                this.previouslyFocusedElement = (/** @type {?} */ (this.document.activeElement));
                // We need the extra check, because IE's svg element has no blur method.
                if (this.previouslyFocusedElement && typeof this.previouslyFocusedElement.blur === 'function') {
                    this.previouslyFocusedElement.blur();
                }
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.trapFocus = /**
         * @private
         * @return {?}
         */
        function () {
            if (!this.focusTrap && this.overlayRef && this.overlayRef.overlayElement) {
                this.focusTrap = this.focusTrapFactory.create((/** @type {?} */ (this.overlayRef)).overlayElement);
                this.focusTrap.focusInitialElement();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwDrawerComponent.prototype.restoreFocus = /**
         * @private
         * @return {?}
         */
        function () {
            // We need the extra check, because IE can set the `activeElement` to null in some cases.
            if (this.previouslyFocusedElement && typeof this.previouslyFocusedElement.focus === 'function') {
                this.previouslyFocusedElement.focus();
            }
            if (this.focusTrap) {
                this.focusTrap.destroy();
            }
        };
        DwDrawerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-drawer',
                        exportAs: 'dwDrawer',
                        template: "\n    <ng-template #drawerTemplate>\n      <div\n        class=\"ant-drawer\"\n        [dwNoAnimation]=\"dwNoAnimation\"\n        [class.ant-drawer-open]=\"isOpen\"\n        [class.no-mask]=\"!dwMask\"\n        [class.ant-drawer-top]=\"dwPlacement === 'top'\"\n        [class.ant-drawer-bottom]=\"dwPlacement === 'bottom'\"\n        [class.ant-drawer-right]=\"dwPlacement === 'right'\"\n        [class.ant-drawer-left]=\"dwPlacement === 'left'\"\n        [style.transform]=\"offsetTransform\"\n        [style.transition]=\"placementChanging ? 'none' : null\"\n        [style.zIndex]=\"dwZIndex\"\n      >\n        <div class=\"ant-drawer-mask\" (click)=\"maskClick()\" *ngIf=\"dwMask\" [ngStyle]=\"dwMaskStyle\"></div>\n        <div\n          class=\"ant-drawer-content-wrapper {{ dwWrapClassName }}\"\n          [style.width]=\"width\"\n          [style.height]=\"height\"\n          [style.transform]=\"transform\"\n          [style.transition]=\"placementChanging ? 'none' : null\"\n        >\n          <div class=\"ant-drawer-content\">\n            <div class=\"ant-drawer-wrapper-body\" [style.height]=\"isLeftOrRight ? '100%' : null\">\n              <div *ngIf=\"dwTitle || dwClosable\" [class.ant-drawer-header]=\"!!dwTitle\" [class.ant-drawer-header-no-title]=\"!dwTitle\">\n                <div *ngIf=\"dwTitle\" class=\"ant-drawer-title\">\n                  <ng-container *dwStringTemplateOutlet=\"dwTitle\"><div [innerHTML]=\"dwTitle\"></div></ng-container>\n                </div>\n                <button *ngIf=\"dwClosable\" (click)=\"closeClick()\" aria-label=\"Close\" class=\"ant-drawer-close\" style=\"--scroll-bar: 0px;\">\n                  <i dw-icon dwType=\"close\"></i>\n                </button>\n              </div>\n              <div class=\"ant-drawer-body\" [ngStyle]=\"dwBodyStyle\">\n                <ng-template cdkPortalOutlet></ng-template>\n                <ng-container *ngIf=\"isTemplateRef(dwContent)\">\n                  <ng-container *ngTemplateOutlet=\"$any(dwContent); context: templateContext\"></ng-container>\n                </ng-container>\n                <ng-content *ngIf=\"!dwContent\"></ng-content>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n  ",
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwDrawerComponent.ctorParameters = function () { return [
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [common.DOCUMENT,] }] },
            { type: config.DwConfigService },
            { type: core.Renderer2 },
            { type: overlay.Overlay },
            { type: core.Injector },
            { type: core.ChangeDetectorRef },
            { type: a11y.ConfigurableFocusTrapFactory },
            { type: core.ViewContainerRef },
            { type: overlay.OverlayKeyboardDispatcher }
        ]; };
        DwDrawerComponent.propDecorators = {
            dwContent: [{ type: core.Input }],
            dwClosable: [{ type: core.Input }],
            dwMaskClosable: [{ type: core.Input }],
            dwMask: [{ type: core.Input }],
            dwCloseOnNavigation: [{ type: core.Input }],
            dwNoAnimation: [{ type: core.Input }],
            dwKeyboard: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            dwPlacement: [{ type: core.Input }],
            dwMaskStyle: [{ type: core.Input }],
            dwBodyStyle: [{ type: core.Input }],
            dwWrapClassName: [{ type: core.Input }],
            dwWidth: [{ type: core.Input }],
            dwHeight: [{ type: core.Input }],
            dwZIndex: [{ type: core.Input }],
            dwOffsetX: [{ type: core.Input }],
            dwOffsetY: [{ type: core.Input }],
            dwVisible: [{ type: core.Input }],
            dwOnViewInit: [{ type: core.Output }],
            dwOnClose: [{ type: core.Output }],
            drawerTemplate: [{ type: core.ViewChild, args: ['drawerTemplate', { static: true },] }],
            bodyPortalOutlet: [{ type: core.ViewChild, args: [portal.CdkPortalOutlet, { static: false },] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDrawerComponent.prototype, "dwClosable", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDrawerComponent.prototype, "dwMaskClosable", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDrawerComponent.prototype, "dwMask", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDrawerComponent.prototype, "dwCloseOnNavigation", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwDrawerComponent.prototype, "dwNoAnimation", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDrawerComponent.prototype, "dwKeyboard", void 0);
        return DwDrawerComponent;
    }(DwDrawerRef));
    if (false) {
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwClosable;
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwMaskClosable;
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwMask;
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwNoAnimation;
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwKeyboard;
        /** @type {?} */
        DwDrawerComponent.ngAcceptInputType_dwCloseOnNavigation;
        /** @type {?} */
        DwDrawerComponent.prototype.dwContent;
        /** @type {?} */
        DwDrawerComponent.prototype.dwClosable;
        /** @type {?} */
        DwDrawerComponent.prototype.dwMaskClosable;
        /** @type {?} */
        DwDrawerComponent.prototype.dwMask;
        /** @type {?} */
        DwDrawerComponent.prototype.dwCloseOnNavigation;
        /** @type {?} */
        DwDrawerComponent.prototype.dwNoAnimation;
        /** @type {?} */
        DwDrawerComponent.prototype.dwKeyboard;
        /** @type {?} */
        DwDrawerComponent.prototype.dwTitle;
        /** @type {?} */
        DwDrawerComponent.prototype.dwPlacement;
        /** @type {?} */
        DwDrawerComponent.prototype.dwMaskStyle;
        /** @type {?} */
        DwDrawerComponent.prototype.dwBodyStyle;
        /** @type {?} */
        DwDrawerComponent.prototype.dwWrapClassName;
        /** @type {?} */
        DwDrawerComponent.prototype.dwWidth;
        /** @type {?} */
        DwDrawerComponent.prototype.dwHeight;
        /** @type {?} */
        DwDrawerComponent.prototype.dwZIndex;
        /** @type {?} */
        DwDrawerComponent.prototype.dwOffsetX;
        /** @type {?} */
        DwDrawerComponent.prototype.dwOffsetY;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.componentInstance;
        /** @type {?} */
        DwDrawerComponent.prototype.dwOnViewInit;
        /** @type {?} */
        DwDrawerComponent.prototype.dwOnClose;
        /** @type {?} */
        DwDrawerComponent.prototype.drawerTemplate;
        /** @type {?} */
        DwDrawerComponent.prototype.bodyPortalOutlet;
        /** @type {?} */
        DwDrawerComponent.prototype.destroy$;
        /** @type {?} */
        DwDrawerComponent.prototype.previouslyFocusedElement;
        /** @type {?} */
        DwDrawerComponent.prototype.placementChanging;
        /** @type {?} */
        DwDrawerComponent.prototype.placementChangeTimeoutId;
        /** @type {?} */
        DwDrawerComponent.prototype.dwContentParams;
        /** @type {?} */
        DwDrawerComponent.prototype.overlayRef;
        /** @type {?} */
        DwDrawerComponent.prototype.portal;
        /** @type {?} */
        DwDrawerComponent.prototype.focusTrap;
        /** @type {?} */
        DwDrawerComponent.prototype.isOpen;
        /** @type {?} */
        DwDrawerComponent.prototype.templateContext;
        /** @type {?} */
        DwDrawerComponent.prototype.dwAfterOpen;
        /** @type {?} */
        DwDrawerComponent.prototype.dwAfterClose;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.document;
        /** @type {?} */
        DwDrawerComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.overlay;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.injector;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.changeDetectorRef;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.focusTrapFactory;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.viewContainerRef;
        /**
         * @type {?}
         * @private
         */
        DwDrawerComponent.prototype.overlayKeyboardDispatcher;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer.service.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDrawerServiceModule = /** @class */ (function () {
        function DwDrawerServiceModule() {
        }
        DwDrawerServiceModule.decorators = [
            { type: core.NgModule }
        ];
        return DwDrawerServiceModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDrawerModule = /** @class */ (function () {
        function DwDrawerModule() {
        }
        DwDrawerModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, overlay.OverlayModule, portal.PortalModule, icon.DwIconModule, outlet.DwOutletModule, noAnimation.DwNoAnimationModule, DwDrawerServiceModule],
                        exports: [DwDrawerComponent],
                        declarations: [DwDrawerComponent],
                        entryComponents: [DwDrawerComponent]
                    },] }
        ];
        return DwDrawerModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @template T, R
     */
    var   /**
     * @template T, R
     */
    DrawerBuilderForService = /** @class */ (function () {
        function DrawerBuilderForService(overlay, options) {
            var _this = this;
            this.overlay = overlay;
            this.options = options;
            this.unsubscribe$ = new rxjs.Subject();
            /**
             * pick {\@link DwDrawerOptions.dwOnCancel} and omit this option
             */
            var _a = this.options, dwOnCancel = _a.dwOnCancel, componentOption = __rest(_a, ["dwOnCancel"]);
            this.overlayRef = this.overlay.create();
            this.drawerRef = this.overlayRef.attach(new portal.ComponentPortal(DwDrawerComponent)).instance;
            this.updateOptions(componentOption);
            // Prevent repeatedly open drawer when tap focus element.
            this.drawerRef.savePreviouslyFocusedElement();
            this.drawerRef.dwOnViewInit.pipe(operators.takeUntil(this.unsubscribe$)).subscribe((/**
             * @return {?}
             */
            function () {
                (/** @type {?} */ (_this.drawerRef)).open();
            }));
            this.drawerRef.dwOnClose.subscribe((/**
             * @return {?}
             */
            function () {
                if (dwOnCancel) {
                    dwOnCancel().then((/**
                     * @param {?} canClose
                     * @return {?}
                     */
                    function (canClose) {
                        if (canClose !== false) {
                            (/** @type {?} */ (_this.drawerRef)).close();
                        }
                    }));
                }
                else {
                    (/** @type {?} */ (_this.drawerRef)).close();
                }
            }));
            this.drawerRef.afterClose.pipe(operators.takeUntil(this.unsubscribe$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.overlayRef.dispose();
                _this.drawerRef = null;
                _this.unsubscribe$.next();
                _this.unsubscribe$.complete();
            }));
        }
        /**
         * @return {?}
         */
        DrawerBuilderForService.prototype.getInstance = /**
         * @return {?}
         */
        function () {
            return (/** @type {?} */ (this.drawerRef));
        };
        /**
         * @param {?} options
         * @return {?}
         */
        DrawerBuilderForService.prototype.updateOptions = /**
         * @param {?} options
         * @return {?}
         */
        function (options) {
            Object.assign((/** @type {?} */ (this.drawerRef)), options);
        };
        return DrawerBuilderForService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DrawerBuilderForService.prototype.drawerRef;
        /**
         * @type {?}
         * @private
         */
        DrawerBuilderForService.prototype.overlayRef;
        /**
         * @type {?}
         * @private
         */
        DrawerBuilderForService.prototype.unsubscribe$;
        /**
         * @type {?}
         * @private
         */
        DrawerBuilderForService.prototype.overlay;
        /**
         * @type {?}
         * @private
         */
        DrawerBuilderForService.prototype.options;
    }
    var DwDrawerService = /** @class */ (function () {
        function DwDrawerService(overlay) {
            this.overlay = overlay;
        }
        /**
         * @template T, D, R
         * @param {?} options
         * @return {?}
         */
        DwDrawerService.prototype.create = /**
         * @template T, D, R
         * @param {?} options
         * @return {?}
         */
        function (options) {
            return new DrawerBuilderForService(this.overlay, options).getInstance();
        };
        DwDrawerService.decorators = [
            { type: core.Injectable, args: [{ providedIn: DwDrawerServiceModule },] }
        ];
        /** @nocollapse */
        DwDrawerService.ctorParameters = function () { return [
            { type: overlay.Overlay }
        ]; };
        /** @nocollapse */ DwDrawerService.ɵprov = core.ɵɵdefineInjectable({ factory: function DwDrawerService_Factory() { return new DwDrawerService(core.ɵɵinject(overlay.Overlay)); }, token: DwDrawerService, providedIn: DwDrawerServiceModule });
        return DwDrawerService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwDrawerService.prototype.overlay;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: drawer-options.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     * @template T, D
     */
    function DwDrawerOptionsOfComponent() { }
    if (false) {
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwClosable;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwMaskClosable;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwCloseOnNavigation;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwMask;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwKeyboard;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwNoAnimation;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwTitle;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwContent;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwContentParams;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwMaskStyle;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwBodyStyle;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwWrapClassName;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwWidth;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwHeight;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwPlacement;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwZIndex;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwOffsetX;
        /** @type {?|undefined} */
        DwDrawerOptionsOfComponent.prototype.dwOffsetY;
    }
    /**
     * @record
     * @template T, D
     */
    function DwDrawerOptions() { }
    if (false) {
        /**
         * @return {?}
         */
        DwDrawerOptions.prototype.dwOnCancel = function () { };
    }

    exports.DRAWER_ANIMATE_DURATION = DRAWER_ANIMATE_DURATION;
    exports.DrawerBuilderForService = DrawerBuilderForService;
    exports.DwDrawerComponent = DwDrawerComponent;
    exports.DwDrawerModule = DwDrawerModule;
    exports.DwDrawerRef = DwDrawerRef;
    exports.DwDrawerService = DwDrawerService;
    exports.DwDrawerServiceModule = DwDrawerServiceModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-drawer.umd.js.map
