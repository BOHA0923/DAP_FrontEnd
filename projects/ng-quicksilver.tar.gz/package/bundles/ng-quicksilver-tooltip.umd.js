(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/no-animation'), require('@angular/cdk/overlay'), require('ng-quicksilver/core/logger'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('ng-quicksilver/core/outlet')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/tooltip', ['exports', '@angular/core', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/no-animation', '@angular/cdk/overlay', 'ng-quicksilver/core/logger', 'ng-quicksilver/core/overlay', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/common', 'ng-quicksilver/core/outlet'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].tooltip = {}), global.ng.core, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core['no-animation'], global.ng.cdk.overlay, global['ng-quicksilver'].core.logger, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.common, global['ng-quicksilver'].core.outlet));
}(this, (function (exports, core, animation, noAnimation, overlay, logger, overlay$1, util, rxjs, operators, common, outlet) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: base.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @abstract
     */
    var DwTooltipBaseDirective = /** @class */ (function () {
        function DwTooltipBaseDirective(elementRef, hostView, resolver, renderer, noAnimation) {
            this.elementRef = elementRef;
            this.hostView = hostView;
            this.resolver = resolver;
            this.renderer = renderer;
            this.noAnimation = noAnimation;
            this.specificVisibleChange = new core.EventEmitter();
            /**
             * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
             * Please use a more specific API. Like `dwTooltipTrigger`.
             */
            this.dwTrigger = 'hover';
            /**
             * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
             * Please use a more specific API. Like `dwTooltipPlacement`.
             */
            this.dwPlacement = 'top';
            this.visible = false;
            this.needProxyProperties = ['noAnimation'];
            this.dwVisibleChange = new core.EventEmitter();
            this.destroy$ = new rxjs.Subject();
            this.triggerDisposables = [];
        }
        Object.defineProperty(DwTooltipBaseDirective.prototype, "title", {
            /**
             * This true title that would be used in other parts on this component.
             */
            get: /**
             * This true title that would be used in other parts on this component.
             * @protected
             * @return {?}
             */
            function () {
                return this.specificTitle || this.directiveNameTitle || this.dwTitle || null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "content", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificContent || this.directiveNameContent || this.dwContent || null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "placement", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificPlacement || this.dwPlacement;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "trigger", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                // DwTooltipTrigger can be null.
                return typeof this.specificTrigger !== 'undefined' ? this.specificTrigger : this.dwTrigger;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "isVisible", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificVisible || this.dwVisible || false;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "mouseEnterDelay", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificMouseEnterDelay || this.dwMouseEnterDelay || 0.15;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "mouseLeaveDelay", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificMouseLeaveDelay || this.dwMouseLeaveDelay || 0.1;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "overlayClassName", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificOverlayClassName || this.dwOverlayClassName || null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseDirective.prototype, "overlayStyle", {
            get: /**
             * @protected
             * @return {?}
             */
            function () {
                return this.specificOverlayStyle || this.dwOverlayStyle || null;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} isNeeded
         * @param {?} property
         * @param {?} newProperty
         * @param {?=} comp
         * @param {?=} shared
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.warnDeprecationIfNeeded = /**
         * @param {?} isNeeded
         * @param {?} property
         * @param {?} newProperty
         * @param {?=} comp
         * @param {?=} shared
         * @return {?}
         */
        function (isNeeded, property, newProperty, comp, shared) {
            if (comp === void 0) { comp = 'dw-tooltip'; }
            if (shared === void 0) { shared = true; }
            if (isNeeded) {
                /** @type {?} */
                var message = "'" + property + "' of '" + comp + "' is deprecated and will be removed in 10.0.0.\n      Please use '" + newProperty + "' instead.";
                if (shared) {
                    message = message + " The same with 'dw-popover' and 'dw-popconfirm'.";
                }
                logger.warnDeprecation(message);
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.warnDeprecationByChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            // warn deprecated things when specific property is not given
            this.warnDeprecationIfNeeded(changes.dwTitle && !this.specificTitle && !this.directiveNameTitle, 'dwTitle', 'dwTooltipTitle');
            this.warnDeprecationIfNeeded(changes.dwContent && !this.specificContent, 'dwContent', 'dwPopoverContent', 'dw-popover', false);
            this.warnDeprecationIfNeeded(changes.dwPlacement && !this.specificPlacement, 'dwPlacement', 'dwTooltipPlacement');
            this.warnDeprecationIfNeeded(changes.dwTrigger && !this.specificTrigger, 'dwTrigger', 'dwTooltipTrigger');
            this.warnDeprecationIfNeeded(changes.dwVisible && !this.specificVisible, 'dwVisible', 'dwTooltipVisible');
            this.warnDeprecationIfNeeded(changes.dwMouseEnterDelay && !this.specificMouseEnterDelay, 'dwMouseEnterDelay', 'dwTooltipMouseEnterDelay');
            this.warnDeprecationIfNeeded(changes.dwMouseLeaveDelay && !this.specificMouseLeaveDelay, 'dwMouseLeaveDelay', 'dwTooltipMouseLeaveDelay');
            this.warnDeprecationIfNeeded(changes.dwOverlayClassName && !this.specificOverlayClassName, 'dwOverlayClassName', 'dwTooltipClassName');
            this.warnDeprecationIfNeeded(changes.dwOverlayStyle && !this.specificOverlayStyle, 'dwOverlayStyle', 'dwTooltipOverlayStyle');
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwTrigger = changes.dwTrigger, specificTrigger = changes.specificTrigger;
            /** @type {?} */
            var trigger = specificTrigger || dwTrigger;
            if (trigger && !trigger.isFirstChange()) {
                this.registerTriggers();
            }
            if (this.component) {
                this.updateChangedProperties(changes);
            }
            this.warnDeprecationByChanges(changes);
        };
        /**
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            this.createComponent();
            this.registerTriggers();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
            // Clear toggling timer. Issue #3875 #4317 #4386
            this.clearTogglingTimer();
            this.removeTriggerListeners();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.show = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.component) === null || _a === void 0 ? void 0 : _a.show();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.hide = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.component) === null || _a === void 0 ? void 0 : _a.hide();
        };
        /**
         * Force the component to update its position.
         */
        /**
         * Force the component to update its position.
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.updatePosition = /**
         * Force the component to update its position.
         * @return {?}
         */
        function () {
            if (this.component) {
                this.component.updatePosition();
            }
        };
        /**
         * Create a dynamic tooltip component. This method can be override.
         */
        /**
         * Create a dynamic tooltip component. This method can be override.
         * @protected
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.createComponent = /**
         * Create a dynamic tooltip component. This method can be override.
         * @protected
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var componentRef = this.hostView.createComponent(this.componentFactory);
            this.component = componentRef.instance;
            // Remove the component's DOM because it should be in the overlay container.
            this.renderer.removeChild(this.renderer.parentNode(this.elementRef.nativeElement), componentRef.location.nativeElement);
            this.component.setOverlayOrigin({ elementRef: this.specificOrigin || this.elementRef });
            this.updateChangedProperties(this.needProxyProperties);
            this.component.dwVisibleChange.pipe(operators.distinctUntilChanged(), operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} visible
             * @return {?}
             */
            function (visible) {
                _this.visible = visible;
                _this.specificVisibleChange.emit(visible);
                _this.dwVisibleChange.emit(visible);
            }));
        };
        /**
         * @protected
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.registerTriggers = /**
         * @protected
         * @return {?}
         */
        function () {
            var _this = this;
            // When the method gets invoked, all properties has been synced to the dynamic component.
            // After removing the old API, we can just check the directive's own `dwTrigger`.
            /** @type {?} */
            var el = this.elementRef.nativeElement;
            /** @type {?} */
            var trigger = this.trigger;
            this.removeTriggerListeners();
            if (trigger === 'hover') {
                /** @type {?} */
                var overlayElement_1;
                this.triggerDisposables.push(this.renderer.listen(el, 'mouseenter', (/**
                 * @return {?}
                 */
                function () {
                    _this.delayEnterLeave(true, true, _this.mouseEnterDelay);
                })));
                this.triggerDisposables.push(this.renderer.listen(el, 'mouseleave', (/**
                 * @return {?}
                 */
                function () {
                    var _a;
                    _this.delayEnterLeave(true, false, _this.mouseLeaveDelay);
                    if (((_a = _this.component) === null || _a === void 0 ? void 0 : _a.overlay.overlayRef) && !overlayElement_1) {
                        overlayElement_1 = _this.component.overlay.overlayRef.overlayElement;
                        _this.triggerDisposables.push(_this.renderer.listen(overlayElement_1, 'mouseenter', (/**
                         * @return {?}
                         */
                        function () {
                            _this.delayEnterLeave(false, true);
                        })));
                        _this.triggerDisposables.push(_this.renderer.listen(overlayElement_1, 'mouseleave', (/**
                         * @return {?}
                         */
                        function () {
                            _this.delayEnterLeave(false, false);
                        })));
                    }
                })));
            }
            else if (trigger === 'focus') {
                this.triggerDisposables.push(this.renderer.listen(el, 'focus', (/**
                 * @return {?}
                 */
                function () { return _this.show(); })));
                this.triggerDisposables.push(this.renderer.listen(el, 'blur', (/**
                 * @return {?}
                 */
                function () { return _this.hide(); })));
            }
            else if (trigger === 'click') {
                this.triggerDisposables.push(this.renderer.listen(el, 'click', (/**
                 * @param {?} e
                 * @return {?}
                 */
                function (e) {
                    e.preventDefault();
                    _this.show();
                })));
            } // Else do nothing because user wants to control the visibility programmatically.
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.updatePropertiesByChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            /** @type {?} */
            var properties = {
                specificTitle: ['dwTitle', this.title],
                directiveNameTitle: ['dwTitle', this.title],
                dwTitle: ['dwTitle', this.title],
                specificContent: ['dwContent', this.content],
                directiveNameContent: ['dwContent', this.content],
                dwContent: ['dwContent', this.content],
                specificTrigger: ['dwTrigger', this.trigger],
                dwTrigger: ['dwTrigger', this.trigger],
                specificPlacement: ['dwPlacement', this.placement],
                dwPlacement: ['dwPlacement', this.placement],
                specificVisible: ['dwVisible', this.isVisible],
                dwVisible: ['dwVisible', this.isVisible],
                specificMouseEnterDelay: ['dwMouseEnterDelay', this.mouseEnterDelay],
                dwMouseEnterDelay: ['dwMouseEnterDelay', this.mouseEnterDelay],
                specificMouseLeaveDelay: ['dwMouseLeaveDelay', this.mouseLeaveDelay],
                dwMouseLeaveDelay: ['dwMouseLeaveDelay', this.mouseLeaveDelay],
                specificOverlayClassName: ['dwOverlayClassName', this.overlayClassName],
                dwOverlayClassName: ['dwOverlayClassName', this.overlayClassName],
                specificOverlayStyle: ['dwOverlayStyle', this.overlayStyle],
                dwOverlayStyle: ['dwOverlayStyle', this.overlayStyle]
            };
            /** @type {?} */
            var keys = Object.keys(changes);
            keys.forEach((/**
             * @param {?} property
             * @return {?}
             */
            function (property) {
                // @ts-ignore
                if (properties[property]) {
                    // @ts-ignore
                    var _a = __read(properties[property], 2), name_1 = _a[0], value = _a[1];
                    _this.updateComponentValue(name_1, value);
                }
            }));
        };
        /**
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.updatePropertiesByArray = /**
         * @return {?}
         */
        function () {
            this.updateComponentValue('dwTitle', this.title);
            this.updateComponentValue('dwContent', this.content);
            this.updateComponentValue('dwPlacement', this.placement);
            this.updateComponentValue('dwTrigger', this.trigger);
            this.updateComponentValue('dwVisible', this.isVisible);
            this.updateComponentValue('dwMouseEnterDelay', this.mouseEnterDelay);
            this.updateComponentValue('dwMouseLeaveDelay', this.mouseLeaveDelay);
            this.updateComponentValue('dwOverlayClassName', this.overlayClassName);
            this.updateComponentValue('dwOverlayStyle', this.overlayStyle);
        };
        /**
         * Sync changed properties to the component and trigger change detection in that component.
         */
        /**
         * Sync changed properties to the component and trigger change detection in that component.
         * @protected
         * @param {?} propertiesOrChanges
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.updateChangedProperties = /**
         * Sync changed properties to the component and trigger change detection in that component.
         * @protected
         * @param {?} propertiesOrChanges
         * @return {?}
         */
        function (propertiesOrChanges) {
            var _this = this;
            var _a;
            /** @type {?} */
            var isArray = Array.isArray(propertiesOrChanges);
            /** @type {?} */
            var keys = isArray ? ((/** @type {?} */ (propertiesOrChanges))) : Object.keys(propertiesOrChanges);
            keys.forEach((/**
             * @param {?} property
             * @return {?}
             */
            function (property) {
                if (_this.needProxyProperties.indexOf(property) !== -1) {
                    // @ts-ignore
                    _this.updateComponentValue(property, _this[property]);
                }
            }));
            if (isArray) {
                this.updatePropertiesByArray();
            }
            else {
                this.updatePropertiesByChanges((/** @type {?} */ (propertiesOrChanges)));
            }
            (_a = this.component) === null || _a === void 0 ? void 0 : _a.updateByDirective();
        };
        /**
         * @private
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.updateComponentValue = /**
         * @private
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        function (key, value) {
            if (typeof value !== 'undefined') {
                // @ts-ignore
                this.component[key] = value;
            }
        };
        /**
         * @private
         * @param {?} isOrigin
         * @param {?} isEnter
         * @param {?=} delay
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.delayEnterLeave = /**
         * @private
         * @param {?} isOrigin
         * @param {?} isEnter
         * @param {?=} delay
         * @return {?}
         */
        function (isOrigin, isEnter, delay) {
            var _this = this;
            if (delay === void 0) { delay = -1; }
            if (this.delayTimer) {
                this.clearTogglingTimer();
            }
            else if (delay > 0) {
                this.delayTimer = setTimeout((/**
                 * @return {?}
                 */
                function () {
                    _this.delayTimer = undefined;
                    isEnter ? _this.show() : _this.hide();
                }), delay * 1000);
            }
            else {
                // `isOrigin` is used due to the tooltip will not hide immediately
                // (may caused by the fade-out animation).
                isEnter && isOrigin ? this.show() : this.hide();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.removeTriggerListeners = /**
         * @private
         * @return {?}
         */
        function () {
            this.triggerDisposables.forEach((/**
             * @param {?} dispose
             * @return {?}
             */
            function (dispose) { return dispose(); }));
            this.triggerDisposables.length = 0;
        };
        /**
         * @private
         * @return {?}
         */
        DwTooltipBaseDirective.prototype.clearTogglingTimer = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.delayTimer) {
                clearTimeout(this.delayTimer);
                this.delayTimer = undefined;
            }
        };
        DwTooltipBaseDirective.decorators = [
            { type: core.Directive }
        ];
        /** @nocollapse */
        DwTooltipBaseDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.ViewContainerRef },
            { type: core.ComponentFactoryResolver },
            { type: core.Renderer2 },
            { type: noAnimation.DwNoAnimationDirective }
        ]; };
        DwTooltipBaseDirective.propDecorators = {
            dwTitle: [{ type: core.Input }],
            dwContent: [{ type: core.Input }],
            dwTrigger: [{ type: core.Input }],
            dwPlacement: [{ type: core.Input }],
            dwMouseEnterDelay: [{ type: core.Input }],
            dwMouseLeaveDelay: [{ type: core.Input }],
            dwOverlayClassName: [{ type: core.Input }],
            dwOverlayStyle: [{ type: core.Input }],
            dwVisible: [{ type: core.Input }],
            dwVisibleChange: [{ type: core.Output }]
        };
        return DwTooltipBaseDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTooltipBaseDirective.prototype.directiveNameTitle;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificTitle;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.directiveNameContent;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificContent;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificTrigger;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificPlacement;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificOrigin;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificVisible;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificMouseEnterDelay;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificMouseLeaveDelay;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificOverlayClassName;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificOverlayStyle;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.specificVisibleChange;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * Please use a more specific API. Like `dwTooltipTitle`.
         * @type {?}
         */
        DwTooltipBaseDirective.prototype.dwTitle;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * Please use a more specific API. Like `dwPopoverContent`.
         * @type {?}
         */
        DwTooltipBaseDirective.prototype.dwContent;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * Please use a more specific API. Like `dwTooltipTrigger`.
         * @type {?}
         */
        DwTooltipBaseDirective.prototype.dwTrigger;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * Please use a more specific API. Like `dwTooltipPlacement`.
         * @type {?}
         */
        DwTooltipBaseDirective.prototype.dwPlacement;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwMouseEnterDelay;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwMouseLeaveDelay;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwOverlayClassName;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwOverlayStyle;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwVisible;
        /**
         * For create tooltip dynamically. This should be override for each different component.
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.componentFactory;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.visible;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.needProxyProperties;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.dwVisibleChange;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.component;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.destroy$;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.triggerDisposables;
        /**
         * @type {?}
         * @private
         */
        DwTooltipBaseDirective.prototype.delayTimer;
        /** @type {?} */
        DwTooltipBaseDirective.prototype.elementRef;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.hostView;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.resolver;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.renderer;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseDirective.prototype.noAnimation;
    }
    /**
     * @abstract
     */
    var DwTooltipBaseComponent = /** @class */ (function () {
        function DwTooltipBaseComponent(cdr, noAnimation) {
            this.cdr = cdr;
            this.noAnimation = noAnimation;
            this.dwVisibleChange = new rxjs.Subject();
            this.dwTitle = null;
            this.dwContent = null;
            this.dwOverlayStyle = {};
            this._visible = false;
            this._trigger = 'hover';
            this.preferredPlacement = 'top';
            this._classMap = {};
            this._hasBackdrop = false;
            this._prefix = 'ant-tooltip-placement';
            this._positions = __spread(overlay$1.DEFAULT_TOOLTIP_POSITIONS);
        }
        Object.defineProperty(DwTooltipBaseComponent.prototype, "dwVisible", {
            get: /**
             * @return {?}
             */
            function () {
                return this._visible;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                /** @type {?} */
                var visible = util.toBoolean(value);
                if (this._visible !== visible) {
                    this._visible = visible;
                    this.dwVisibleChange.next(visible);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseComponent.prototype, "dwTrigger", {
            get: /**
             * @return {?}
             */
            function () {
                return this._trigger;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this._trigger = value;
                this._hasBackdrop = this._trigger === 'click';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTooltipBaseComponent.prototype, "dwPlacement", {
            get: /**
             * @return {?}
             */
            function () {
                return this.preferredPlacement;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (value !== this.preferredPlacement) {
                    this.preferredPlacement = value;
                    this._positions = __spread([overlay$1.POSITION_MAP[this.dwPlacement]], this._positions);
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.dwVisibleChange.complete();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.show = /**
         * @return {?}
         */
        function () {
            if (this.dwVisible) {
                return;
            }
            if (!this.isEmpty()) {
                this.dwVisible = true;
                this.dwVisibleChange.next(true);
                this.cdr.detectChanges();
            }
        };
        /**
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.hide = /**
         * @return {?}
         */
        function () {
            if (!this.dwVisible) {
                return;
            }
            this.dwVisible = false;
            this.dwVisibleChange.next(false);
            this.cdr.detectChanges();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.updateByDirective = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.setClassMap();
            this.cdr.detectChanges();
            Promise.resolve().then((/**
             * @return {?}
             */
            function () {
                _this.updatePosition();
                _this.updateVisibilityByTitle();
            }));
        };
        /**
         * Force the component to update its position.
         */
        /**
         * Force the component to update its position.
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.updatePosition = /**
         * Force the component to update its position.
         * @return {?}
         */
        function () {
            if (this.origin && this.overlay && this.overlay.overlayRef) {
                this.overlay.overlayRef.updatePosition();
            }
        };
        /**
         * @param {?} position
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.onPositionChange = /**
         * @param {?} position
         * @return {?}
         */
        function (position) {
            this.preferredPlacement = (/** @type {?} */ (overlay$1.getPlacementName(position)));
            this.setClassMap();
            this.cdr.detectChanges();
        };
        /**
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.setClassMap = /**
         * @return {?}
         */
        function () {
            var _a;
            this._classMap = (_a = {},
                _a[this.dwOverlayClassName] = true,
                _a[this._prefix + "-" + this.preferredPlacement] = true,
                _a);
        };
        /**
         * @param {?} origin
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.setOverlayOrigin = /**
         * @param {?} origin
         * @return {?}
         */
        function (origin) {
            this.origin = origin;
            this.cdr.markForCheck();
        };
        /**
         * Hide the component while the content is empty.
         */
        /**
         * Hide the component while the content is empty.
         * @private
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.updateVisibilityByTitle = /**
         * Hide the component while the content is empty.
         * @private
         * @return {?}
         */
        function () {
            if (this.isEmpty()) {
                this.hide();
            }
        };
        DwTooltipBaseComponent.decorators = [
            { type: core.Directive }
        ];
        /** @nocollapse */
        DwTooltipBaseComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: noAnimation.DwNoAnimationDirective }
        ]; };
        DwTooltipBaseComponent.propDecorators = {
            overlay: [{ type: core.ViewChild, args: ['overlay', { static: false },] }]
        };
        return DwTooltipBaseComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTooltipBaseComponent.ngAcceptInputType_dwVisible;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.overlay;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwVisibleChange;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwTitle;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwContent;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwOverlayClassName;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwOverlayStyle;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwMouseEnterDelay;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.dwMouseLeaveDelay;
        /** @type {?} */
        DwTooltipBaseComponent.prototype._visible;
        /**
         * @type {?}
         * @protected
         */
        DwTooltipBaseComponent.prototype._trigger;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.origin;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.preferredPlacement;
        /** @type {?} */
        DwTooltipBaseComponent.prototype._classMap;
        /** @type {?} */
        DwTooltipBaseComponent.prototype._hasBackdrop;
        /** @type {?} */
        DwTooltipBaseComponent.prototype._prefix;
        /** @type {?} */
        DwTooltipBaseComponent.prototype._positions;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.cdr;
        /** @type {?} */
        DwTooltipBaseComponent.prototype.noAnimation;
        /**
         * Empty component cannot be opened.
         * @abstract
         * @protected
         * @return {?}
         */
        DwTooltipBaseComponent.prototype.isEmpty = function () { };
    }
    /**
     * @param {?} value
     * @return {?}
     */
    function isTooltipEmpty(value) {
        return value instanceof core.TemplateRef ? false : value === '' || !util.isNotNil(value);
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tooltip.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTooltipDirective = /** @class */ (function (_super) {
        __extends(DwTooltipDirective, _super);
        function DwTooltipDirective(elementRef, hostView, resolver, renderer, noAnimation) {
            var _this = _super.call(this, elementRef, hostView, resolver, renderer, noAnimation) || this;
            // tslint:disable-next-line:no-output-rename
            _this.specificVisibleChange = new core.EventEmitter();
            _this.componentFactory = _this.resolver.resolveComponentFactory(DwToolTipComponent);
            return _this;
        }
        DwTooltipDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-tooltip]',
                        exportAs: 'dwTooltip',
                        host: {
                            '[class.ant-tooltip-open]': 'visible'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwTooltipDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.ViewContainerRef },
            { type: core.ComponentFactoryResolver },
            { type: core.Renderer2 },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwTooltipDirective.propDecorators = {
            specificTitle: [{ type: core.Input, args: ['dwTooltipTitle',] }],
            directiveNameTitle: [{ type: core.Input, args: ['dw-tooltip',] }],
            specificTrigger: [{ type: core.Input, args: ['dwTooltipTrigger',] }],
            specificPlacement: [{ type: core.Input, args: ['dwTooltipPlacement',] }],
            specificOrigin: [{ type: core.Input, args: ['dwTooltipOrigin',] }],
            specificVisible: [{ type: core.Input, args: ['dwTooltipVisible',] }],
            specificMouseEnterDelay: [{ type: core.Input, args: ['dwTooltipMouseEnterDelay',] }],
            specificMouseLeaveDelay: [{ type: core.Input, args: ['dwTooltipMouseLeaveDelay',] }],
            specificOverlayClassName: [{ type: core.Input, args: ['dwTooltipOverlayClassName',] }],
            specificOverlayStyle: [{ type: core.Input, args: ['dwTooltipOverlayStyle',] }],
            specificVisibleChange: [{ type: core.Output, args: ['dwTooltipVisibleChange',] }]
        };
        return DwTooltipDirective;
    }(DwTooltipBaseDirective));
    if (false) {
        /** @type {?} */
        DwTooltipDirective.prototype.specificTitle;
        /** @type {?} */
        DwTooltipDirective.prototype.directiveNameTitle;
        /** @type {?} */
        DwTooltipDirective.prototype.specificTrigger;
        /** @type {?} */
        DwTooltipDirective.prototype.specificPlacement;
        /** @type {?} */
        DwTooltipDirective.prototype.specificOrigin;
        /** @type {?} */
        DwTooltipDirective.prototype.specificVisible;
        /** @type {?} */
        DwTooltipDirective.prototype.specificMouseEnterDelay;
        /** @type {?} */
        DwTooltipDirective.prototype.specificMouseLeaveDelay;
        /** @type {?} */
        DwTooltipDirective.prototype.specificOverlayClassName;
        /** @type {?} */
        DwTooltipDirective.prototype.specificOverlayStyle;
        /** @type {?} */
        DwTooltipDirective.prototype.specificVisibleChange;
        /** @type {?} */
        DwTooltipDirective.prototype.componentFactory;
    }
    var DwToolTipComponent = /** @class */ (function (_super) {
        __extends(DwToolTipComponent, _super);
        function DwToolTipComponent(cdr, noAnimation) {
            var _this = _super.call(this, cdr, noAnimation) || this;
            _this.noAnimation = noAnimation;
            _this.dwTitle = null;
            return _this;
        }
        /**
         * @protected
         * @return {?}
         */
        DwToolTipComponent.prototype.isEmpty = /**
         * @protected
         * @return {?}
         */
        function () {
            return isTooltipEmpty(this.dwTitle);
        };
        DwToolTipComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tooltip',
                        exportAs: 'dwTooltipComponent',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        animations: [animation.zoomBigMotion],
                        template: "\n    <ng-template\n      #overlay=\"cdkConnectedOverlay\"\n      cdkConnectedOverlay\n      dwConnectedOverlay\n      [cdkConnectedOverlayOrigin]=\"origin\"\n      [cdkConnectedOverlayOpen]=\"_visible\"\n      [cdkConnectedOverlayHasBackdrop]=\"_hasBackdrop\"\n      [cdkConnectedOverlayPositions]=\"_positions\"\n      (backdropClick)=\"hide()\"\n      (detach)=\"hide()\"\n      (positionChange)=\"onPositionChange($event)\"\n    >\n      <div\n        class=\"ant-tooltip\"\n        [ngClass]=\"_classMap\"\n        [ngStyle]=\"dwOverlayStyle\"\n        [@.disabled]=\"noAnimation?.dwNoAnimation\"\n        [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n        [@zoomBigMotion]=\"'active'\"\n      >\n        <div class=\"ant-tooltip-content\">\n          <div class=\"ant-tooltip-arrow\"></div>\n          <div class=\"ant-tooltip-inner\">\n            <ng-container *dwStringTemplateOutlet=\"dwTitle\">{{ dwTitle }}</ng-container>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n  ",
                        preserveWhitespaces: false
                    }] }
        ];
        /** @nocollapse */
        DwToolTipComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwToolTipComponent.propDecorators = {
            dwTitle: [{ type: core.Input }]
        };
        return DwToolTipComponent;
    }(DwTooltipBaseComponent));
    if (false) {
        /** @type {?} */
        DwToolTipComponent.prototype.dwTitle;
        /** @type {?} */
        DwToolTipComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tooltip.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwToolTipModule = /** @class */ (function () {
        function DwToolTipModule() {
        }
        DwToolTipModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [DwToolTipComponent, DwTooltipDirective],
                        exports: [DwToolTipComponent, DwTooltipDirective],
                        entryComponents: [DwToolTipComponent],
                        imports: [common.CommonModule, overlay.OverlayModule, outlet.DwOutletModule, overlay$1.DwOverlayModule, noAnimation.DwNoAnimationModule]
                    },] }
        ];
        return DwToolTipModule;
    }());

    exports.DwToolTipComponent = DwToolTipComponent;
    exports.DwToolTipModule = DwToolTipModule;
    exports.DwTooltipBaseComponent = DwTooltipBaseComponent;
    exports.DwTooltipBaseDirective = DwTooltipBaseDirective;
    exports.DwTooltipDirective = DwTooltipDirective;
    exports.isTooltipEmpty = isTooltipEmpty;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-tooltip.umd.js.map
