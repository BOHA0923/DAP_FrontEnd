(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/overlay'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/logger'), require('ng-quicksilver/core/util'), require('@angular/common'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/i18n'), require('ng-quicksilver/icon'), require('ng-quicksilver/core/polyfill'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/time-picker', ['exports', '@angular/cdk/overlay', '@angular/core', '@angular/forms', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/config', 'ng-quicksilver/core/logger', 'ng-quicksilver/core/util', '@angular/common', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/overlay', 'ng-quicksilver/i18n', 'ng-quicksilver/icon', 'ng-quicksilver/core/polyfill', 'rxjs', 'rxjs/operators'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver']['time-picker'] = {}), global.ng.cdk.overlay, global.ng.core, global.ng.forms, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.logger, global['ng-quicksilver'].core.util, global.ng.common, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].i18n, global['ng-quicksilver'].icon, global['ng-quicksilver'].core.polyfill, global.rxjs, global.rxjs.operators));
}(this, (function (exports, overlay, core, forms, animation, config, logger, util, common, outlet, overlay$1, i18n, icon, polyfill, rxjs, operators) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: time-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'timePicker';
    var DwTimePickerComponent = /** @class */ (function () {
        function DwTimePickerComponent(dwConfigService, element, renderer, cdr) {
            this.dwConfigService = dwConfigService;
            this.element = element;
            this.renderer = renderer;
            this.cdr = cdr;
            this.isInit = false;
            this.focused = false;
            this.value = null;
            this.overlayPositions = [
                {
                    originX: 'start',
                    originY: 'bottom',
                    overlayX: 'start',
                    overlayY: 'top',
                    offsetY: 3
                }
            ];
            this.dwSize = null;
            this.dwHourStep = 1;
            this.dwMinuteStep = 1;
            this.dwSecondStep = 1;
            this.dwClearText = 'clear';
            this.dwPopupClassName = '';
            this.dwPlaceHolder = '';
            this.dwFormat = 'HH:mm:ss';
            this.dwOpen = false;
            this.dwUse12Hours = false;
            this.dwSuffixIcon = 'clock-circle';
            this.dwOpenChange = new core.EventEmitter();
            this.dwHideDisabledOptions = false;
            this.dwAllowEmpty = true;
            this.dwDisabled = false;
            this.dwAutoFocus = false;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerComponent.prototype.setValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.value = value ? new Date(value) : null;
            if (this._onChange) {
                this._onChange(this.value);
            }
            if (this._onTouched) {
                this._onTouched();
            }
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.open = /**
         * @return {?}
         */
        function () {
            if (this.dwDisabled) {
                return;
            }
            this.focus();
            this.dwOpen = true;
            this.dwOpenChange.emit(this.dwOpen);
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.close = /**
         * @return {?}
         */
        function () {
            this.dwOpen = false;
            this.cdr.markForCheck();
            this.dwOpenChange.emit(this.dwOpen);
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.updateAutoFocus = /**
         * @return {?}
         */
        function () {
            if (this.isInit && !this.dwDisabled) {
                if (this.dwAutoFocus) {
                    this.renderer.setAttribute(this.inputRef.nativeElement, 'autofocus', 'autofocus');
                }
                else {
                    this.renderer.removeAttribute(this.inputRef.nativeElement, 'autofocus');
                }
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwTimePickerComponent.prototype.onClickClearBtn = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.stopPropagation();
            this.setValue(null);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerComponent.prototype.onFocus = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.focused = value;
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            if (this.inputRef.nativeElement) {
                this.inputRef.nativeElement.focus();
            }
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.blur = /**
         * @return {?}
         */
        function () {
            if (this.inputRef.nativeElement) {
                this.inputRef.nativeElement.blur();
            }
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.inputSize = Math.max(8, this.dwFormat.length) + 2;
            this.origin = new overlay.CdkOverlayOrigin(this.element);
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTimePickerComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwUse12Hours = changes.dwUse12Hours, dwFormat = changes.dwFormat, dwDisabled = changes.dwDisabled, dwAutoFocus = changes.dwAutoFocus;
            if (dwUse12Hours && !dwUse12Hours.previousValue && dwUse12Hours.currentValue && !dwFormat) {
                this.dwFormat = 'h:mm:ss a';
            }
            if (dwDisabled) {
                /** @type {?} */
                var value = dwDisabled.currentValue;
                /** @type {?} */
                var input = (/** @type {?} */ (this.inputRef.nativeElement));
                if (value) {
                    this.renderer.setAttribute(input, 'disabled', '');
                }
                else {
                    this.renderer.removeAttribute(input, 'disabled');
                }
            }
            if (dwAutoFocus) {
                this.updateAutoFocus();
            }
        };
        /**
         * @return {?}
         */
        DwTimePickerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            this.isInit = true;
            this.updateAutoFocus();
        };
        /**
         * @param {?} time
         * @return {?}
         */
        DwTimePickerComponent.prototype.writeValue = /**
         * @param {?} time
         * @return {?}
         */
        function (time) {
            if (time instanceof Date) {
                this.value = time;
            }
            else if (util.isNil(time)) {
                this.value = null;
            }
            else {
                logger.warn('Non-Date type is not recommended for time-picker, use "Date" type.');
                this.value = new Date(time);
            }
            this.cdr.markForCheck();
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimePickerComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this._onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimePickerComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this._onTouched = fn;
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwTimePickerComponent.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            this.dwDisabled = isDisabled;
            this.cdr.markForCheck();
        };
        DwTimePickerComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'dw-time-picker',
                        exportAs: 'dwTimePicker',
                        template: "\n    <div class=\"ant-picker-input\">\n      <input\n        #inputElement\n        type=\"text\"\n        [size]=\"inputSize\"\n        [dwTime]=\"dwFormat\"\n        [placeholder]=\"dwPlaceHolder || ('TimePicker.placeholder' | dwI18n)\"\n        [(ngModel)]=\"value\"\n        [disabled]=\"dwDisabled\"\n        (focus)=\"onFocus(true)\"\n        (blur)=\"onFocus(false)\"\n      />\n      <span class=\"ant-picker-suffix\">\n        <ng-container *dwStringTemplateOutlet=\"dwSuffixIcon; let suffixIcon\">\n          <i dw-icon [dwType]=\"suffixIcon\"></i>\n        </ng-container>\n      </span>\n      <span *ngIf=\"dwAllowEmpty && value\" class=\"ant-picker-clear\" (click)=\"onClickClearBtn($event)\">\n        <i dw-icon dwType=\"close-circle\" dwTheme=\"fill\" [attr.aria-label]=\"dwClearText\" [attr.title]=\"dwClearText\"></i>\n      </span>\n    </div>\n\n    <ng-template\n      cdkConnectedOverlay\n      dwConnectedOverlay\n      cdkConnectedOverlayHasBackdrop\n      [cdkConnectedOverlayPositions]=\"overlayPositions\"\n      [cdkConnectedOverlayOrigin]=\"origin\"\n      [cdkConnectedOverlayOpen]=\"dwOpen\"\n      [cdkConnectedOverlayOffsetY]=\"-2\"\n      [cdkConnectedOverlayTransformOriginOn]=\"'.ant-picker-dropdown'\"\n      (detach)=\"close()\"\n      (backdropClick)=\"close()\"\n    >\n      <div [@slideMotion]=\"'enter'\" class=\"ant-picker-dropdown\">\n        <div class=\"ant-picker-panel-container\">\n          <div tabindex=\"-1\" class=\"ant-picker-panel\">\n            <dw-time-picker-panel\n              [ngClass]=\"dwPopupClassName\"\n              [format]=\"dwFormat\"\n              [dwHourStep]=\"dwHourStep\"\n              [dwMinuteStep]=\"dwMinuteStep\"\n              [dwSecondStep]=\"dwSecondStep\"\n              [dwDisabledHours]=\"dwDisabledHours\"\n              [dwDisabledMinutes]=\"dwDisabledMinutes\"\n              [dwDisabledSeconds]=\"dwDisabledSeconds\"\n              [dwPlaceHolder]=\"dwPlaceHolder || ('TimePicker.placeholder' | dwI18n)\"\n              [dwHideDisabledOptions]=\"dwHideDisabledOptions\"\n              [dwUse12Hours]=\"dwUse12Hours\"\n              [dwDefaultOpenValue]=\"dwDefaultOpenValue\"\n              [dwAddOn]=\"dwAddOn\"\n              [dwClearText]=\"dwClearText\"\n              [dwAllowEmpty]=\"dwAllowEmpty\"\n              [(ngModel)]=\"value\"\n              (ngModelChange)=\"setValue($event)\"\n              (closePanel)=\"close()\"\n            >\n            </dw-time-picker-panel>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-picker]': "true",
                            '[class.ant-picker-large]': "dwSize === 'large'",
                            '[class.ant-picker-small]': "dwSize === 'small'",
                            '[class.ant-picker-disabled]': "dwDisabled",
                            '[class.ant-picker-focused]': "focused",
                            '(click)': 'open()'
                        },
                        animations: [animation.slideMotion],
                        providers: [{ provide: forms.NG_VALUE_ACCESSOR, useExisting: DwTimePickerComponent, multi: true }]
                    }] }
        ];
        /** @nocollapse */
        DwTimePickerComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: core.ChangeDetectorRef }
        ]; };
        DwTimePickerComponent.propDecorators = {
            inputRef: [{ type: core.ViewChild, args: ['inputElement', { static: true },] }],
            dwSize: [{ type: core.Input }],
            dwHourStep: [{ type: core.Input }],
            dwMinuteStep: [{ type: core.Input }],
            dwSecondStep: [{ type: core.Input }],
            dwClearText: [{ type: core.Input }],
            dwPopupClassName: [{ type: core.Input }],
            dwPlaceHolder: [{ type: core.Input }],
            dwAddOn: [{ type: core.Input }],
            dwDefaultOpenValue: [{ type: core.Input }],
            dwDisabledHours: [{ type: core.Input }],
            dwDisabledMinutes: [{ type: core.Input }],
            dwDisabledSeconds: [{ type: core.Input }],
            dwFormat: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            dwUse12Hours: [{ type: core.Input }],
            dwSuffixIcon: [{ type: core.Input }],
            dwOpenChange: [{ type: core.Output }],
            dwHideDisabledOptions: [{ type: core.Input }],
            dwAllowEmpty: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwAutoFocus: [{ type: core.Input }]
        };
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Number)
        ], DwTimePickerComponent.prototype, "dwHourStep", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Number)
        ], DwTimePickerComponent.prototype, "dwMinuteStep", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Number)
        ], DwTimePickerComponent.prototype, "dwSecondStep", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTimePickerComponent.prototype, "dwClearText", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTimePickerComponent.prototype, "dwPopupClassName", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTimePickerComponent.prototype, "dwFormat", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTimePickerComponent.prototype, "dwUse12Hours", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Object)
        ], DwTimePickerComponent.prototype, "dwSuffixIcon", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTimePickerComponent.prototype, "dwHideDisabledOptions", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTimePickerComponent.prototype, "dwAllowEmpty", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTimePickerComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTimePickerComponent.prototype, "dwAutoFocus", void 0);
        return DwTimePickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTimePickerComponent.ngAcceptInputType_dwUse12Hours;
        /** @type {?} */
        DwTimePickerComponent.ngAcceptInputType_dwHideDisabledOptions;
        /** @type {?} */
        DwTimePickerComponent.ngAcceptInputType_dwAllowEmpty;
        /** @type {?} */
        DwTimePickerComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwTimePickerComponent.ngAcceptInputType_dwAutoFocus;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerComponent.prototype._onChange;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerComponent.prototype._onTouched;
        /** @type {?} */
        DwTimePickerComponent.prototype.isInit;
        /** @type {?} */
        DwTimePickerComponent.prototype.focused;
        /** @type {?} */
        DwTimePickerComponent.prototype.value;
        /** @type {?} */
        DwTimePickerComponent.prototype.origin;
        /** @type {?} */
        DwTimePickerComponent.prototype.inputSize;
        /** @type {?} */
        DwTimePickerComponent.prototype.overlayPositions;
        /** @type {?} */
        DwTimePickerComponent.prototype.inputRef;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwSize;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwHourStep;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwMinuteStep;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwSecondStep;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwClearText;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwPopupClassName;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwPlaceHolder;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwAddOn;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwDefaultOpenValue;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwDisabledHours;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwDisabledMinutes;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwDisabledSeconds;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwFormat;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwOpen;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwUse12Hours;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwSuffixIcon;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwOpenChange;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwHideDisabledOptions;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwAllowEmpty;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwDisabled;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwAutoFocus;
        /** @type {?} */
        DwTimePickerComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerComponent.prototype.element;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerComponent.prototype.renderer;
        /** @type {?} */
        DwTimePickerComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: time-holder.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var TimeHolder = /** @class */ (function () {
        function TimeHolder() {
            this.selected12Hours = undefined;
            this._use12Hours = false;
            this._changes = new rxjs.Subject();
        }
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        TimeHolder.prototype.setMinutes = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        function (value, disabled) {
            if (value !== (/** @type {?} */ (this)).minutes && !disabled) {
                (/** @type {?} */ (this)).initValue();
                (/** @type {?} */ (this)).value.setMinutes(value);
                (/** @type {?} */ (this)).update();
            }
            return (/** @type {?} */ (this));
        };
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        TimeHolder.prototype.setHours = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        function (value, disabled) {
            if (value !== (/** @type {?} */ (this)).hours && !disabled) {
                (/** @type {?} */ (this)).initValue();
                if ((/** @type {?} */ (this))._use12Hours) {
                    if ((/** @type {?} */ (this)).selected12Hours === 'PM' && value !== 12) {
                        (/** @type {?} */ (this)).value.setHours(((/** @type {?} */ (value))) + 12);
                    }
                    else if ((/** @type {?} */ (this)).selected12Hours === 'AM' && value === 12) {
                        (/** @type {?} */ (this)).value.setHours(0);
                    }
                    else {
                        (/** @type {?} */ (this)).value.setHours(value);
                    }
                }
                else {
                    (/** @type {?} */ (this)).value.setHours(value);
                }
                (/** @type {?} */ (this)).update();
            }
            return (/** @type {?} */ (this));
        };
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        TimeHolder.prototype.setSeconds = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?} disabled
         * @return {THIS}
         */
        function (value, disabled) {
            if (value !== (/** @type {?} */ (this)).seconds && !disabled) {
                (/** @type {?} */ (this)).initValue();
                (/** @type {?} */ (this)).value.setSeconds(value);
                (/** @type {?} */ (this)).update();
            }
            return (/** @type {?} */ (this));
        };
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @return {THIS}
         */
        TimeHolder.prototype.setUse12Hours = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @return {THIS}
         */
        function (value) {
            (/** @type {?} */ (this))._use12Hours = value;
            return (/** @type {?} */ (this));
        };
        Object.defineProperty(TimeHolder.prototype, "changes", {
            get: /**
             * @return {?}
             */
            function () {
                return this._changes.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?=} use12Hours
         * @return {THIS}
         */
        TimeHolder.prototype.setValue = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @param {?=} use12Hours
         * @return {THIS}
         */
        function (value, use12Hours) {
            if (util.isNotNil(use12Hours)) {
                (/** @type {?} */ (this))._use12Hours = (/** @type {?} */ (use12Hours));
            }
            if (value !== (/** @type {?} */ (this)).value) {
                (/** @type {?} */ (this))._value = value;
                if (util.isNotNil((/** @type {?} */ (this)).value)) {
                    if ((/** @type {?} */ (this))._use12Hours && util.isNotNil((/** @type {?} */ (this)).hours)) {
                        (/** @type {?} */ (this)).selected12Hours = (/** @type {?} */ (this)).hours >= 12 ? 'PM' : 'AM';
                    }
                }
                else {
                    (/** @type {?} */ (this))._clear();
                }
            }
            return (/** @type {?} */ (this));
        };
        /**
         * @return {?}
         */
        TimeHolder.prototype.initValue = /**
         * @return {?}
         */
        function () {
            if (util.isNil(this.value)) {
                this.setValue(new Date(), this._use12Hours);
            }
        };
        /**
         * @return {?}
         */
        TimeHolder.prototype.clear = /**
         * @return {?}
         */
        function () {
            this._clear();
            this.update();
        };
        Object.defineProperty(TimeHolder.prototype, "isEmpty", {
            get: /**
             * @return {?}
             */
            function () {
                return !(util.isNotNil(this.hours) || util.isNotNil(this.minutes) || util.isNotNil(this.seconds));
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @private
         * @return {?}
         */
        TimeHolder.prototype._clear = /**
         * @private
         * @return {?}
         */
        function () {
            this._value = undefined;
            this.selected12Hours = undefined;
        };
        /**
         * @private
         * @return {?}
         */
        TimeHolder.prototype.update = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.isEmpty) {
                this._value = undefined;
            }
            else {
                if (util.isNotNil(this.hours)) {
                    (/** @type {?} */ (this.value)).setHours((/** @type {?} */ (this.hours)));
                }
                if (util.isNotNil(this.minutes)) {
                    (/** @type {?} */ (this.value)).setMinutes((/** @type {?} */ (this.minutes)));
                }
                if (util.isNotNil(this.seconds)) {
                    (/** @type {?} */ (this.value)).setSeconds((/** @type {?} */ (this.seconds)));
                }
                if (this._use12Hours) {
                    if (this.selected12Hours === 'PM' && (/** @type {?} */ (this.hours)) < 12) {
                        (/** @type {?} */ (this.value)).setHours((/** @type {?} */ (this.hours)) + 12);
                    }
                    if (this.selected12Hours === 'AM' && (/** @type {?} */ (this.hours)) >= 12) {
                        (/** @type {?} */ (this.value)).setHours((/** @type {?} */ (this.hours)) - 12);
                    }
                }
            }
            this.changed();
        };
        /**
         * @return {?}
         */
        TimeHolder.prototype.changed = /**
         * @return {?}
         */
        function () {
            this._changes.next(this.value);
        };
        Object.defineProperty(TimeHolder.prototype, "viewHours", {
            /**
             * @description
             * UI view hours
             * Get viewHours which is selected in `time-picker-panel` and its range is [12, 1, 2, ..., 11]
             */
            get: /**
             * \@description
             * UI view hours
             * Get viewHours which is selected in `time-picker-panel` and its range is [12, 1, 2, ..., 11]
             * @return {?}
             */
            function () {
                return this._use12Hours && util.isNotNil(this.hours) ? this.calculateViewHour((/** @type {?} */ (this.hours))) : this.hours;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} value
         * @return {?}
         */
        TimeHolder.prototype.setSelected12Hours = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if ((/** @type {?} */ (value)).toUpperCase() !== this.selected12Hours) {
                this.selected12Hours = (/** @type {?} */ (value)).toUpperCase();
                this.update();
            }
        };
        Object.defineProperty(TimeHolder.prototype, "value", {
            get: /**
             * @return {?}
             */
            function () {
                return this._value || this._defaultOpenValue;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TimeHolder.prototype, "hours", {
            get: /**
             * @return {?}
             */
            function () {
                var _a;
                return (_a = this.value) === null || _a === void 0 ? void 0 : _a.getHours();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TimeHolder.prototype, "minutes", {
            get: /**
             * @return {?}
             */
            function () {
                var _a;
                return (_a = this.value) === null || _a === void 0 ? void 0 : _a.getMinutes();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TimeHolder.prototype, "seconds", {
            get: /**
             * @return {?}
             */
            function () {
                var _a;
                return (_a = this.value) === null || _a === void 0 ? void 0 : _a.getSeconds();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @return {THIS}
         */
        TimeHolder.prototype.setDefaultOpenValue = /**
         * @template THIS
         * @this {THIS}
         * @param {?} value
         * @return {THIS}
         */
        function (value) {
            (/** @type {?} */ (this))._defaultOpenValue = value;
            return (/** @type {?} */ (this));
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        TimeHolder.prototype.calculateViewHour = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            /** @type {?} */
            var selected12Hours = this.selected12Hours;
            if (selected12Hours === 'PM' && value > 12) {
                return value - 12;
            }
            if (selected12Hours === 'AM' && value === 0) {
                return 12;
            }
            return value;
        };
        return TimeHolder;
    }());
    if (false) {
        /** @type {?} */
        TimeHolder.prototype.selected12Hours;
        /**
         * @type {?}
         * @private
         */
        TimeHolder.prototype._value;
        /**
         * @type {?}
         * @private
         */
        TimeHolder.prototype._use12Hours;
        /**
         * @type {?}
         * @private
         */
        TimeHolder.prototype._defaultOpenValue;
        /**
         * @type {?}
         * @private
         */
        TimeHolder.prototype._changes;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: time-value-accessor.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTimeValueAccessorDirective = /** @class */ (function () {
        function DwTimeValueAccessorDirective(dateHelper, elementRef) {
            this.dateHelper = dateHelper;
            this.elementRef = elementRef;
        }
        /**
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.keyup = /**
         * @return {?}
         */
        function () {
            this.changed();
        };
        /**
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.blur = /**
         * @return {?}
         */
        function () {
            this.touched();
        };
        /**
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.changed = /**
         * @return {?}
         */
        function () {
            if (this._onChange) {
                /** @type {?} */
                var value = this.dateHelper.parseTime(this.elementRef.nativeElement.value, this.dwTime);
                this._onChange((/** @type {?} */ (value)));
            }
        };
        /**
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.touched = /**
         * @return {?}
         */
        function () {
            if (this._onTouch) {
                this._onTouch();
            }
        };
        /**
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.setRange = /**
         * @return {?}
         */
        function () {
            this.elementRef.nativeElement.focus();
            this.elementRef.nativeElement.setSelectionRange(0, this.elementRef.nativeElement.value.length);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.elementRef.nativeElement.value = this.dateHelper.format(value, (/** @type {?} */ (this.dwTime)));
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this._onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimeValueAccessorDirective.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this._onTouch = fn;
        };
        DwTimeValueAccessorDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'input[dwTime]',
                        exportAs: 'dwTime',
                        providers: [{ provide: forms.NG_VALUE_ACCESSOR, useExisting: DwTimeValueAccessorDirective, multi: true }]
                    },] }
        ];
        /** @nocollapse */
        DwTimeValueAccessorDirective.ctorParameters = function () { return [
            { type: i18n.DateHelperService },
            { type: core.ElementRef }
        ]; };
        DwTimeValueAccessorDirective.propDecorators = {
            dwTime: [{ type: core.Input }],
            keyup: [{ type: core.HostListener, args: ['keyup',] }],
            blur: [{ type: core.HostListener, args: ['blur',] }]
        };
        return DwTimeValueAccessorDirective;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwTimeValueAccessorDirective.prototype._onChange;
        /**
         * @type {?}
         * @private
         */
        DwTimeValueAccessorDirective.prototype._onTouch;
        /** @type {?} */
        DwTimeValueAccessorDirective.prototype.dwTime;
        /**
         * @type {?}
         * @private
         */
        DwTimeValueAccessorDirective.prototype.dateHelper;
        /**
         * @type {?}
         * @private
         */
        DwTimeValueAccessorDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: time-picker-panel.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} length
     * @param {?=} step
     * @param {?=} start
     * @return {?}
     */
    function makeRange(length, step, start) {
        if (step === void 0) { step = 1; }
        if (start === void 0) { start = 0; }
        return new Array(Math.ceil(length / step)).fill(0).map((/**
         * @param {?} _
         * @param {?} i
         * @return {?}
         */
        function (_, i) { return (i + start) * step; }));
    }
    var DwTimePickerPanelComponent = /** @class */ (function () {
        function DwTimePickerPanelComponent(cdr, dateHelper) {
            this.cdr = cdr;
            this.dateHelper = dateHelper;
            this._dwHourStep = 1;
            this._dwMinuteStep = 1;
            this._dwSecondStep = 1;
            this.unsubscribe$ = new rxjs.Subject();
            this._format = 'HH:mm:ss';
            this._disabledHours = (/**
             * @return {?}
             */
            function () { return []; });
            this._disabledMinutes = (/**
             * @return {?}
             */
            function () { return []; });
            this._disabledSeconds = (/**
             * @return {?}
             */
            function () { return []; });
            this._allowEmpty = true;
            this.time = new TimeHolder();
            this.hourEnabled = true;
            this.minuteEnabled = true;
            this.secondEnabled = true;
            this.firstScrolled = false;
            this.enabledColumns = 3;
            this.dwInDatePicker = false; // If inside a date-picker, more diff works need to be done
            this.dwHideDisabledOptions = false;
            this.dwUse12Hours = false;
            this.closePanel = new core.EventEmitter();
        }
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwAllowEmpty", {
            get: /**
             * @return {?}
             */
            function () {
                return this._allowEmpty;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._allowEmpty = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwDisabledHours", {
            get: /**
             * @return {?}
             */
            function () {
                return this._disabledHours;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this._disabledHours = value;
                if (!!this._disabledHours) {
                    this.buildHours();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwDisabledMinutes", {
            get: /**
             * @return {?}
             */
            function () {
                return this._disabledMinutes;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._disabledMinutes = value;
                    this.buildMinutes();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwDisabledSeconds", {
            get: /**
             * @return {?}
             */
            function () {
                return this._disabledSeconds;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._disabledSeconds = value;
                    this.buildSeconds();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "format", {
            get: /**
             * @return {?}
             */
            function () {
                return this._format;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._format = value;
                    this.enabledColumns = 0;
                    /** @type {?} */
                    var charSet = new Set(value);
                    this.hourEnabled = charSet.has('H') || charSet.has('h');
                    this.minuteEnabled = charSet.has('m');
                    this.secondEnabled = charSet.has('s');
                    if (this.hourEnabled) {
                        this.enabledColumns++;
                    }
                    if (this.minuteEnabled) {
                        this.enabledColumns++;
                    }
                    if (this.secondEnabled) {
                        this.enabledColumns++;
                    }
                    if (this.dwUse12Hours) {
                        this.build12Hours();
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwHourStep", {
            get: /**
             * @return {?}
             */
            function () {
                return this._dwHourStep;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._dwHourStep = value;
                    this.buildHours();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwMinuteStep", {
            get: /**
             * @return {?}
             */
            function () {
                return this._dwMinuteStep;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._dwMinuteStep = value;
                    this.buildMinutes();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTimePickerPanelComponent.prototype, "dwSecondStep", {
            get: /**
             * @return {?}
             */
            function () {
                return this._dwSecondStep;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (util.isNotNil(value)) {
                    this._dwSecondStep = value;
                    this.buildSeconds();
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.selectInputRange = /**
         * @return {?}
         */
        function () {
            var _this = this;
            setTimeout((/**
             * @return {?}
             */
            function () {
                if (_this.dwTimeValueAccessorDirective) {
                    _this.dwTimeValueAccessorDirective.setRange();
                }
            }));
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.buildHours = /**
         * @return {?}
         */
        function () {
            var _a;
            /** @type {?} */
            var hourRanges = 24;
            /** @type {?} */
            var disabledHours = (_a = this.dwDisabledHours) === null || _a === void 0 ? void 0 : _a.call(this);
            /** @type {?} */
            var startIndex = 0;
            if (this.dwUse12Hours) {
                hourRanges = 12;
                if (disabledHours) {
                    if (this.time.selected12Hours === 'PM') {
                        /**
                         * Filter and transform hours which greater or equal to 12
                         * [0, 1, 2, ..., 12, 13, 14, 15, ..., 23] => [12, 1, 2, 3, ..., 11]
                         */
                        disabledHours = disabledHours.filter((/**
                         * @param {?} i
                         * @return {?}
                         */
                        function (i) { return i >= 12; })).map((/**
                         * @param {?} i
                         * @return {?}
                         */
                        function (i) { return (i > 12 ? i - 12 : i); }));
                    }
                    else {
                        /**
                         * Filter and transform hours which less than 12
                         * [0, 1, 2,..., 12, 13, 14, 15, ...23] => [12, 1, 2, 3, ..., 11]
                         */
                        disabledHours = disabledHours.filter((/**
                         * @param {?} i
                         * @return {?}
                         */
                        function (i) { return i < 12 || i === 24; })).map((/**
                         * @param {?} i
                         * @return {?}
                         */
                        function (i) { return (i === 24 || i === 0 ? 12 : i); }));
                    }
                }
                startIndex = 1;
            }
            this.hourRange = makeRange(hourRanges, this.dwHourStep, startIndex).map((/**
             * @param {?} r
             * @return {?}
             */
            function (r) {
                return {
                    index: r,
                    disabled: !!disabledHours && disabledHours.indexOf(r) !== -1
                };
            }));
            if (this.dwUse12Hours && this.hourRange[this.hourRange.length - 1].index === 12) {
                /** @type {?} */
                var temp = __spread(this.hourRange);
                temp.unshift(temp[temp.length - 1]);
                temp.splice(temp.length - 1, 1);
                this.hourRange = temp;
            }
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.buildMinutes = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.minuteRange = makeRange(60, this.dwMinuteStep).map((/**
             * @param {?} r
             * @return {?}
             */
            function (r) {
                return {
                    index: r,
                    disabled: !!_this.dwDisabledMinutes && _this.dwDisabledMinutes((/** @type {?} */ (_this.time.hours))).indexOf(r) !== -1
                };
            }));
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.buildSeconds = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.secondRange = makeRange(60, this.dwSecondStep).map((/**
             * @param {?} r
             * @return {?}
             */
            function (r) {
                return {
                    index: r,
                    disabled: !!_this.dwDisabledSeconds && _this.dwDisabledSeconds((/** @type {?} */ (_this.time.hours)), (/** @type {?} */ (_this.time.minutes))).indexOf(r) !== -1
                };
            }));
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.build12Hours = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var isUpperFormat = this._format.includes('A');
            this.use12HoursRange = [
                {
                    index: 0,
                    value: isUpperFormat ? 'AM' : 'am'
                },
                {
                    index: 1,
                    value: isUpperFormat ? 'PM' : 'pm'
                }
            ];
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.buildTimes = /**
         * @return {?}
         */
        function () {
            this.buildHours();
            this.buildMinutes();
            this.buildSeconds();
            this.build12Hours();
        };
        /**
         * @param {?=} delay
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.scrollToTime = /**
         * @param {?=} delay
         * @return {?}
         */
        function (delay) {
            if (delay === void 0) { delay = 0; }
            if (this.hourEnabled && this.hourListElement) {
                this.scrollToSelected(this.hourListElement.nativeElement, (/** @type {?} */ (this.time.viewHours)), delay, 'hour');
            }
            if (this.minuteEnabled && this.minuteListElement) {
                this.scrollToSelected(this.minuteListElement.nativeElement, (/** @type {?} */ (this.time.minutes)), delay, 'minute');
            }
            if (this.secondEnabled && this.secondListElement) {
                this.scrollToSelected(this.secondListElement.nativeElement, (/** @type {?} */ (this.time.seconds)), delay, 'second');
            }
            if (this.dwUse12Hours && this.use12HoursListElement) {
                /** @type {?} */
                var selectedHours = this.time.selected12Hours;
                /** @type {?} */
                var index = selectedHours === 'AM' ? 0 : 1;
                this.scrollToSelected(this.use12HoursListElement.nativeElement, index, delay, '12-hour');
            }
        };
        /**
         * @param {?} hour
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.selectHour = /**
         * @param {?} hour
         * @return {?}
         */
        function (hour) {
            this.time.setHours(hour.index, hour.disabled);
            if (!!this._disabledMinutes) {
                this.buildMinutes();
            }
            if (this._disabledSeconds || this._disabledMinutes) {
                this.buildSeconds();
            }
        };
        /**
         * @param {?} minute
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.selectMinute = /**
         * @param {?} minute
         * @return {?}
         */
        function (minute) {
            this.time.setMinutes(minute.index, minute.disabled);
            if (!!this._disabledSeconds) {
                this.buildSeconds();
            }
        };
        /**
         * @param {?} second
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.selectSecond = /**
         * @param {?} second
         * @return {?}
         */
        function (second) {
            this.time.setSeconds(second.index, second.disabled);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.select12Hours = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.time.setSelected12Hours(value.value);
            if (!!this._disabledHours) {
                this.buildHours();
            }
            if (!!this._disabledMinutes) {
                this.buildMinutes();
            }
            if (!!this._disabledSeconds) {
                this.buildSeconds();
            }
        };
        /**
         * @param {?} instance
         * @param {?} index
         * @param {?=} duration
         * @param {?=} unit
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.scrollToSelected = /**
         * @param {?} instance
         * @param {?} index
         * @param {?=} duration
         * @param {?=} unit
         * @return {?}
         */
        function (instance, index, duration, unit) {
            if (duration === void 0) { duration = 0; }
            if (!instance) {
                return;
            }
            /** @type {?} */
            var transIndex = this.translateIndex(index, unit);
            /** @type {?} */
            var currentOption = (/** @type {?} */ ((instance.children[transIndex] || instance.children[0])));
            this.scrollTo(instance, currentOption.offsetTop, duration);
        };
        /**
         * @param {?} index
         * @param {?} unit
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.translateIndex = /**
         * @param {?} index
         * @param {?} unit
         * @return {?}
         */
        function (index, unit) {
            var _a, _b, _c;
            if (unit === 'hour') {
                return this.calcIndex((_a = this.dwDisabledHours) === null || _a === void 0 ? void 0 : _a.call(this), this.hourRange.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.index; })).indexOf(index));
            }
            else if (unit === 'minute') {
                return this.calcIndex((_b = this.dwDisabledMinutes) === null || _b === void 0 ? void 0 : _b.call(this, (/** @type {?} */ (this.time.hours))), this.minuteRange.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.index; })).indexOf(index));
            }
            else if (unit === 'second') {
                // second
                return this.calcIndex((_c = this.dwDisabledSeconds) === null || _c === void 0 ? void 0 : _c.call(this, (/** @type {?} */ (this.time.hours)), (/** @type {?} */ (this.time.minutes))), this.secondRange.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.index; })).indexOf(index));
            }
            else {
                // 12-hour
                return this.calcIndex([], this.use12HoursRange.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.index; })).indexOf(index));
            }
        };
        /**
         * @param {?} element
         * @param {?} to
         * @param {?} duration
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.scrollTo = /**
         * @param {?} element
         * @param {?} to
         * @param {?} duration
         * @return {?}
         */
        function (element, to, duration) {
            var _this = this;
            if (duration <= 0) {
                element.scrollTop = to;
                return;
            }
            /** @type {?} */
            var difference = to - element.scrollTop;
            /** @type {?} */
            var perTick = (difference / duration) * 10;
            polyfill.reqAnimFrame((/**
             * @return {?}
             */
            function () {
                element.scrollTop = element.scrollTop + perTick;
                if (element.scrollTop === to) {
                    return;
                }
                _this.scrollTo(element, to, duration - 10);
            }));
        };
        /**
         * @param {?} array
         * @param {?} index
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.calcIndex = /**
         * @param {?} array
         * @param {?} index
         * @return {?}
         */
        function (array, index) {
            if ((array === null || array === void 0 ? void 0 : array.length) && this.dwHideDisabledOptions) {
                return (index -
                    array.reduce((/**
                     * @param {?} pre
                     * @param {?} value
                     * @return {?}
                     */
                    function (pre, value) {
                        return pre + (value < index ? 1 : 0);
                    }), 0));
            }
            else {
                return index;
            }
        };
        /**
         * @protected
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.changed = /**
         * @protected
         * @return {?}
         */
        function () {
            if (this.onChange) {
                this.onChange((/** @type {?} */ (this.time.value)));
            }
        };
        /**
         * @protected
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.touched = /**
         * @protected
         * @return {?}
         */
        function () {
            if (this.onTouch) {
                this.onTouch();
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.timeDisabled = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _a, _b, _c, _d, _e, _f;
            /** @type {?} */
            var hour = value.getHours();
            /** @type {?} */
            var minute = value.getMinutes();
            /** @type {?} */
            var second = value.getSeconds();
            return (((_b = (_a = this.dwDisabledHours) === null || _a === void 0 ? void 0 : _a.call(this).indexOf(hour)) !== null && _b !== void 0 ? _b : -1) > -1 ||
                ((_d = (_c = this.dwDisabledMinutes) === null || _c === void 0 ? void 0 : _c.call(this, hour).indexOf(minute)) !== null && _d !== void 0 ? _d : -1) > -1 ||
                ((_f = (_e = this.dwDisabledSeconds) === null || _e === void 0 ? void 0 : _e.call(this, hour, minute).indexOf(second)) !== null && _f !== void 0 ? _f : -1) > -1);
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.onClickNow = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var now = new Date();
            if (this.timeDisabled(now)) {
                return;
            }
            this.time.setValue(now);
            this.changed();
            this.closePanel.emit();
        };
        /**
         * @param {?} hour
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.isSelectedHour = /**
         * @param {?} hour
         * @return {?}
         */
        function (hour) {
            return hour.index === this.time.viewHours;
        };
        /**
         * @param {?} minute
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.isSelectedMinute = /**
         * @param {?} minute
         * @return {?}
         */
        function (minute) {
            return minute.index === this.time.minutes;
        };
        /**
         * @param {?} second
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.isSelectedSecond = /**
         * @param {?} second
         * @return {?}
         */
        function (second) {
            return second.index === this.time.seconds;
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.isSelected12Hours = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return value.value.toUpperCase() === this.time.selected12Hours;
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.time.changes.pipe(operators.takeUntil(this.unsubscribe$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.changed();
                _this.touched();
            }));
            this.buildTimes();
            this.selectInputRange();
            setTimeout((/**
             * @return {?}
             */
            function () {
                _this.scrollToTime();
                _this.firstScrolled = true;
            }));
        };
        /**
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.unsubscribe$.next();
            this.unsubscribe$.complete();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwUse12Hours = changes.dwUse12Hours, dwDefaultOpenValue = changes.dwDefaultOpenValue;
            if (!(dwUse12Hours === null || dwUse12Hours === void 0 ? void 0 : dwUse12Hours.previousValue) && (dwUse12Hours === null || dwUse12Hours === void 0 ? void 0 : dwUse12Hours.currentValue)) {
                this.build12Hours();
                this.enabledColumns++;
            }
            if (dwDefaultOpenValue === null || dwDefaultOpenValue === void 0 ? void 0 : dwDefaultOpenValue.currentValue) {
                this.time.setDefaultOpenValue(this.dwDefaultOpenValue || new Date());
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.time.setValue(value, this.dwUse12Hours);
            this.buildTimes();
            if (value && this.firstScrolled) {
                this.scrollToTime(120);
            }
            // Mark this component to be checked manually with internal properties changing (see: https://github.com/angular/angular/issues/10816)
            this.cdr.markForCheck();
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTimePickerPanelComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouch = fn;
        };
        DwTimePickerPanelComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'dw-time-picker-panel',
                        exportAs: 'dwTimePickerPanel',
                        template: "\n    <div *ngIf=\"dwInDatePicker\" class=\"ant-picker-header\">\n      <div class=\"ant-picker-header-view\">{{ dateHelper.format($any(time?.value), format) || '&nbsp;' }}</div>\n    </div>\n    <div class=\"ant-picker-content\">\n      <ul *ngIf=\"hourEnabled\" #hourListElement class=\"ant-picker-time-panel-column\" style=\"position: relative;\">\n        <ng-container *ngFor=\"let hour of hourRange\">\n          <li\n            *ngIf=\"!(dwHideDisabledOptions && hour.disabled)\"\n            class=\"ant-picker-time-panel-cell\"\n            (click)=\"selectHour(hour)\"\n            [class.ant-picker-time-panel-cell-selected]=\"isSelectedHour(hour)\"\n            [class.ant-picker-time-panel-cell-disabled]=\"hour.disabled\"\n          >\n            <div class=\"ant-picker-time-panel-cell-inner\">{{ hour.index | number: '2.0-0' }}</div>\n          </li>\n        </ng-container>\n      </ul>\n      <ul *ngIf=\"minuteEnabled\" #minuteListElement class=\"ant-picker-time-panel-column\" style=\"position: relative;\">\n        <ng-container *ngFor=\"let minute of minuteRange\">\n          <li\n            *ngIf=\"!(dwHideDisabledOptions && minute.disabled)\"\n            class=\"ant-picker-time-panel-cell\"\n            (click)=\"selectMinute(minute)\"\n            [class.ant-picker-time-panel-cell-selected]=\"isSelectedMinute(minute)\"\n            [class.ant-picker-time-panel-cell-disabled]=\"minute.disabled\"\n          >\n            <div class=\"ant-picker-time-panel-cell-inner\">{{ minute.index | number: '2.0-0' }}</div>\n          </li>\n        </ng-container>\n      </ul>\n      <ul *ngIf=\"secondEnabled\" #secondListElement class=\"ant-picker-time-panel-column\" style=\"position: relative;\">\n        <ng-container *ngFor=\"let second of secondRange\">\n          <li\n            *ngIf=\"!(dwHideDisabledOptions && second.disabled)\"\n            class=\"ant-picker-time-panel-cell\"\n            (click)=\"selectSecond(second)\"\n            [class.ant-picker-time-panel-cell-selected]=\"isSelectedSecond(second)\"\n            [class.ant-picker-time-panel-cell-disabled]=\"second.disabled\"\n          >\n            <div class=\"ant-picker-time-panel-cell-inner\">{{ second.index | number: '2.0-0' }}</div>\n          </li>\n        </ng-container>\n      </ul>\n      <ul *ngIf=\"dwUse12Hours\" #use12HoursListElement class=\"ant-picker-time-panel-column\" style=\"position: relative;\">\n        <ng-container *ngFor=\"let range of use12HoursRange\">\n          <li\n            *ngIf=\"!dwHideDisabledOptions\"\n            (click)=\"select12Hours(range)\"\n            class=\"ant-picker-time-panel-cell\"\n            [class.ant-picker-time-panel-cell-selected]=\"isSelected12Hours(range)\"\n          >\n            <div class=\"ant-picker-time-panel-cell-inner\">{{ range.value }}</div>\n          </li>\n        </ng-container>\n      </ul>\n    </div>\n    <div *ngIf=\"!dwInDatePicker\" class=\"ant-picker-footer\">\n      <div *ngIf=\"dwAddOn\" class=\"ant-picker-footer-extra\">\n        <ng-template [ngTemplateOutlet]=\"dwAddOn\"></ng-template>\n      </div>\n      <ul class=\"ant-picker-ranges\">\n        <li class=\"ant-picker-now\">\n          <a (click)=\"onClickNow()\">\n            {{ 'Calendar.lang.now' | dwI18n }}\n          </a>\n        </li>\n      </ul>\n    </div>\n  ",
                        host: {
                            '[class.ant-picker-time-panel]': "true",
                            '[class.ant-picker-time-panel-column-0]': "enabledColumns === 0 && !dwInDatePicker",
                            '[class.ant-picker-time-panel-column-1]': "enabledColumns === 1 && !dwInDatePicker",
                            '[class.ant-picker-time-panel-column-2]': "enabledColumns === 2 && !dwInDatePicker",
                            '[class.ant-picker-time-panel-column-3]': "enabledColumns === 3 && !dwInDatePicker",
                            '[class.ant-picker-time-panel-narrow]': "enabledColumns < 3",
                            '[class.ant-picker-time-panel-placement-bottomLeft]': "!dwInDatePicker"
                        },
                        providers: [{ provide: forms.NG_VALUE_ACCESSOR, useExisting: DwTimePickerPanelComponent, multi: true }]
                    }] }
        ];
        /** @nocollapse */
        DwTimePickerPanelComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: i18n.DateHelperService }
        ]; };
        DwTimePickerPanelComponent.propDecorators = {
            dwTimeValueAccessorDirective: [{ type: core.ViewChild, args: [DwTimeValueAccessorDirective, { static: false },] }],
            hourListElement: [{ type: core.ViewChild, args: ['hourListElement', { static: false },] }],
            minuteListElement: [{ type: core.ViewChild, args: ['minuteListElement', { static: false },] }],
            secondListElement: [{ type: core.ViewChild, args: ['secondListElement', { static: false },] }],
            use12HoursListElement: [{ type: core.ViewChild, args: ['use12HoursListElement', { static: false },] }],
            dwInDatePicker: [{ type: core.Input }],
            dwAddOn: [{ type: core.Input }],
            dwHideDisabledOptions: [{ type: core.Input }],
            dwClearText: [{ type: core.Input }],
            dwPlaceHolder: [{ type: core.Input }],
            dwUse12Hours: [{ type: core.Input }],
            dwDefaultOpenValue: [{ type: core.Input }],
            closePanel: [{ type: core.Output }],
            dwAllowEmpty: [{ type: core.Input }],
            dwDisabledHours: [{ type: core.Input }],
            dwDisabledMinutes: [{ type: core.Input }],
            dwDisabledSeconds: [{ type: core.Input }],
            format: [{ type: core.Input }],
            dwHourStep: [{ type: core.Input }],
            dwMinuteStep: [{ type: core.Input }],
            dwSecondStep: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTimePickerPanelComponent.prototype, "dwUse12Hours", void 0);
        return DwTimePickerPanelComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTimePickerPanelComponent.ngAcceptInputType_dwUse12Hours;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._dwHourStep;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._dwMinuteStep;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._dwSecondStep;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype.unsubscribe$;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype.onChange;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype.onTouch;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._format;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._disabledHours;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._disabledMinutes;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._disabledSeconds;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype._allowEmpty;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.time;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.hourEnabled;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.minuteEnabled;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.secondEnabled;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.firstScrolled;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.enabledColumns;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.hourRange;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.minuteRange;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.secondRange;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.use12HoursRange;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwTimeValueAccessorDirective;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.hourListElement;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.minuteListElement;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.secondListElement;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.use12HoursListElement;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwInDatePicker;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwAddOn;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwHideDisabledOptions;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwClearText;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwPlaceHolder;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwUse12Hours;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dwDefaultOpenValue;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.closePanel;
        /**
         * @type {?}
         * @private
         */
        DwTimePickerPanelComponent.prototype.cdr;
        /** @type {?} */
        DwTimePickerPanelComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: time-picker.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTimePickerModule = /** @class */ (function () {
        function DwTimePickerModule() {
        }
        DwTimePickerModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [DwTimePickerComponent, DwTimePickerPanelComponent, DwTimeValueAccessorDirective],
                        exports: [DwTimePickerPanelComponent, DwTimePickerComponent],
                        imports: [common.CommonModule, forms.FormsModule, i18n.DwI18nModule, overlay.OverlayModule, icon.DwIconModule, overlay$1.DwOverlayModule, outlet.DwOutletModule]
                    },] }
        ];
        return DwTimePickerModule;
    }());

    exports.DwTimePickerComponent = DwTimePickerComponent;
    exports.DwTimePickerModule = DwTimePickerModule;
    exports.DwTimePickerPanelComponent = DwTimePickerPanelComponent;
    exports.DwTimeValueAccessorDirective = DwTimeValueAccessorDirective;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-time-picker.umd.js.map
