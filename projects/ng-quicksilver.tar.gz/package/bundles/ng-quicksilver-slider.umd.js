(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/keycodes'), require('@angular/cdk/platform'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/tooltip'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/slider', ['exports', '@angular/cdk/keycodes', '@angular/cdk/platform', '@angular/core', '@angular/forms', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', 'ng-quicksilver/tooltip', '@angular/common'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].slider = {}), global.ng.cdk.keycodes, global.ng.cdk.platform, global.ng.core, global.ng.forms, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].tooltip, global.ng.common));
}(this, (function (exports, keycodes, platform, core, forms, util, rxjs, operators, tooltip, common) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: slider.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderService = /** @class */ (function () {
        function DwSliderService() {
            this.isDragging = false;
        }
        DwSliderService.decorators = [
            { type: core.Injectable }
        ];
        return DwSliderService;
    }());
    if (false) {
        /** @type {?} */
        DwSliderService.prototype.isDragging;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: handle.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderHandleComponent = /** @class */ (function () {
        function DwSliderHandleComponent(sliderService, cdr) {
            var _this = this;
            this.sliderService = sliderService;
            this.cdr = cdr;
            this.tooltipVisible = 'default';
            this.active = false;
            this.style = {};
            this.enterHandle = (/**
             * @return {?}
             */
            function () {
                if (!_this.sliderService.isDragging) {
                    _this.toggleTooltip(true);
                    _this.updateTooltipPosition();
                    _this.cdr.detectChanges();
                }
            });
            this.leaveHandle = (/**
             * @return {?}
             */
            function () {
                if (!_this.sliderService.isDragging) {
                    _this.toggleTooltip(false);
                    _this.cdr.detectChanges();
                }
            });
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSliderHandleComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            var offset = changes.offset, value = changes.value, active = changes.active, tooltipVisible = changes.tooltipVisible, reverse = changes.reverse;
            if (offset || reverse) {
                this.updateStyle();
            }
            if (value) {
                this.updateTooltipTitle();
                this.updateTooltipPosition();
            }
            if (active) {
                if (active.currentValue) {
                    this.toggleTooltip(true);
                }
                else {
                    this.toggleTooltip(false);
                }
            }
            if ((tooltipVisible === null || tooltipVisible === void 0 ? void 0 : tooltipVisible.currentValue) === 'always') {
                Promise.resolve().then((/**
                 * @return {?}
                 */
                function () { return _this.toggleTooltip(true, true); }));
            }
        };
        /**
         * @return {?}
         */
        DwSliderHandleComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.handleEl) === null || _a === void 0 ? void 0 : _a.nativeElement.focus();
        };
        /**
         * @private
         * @param {?} show
         * @param {?=} force
         * @return {?}
         */
        DwSliderHandleComponent.prototype.toggleTooltip = /**
         * @private
         * @param {?} show
         * @param {?=} force
         * @return {?}
         */
        function (show, force) {
            if (force === void 0) { force = false; }
            var _a, _b;
            if (!force && (this.tooltipVisible !== 'default' || !this.tooltip)) {
                return;
            }
            if (show) {
                (_a = this.tooltip) === null || _a === void 0 ? void 0 : _a.show();
            }
            else {
                (_b = this.tooltip) === null || _b === void 0 ? void 0 : _b.hide();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderHandleComponent.prototype.updateTooltipTitle = /**
         * @private
         * @return {?}
         */
        function () {
            this.tooltipTitle = this.tooltipFormatter ? this.tooltipFormatter((/** @type {?} */ (this.value))) : "" + this.value;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderHandleComponent.prototype.updateTooltipPosition = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.tooltip) {
                Promise.resolve().then((/**
                 * @return {?}
                 */
                function () { var _a; return (_a = _this.tooltip) === null || _a === void 0 ? void 0 : _a.updatePosition(); }));
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderHandleComponent.prototype.updateStyle = /**
         * @private
         * @return {?}
         */
        function () {
            var _a, _b;
            /** @type {?} */
            var vertical = this.vertical;
            /** @type {?} */
            var reverse = this.reverse;
            /** @type {?} */
            var offset = this.offset;
            /** @type {?} */
            var positionStyle = vertical
                ? (_a = {},
                    _a[reverse ? 'top' : 'bottom'] = offset + "%",
                    _a[reverse ? 'bottom' : 'top'] = 'auto',
                    _a.transform = reverse ? null : "translateY(+50%)",
                    _a) : (_b = {},
                _b[reverse ? 'right' : 'left'] = offset + "%",
                _b[reverse ? 'left' : 'right'] = 'auto',
                _b.transform = "translateX(" + (reverse ? '+' : '-') + "50%)",
                _b);
            this.style = positionStyle;
            this.cdr.markForCheck();
        };
        DwSliderHandleComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-slider-handle',
                        exportAs: 'dwSliderHandle',
                        preserveWhitespaces: false,
                        template: "\n    <div\n      #handle\n      class=\"ant-slider-handle\"\n      tabindex=\"0\"\n      dw-tooltip\n      [ngStyle]=\"style\"\n      [dwTooltipTitle]=\"tooltipFormatter === null || tooltipVisible === 'never' ? null : tooltipTitle\"\n      [dwTooltipTrigger]=\"null\"\n      [dwTooltipPlacement]=\"tooltipPlacement\"\n    ></div>\n  ",
                        host: {
                            '(mouseenter)': 'enterHandle()',
                            '(mouseleave)': 'leaveHandle()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSliderHandleComponent.ctorParameters = function () { return [
            { type: DwSliderService },
            { type: core.ChangeDetectorRef }
        ]; };
        DwSliderHandleComponent.propDecorators = {
            handleEl: [{ type: core.ViewChild, args: ['handle', { static: false },] }],
            tooltip: [{ type: core.ViewChild, args: [tooltip.DwTooltipDirective, { static: false },] }],
            vertical: [{ type: core.Input }],
            reverse: [{ type: core.Input }],
            offset: [{ type: core.Input }],
            value: [{ type: core.Input }],
            tooltipVisible: [{ type: core.Input }],
            tooltipPlacement: [{ type: core.Input }],
            tooltipFormatter: [{ type: core.Input }],
            active: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderHandleComponent.prototype, "active", void 0);
        return DwSliderHandleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSliderHandleComponent.ngAcceptInputType_active;
        /** @type {?} */
        DwSliderHandleComponent.prototype.handleEl;
        /** @type {?} */
        DwSliderHandleComponent.prototype.tooltip;
        /** @type {?} */
        DwSliderHandleComponent.prototype.vertical;
        /** @type {?} */
        DwSliderHandleComponent.prototype.reverse;
        /** @type {?} */
        DwSliderHandleComponent.prototype.offset;
        /** @type {?} */
        DwSliderHandleComponent.prototype.value;
        /** @type {?} */
        DwSliderHandleComponent.prototype.tooltipVisible;
        /** @type {?} */
        DwSliderHandleComponent.prototype.tooltipPlacement;
        /** @type {?} */
        DwSliderHandleComponent.prototype.tooltipFormatter;
        /** @type {?} */
        DwSliderHandleComponent.prototype.active;
        /** @type {?} */
        DwSliderHandleComponent.prototype.tooltipTitle;
        /** @type {?} */
        DwSliderHandleComponent.prototype.style;
        /** @type {?} */
        DwSliderHandleComponent.prototype.enterHandle;
        /** @type {?} */
        DwSliderHandleComponent.prototype.leaveHandle;
        /**
         * @type {?}
         * @private
         */
        DwSliderHandleComponent.prototype.sliderService;
        /**
         * @type {?}
         * @private
         */
        DwSliderHandleComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: slider.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderComponent = /** @class */ (function () {
        function DwSliderComponent(sliderService, cdr, platform) {
            this.sliderService = sliderService;
            this.cdr = cdr;
            this.platform = platform;
            this.dwDisabled = false;
            this.dwDots = false;
            this.dwIncluded = true;
            this.dwRange = false;
            this.dwVertical = false;
            this.dwReverse = false;
            this.dwMarks = null;
            this.dwMax = 100;
            this.dwMin = 0;
            this.dwStep = 1;
            this.dwTooltipVisible = 'default';
            this.dwTooltipPlacement = 'top';
            this.dwOnAfterChange = new core.EventEmitter();
            this.value = null;
            this.cacheSliderStart = null;
            this.cacheSliderLength = null;
            this.activeValueIndex = undefined; // Current activated handle's index ONLY for range=true
            // Current activated handle's index ONLY for range=true
            this.track = { offset: null, length: null }; // Track's offset and length
            // Track's offset and length
            this.handles = []; // Handles' offset
            // Handles' offset
            this.marksArray = null; // "steps" in array type with more data & FILTER out the invalid mark
            // "steps" in array type with more data & FILTER out the invalid mark
            this.bounds = { lower: null, upper: null }; // now for dw-slider-step
        }
        /**
         * @return {?}
         */
        DwSliderComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.handles = generateHandlers(this.dwRange ? 2 : 1);
            this.marksArray = this.dwMarks ? this.generateMarkItems(this.dwMarks) : null;
            this.bindDraggingHandlers();
            this.toggleDragDisabled(this.dwDisabled);
            if (this.getValue() === null) {
                this.setValue(this.formatValue(null));
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSliderComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwDisabled = changes.dwDisabled, dwMarks = changes.dwMarks, dwRange = changes.dwRange;
            if (dwDisabled && !dwDisabled.firstChange) {
                this.toggleDragDisabled(dwDisabled.currentValue);
            }
            else if (dwMarks && !dwMarks.firstChange) {
                this.marksArray = this.dwMarks ? this.generateMarkItems(this.dwMarks) : null;
            }
            else if (dwRange && !dwRange.firstChange) {
                this.setValue(this.formatValue(null));
            }
        };
        /**
         * @return {?}
         */
        DwSliderComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.unsubscribeDrag();
        };
        /**
         * @param {?} val
         * @return {?}
         */
        DwSliderComponent.prototype.writeValue = /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            this.setValue(val, true);
        };
        /**
         * @param {?} _value
         * @return {?}
         */
        DwSliderComponent.prototype.onValueChange = /**
         * @param {?} _value
         * @return {?}
         */
        function (_value) { };
        /**
         * @return {?}
         */
        DwSliderComponent.prototype.onTouched = /**
         * @return {?}
         */
        function () { };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwSliderComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onValueChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwSliderComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwSliderComponent.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            this.dwDisabled = isDisabled;
            this.toggleDragDisabled(isDisabled);
        };
        /**
         * Event handler is only triggered when a slider handler is focused.
         */
        /**
         * Event handler is only triggered when a slider handler is focused.
         * @param {?} e
         * @return {?}
         */
        DwSliderComponent.prototype.onKeyDown = /**
         * Event handler is only triggered when a slider handler is focused.
         * @param {?} e
         * @return {?}
         */
        function (e) {
            /** @type {?} */
            var code = e.keyCode;
            /** @type {?} */
            var isIncrease = code === keycodes.RIGHT_ARROW || code === keycodes.UP_ARROW;
            /** @type {?} */
            var isDecrease = code === keycodes.LEFT_ARROW || code === keycodes.DOWN_ARROW;
            if (!(isIncrease || isDecrease)) {
                return;
            }
            e.preventDefault();
            /** @type {?} */
            var step = (isDecrease ? -this.dwStep : this.dwStep) * (this.dwReverse ? -1 : 1);
            /** @type {?} */
            var newVal = this.dwRange ? ((/** @type {?} */ (this.value)))[(/** @type {?} */ (this.activeValueIndex))] + step : ((/** @type {?} */ (this.value))) + step;
            this.setActiveValue(util.ensureNumberInRange(newVal, this.dwMin, this.dwMax));
        };
        /**
         * @private
         * @param {?} value
         * @param {?=} isWriteValue
         * @return {?}
         */
        DwSliderComponent.prototype.setValue = /**
         * @private
         * @param {?} value
         * @param {?=} isWriteValue
         * @return {?}
         */
        function (value, isWriteValue) {
            if (isWriteValue === void 0) { isWriteValue = false; }
            if (isWriteValue) {
                this.value = this.formatValue(value);
                this.updateTrackAndHandles();
            }
            else if (!valuesEqual((/** @type {?} */ (this.value)), (/** @type {?} */ (value)))) {
                this.value = value;
                this.updateTrackAndHandles();
                this.onValueChange(this.getValue(true));
            }
        };
        /**
         * @private
         * @param {?=} cloneAndSort
         * @return {?}
         */
        DwSliderComponent.prototype.getValue = /**
         * @private
         * @param {?=} cloneAndSort
         * @return {?}
         */
        function (cloneAndSort) {
            if (cloneAndSort === void 0) { cloneAndSort = false; }
            if (cloneAndSort && this.value && isValueRange(this.value)) {
                return __spread(this.value).sort((/**
                 * @param {?} a
                 * @param {?} b
                 * @return {?}
                 */
                function (a, b) { return a - b; }));
            }
            return (/** @type {?} */ (this.value));
        };
        /**
         * Clone & sort current value and convert them to offsets, then return the new one.
         */
        /**
         * Clone & sort current value and convert them to offsets, then return the new one.
         * @private
         * @param {?=} value
         * @return {?}
         */
        DwSliderComponent.prototype.getValueToOffset = /**
         * Clone & sort current value and convert them to offsets, then return the new one.
         * @private
         * @param {?=} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            /** @type {?} */
            var normalizedValue = value;
            if (typeof normalizedValue === 'undefined') {
                normalizedValue = this.getValue(true);
            }
            return isValueRange(normalizedValue) ? normalizedValue.map((/**
             * @param {?} val
             * @return {?}
             */
            function (val) { return _this.valueToOffset(val); })) : this.valueToOffset(normalizedValue);
        };
        /**
         * Find the closest value to be activated.
         */
        /**
         * Find the closest value to be activated.
         * @private
         * @param {?} pointerValue
         * @return {?}
         */
        DwSliderComponent.prototype.setActiveValueIndex = /**
         * Find the closest value to be activated.
         * @private
         * @param {?} pointerValue
         * @return {?}
         */
        function (pointerValue) {
            /** @type {?} */
            var value = this.getValue();
            if (isValueRange(value)) {
                /** @type {?} */
                var minimal_1 = null;
                /** @type {?} */
                var gap_1;
                /** @type {?} */
                var activeIndex_1 = -1;
                value.forEach((/**
                 * @param {?} val
                 * @param {?} index
                 * @return {?}
                 */
                function (val, index) {
                    gap_1 = Math.abs(pointerValue - val);
                    if (minimal_1 === null || gap_1 < (/** @type {?} */ (minimal_1))) {
                        minimal_1 = gap_1;
                        activeIndex_1 = index;
                    }
                }));
                this.activeValueIndex = activeIndex_1;
                this.handlerComponents.toArray()[activeIndex_1].focus();
            }
            else {
                this.handlerComponents.toArray()[0].focus();
            }
        };
        /**
         * @private
         * @param {?} pointerValue
         * @return {?}
         */
        DwSliderComponent.prototype.setActiveValue = /**
         * @private
         * @param {?} pointerValue
         * @return {?}
         */
        function (pointerValue) {
            if (isValueRange((/** @type {?} */ (this.value)))) {
                /** @type {?} */
                var newValue = __spread(((/** @type {?} */ (this.value))));
                newValue[(/** @type {?} */ (this.activeValueIndex))] = pointerValue;
                this.setValue(newValue);
            }
            else {
                this.setValue(pointerValue);
            }
        };
        /**
         * Update track and handles' position and length.
         */
        /**
         * Update track and handles' position and length.
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.updateTrackAndHandles = /**
         * Update track and handles' position and length.
         * @private
         * @return {?}
         */
        function () {
            var _a, _b;
            /** @type {?} */
            var value = this.getValue();
            /** @type {?} */
            var offset = this.getValueToOffset(value);
            /** @type {?} */
            var valueSorted = this.getValue(true);
            /** @type {?} */
            var offsetSorted = this.getValueToOffset(valueSorted);
            /** @type {?} */
            var boundParts = isValueRange(valueSorted) ? valueSorted : [0, valueSorted];
            /** @type {?} */
            var trackParts = isValueRange(offsetSorted) ? [offsetSorted[0], offsetSorted[1] - offsetSorted[0]] : [0, offsetSorted];
            this.handles.forEach((/**
             * @param {?} handle
             * @param {?} index
             * @return {?}
             */
            function (handle, index) {
                handle.offset = isValueRange(offset) ? offset[index] : offset;
                handle.value = isValueRange(value) ? value[index] : value || 0;
            }));
            _a = __read(boundParts, 2), this.bounds.lower = _a[0], this.bounds.upper = _a[1];
            _b = __read(trackParts, 2), this.track.offset = _b[0], this.track.length = _b[1];
            this.cdr.markForCheck();
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwSliderComponent.prototype.onDragStart = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.toggleDragMoving(true);
            this.cacheSliderProperty();
            this.setActiveValueIndex(this.getLogicalValue(value));
            this.setActiveValue(this.getLogicalValue(value));
            this.showHandleTooltip(this.dwRange ? this.activeValueIndex : 0);
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwSliderComponent.prototype.onDragMove = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.setActiveValue(this.getLogicalValue(value));
            this.cdr.markForCheck();
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwSliderComponent.prototype.getLogicalValue = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return this.dwReverse ? this.dwMax - value : value;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.onDragEnd = /**
         * @private
         * @return {?}
         */
        function () {
            this.dwOnAfterChange.emit(this.getValue(true));
            this.toggleDragMoving(false);
            this.cacheSliderProperty(true);
            this.hideAllHandleTooltip();
            this.cdr.markForCheck();
        };
        /**
         * Create user interactions handles.
         */
        /**
         * Create user interactions handles.
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.bindDraggingHandlers = /**
         * Create user interactions handles.
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.platform.isBrowser) {
                return;
            }
            /** @type {?} */
            var sliderDOM = this.slider.nativeElement;
            /** @type {?} */
            var orientField = this.dwVertical ? 'pageY' : 'pageX';
            /** @type {?} */
            var mouse = {
                start: 'mousedown',
                move: 'mousemove',
                end: 'mouseup',
                pluckKey: [orientField]
            };
            /** @type {?} */
            var touch = {
                start: 'touchstart',
                move: 'touchmove',
                end: 'touchend',
                pluckKey: ['touches', '0', orientField],
                filter: (/**
                 * @param {?} e
                 * @return {?}
                 */
                function (e) { return e instanceof TouchEvent; })
            };
            [mouse, touch].forEach((/**
             * @param {?} source
             * @return {?}
             */
            function (source) {
                var start = source.start, move = source.move, end = source.end, pluckKey = source.pluckKey, _a = source.filter, filterFunc = _a === void 0 ? (/**
                 * @return {?}
                 */
                function () { return true; }) : _a;
                source.startPlucked$ = rxjs.fromEvent(sliderDOM, start).pipe(operators.filter(filterFunc), operators.tap(util.silentEvent), operators.pluck.apply(void 0, __spread(pluckKey)), operators.map((/**
                 * @param {?} position
                 * @return {?}
                 */
                function (position) { return _this.findClosestValue(position); })));
                source.end$ = rxjs.fromEvent(document, end);
                source.moveResolved$ = rxjs.fromEvent(document, move).pipe(operators.filter(filterFunc), operators.tap(util.silentEvent), operators.pluck.apply(void 0, __spread(pluckKey)), operators.distinctUntilChanged(), operators.map((/**
                 * @param {?} position
                 * @return {?}
                 */
                function (position) { return _this.findClosestValue(position); })), operators.distinctUntilChanged(), operators.takeUntil(source.end$));
            }));
            this.dragStart$ = rxjs.merge((/** @type {?} */ (mouse.startPlucked$)), (/** @type {?} */ (touch.startPlucked$)));
            this.dragMove$ = rxjs.merge((/** @type {?} */ (mouse.moveResolved$)), (/** @type {?} */ (touch.moveResolved$)));
            this.dragEnd$ = rxjs.merge((/** @type {?} */ (mouse.end$)), (/** @type {?} */ (touch.end$)));
        };
        /**
         * @private
         * @param {?=} periods
         * @return {?}
         */
        DwSliderComponent.prototype.subscribeDrag = /**
         * @private
         * @param {?=} periods
         * @return {?}
         */
        function (periods) {
            if (periods === void 0) { periods = ['start', 'move', 'end']; }
            if (periods.indexOf('start') !== -1 && this.dragStart$ && !this.dragStart_) {
                this.dragStart_ = this.dragStart$.subscribe(this.onDragStart.bind(this));
            }
            if (periods.indexOf('move') !== -1 && this.dragMove$ && !this.dragMove_) {
                this.dragMove_ = this.dragMove$.subscribe(this.onDragMove.bind(this));
            }
            if (periods.indexOf('end') !== -1 && this.dragEnd$ && !this.dragEnd_) {
                this.dragEnd_ = this.dragEnd$.subscribe(this.onDragEnd.bind(this));
            }
        };
        /**
         * @private
         * @param {?=} periods
         * @return {?}
         */
        DwSliderComponent.prototype.unsubscribeDrag = /**
         * @private
         * @param {?=} periods
         * @return {?}
         */
        function (periods) {
            if (periods === void 0) { periods = ['start', 'move', 'end']; }
            if (periods.indexOf('start') !== -1 && this.dragStart_) {
                this.dragStart_.unsubscribe();
                this.dragStart_ = null;
            }
            if (periods.indexOf('move') !== -1 && this.dragMove_) {
                this.dragMove_.unsubscribe();
                this.dragMove_ = null;
            }
            if (periods.indexOf('end') !== -1 && this.dragEnd_) {
                this.dragEnd_.unsubscribe();
                this.dragEnd_ = null;
            }
        };
        /**
         * @private
         * @param {?} movable
         * @return {?}
         */
        DwSliderComponent.prototype.toggleDragMoving = /**
         * @private
         * @param {?} movable
         * @return {?}
         */
        function (movable) {
            /** @type {?} */
            var periods = ['move', 'end'];
            if (movable) {
                this.sliderService.isDragging = true;
                this.subscribeDrag(periods);
            }
            else {
                this.sliderService.isDragging = false;
                this.unsubscribeDrag(periods);
            }
        };
        /**
         * @private
         * @param {?} disabled
         * @return {?}
         */
        DwSliderComponent.prototype.toggleDragDisabled = /**
         * @private
         * @param {?} disabled
         * @return {?}
         */
        function (disabled) {
            if (disabled) {
                this.unsubscribeDrag();
            }
            else {
                this.subscribeDrag(['start']);
            }
        };
        /**
         * @private
         * @param {?} position
         * @return {?}
         */
        DwSliderComponent.prototype.findClosestValue = /**
         * @private
         * @param {?} position
         * @return {?}
         */
        function (position) {
            /** @type {?} */
            var sliderStart = this.getSliderStartPosition();
            /** @type {?} */
            var sliderLength = this.getSliderLength();
            /** @type {?} */
            var ratio = util.ensureNumberInRange((position - sliderStart) / sliderLength, 0, 1);
            /** @type {?} */
            var val = (this.dwMax - this.dwMin) * (this.dwVertical ? 1 - ratio : ratio) + this.dwMin;
            /** @type {?} */
            var points = this.dwMarks === null ? [] : Object.keys(this.dwMarks).map(parseFloat);
            if (this.dwStep !== 0 && !this.dwDots) {
                /** @type {?} */
                var closestOne = Math.round(val / this.dwStep) * this.dwStep;
                points.push(closestOne);
            }
            /** @type {?} */
            var gaps = points.map((/**
             * @param {?} point
             * @return {?}
             */
            function (point) { return Math.abs(val - point); }));
            /** @type {?} */
            var closest = points[gaps.indexOf(Math.min.apply(Math, __spread(gaps)))];
            return this.dwStep === null ? closest : parseFloat(closest.toFixed(util.getPrecision(this.dwStep)));
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwSliderComponent.prototype.valueToOffset = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return util.getPercent(this.dwMin, this.dwMax, value);
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.getSliderStartPosition = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.cacheSliderStart !== null) {
                return this.cacheSliderStart;
            }
            /** @type {?} */
            var offset = util.getElementOffset(this.slider.nativeElement);
            return this.dwVertical ? offset.top : offset.left;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.getSliderLength = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.cacheSliderLength !== null) {
                return this.cacheSliderLength;
            }
            /** @type {?} */
            var sliderDOM = this.slider.nativeElement;
            return this.dwVertical ? sliderDOM.clientHeight : sliderDOM.clientWidth;
        };
        /**
         * Cache DOM layout/reflow operations for performance (may not necessary?)
         */
        /**
         * Cache DOM layout/reflow operations for performance (may not necessary?)
         * @private
         * @param {?=} remove
         * @return {?}
         */
        DwSliderComponent.prototype.cacheSliderProperty = /**
         * Cache DOM layout/reflow operations for performance (may not necessary?)
         * @private
         * @param {?=} remove
         * @return {?}
         */
        function (remove) {
            if (remove === void 0) { remove = false; }
            this.cacheSliderStart = remove ? null : this.getSliderStartPosition();
            this.cacheSliderLength = remove ? null : this.getSliderLength();
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwSliderComponent.prototype.formatValue = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            if (!value) {
                return this.dwRange ? [this.dwMin, this.dwMax] : this.dwMin;
            }
            else if (assertValueValid(value, this.dwRange)) {
                return isValueRange(value)
                    ? value.map((/**
                     * @param {?} val
                     * @return {?}
                     */
                    function (val) { return util.ensureNumberInRange(val, _this.dwMin, _this.dwMax); }))
                    : util.ensureNumberInRange(value, this.dwMin, this.dwMax);
            }
            else {
                return this.dwDefaultValue ? this.dwDefaultValue : this.dwRange ? [this.dwMin, this.dwMax] : this.dwMin;
            }
        };
        /**
         * Show one handle's tooltip and hide others'.
         */
        /**
         * Show one handle's tooltip and hide others'.
         * @private
         * @param {?=} handleIndex
         * @return {?}
         */
        DwSliderComponent.prototype.showHandleTooltip = /**
         * Show one handle's tooltip and hide others'.
         * @private
         * @param {?=} handleIndex
         * @return {?}
         */
        function (handleIndex) {
            if (handleIndex === void 0) { handleIndex = 0; }
            this.handles.forEach((/**
             * @param {?} handle
             * @param {?} index
             * @return {?}
             */
            function (handle, index) {
                handle.active = index === handleIndex;
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderComponent.prototype.hideAllHandleTooltip = /**
         * @private
         * @return {?}
         */
        function () {
            this.handles.forEach((/**
             * @param {?} handle
             * @return {?}
             */
            function (handle) { return (handle.active = false); }));
        };
        /**
         * @private
         * @param {?} marks
         * @return {?}
         */
        DwSliderComponent.prototype.generateMarkItems = /**
         * @private
         * @param {?} marks
         * @return {?}
         */
        function (marks) {
            /** @type {?} */
            var marksArray = [];
            for (var key in marks) {
                /** @type {?} */
                var mark = marks[key];
                /** @type {?} */
                var val = typeof key === 'number' ? key : parseFloat(key);
                if (val >= this.dwMin && val <= this.dwMax) {
                    marksArray.push({ value: val, offset: this.valueToOffset(val), config: mark });
                }
            }
            return marksArray.length ? marksArray : null;
        };
        DwSliderComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-slider',
                        exportAs: 'dwSlider',
                        preserveWhitespaces: false,
                        providers: [
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwSliderComponent; })),
                                multi: true
                            },
                            DwSliderService
                        ],
                        host: {
                            '(keydown)': 'onKeyDown($event)'
                        },
                        template: "\n    <div\n      #slider\n      class=\"ant-slider\"\n      [class.ant-slider-disabled]=\"dwDisabled\"\n      [class.ant-slider-vertical]=\"dwVertical\"\n      [class.ant-slider-with-marks]=\"marksArray\"\n    >\n      <div class=\"ant-slider-rail\"></div>\n      <dw-slider-track\n        [vertical]=\"dwVertical\"\n        [included]=\"dwIncluded\"\n        [offset]=\"track.offset!\"\n        [length]=\"track.length!\"\n        [reverse]=\"dwReverse\"\n      ></dw-slider-track>\n      <dw-slider-step\n        *ngIf=\"marksArray\"\n        [vertical]=\"dwVertical\"\n        [lowerBound]=\"$any(bounds.lower)\"\n        [upperBound]=\"$any(bounds.upper)\"\n        [marksArray]=\"marksArray\"\n        [included]=\"dwIncluded\"\n      ></dw-slider-step>\n      <dw-slider-handle\n        *ngFor=\"let handle of handles\"\n        [vertical]=\"dwVertical\"\n        [reverse]=\"dwReverse\"\n        [offset]=\"handle.offset!\"\n        [value]=\"handle.value!\"\n        [active]=\"handle.active\"\n        [tooltipFormatter]=\"dwTipFormatter\"\n        [tooltipVisible]=\"dwTooltipVisible\"\n        [tooltipPlacement]=\"dwTooltipPlacement\"\n      ></dw-slider-handle>\n      <dw-slider-marks\n        *ngIf=\"marksArray\"\n        [vertical]=\"dwVertical\"\n        [min]=\"dwMin\"\n        [max]=\"dwMax\"\n        [lowerBound]=\"$any(bounds.lower)\"\n        [upperBound]=\"$any(bounds.upper)\"\n        [marksArray]=\"marksArray\"\n        [included]=\"dwIncluded\"\n      ></dw-slider-marks>\n    </div>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwSliderComponent.ctorParameters = function () { return [
            { type: DwSliderService },
            { type: core.ChangeDetectorRef },
            { type: platform.Platform }
        ]; };
        DwSliderComponent.propDecorators = {
            slider: [{ type: core.ViewChild, args: ['slider', { static: true },] }],
            handlerComponents: [{ type: core.ViewChildren, args: [DwSliderHandleComponent,] }],
            dwDisabled: [{ type: core.Input }],
            dwDots: [{ type: core.Input }],
            dwIncluded: [{ type: core.Input }],
            dwRange: [{ type: core.Input }],
            dwVertical: [{ type: core.Input }],
            dwReverse: [{ type: core.Input }],
            dwDefaultValue: [{ type: core.Input }],
            dwMarks: [{ type: core.Input }],
            dwMax: [{ type: core.Input }],
            dwMin: [{ type: core.Input }],
            dwStep: [{ type: core.Input }],
            dwTooltipVisible: [{ type: core.Input }],
            dwTooltipPlacement: [{ type: core.Input }],
            dwTipFormatter: [{ type: core.Input }],
            dwOnAfterChange: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderComponent.prototype, "dwDots", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderComponent.prototype, "dwIncluded", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderComponent.prototype, "dwRange", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderComponent.prototype, "dwVertical", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderComponent.prototype, "dwReverse", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwSliderComponent.prototype, "dwMax", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwSliderComponent.prototype, "dwMin", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Object)
        ], DwSliderComponent.prototype, "dwStep", void 0);
        return DwSliderComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwDots;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwIncluded;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwRange;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwVertical;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwMax;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwMin;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwStep;
        /** @type {?} */
        DwSliderComponent.ngAcceptInputType_dwReverse;
        /** @type {?} */
        DwSliderComponent.prototype.slider;
        /** @type {?} */
        DwSliderComponent.prototype.handlerComponents;
        /** @type {?} */
        DwSliderComponent.prototype.dwDisabled;
        /** @type {?} */
        DwSliderComponent.prototype.dwDots;
        /** @type {?} */
        DwSliderComponent.prototype.dwIncluded;
        /** @type {?} */
        DwSliderComponent.prototype.dwRange;
        /** @type {?} */
        DwSliderComponent.prototype.dwVertical;
        /** @type {?} */
        DwSliderComponent.prototype.dwReverse;
        /** @type {?} */
        DwSliderComponent.prototype.dwDefaultValue;
        /** @type {?} */
        DwSliderComponent.prototype.dwMarks;
        /** @type {?} */
        DwSliderComponent.prototype.dwMax;
        /** @type {?} */
        DwSliderComponent.prototype.dwMin;
        /** @type {?} */
        DwSliderComponent.prototype.dwStep;
        /** @type {?} */
        DwSliderComponent.prototype.dwTooltipVisible;
        /** @type {?} */
        DwSliderComponent.prototype.dwTooltipPlacement;
        /** @type {?} */
        DwSliderComponent.prototype.dwTipFormatter;
        /** @type {?} */
        DwSliderComponent.prototype.dwOnAfterChange;
        /** @type {?} */
        DwSliderComponent.prototype.value;
        /** @type {?} */
        DwSliderComponent.prototype.cacheSliderStart;
        /** @type {?} */
        DwSliderComponent.prototype.cacheSliderLength;
        /** @type {?} */
        DwSliderComponent.prototype.activeValueIndex;
        /** @type {?} */
        DwSliderComponent.prototype.track;
        /** @type {?} */
        DwSliderComponent.prototype.handles;
        /** @type {?} */
        DwSliderComponent.prototype.marksArray;
        /** @type {?} */
        DwSliderComponent.prototype.bounds;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragStart$;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragMove$;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragEnd$;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragStart_;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragMove_;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.dragEnd_;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.sliderService;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwSliderComponent.prototype.platform;
    }
    /**
     * @return {?}
     */
    function getValueTypeNotMatchError() {
        return new Error("The \"dwRange\" can't match the \"ngModel\"'s type, please check these properties: \"dwRange\", \"ngModel\", \"dwDefaultValue\".");
    }
    /**
     * @param {?} value
     * @return {?}
     */
    function isValueRange(value) {
        if (value instanceof Array) {
            return value.length === 2;
        }
        else {
            return false;
        }
    }
    /**
     * @param {?} amount
     * @return {?}
     */
    function generateHandlers(amount) {
        return Array(amount)
            .fill(0)
            .map((/**
         * @return {?}
         */
        function () { return ({ offset: null, value: null, active: false }); }));
    }
    /**
     * Check if value is valid and throw error if value-type/range not match.
     * @param {?} value
     * @param {?=} isRange
     * @return {?}
     */
    function assertValueValid(value, isRange) {
        if ((!isValueRange(value) && isNaN(value)) || (isValueRange(value) && value.some((/**
         * @param {?} v
         * @return {?}
         */
        function (v) { return isNaN(v); })))) {
            return false;
        }
        return assertValueTypeMatch(value, isRange);
    }
    /**
     * Assert that if `this.dwRange` is `true`, value is also a range, vice versa.
     * @param {?} value
     * @param {?=} isRange
     * @return {?}
     */
    function assertValueTypeMatch(value, isRange) {
        if (isRange === void 0) { isRange = false; }
        if (isValueRange(value) !== isRange) {
            throw getValueTypeNotMatchError();
        }
        return true;
    }
    /**
     * @param {?} valA
     * @param {?} valB
     * @return {?}
     */
    function valuesEqual(valA, valB) {
        if (typeof valA !== typeof valB) {
            return false;
        }
        return isValueRange(valA) && isValueRange(valB) ? util.arraysEqual(valA, valB) : valA === valB;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: marks.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderMarksComponent = /** @class */ (function () {
        function DwSliderMarksComponent() {
            this.lowerBound = null;
            this.upperBound = null;
            this.marksArray = [];
            this.vertical = false;
            this.included = false;
            this.marks = [];
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSliderMarksComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var marksArray = changes.marksArray, lowerBound = changes.lowerBound, upperBound = changes.upperBound;
            if (marksArray) {
                this.buildMarks();
            }
            if (marksArray || lowerBound || upperBound) {
                this.togglePointActive();
            }
        };
        /**
         * @param {?} _index
         * @param {?} mark
         * @return {?}
         */
        DwSliderMarksComponent.prototype.trackById = /**
         * @param {?} _index
         * @param {?} mark
         * @return {?}
         */
        function (_index, mark) {
            return mark.value;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderMarksComponent.prototype.buildMarks = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var range = this.max - this.min;
            this.marks = this.marksArray.map((/**
             * @param {?} mark
             * @return {?}
             */
            function (mark) {
                var value = mark.value, offset = mark.offset, config = mark.config;
                /** @type {?} */
                var style = _this.getMarkStyles(value, range, config);
                /** @type {?} */
                var label = isConfigObject(config) ? config.label : config;
                return {
                    label: label,
                    offset: offset,
                    style: style,
                    value: value,
                    config: config,
                    active: false
                };
            }));
        };
        /**
         * @private
         * @param {?} value
         * @param {?} range
         * @param {?} config
         * @return {?}
         */
        DwSliderMarksComponent.prototype.getMarkStyles = /**
         * @private
         * @param {?} value
         * @param {?} range
         * @param {?} config
         * @return {?}
         */
        function (value, range, config) {
            /** @type {?} */
            var style;
            if (this.vertical) {
                style = {
                    marginBottom: '-50%',
                    bottom: ((value - this.min) / range) * 100 + "%"
                };
            }
            else {
                style = {
                    transform: "translate3d(-50%, 0, 0)",
                    left: ((value - this.min) / range) * 100 + "%"
                };
            }
            if (isConfigObject(config) && config.style) {
                style = __assign(__assign({}, style), config.style);
            }
            return style;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderMarksComponent.prototype.togglePointActive = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.marks && this.lowerBound !== null && this.upperBound !== null) {
                this.marks.forEach((/**
                 * @param {?} mark
                 * @return {?}
                 */
                function (mark) {
                    /** @type {?} */
                    var value = mark.value;
                    /** @type {?} */
                    var isActive = (!_this.included && value === _this.upperBound) || (_this.included && value <= (/** @type {?} */ (_this.upperBound)) && value >= (/** @type {?} */ (_this.lowerBound)));
                    mark.active = isActive;
                }));
            }
        };
        DwSliderMarksComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        preserveWhitespaces: false,
                        selector: 'dw-slider-marks',
                        exportAs: 'dwSliderMarks',
                        template: "\n    <div class=\"ant-slider-mark\">\n      <span\n        class=\"ant-slider-mark-text\"\n        *ngFor=\"let attr of marks; trackBy: trackById\"\n        [class.ant-slider-mark-active]=\"attr.active\"\n        [ngStyle]=\"attr.style!\"\n        [innerHTML]=\"attr.label\"\n      >\n      </span>\n    </div>\n  "
                    }] }
        ];
        DwSliderMarksComponent.propDecorators = {
            lowerBound: [{ type: core.Input }],
            upperBound: [{ type: core.Input }],
            marksArray: [{ type: core.Input }],
            min: [{ type: core.Input }],
            max: [{ type: core.Input }],
            vertical: [{ type: core.Input }],
            included: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderMarksComponent.prototype, "vertical", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderMarksComponent.prototype, "included", void 0);
        return DwSliderMarksComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSliderMarksComponent.ngAcceptInputType_vertical;
        /** @type {?} */
        DwSliderMarksComponent.ngAcceptInputType_included;
        /** @type {?} */
        DwSliderMarksComponent.prototype.lowerBound;
        /** @type {?} */
        DwSliderMarksComponent.prototype.upperBound;
        /** @type {?} */
        DwSliderMarksComponent.prototype.marksArray;
        /** @type {?} */
        DwSliderMarksComponent.prototype.min;
        /** @type {?} */
        DwSliderMarksComponent.prototype.max;
        /** @type {?} */
        DwSliderMarksComponent.prototype.vertical;
        /** @type {?} */
        DwSliderMarksComponent.prototype.included;
        /** @type {?} */
        DwSliderMarksComponent.prototype.marks;
    }
    /**
     * @param {?} config
     * @return {?}
     */
    function isConfigObject(config) {
        return typeof config !== 'string';
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: step.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderStepComponent = /** @class */ (function () {
        function DwSliderStepComponent() {
            this.lowerBound = null;
            this.upperBound = null;
            this.marksArray = [];
            this.vertical = false;
            this.included = false;
            this.steps = [];
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSliderStepComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.marksArray) {
                this.buildSteps();
            }
            if (changes.marksArray || changes.lowerBound || changes.upperBound) {
                this.togglePointActive();
            }
        };
        /**
         * @param {?} _index
         * @param {?} step
         * @return {?}
         */
        DwSliderStepComponent.prototype.trackById = /**
         * @param {?} _index
         * @param {?} step
         * @return {?}
         */
        function (_index, step) {
            return step.value;
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderStepComponent.prototype.buildSteps = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var orient = this.vertical ? 'bottom' : 'left';
            this.steps = this.marksArray.map((/**
             * @param {?} mark
             * @return {?}
             */
            function (mark) {
                var _a;
                var value = mark.value, offset = mark.offset, config = mark.config;
                return {
                    value: value,
                    offset: offset,
                    config: config,
                    active: false,
                    style: (_a = {},
                        _a[orient] = offset + "%",
                        _a)
                };
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwSliderStepComponent.prototype.togglePointActive = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.steps && this.lowerBound !== null && this.upperBound !== null) {
                this.steps.forEach((/**
                 * @param {?} step
                 * @return {?}
                 */
                function (step) {
                    /** @type {?} */
                    var value = step.value;
                    /** @type {?} */
                    var isActive = (!_this.included && value === _this.upperBound) || (_this.included && value <= (/** @type {?} */ (_this.upperBound)) && value >= (/** @type {?} */ (_this.lowerBound)));
                    step.active = isActive;
                }));
            }
        };
        DwSliderStepComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-slider-step',
                        exportAs: 'dwSliderStep',
                        preserveWhitespaces: false,
                        template: "\n    <div class=\"ant-slider-step\">\n      <span\n        class=\"ant-slider-dot\"\n        *ngFor=\"let mark of steps; trackBy: trackById\"\n        [class.ant-slider-dot-active]=\"mark.active\"\n        [ngStyle]=\"mark.style!\"\n      >\n      </span>\n    </div>\n  "
                    }] }
        ];
        DwSliderStepComponent.propDecorators = {
            lowerBound: [{ type: core.Input }],
            upperBound: [{ type: core.Input }],
            marksArray: [{ type: core.Input }],
            vertical: [{ type: core.Input }],
            included: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderStepComponent.prototype, "vertical", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderStepComponent.prototype, "included", void 0);
        return DwSliderStepComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSliderStepComponent.ngAcceptInputType_vertical;
        /** @type {?} */
        DwSliderStepComponent.ngAcceptInputType_included;
        /** @type {?} */
        DwSliderStepComponent.prototype.lowerBound;
        /** @type {?} */
        DwSliderStepComponent.prototype.upperBound;
        /** @type {?} */
        DwSliderStepComponent.prototype.marksArray;
        /** @type {?} */
        DwSliderStepComponent.prototype.vertical;
        /** @type {?} */
        DwSliderStepComponent.prototype.included;
        /** @type {?} */
        DwSliderStepComponent.prototype.steps;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: track.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwSliderTrackStyle() { }
    if (false) {
        /** @type {?|undefined} */
        DwSliderTrackStyle.prototype.bottom;
        /** @type {?|undefined} */
        DwSliderTrackStyle.prototype.height;
        /** @type {?|undefined} */
        DwSliderTrackStyle.prototype.left;
        /** @type {?|undefined} */
        DwSliderTrackStyle.prototype.width;
        /** @type {?|undefined} */
        DwSliderTrackStyle.prototype.visibility;
    }
    var DwSliderTrackComponent = /** @class */ (function () {
        function DwSliderTrackComponent() {
            this.offset = 0;
            this.reverse = false;
            this.length = 0;
            this.vertical = false;
            this.included = false;
            this.style = {};
        }
        /**
         * @return {?}
         */
        DwSliderTrackComponent.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            var _a, _b;
            /** @type {?} */
            var vertical = this.vertical;
            /** @type {?} */
            var reverse = this.reverse;
            /** @type {?} */
            var visibility = this.included ? 'visible' : 'hidden';
            /** @type {?} */
            var offset = this.offset;
            /** @type {?} */
            var length = this.length;
            /** @type {?} */
            var positonStyle = vertical
                ? (_a = {},
                    _a[reverse ? 'top' : 'bottom'] = offset + "%",
                    _a[reverse ? 'bottom' : 'top'] = 'auto',
                    _a.height = length + "%",
                    _a.visibility = visibility,
                    _a) : (_b = {},
                _b[reverse ? 'right' : 'left'] = offset + "%",
                _b[reverse ? 'left' : 'right'] = 'auto',
                _b.width = length + "%",
                _b.visibility = visibility,
                _b);
            this.style = positonStyle;
        };
        DwSliderTrackComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-slider-track',
                        exportAs: 'dwSliderTrack',
                        preserveWhitespaces: false,
                        template: " <div class=\"ant-slider-track\" [ngStyle]=\"style\"></div> "
                    }] }
        ];
        DwSliderTrackComponent.propDecorators = {
            offset: [{ type: core.Input }],
            reverse: [{ type: core.Input }],
            length: [{ type: core.Input }],
            vertical: [{ type: core.Input }],
            included: [{ type: core.Input }]
        };
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Number)
        ], DwSliderTrackComponent.prototype, "offset", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwSliderTrackComponent.prototype, "reverse", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Number)
        ], DwSliderTrackComponent.prototype, "length", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderTrackComponent.prototype, "vertical", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSliderTrackComponent.prototype, "included", void 0);
        return DwSliderTrackComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSliderTrackComponent.ngAcceptInputType_offset;
        /** @type {?} */
        DwSliderTrackComponent.ngAcceptInputType_length;
        /** @type {?} */
        DwSliderTrackComponent.ngAcceptInputType_vertical;
        /** @type {?} */
        DwSliderTrackComponent.ngAcceptInputType_included;
        /** @type {?} */
        DwSliderTrackComponent.ngAcceptInputType_reverse;
        /** @type {?} */
        DwSliderTrackComponent.prototype.offset;
        /** @type {?} */
        DwSliderTrackComponent.prototype.reverse;
        /** @type {?} */
        DwSliderTrackComponent.prototype.length;
        /** @type {?} */
        DwSliderTrackComponent.prototype.vertical;
        /** @type {?} */
        DwSliderTrackComponent.prototype.included;
        /** @type {?} */
        DwSliderTrackComponent.prototype.style;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: slider.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSliderModule = /** @class */ (function () {
        function DwSliderModule() {
        }
        DwSliderModule.decorators = [
            { type: core.NgModule, args: [{
                        exports: [DwSliderComponent, DwSliderTrackComponent, DwSliderHandleComponent, DwSliderStepComponent, DwSliderMarksComponent],
                        declarations: [DwSliderComponent, DwSliderTrackComponent, DwSliderHandleComponent, DwSliderStepComponent, DwSliderMarksComponent],
                        imports: [common.CommonModule, platform.PlatformModule, tooltip.DwToolTipModule]
                    },] }
        ];
        return DwSliderModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: typings.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function DwMarkObj() { }
    if (false) {
        /** @type {?|undefined} */
        DwMarkObj.prototype.style;
        /** @type {?} */
        DwMarkObj.prototype.label;
    }
    var DwMarks = /** @class */ (function () {
        function DwMarks() {
        }
        return DwMarks;
    }());
    /**
     * Processed steps that would be passed to sub components.
     * @record
     */
    function DwExtendedMark() { }
    if (false) {
        /** @type {?} */
        DwExtendedMark.prototype.value;
        /** @type {?} */
        DwExtendedMark.prototype.offset;
        /** @type {?} */
        DwExtendedMark.prototype.config;
    }
    /**
     * Marks that would be rendered.
     * @record
     */
    function DwDisplayedMark() { }
    if (false) {
        /** @type {?} */
        DwDisplayedMark.prototype.active;
        /** @type {?} */
        DwDisplayedMark.prototype.label;
        /** @type {?|undefined} */
        DwDisplayedMark.prototype.style;
    }
    /**
     * Steps that would be rendered.
     * @record
     */
    function DwDisplayedStep() { }
    if (false) {
        /** @type {?} */
        DwDisplayedStep.prototype.active;
        /** @type {?|undefined} */
        DwDisplayedStep.prototype.style;
    }
    /**
     * @record
     */
    function DwSliderHandler() { }
    if (false) {
        /** @type {?} */
        DwSliderHandler.prototype.offset;
        /** @type {?} */
        DwSliderHandler.prototype.value;
        /** @type {?} */
        DwSliderHandler.prototype.active;
    }

    exports.DwMarks = DwMarks;
    exports.DwSliderComponent = DwSliderComponent;
    exports.DwSliderModule = DwSliderModule;
    exports.ɵDwSliderHandleComponent = DwSliderHandleComponent;
    exports.ɵDwSliderMarksComponent = DwSliderMarksComponent;
    exports.ɵDwSliderService = DwSliderService;
    exports.ɵDwSliderStepComponent = DwSliderStepComponent;
    exports.ɵDwSliderTrackComponent = DwSliderTrackComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-slider.umd.js.map
