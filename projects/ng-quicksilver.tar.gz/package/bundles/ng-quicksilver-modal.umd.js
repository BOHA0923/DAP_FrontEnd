(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/overlay'), require('@angular/cdk/portal'), require('@angular/core'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/logger'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/cdk/a11y'), require('@angular/common'), require('@angular/platform-browser/animations'), require('ng-quicksilver/i18n'), require('@angular/animations'), require('@angular/cdk/keycodes'), require('ng-quicksilver/button'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/pipe'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/modal', ['exports', '@angular/cdk/overlay', '@angular/cdk/portal', '@angular/core', 'ng-quicksilver/core/config', 'ng-quicksilver/core/logger', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/cdk/a11y', '@angular/common', '@angular/platform-browser/animations', 'ng-quicksilver/i18n', '@angular/animations', '@angular/cdk/keycodes', 'ng-quicksilver/button', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/pipe', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].modal = {}), global.ng.cdk.overlay, global.ng.cdk.portal, global.ng.core, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.logger, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.cdk.a11y, global.ng.common, global.ng.platformBrowser.animations, global['ng-quicksilver'].i18n, global.ng.animations, global.ng.cdk.keycodes, global['ng-quicksilver'].button, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core.pipe, global['ng-quicksilver'].icon));
}(this, (function (exports, overlay, portal, core, config, logger, util, rxjs, operators, a11y, common, animations, i18n, animations$1, keycodes, button, noAnimation, outlet, pipe, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function StyleObjectLike() { }
    /** @type {?} */
    var noopFun = (/**
     * @return {?}
     */
    function () { return void 0; });
    var ɵ0 = noopFun;
    /**
     * @template T, R
     */
    var   /**
     * @template T, R
     */
    ModalOptions = /** @class */ (function () {
        function ModalOptions() {
            this.dwClosable = true;
            this.dwOkLoading = false;
            this.dwOkDisabled = false;
            this.dwCancelDisabled = false;
            this.dwCancelLoading = false;
            this.dwNoAnimation = false;
            this.dwAutofocus = 'auto';
            this.dwKeyboard = true;
            this.dwZIndex = 1000;
            this.dwWidth = 520;
            this.dwCloseIcon = 'close';
            this.dwOkType = 'primary';
            this.dwModalType = 'default';
            this.dwOnCancel = noopFun;
            this.dwOnOk = noopFun;
            // Confirm
            this.dwIconType = 'question-circle';
        }
        return ModalOptions;
    }());
    if (false) {
        /** @type {?} */
        ModalOptions.prototype.dwClosable;
        /** @type {?} */
        ModalOptions.prototype.dwOkLoading;
        /** @type {?} */
        ModalOptions.prototype.dwOkDisabled;
        /** @type {?} */
        ModalOptions.prototype.dwCancelDisabled;
        /** @type {?} */
        ModalOptions.prototype.dwCancelLoading;
        /** @type {?} */
        ModalOptions.prototype.dwNoAnimation;
        /** @type {?} */
        ModalOptions.prototype.dwAutofocus;
        /** @type {?} */
        ModalOptions.prototype.dwMask;
        /** @type {?} */
        ModalOptions.prototype.dwMaskClosable;
        /** @type {?} */
        ModalOptions.prototype.dwKeyboard;
        /** @type {?} */
        ModalOptions.prototype.dwZIndex;
        /** @type {?} */
        ModalOptions.prototype.dwWidth;
        /** @type {?} */
        ModalOptions.prototype.dwCloseIcon;
        /** @type {?} */
        ModalOptions.prototype.dwOkType;
        /** @type {?} */
        ModalOptions.prototype.dwModalType;
        /** @type {?} */
        ModalOptions.prototype.dwOnCancel;
        /** @type {?} */
        ModalOptions.prototype.dwOnOk;
        /** @type {?} */
        ModalOptions.prototype.dwComponentParams;
        /** @type {?} */
        ModalOptions.prototype.dwMaskStyle;
        /** @type {?} */
        ModalOptions.prototype.dwBodyStyle;
        /** @type {?} */
        ModalOptions.prototype.dwWrapClassName;
        /** @type {?} */
        ModalOptions.prototype.dwClassName;
        /** @type {?} */
        ModalOptions.prototype.dwStyle;
        /** @type {?} */
        ModalOptions.prototype.dwTitle;
        /** @type {?} */
        ModalOptions.prototype.dwFooter;
        /** @type {?} */
        ModalOptions.prototype.dwCancelText;
        /** @type {?} */
        ModalOptions.prototype.dwOkText;
        /** @type {?} */
        ModalOptions.prototype.dwContent;
        /** @type {?} */
        ModalOptions.prototype.dwCloseOnNavigation;
        /** @type {?} */
        ModalOptions.prototype.dwViewContainerRef;
        /**
         * Reset the container element.
         * @deprecated Not supported.
         * \@breaking-change 10.0.0
         * @type {?}
         */
        ModalOptions.prototype.dwGetContainer;
        /** @type {?} */
        ModalOptions.prototype.dwAfterOpen;
        /** @type {?} */
        ModalOptions.prototype.dwAfterClose;
        /** @type {?} */
        ModalOptions.prototype.dwIconType;
    }
    /**
     * @record
     * @template T
     */
    function ModalButtonOptions() { }
    if (false) {
        /** @type {?} */
        ModalButtonOptions.prototype.label;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.type;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.shape;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.ghost;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.size;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.autoLoading;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.show;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.loading;
        /** @type {?|undefined} */
        ModalButtonOptions.prototype.disabled;
        /* Skipping unhandled member: [key: string]: DwSafeAny;*/
        /**
         * @this {?}
         * @param {?=} contentComponentInstance
         * @return {?}
         */
        ModalButtonOptions.prototype.onClick = function (contentComponentInstance) { };
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-config.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /** @type {?} */
    var ZOOM_CLASS_NAME_MAP = {
        enter: 'zoom-enter',
        enterActive: 'zoom-enter-active',
        leave: 'zoom-leave',
        leaveActive: 'zoom-leave-active'
    };
    /** @type {?} */
    var FADE_CLASS_NAME_MAP = {
        enter: 'fade-enter',
        enterActive: 'fade-enter-active',
        leave: 'fade-leave',
        leaveActive: 'fade-leave-active'
    };
    /** @type {?} */
    var MODAL_MASK_CLASS_NAME = 'ant-modal-mask';
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'modal';

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-animations.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var dwModalAnimations = {
        modalContainer: animations$1.trigger('modalContainer', [
            animations$1.state('void, exit', animations$1.style({})),
            animations$1.state('enter', animations$1.style({})),
            animations$1.transition('* => enter', animations$1.animate('.24s', animations$1.style({}))),
            animations$1.transition('* => void, * => exit', animations$1.animate('.2s', animations$1.style({})))
        ])
    };

    /**
     * @fileoverview added by tsickle
     * Generated from: utils.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @param {?} config
     * @param {?} defaultOptions
     * @return {?}
     */
    function applyConfigDefaults(config, defaultOptions) {
        return __assign(__assign({}, defaultOptions), config);
    }
    /**
     * @template T
     * @param {?} userValue
     * @param {?} configValue
     * @param {?} defaultValue
     * @return {?}
     */
    function getValueWithConfig(userValue, configValue, defaultValue) {
        return typeof userValue === 'undefined' ? (typeof configValue === 'undefined' ? defaultValue : configValue) : userValue;
    }
    /**
     * Assign the params into the content component instance.
     * @deprecated Should use dependency injection to get the params for user
     * \@breaking-change 10.0.0
     * @template T
     * @param {?} instance
     * @param {?} params
     * @return {?}
     */
    function setContentInstanceParams(instance, params) {
        Object.assign(instance, params);
    }
    /**
     * @param {?} component
     * @return {?}
     */
    function getConfigFromComponent(component) {
        var dwMask = component.dwMask, dwMaskClosable = component.dwMaskClosable, dwClosable = component.dwClosable, dwOkLoading = component.dwOkLoading, dwOkDisabled = component.dwOkDisabled, dwCancelDisabled = component.dwCancelDisabled, dwCancelLoading = component.dwCancelLoading, dwKeyboard = component.dwKeyboard, dwNoAnimation = component.dwNoAnimation, dwContent = component.dwContent, dwComponentParams = component.dwComponentParams, dwFooter = component.dwFooter, dwGetContainer = component.dwGetContainer, dwZIndex = component.dwZIndex, dwWidth = component.dwWidth, dwWrapClassName = component.dwWrapClassName, dwClassName = component.dwClassName, dwStyle = component.dwStyle, dwTitle = component.dwTitle, dwCloseIcon = component.dwCloseIcon, dwMaskStyle = component.dwMaskStyle, dwBodyStyle = component.dwBodyStyle, dwOkText = component.dwOkText, dwCancelText = component.dwCancelText, dwOkType = component.dwOkType, dwIconType = component.dwIconType, dwModalType = component.dwModalType, dwOnOk = component.dwOnOk, dwOnCancel = component.dwOnCancel, dwAfterOpen = component.dwAfterOpen, dwAfterClose = component.dwAfterClose, dwCloseOnNavigation = component.dwCloseOnNavigation, dwAutofocus = component.dwAutofocus;
        return {
            dwMask: dwMask,
            dwMaskClosable: dwMaskClosable,
            dwClosable: dwClosable,
            dwOkLoading: dwOkLoading,
            dwOkDisabled: dwOkDisabled,
            dwCancelDisabled: dwCancelDisabled,
            dwCancelLoading: dwCancelLoading,
            dwKeyboard: dwKeyboard,
            dwNoAnimation: dwNoAnimation,
            dwContent: dwContent,
            dwComponentParams: dwComponentParams,
            dwFooter: dwFooter,
            dwGetContainer: dwGetContainer,
            dwZIndex: dwZIndex,
            dwWidth: dwWidth,
            dwWrapClassName: dwWrapClassName,
            dwClassName: dwClassName,
            dwStyle: dwStyle,
            dwTitle: dwTitle,
            dwCloseIcon: dwCloseIcon,
            dwMaskStyle: dwMaskStyle,
            dwBodyStyle: dwBodyStyle,
            dwOkText: dwOkText,
            dwCancelText: dwCancelText,
            dwOkType: dwOkType,
            dwIconType: dwIconType,
            dwModalType: dwModalType,
            dwOnOk: dwOnOk,
            dwOnCancel: dwOnCancel,
            dwAfterOpen: dwAfterOpen,
            dwAfterClose: dwAfterClose,
            dwCloseOnNavigation: dwCloseOnNavigation,
            dwAutofocus: dwAutofocus
        };
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-container.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @return {?}
     */
    function throwDwModalContentAlreadyAttachedError() {
        throw Error('Attempting to attach modal content after content is already attached');
    }
    var BaseModalContainer = /** @class */ (function (_super) {
        __extends(BaseModalContainer, _super);
        function BaseModalContainer(elementRef, focusTrapFactory, cdr, render, overlayRef, dwConfigService, config, document, animationType) {
            var _this = _super.call(this) || this;
            _this.elementRef = elementRef;
            _this.focusTrapFactory = focusTrapFactory;
            _this.cdr = cdr;
            _this.render = render;
            _this.overlayRef = overlayRef;
            _this.dwConfigService = dwConfigService;
            _this.config = config;
            _this.animationType = animationType;
            _this.animationStateChanged = new core.EventEmitter();
            _this.containerClick = new core.EventEmitter();
            _this.cancelTriggered = new core.EventEmitter();
            _this.okTriggered = new core.EventEmitter();
            _this.state = 'enter';
            _this.isStringContent = false;
            _this.elementFocusedBeforeModalWasOpened = null;
            _this.mouseDown = false;
            _this.oldMaskStyle = null;
            _this.destroy$ = new rxjs.Subject();
            _this.document = document;
            _this.isStringContent = typeof config.dwContent === 'string';
            _this.setContainer();
            _this.dwConfigService
                .getConfigChangeEventForComponent(DW_CONFIG_COMPONENT_NAME)
                .pipe(operators.takeUntil(_this.destroy$))
                .subscribe((/**
             * @return {?}
             */
            function () {
                _this.updateMaskClassname();
            }));
            return _this;
        }
        Object.defineProperty(BaseModalContainer.prototype, "showMask", {
            get: /**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var defaultConfig = this.dwConfigService.getConfigForComponent(DW_CONFIG_COMPONENT_NAME) || {};
                return !!getValueWithConfig(this.config.dwMask, defaultConfig.dwMask, true);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseModalContainer.prototype, "maskClosable", {
            get: /**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var defaultConfig = this.dwConfigService.getConfigForComponent(DW_CONFIG_COMPONENT_NAME) || {};
                return !!getValueWithConfig(this.config.dwMaskClosable, defaultConfig.dwMaskClosable, true);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} e
         * @return {?}
         */
        BaseModalContainer.prototype.onContainerClick = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            if (e.target === e.currentTarget && !this.mouseDown && this.showMask && this.maskClosable) {
                this.containerClick.emit();
            }
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.onMousedown = /**
         * @return {?}
         */
        function () {
            this.mouseDown = true;
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.onMouseup = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.mouseDown) {
                setTimeout((/**
                 * @return {?}
                 */
                function () {
                    _this.mouseDown = false;
                }));
            }
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.onCloseClick = /**
         * @return {?}
         */
        function () {
            this.cancelTriggered.emit();
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.onOkClick = /**
         * @return {?}
         */
        function () {
            this.okTriggered.emit();
        };
        /**
         * @template T
         * @param {?} portal
         * @return {?}
         */
        BaseModalContainer.prototype.attachComponentPortal = /**
         * @template T
         * @param {?} portal
         * @return {?}
         */
        function (portal) {
            if (this.portalOutlet.hasAttached()) {
                throwDwModalContentAlreadyAttachedError();
            }
            this.savePreviouslyFocusedElement();
            this.setModalTransformOrigin();
            return this.portalOutlet.attachComponentPortal(portal);
        };
        /**
         * @template C
         * @param {?} portal
         * @return {?}
         */
        BaseModalContainer.prototype.attachTemplatePortal = /**
         * @template C
         * @param {?} portal
         * @return {?}
         */
        function (portal) {
            if (this.portalOutlet.hasAttached()) {
                throwDwModalContentAlreadyAttachedError();
            }
            this.savePreviouslyFocusedElement();
            return this.portalOutlet.attachTemplatePortal(portal);
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.attachStringContent = /**
         * @return {?}
         */
        function () {
            this.savePreviouslyFocusedElement();
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.getNativeElement = /**
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement;
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.animationDisabled = /**
         * @private
         * @return {?}
         */
        function () {
            return this.config.dwNoAnimation || this.animationType === 'NoopAnimations';
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.setModalTransformOrigin = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var modalElement = this.modalElementRef.nativeElement;
            if ((/** @type {?} */ (this.elementFocusedBeforeModalWasOpened))) {
                /** @type {?} */
                var previouslyDOMRect = (/** @type {?} */ (this.elementFocusedBeforeModalWasOpened)).getBoundingClientRect();
                /** @type {?} */
                var lastPosition = util.getElementOffset((/** @type {?} */ (this.elementFocusedBeforeModalWasOpened)));
                /** @type {?} */
                var x = lastPosition.left + previouslyDOMRect.width / 2;
                /** @type {?} */
                var y = lastPosition.top + previouslyDOMRect.height / 2;
                /** @type {?} */
                var transformOrigin = x - modalElement.offsetLeft + "px " + (y - modalElement.offsetTop) + "px 0px";
                this.render.setStyle(modalElement, 'transform-origin', transformOrigin);
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.savePreviouslyFocusedElement = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.focusTrap) {
                this.focusTrap = this.focusTrapFactory.create(this.elementRef.nativeElement);
            }
            if (this.document) {
                this.elementFocusedBeforeModalWasOpened = (/** @type {?} */ (this.document.activeElement));
                if (this.elementRef.nativeElement.focus) {
                    Promise.resolve().then((/**
                     * @return {?}
                     */
                    function () { return _this.elementRef.nativeElement.focus(); }));
                }
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.trapFocus = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var element = this.elementRef.nativeElement;
            if (this.config.dwAutofocus) {
                this.focusTrap.focusInitialElementWhenReady().then();
            }
            else {
                /** @type {?} */
                var activeElement = this.document.activeElement;
                if (activeElement !== element && !element.contains(activeElement)) {
                    element.focus();
                }
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.restoreFocus = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var toFocus = (/** @type {?} */ (this.elementFocusedBeforeModalWasOpened));
            // We need the extra check, because IE can set the `activeElement` to null in some cases.
            if (toFocus && typeof toFocus.focus === 'function') {
                /** @type {?} */
                var activeElement = (/** @type {?} */ (this.document.activeElement));
                /** @type {?} */
                var element = this.elementRef.nativeElement;
                if (!activeElement || activeElement === this.document.body || activeElement === element || element.contains(activeElement)) {
                    toFocus.focus();
                }
            }
            if (this.focusTrap) {
                this.focusTrap.destroy();
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.setEnterAnimationClass = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.animationDisabled()) {
                return;
            }
            // Make sure to set the `TransformOrigin` style before set the modelElement's class names
            this.setModalTransformOrigin();
            /** @type {?} */
            var modalElement = this.modalElementRef.nativeElement;
            /** @type {?} */
            var backdropElement = this.overlayRef.backdropElement;
            modalElement.classList.add(ZOOM_CLASS_NAME_MAP.enter);
            modalElement.classList.add(ZOOM_CLASS_NAME_MAP.enterActive);
            if (backdropElement) {
                backdropElement.classList.add(FADE_CLASS_NAME_MAP.enter);
                backdropElement.classList.add(FADE_CLASS_NAME_MAP.enterActive);
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.setExitAnimationClass = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var modalElement = this.modalElementRef.nativeElement;
            modalElement.classList.add(ZOOM_CLASS_NAME_MAP.leave);
            modalElement.classList.add(ZOOM_CLASS_NAME_MAP.leaveActive);
            this.setMaskExitAnimationClass();
        };
        /**
         * @private
         * @param {?=} force
         * @return {?}
         */
        BaseModalContainer.prototype.setMaskExitAnimationClass = /**
         * @private
         * @param {?=} force
         * @return {?}
         */
        function (force) {
            if (force === void 0) { force = false; }
            /** @type {?} */
            var backdropElement = this.overlayRef.backdropElement;
            if (backdropElement) {
                if (this.animationDisabled() || force) {
                    // https://github.com/angular/components/issues/18645
                    backdropElement.classList.remove(MODAL_MASK_CLASS_NAME);
                    return;
                }
                backdropElement.classList.add(FADE_CLASS_NAME_MAP.leave);
                backdropElement.classList.add(FADE_CLASS_NAME_MAP.leaveActive);
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.cleanAnimationClass = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.animationDisabled()) {
                return;
            }
            /** @type {?} */
            var backdropElement = this.overlayRef.backdropElement;
            /** @type {?} */
            var modalElement = this.modalElementRef.nativeElement;
            if (backdropElement) {
                backdropElement.classList.remove(FADE_CLASS_NAME_MAP.enter);
                backdropElement.classList.remove(FADE_CLASS_NAME_MAP.enterActive);
            }
            modalElement.classList.remove(ZOOM_CLASS_NAME_MAP.enter);
            modalElement.classList.remove(ZOOM_CLASS_NAME_MAP.enterActive);
            modalElement.classList.remove(ZOOM_CLASS_NAME_MAP.leave);
            modalElement.classList.remove(ZOOM_CLASS_NAME_MAP.leaveActive);
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.bindBackdropStyle = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var backdropElement = this.overlayRef.backdropElement;
            if (backdropElement) {
                if (this.oldMaskStyle) {
                    /** @type {?} */
                    var styles = (/** @type {?} */ (this.oldMaskStyle));
                    Object.keys(styles).forEach((/**
                     * @param {?} key
                     * @return {?}
                     */
                    function (key) {
                        _this.render.removeStyle(backdropElement, key);
                    }));
                    this.oldMaskStyle = null;
                }
                if (typeof this.config.dwMaskStyle === 'object' && Object.keys(this.config.dwMaskStyle).length) {
                    /** @type {?} */
                    var styles_1 = __assign({}, this.config.dwMaskStyle);
                    Object.keys(styles_1).forEach((/**
                     * @param {?} key
                     * @return {?}
                     */
                    function (key) {
                        _this.render.setStyle(backdropElement, key, styles_1[key]);
                    }));
                    this.oldMaskStyle = styles_1;
                }
            }
        };
        /**
         * Set the container element.
         * @deprecated Not supported.
         * @breaking-change 10.0.0
         */
        /**
         * Set the container element.
         * @deprecated Not supported.
         * \@breaking-change 10.0.0
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.setContainer = /**
         * Set the container element.
         * @deprecated Not supported.
         * \@breaking-change 10.0.0
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var container = this.getContainer();
            if (container) {
                this.render.appendChild(container, this.elementRef.nativeElement);
            }
        };
        /**
         * Reset the container element.
         * @deprecated Not supported.
         * @breaking-change 10.0.0
         */
        /**
         * Reset the container element.
         * @deprecated Not supported.
         * \@breaking-change 10.0.0
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.resetContainer = /**
         * Reset the container element.
         * @deprecated Not supported.
         * \@breaking-change 10.0.0
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var container = this.getContainer();
            if (container) {
                this.render.appendChild(this.overlayRef.overlayElement, this.elementRef.nativeElement);
            }
        };
        /**
         * @private
         * @return {?}
         */
        BaseModalContainer.prototype.getContainer = /**
         * @private
         * @return {?}
         */
        function () {
            var dwGetContainer = this.config.dwGetContainer;
            /** @type {?} */
            var container = typeof dwGetContainer === 'function' ? dwGetContainer() : dwGetContainer;
            return container instanceof HTMLElement ? container : null;
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.updateMaskClassname = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var backdropElement = this.overlayRef.backdropElement;
            if (backdropElement) {
                if (this.showMask) {
                    backdropElement.classList.add(MODAL_MASK_CLASS_NAME);
                }
                else {
                    backdropElement.classList.remove(MODAL_MASK_CLASS_NAME);
                }
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        BaseModalContainer.prototype.onAnimationDone = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            if (event.toState === 'enter') {
                this.setContainer();
                this.trapFocus();
            }
            else if (event.toState === 'exit') {
                this.restoreFocus();
            }
            this.cleanAnimationClass();
            this.animationStateChanged.emit(event);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        BaseModalContainer.prototype.onAnimationStart = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            if (event.toState === 'enter') {
                this.setEnterAnimationClass();
                this.bindBackdropStyle();
            }
            else if (event.toState === 'exit') {
                this.resetContainer();
                this.setExitAnimationClass();
            }
            this.animationStateChanged.emit(event);
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.startExitAnimation = /**
         * @return {?}
         */
        function () {
            this.state = 'exit';
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        BaseModalContainer.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.setMaskExitAnimationClass(true);
            this.destroy$.next();
            this.destroy$.complete();
        };
        return BaseModalContainer;
    }(portal.BasePortalOutlet));
    if (false) {
        /** @type {?} */
        BaseModalContainer.prototype.portalOutlet;
        /** @type {?} */
        BaseModalContainer.prototype.modalElementRef;
        /** @type {?} */
        BaseModalContainer.prototype.animationStateChanged;
        /** @type {?} */
        BaseModalContainer.prototype.containerClick;
        /** @type {?} */
        BaseModalContainer.prototype.cancelTriggered;
        /** @type {?} */
        BaseModalContainer.prototype.okTriggered;
        /** @type {?} */
        BaseModalContainer.prototype.state;
        /** @type {?} */
        BaseModalContainer.prototype.document;
        /** @type {?} */
        BaseModalContainer.prototype.modalRef;
        /** @type {?} */
        BaseModalContainer.prototype.isStringContent;
        /**
         * @type {?}
         * @private
         */
        BaseModalContainer.prototype.elementFocusedBeforeModalWasOpened;
        /**
         * @type {?}
         * @private
         */
        BaseModalContainer.prototype.focusTrap;
        /**
         * @type {?}
         * @private
         */
        BaseModalContainer.prototype.mouseDown;
        /**
         * @type {?}
         * @private
         */
        BaseModalContainer.prototype.oldMaskStyle;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.destroy$;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.elementRef;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.focusTrapFactory;
        /** @type {?} */
        BaseModalContainer.prototype.cdr;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.render;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.overlayRef;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.dwConfigService;
        /** @type {?} */
        BaseModalContainer.prototype.config;
        /**
         * @type {?}
         * @protected
         */
        BaseModalContainer.prototype.animationType;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-confirm-container.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalConfirmContainerComponent = /** @class */ (function (_super) {
        __extends(DwModalConfirmContainerComponent, _super);
        function DwModalConfirmContainerComponent(i18n, elementRef, focusTrapFactory, cdr, render, overlayRef, dwConfigService, config, document, animationType) {
            var _this = _super.call(this, elementRef, focusTrapFactory, cdr, render, overlayRef, dwConfigService, config, document, animationType) || this;
            _this.i18n = i18n;
            _this.config = config;
            _this.cancelTriggered = new core.EventEmitter();
            _this.okTriggered = new core.EventEmitter();
            _this.i18n.localeChange.pipe(operators.takeUntil(_this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.locale = _this.i18n.getLocaleData('Modal');
            }));
            return _this;
        }
        /**
         * @return {?}
         */
        DwModalConfirmContainerComponent.prototype.onCancel = /**
         * @return {?}
         */
        function () {
            this.cancelTriggered.emit();
        };
        /**
         * @return {?}
         */
        DwModalConfirmContainerComponent.prototype.onOk = /**
         * @return {?}
         */
        function () {
            this.okTriggered.emit();
        };
        DwModalConfirmContainerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-modal-confirm-container',
                        exportAs: 'dwModalConfirmContainer',
                        template: "\n    <div\n      #modalElement\n      role=\"document\"\n      class=\"ant-modal\"\n      (mousedown)=\"onMousedown()\"\n      [ngClass]=\"config.dwClassName!\"\n      [ngStyle]=\"config.dwStyle!\"\n      [style.width]=\"config?.dwWidth! | dwToCssUnit\"\n    >\n      <div class=\"ant-modal-content\">\n        <button *ngIf=\"config.dwClosable\" dw-modal-close (click)=\"onCloseClick()\"></button>\n        <div class=\"ant-modal-body\" [ngStyle]=\"config.dwBodyStyle!\">\n          <div class=\"ant-modal-confirm-body-wrapper\">\n            <div class=\"ant-modal-confirm-body\">\n              <i dw-icon [dwType]=\"config.dwIconType!\"></i>\n              <span class=\"ant-modal-confirm-title\">\n                <ng-container *dwStringTemplateOutlet=\"config.dwTitle\">\n                  <span [innerHTML]=\"config.dwTitle\"></span>\n                </ng-container>\n              </span>\n              <div class=\"ant-modal-confirm-content\">\n                <ng-template cdkPortalOutlet></ng-template>\n                <div *ngIf=\"isStringContent\" [innerHTML]=\"config.dwContent\"></div>\n              </div>\n            </div>\n            <div class=\"ant-modal-confirm-btns\">\n              <button\n                *ngIf=\"config.dwCancelText !== null\"\n                [attr.cdkFocusInitial]=\"config.dwAutofocus === 'cancel' || null\"\n                dw-button\n                (click)=\"onCancel()\"\n                [dwLoading]=\"!!config.dwCancelLoading\"\n                [disabled]=\"config.dwCancelDisabled\"\n              >\n                {{ config.dwCancelText || locale.cancelText }}\n              </button>\n              <button\n                *ngIf=\"config.dwOkText !== null\"\n                [attr.cdkFocusInitial]=\"config.dwAutofocus === 'ok' || null\"\n                dw-button\n                [dwType]=\"config.dwOkType!\"\n                (click)=\"onOk()\"\n                [dwLoading]=\"!!config.dwOkLoading\"\n                [disabled]=\"config.dwOkDisabled\"\n              >\n                {{ config.dwOkText || locale.okText }}\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  ",
                        animations: [dwModalAnimations.modalContainer],
                        // Using OnPush for modal caused footer can not to detect changes. we can fix it when 8.x.
                        changeDetection: core.ChangeDetectionStrategy.Default,
                        host: {
                            tabindex: '-1',
                            role: 'dialog',
                            '[class]': 'config.dwWrapClassName ? "ant-modal-wrap " + config.dwWrapClassName : "ant-modal-wrap"',
                            '[style.zIndex]': 'config.dwZIndex',
                            '[@.disabled]': 'config.dwNoAnimation',
                            '[@modalContainer]': 'state',
                            '(@modalContainer.start)': 'onAnimationStart($event)',
                            '(@modalContainer.done)': 'onAnimationDone($event)',
                            '(click)': 'onContainerClick($event)',
                            '(mouseup)': 'onMouseup()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwModalConfirmContainerComponent.ctorParameters = function () { return [
            { type: i18n.DwI18nService },
            { type: core.ElementRef },
            { type: a11y.ConfigurableFocusTrapFactory },
            { type: core.ChangeDetectorRef },
            { type: core.Renderer2 },
            { type: overlay.OverlayRef },
            { type: config.DwConfigService },
            { type: ModalOptions },
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [common.DOCUMENT,] }] },
            { type: String, decorators: [{ type: core.Optional }, { type: core.Inject, args: [animations.ANIMATION_MODULE_TYPE,] }] }
        ]; };
        DwModalConfirmContainerComponent.propDecorators = {
            portalOutlet: [{ type: core.ViewChild, args: [portal.CdkPortalOutlet, { static: true },] }],
            modalElementRef: [{ type: core.ViewChild, args: ['modalElement', { static: true },] }],
            cancelTriggered: [{ type: core.Output }],
            okTriggered: [{ type: core.Output }]
        };
        return DwModalConfirmContainerComponent;
    }(BaseModalContainer));
    if (false) {
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.portalOutlet;
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.modalElementRef;
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.cancelTriggered;
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.okTriggered;
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.locale;
        /**
         * @type {?}
         * @private
         */
        DwModalConfirmContainerComponent.prototype.i18n;
        /** @type {?} */
        DwModalConfirmContainerComponent.prototype.config;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-container.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalContainerComponent = /** @class */ (function (_super) {
        __extends(DwModalContainerComponent, _super);
        function DwModalContainerComponent(elementRef, focusTrapFactory, cdr, render, overlayRef, dwConfigService, config, document, animationType) {
            var _this = _super.call(this, elementRef, focusTrapFactory, cdr, render, overlayRef, dwConfigService, config, document, animationType) || this;
            _this.config = config;
            return _this;
        }
        DwModalContainerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-modal-container',
                        exportAs: 'dwModalContainer',
                        template: "\n    <div\n      #modalElement\n      role=\"document\"\n      class=\"ant-modal\"\n      (mousedown)=\"onMousedown()\"\n      [ngClass]=\"config.dwClassName!\"\n      [ngStyle]=\"config.dwStyle!\"\n      [style.width]=\"config?.dwWidth! | dwToCssUnit\"\n    >\n      <div class=\"ant-modal-content\">\n        <button *ngIf=\"config.dwClosable\" dw-modal-close (click)=\"onCloseClick()\"></button>\n        <div *ngIf=\"config.dwTitle\" dw-modal-title></div>\n        <div class=\"ant-modal-body\" [ngStyle]=\"config.dwBodyStyle!\">\n          <ng-template cdkPortalOutlet></ng-template>\n          <div *ngIf=\"isStringContent\" [innerHTML]=\"config.dwContent\"></div>\n        </div>\n        <div\n          *ngIf=\"config.dwFooter !== null\"\n          dw-modal-footer\n          [modalRef]=\"modalRef\"\n          (cancelTriggered)=\"onCloseClick()\"\n          (okTriggered)=\"onOkClick()\"\n        ></div>\n      </div>\n    </div>\n  ",
                        animations: [dwModalAnimations.modalContainer],
                        // Using OnPush for modal caused footer can not to detect changes. we can fix it when 8.x.
                        changeDetection: core.ChangeDetectionStrategy.Default,
                        host: {
                            tabindex: '-1',
                            role: 'dialog',
                            '[class]': 'config.dwWrapClassName ? "ant-modal-wrap " + config.dwWrapClassName : "ant-modal-wrap"',
                            '[style.zIndex]': 'config.dwZIndex',
                            '[@.disabled]': 'config.dwNoAnimation',
                            '[@modalContainer]': 'state',
                            '(@modalContainer.start)': 'onAnimationStart($event)',
                            '(@modalContainer.done)': 'onAnimationDone($event)',
                            '(click)': 'onContainerClick($event)',
                            '(mouseup)': 'onMouseup()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwModalContainerComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: a11y.ConfigurableFocusTrapFactory },
            { type: core.ChangeDetectorRef },
            { type: core.Renderer2 },
            { type: overlay.OverlayRef },
            { type: config.DwConfigService },
            { type: ModalOptions },
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [common.DOCUMENT,] }] },
            { type: String, decorators: [{ type: core.Optional }, { type: core.Inject, args: [animations.ANIMATION_MODULE_TYPE,] }] }
        ]; };
        DwModalContainerComponent.propDecorators = {
            portalOutlet: [{ type: core.ViewChild, args: [portal.CdkPortalOutlet, { static: true },] }],
            modalElementRef: [{ type: core.ViewChild, args: ['modalElement', { static: true },] }]
        };
        return DwModalContainerComponent;
    }(BaseModalContainer));
    if (false) {
        /** @type {?} */
        DwModalContainerComponent.prototype.portalOutlet;
        /** @type {?} */
        DwModalContainerComponent.prototype.modalElementRef;
        /** @type {?} */
        DwModalContainerComponent.prototype.config;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-ref.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @enum {number} */
    var DwModalState = {
        OPEN: 0,
        CLOSING: 1,
        CLOSED: 2,
    };
    /** @enum {string} */
    var DwTriggerAction = {
        CANCEL: "cancel",
        OK: "ok",
    };
    /**
     * @template T, R
     */
    var   /**
     * @template T, R
     */
    DwModalRef = /** @class */ (function () {
        function DwModalRef(overlayRef, config, containerInstance) {
            var _this = this;
            this.overlayRef = overlayRef;
            this.config = config;
            this.containerInstance = containerInstance;
            this.componentInstance = null;
            this.state = 0 /* OPEN */;
            this.afterClose = new rxjs.Subject();
            this.afterOpen = new rxjs.Subject();
            containerInstance.animationStateChanged
                .pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return event.phaseName === 'done' && event.toState === 'enter'; })), operators.take(1))
                .subscribe((/**
             * @return {?}
             */
            function () {
                _this.afterOpen.next();
                _this.afterOpen.complete();
                if (config.dwAfterOpen instanceof core.EventEmitter) {
                    config.dwAfterOpen.emit();
                }
            }));
            containerInstance.animationStateChanged
                .pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return event.phaseName === 'done' && event.toState === 'exit'; })), operators.take(1))
                .subscribe((/**
             * @return {?}
             */
            function () {
                clearTimeout(_this.closeTimeout);
                _this._finishDialogClose();
            }));
            containerInstance.containerClick.pipe(operators.take(1)).subscribe((/**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var cancelable = !_this.config.dwCancelLoading && !_this.config.dwOkLoading;
                if (cancelable) {
                    _this.trigger("cancel" /* CANCEL */);
                }
            }));
            overlayRef
                .keydownEvents()
                .pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                return (((/** @type {?} */ (_this.config.dwKeyboard))) &&
                    !_this.config.dwCancelLoading &&
                    !_this.config.dwOkLoading &&
                    event.keyCode === keycodes.ESCAPE &&
                    !keycodes.hasModifierKey(event));
            })))
                .subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                event.preventDefault();
                _this.trigger("cancel" /* CANCEL */);
            }));
            containerInstance.cancelTriggered.subscribe((/**
             * @return {?}
             */
            function () { return _this.trigger("cancel" /* CANCEL */); }));
            containerInstance.okTriggered.subscribe((/**
             * @return {?}
             */
            function () { return _this.trigger("ok" /* OK */); }));
            overlayRef.detachments().subscribe((/**
             * @return {?}
             */
            function () {
                _this.afterClose.next(_this.result);
                _this.afterClose.complete();
                if (config.dwAfterClose instanceof core.EventEmitter) {
                    config.dwAfterClose.emit(_this.result);
                }
                _this.componentInstance = null;
                _this.overlayRef.dispose();
            }));
        }
        /**
         * @return {?}
         */
        DwModalRef.prototype.getContentComponent = /**
         * @return {?}
         */
        function () {
            return (/** @type {?} */ (this.componentInstance));
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.getElement = /**
         * @return {?}
         */
        function () {
            return this.containerInstance.getNativeElement();
        };
        /**
         * @param {?=} result
         * @return {?}
         */
        DwModalRef.prototype.destroy = /**
         * @param {?=} result
         * @return {?}
         */
        function (result) {
            this.close(result);
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.triggerOk = /**
         * @return {?}
         */
        function () {
            this.trigger("ok" /* OK */);
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.triggerCancel = /**
         * @return {?}
         */
        function () {
            this.trigger("cancel" /* CANCEL */);
        };
        /**
         * Open the modal.
         * @deprecated Opened when create, this method is useless.
         * @breaking-change 10.0.0
         */
        /**
         * Open the modal.
         * @deprecated Opened when create, this method is useless.
         * \@breaking-change 10.0.0
         * @return {?}
         */
        DwModalRef.prototype.open = /**
         * Open the modal.
         * @deprecated Opened when create, this method is useless.
         * \@breaking-change 10.0.0
         * @return {?}
         */
        function () {
            // noop
        };
        /**
         * @param {?=} result
         * @return {?}
         */
        DwModalRef.prototype.close = /**
         * @param {?=} result
         * @return {?}
         */
        function (result) {
            var _this = this;
            this.result = result;
            this.containerInstance.animationStateChanged
                .pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return event.phaseName === 'start'; })), operators.take(1))
                .subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                _this.overlayRef.detachBackdrop();
                _this.closeTimeout = setTimeout((/**
                 * @return {?}
                 */
                function () {
                    _this._finishDialogClose();
                }), event.totalTime + 100);
            }));
            this.containerInstance.startExitAnimation();
            this.state = 1 /* CLOSING */;
        };
        /**
         * @param {?} config
         * @return {?}
         */
        DwModalRef.prototype.updateConfig = /**
         * @param {?} config
         * @return {?}
         */
        function (config) {
            Object.assign(this.config, config);
            this.containerInstance.bindBackdropStyle();
            this.containerInstance.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.getState = /**
         * @return {?}
         */
        function () {
            return this.state;
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.getConfig = /**
         * @return {?}
         */
        function () {
            return this.config;
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype.getBackdropElement = /**
         * @return {?}
         */
        function () {
            return this.overlayRef.backdropElement;
        };
        /**
         * @private
         * @param {?} action
         * @return {?}
         */
        DwModalRef.prototype.trigger = /**
         * @private
         * @param {?} action
         * @return {?}
         */
        function (action) {
            var _this = this;
            /** @type {?} */
            var trigger = { ok: this.config.dwOnOk, cancel: this.config.dwOnCancel }[action];
            /** @type {?} */
            var loadingKey = (/** @type {?} */ ({ ok: 'dwOkLoading', cancel: 'dwCancelLoading' }[action]));
            /** @type {?} */
            var loading = this.config[loadingKey];
            if (loading) {
                return;
            }
            if (trigger instanceof core.EventEmitter) {
                trigger.emit(this.getContentComponent());
            }
            else if (typeof trigger === 'function') {
                /** @type {?} */
                var result = trigger(this.getContentComponent());
                /** @type {?} */
                var caseClose = (/**
                 * @param {?} doClose
                 * @return {?}
                 */
                function (doClose) { return doClose !== false && _this.close((/** @type {?} */ (doClose))); });
                if (util.isPromise(result)) {
                    this.config[loadingKey] = true;
                    /** @type {?} */
                    var handleThen = (/**
                     * @param {?} doClose
                     * @return {?}
                     */
                    function (doClose) {
                        _this.config[loadingKey] = false;
                        _this.closeWhitResult(doClose);
                    });
                    result.then(handleThen).catch(handleThen);
                }
                else {
                    caseClose(result);
                }
            }
        };
        /**
         * @private
         * @param {?} result
         * @return {?}
         */
        DwModalRef.prototype.closeWhitResult = /**
         * @private
         * @param {?} result
         * @return {?}
         */
        function (result) {
            if (result !== false) {
                this.close(result);
            }
        };
        /**
         * @return {?}
         */
        DwModalRef.prototype._finishDialogClose = /**
         * @return {?}
         */
        function () {
            this.state = 2 /* CLOSED */;
            this.overlayRef.dispose();
        };
        return DwModalRef;
    }());
    if (false) {
        /** @type {?} */
        DwModalRef.prototype.componentInstance;
        /** @type {?} */
        DwModalRef.prototype.result;
        /** @type {?} */
        DwModalRef.prototype.state;
        /** @type {?} */
        DwModalRef.prototype.afterClose;
        /** @type {?} */
        DwModalRef.prototype.afterOpen;
        /**
         * @type {?}
         * @private
         */
        DwModalRef.prototype.closeTimeout;
        /**
         * @type {?}
         * @private
         */
        DwModalRef.prototype.overlayRef;
        /**
         * @type {?}
         * @private
         */
        DwModalRef.prototype.config;
        /** @type {?} */
        DwModalRef.prototype.containerInstance;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalService = /** @class */ (function () {
        function DwModalService(overlay, injector, dwConfigService, parentModal) {
            var _this = this;
            this.overlay = overlay;
            this.injector = injector;
            this.dwConfigService = dwConfigService;
            this.parentModal = parentModal;
            this.openModalsAtThisLevel = [];
            this.afterAllClosedAtThisLevel = new rxjs.Subject();
            this.afterAllClose = (/** @type {?} */ (rxjs.defer((/**
             * @return {?}
             */
            function () {
                return _this.openModals.length ? _this._afterAllClosed : _this._afterAllClosed.pipe(operators.startWith(undefined));
            }))));
        }
        Object.defineProperty(DwModalService.prototype, "openModals", {
            get: /**
             * @return {?}
             */
            function () {
                return this.parentModal ? this.parentModal.openModals : this.openModalsAtThisLevel;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwModalService.prototype, "_afterAllClosed", {
            get: /**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var parent = this.parentModal;
                return parent ? parent._afterAllClosed : this.afterAllClosedAtThisLevel;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @template T, R
         * @param {?} config
         * @return {?}
         */
        DwModalService.prototype.create = /**
         * @template T, R
         * @param {?} config
         * @return {?}
         */
        function (config) {
            return this.open((/** @type {?} */ (config.dwContent)), config);
        };
        /**
         * @return {?}
         */
        DwModalService.prototype.closeAll = /**
         * @return {?}
         */
        function () {
            this.closeModals(this.openModals);
        };
        /**
         * @template T
         * @param {?=} options
         * @param {?=} confirmType
         * @return {?}
         */
        DwModalService.prototype.confirm = /**
         * @template T
         * @param {?=} options
         * @param {?=} confirmType
         * @return {?}
         */
        function (options, confirmType) {
            if (options === void 0) { options = {}; }
            if (confirmType === void 0) { confirmType = 'confirm'; }
            if ('dwFooter' in options) {
                logger.warn("The Confirm-Modal doesn't support \"dwFooter\", this property will be ignored.");
            }
            if (!('dwWidth' in options)) {
                options.dwWidth = 416;
            }
            if (!('dwMaskClosable' in options)) {
                options.dwMaskClosable = false;
            }
            options.dwModalType = 'confirm';
            options.dwClassName = "ant-modal-confirm ant-modal-confirm-" + confirmType + " " + (options.dwClassName || '');
            return this.create(options);
        };
        /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        DwModalService.prototype.info = /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        function (options) {
            if (options === void 0) { options = {}; }
            return this.confirmFactory(options, 'info');
        };
        /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        DwModalService.prototype.success = /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        function (options) {
            if (options === void 0) { options = {}; }
            return this.confirmFactory(options, 'success');
        };
        /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        DwModalService.prototype.error = /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        function (options) {
            if (options === void 0) { options = {}; }
            return this.confirmFactory(options, 'error');
        };
        /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        DwModalService.prototype.warning = /**
         * @template T
         * @param {?=} options
         * @return {?}
         */
        function (options) {
            if (options === void 0) { options = {}; }
            return this.confirmFactory(options, 'warning');
        };
        /**
         * @private
         * @template T, R
         * @param {?} componentOrTemplateRef
         * @param {?=} config
         * @return {?}
         */
        DwModalService.prototype.open = /**
         * @private
         * @template T, R
         * @param {?} componentOrTemplateRef
         * @param {?=} config
         * @return {?}
         */
        function (componentOrTemplateRef, config) {
            var _this = this;
            /** @type {?} */
            var configMerged = applyConfigDefaults(config || {}, new ModalOptions());
            /** @type {?} */
            var overlayRef = this.createOverlay(configMerged);
            /** @type {?} */
            var modalContainer = this.attachModalContainer(overlayRef, configMerged);
            /** @type {?} */
            var modalRef = this.attachModalContent(componentOrTemplateRef, modalContainer, overlayRef, configMerged);
            modalContainer.modalRef = modalRef;
            this.openModals.push(modalRef);
            modalRef.afterClose.subscribe((/**
             * @return {?}
             */
            function () { return _this.removeOpenModal(modalRef); }));
            return modalRef;
        };
        /**
         * @private
         * @param {?} modalRef
         * @return {?}
         */
        DwModalService.prototype.removeOpenModal = /**
         * @private
         * @param {?} modalRef
         * @return {?}
         */
        function (modalRef) {
            /** @type {?} */
            var index = this.openModals.indexOf(modalRef);
            if (index > -1) {
                this.openModals.splice(index, 1);
                if (!this.openModals.length) {
                    this._afterAllClosed.next();
                }
            }
        };
        /**
         * @private
         * @param {?} dialogs
         * @return {?}
         */
        DwModalService.prototype.closeModals = /**
         * @private
         * @param {?} dialogs
         * @return {?}
         */
        function (dialogs) {
            /** @type {?} */
            var i = dialogs.length;
            while (i--) {
                dialogs[i].close();
                if (!this.openModals.length) {
                    this._afterAllClosed.next();
                }
            }
        };
        /**
         * @private
         * @param {?} config
         * @return {?}
         */
        DwModalService.prototype.createOverlay = /**
         * @private
         * @param {?} config
         * @return {?}
         */
        function (config) {
            /** @type {?} */
            var globalConfig = this.dwConfigService.getConfigForComponent(DW_CONFIG_COMPONENT_NAME) || {};
            /** @type {?} */
            var overlayConfig = new overlay.OverlayConfig({
                hasBackdrop: true,
                scrollStrategy: this.overlay.scrollStrategies.block(),
                positionStrategy: this.overlay.position().global(),
                disposeOnNavigation: getValueWithConfig(config.dwCloseOnNavigation, globalConfig.dwCloseOnNavigation, true)
            });
            if (getValueWithConfig(config.dwMask, globalConfig.dwMask, true)) {
                overlayConfig.backdropClass = MODAL_MASK_CLASS_NAME;
            }
            return this.overlay.create(overlayConfig);
        };
        /**
         * @private
         * @param {?} overlayRef
         * @param {?} config
         * @return {?}
         */
        DwModalService.prototype.attachModalContainer = /**
         * @private
         * @param {?} overlayRef
         * @param {?} config
         * @return {?}
         */
        function (overlayRef, config) {
            /** @type {?} */
            var userInjector = config && config.dwViewContainerRef && config.dwViewContainerRef.injector;
            /** @type {?} */
            var injector = new portal.PortalInjector(userInjector || this.injector, new WeakMap([
                [overlay.OverlayRef, overlayRef],
                [ModalOptions, config]
            ]));
            /** @type {?} */
            var ContainerComponent = config.dwModalType === 'confirm'
                ? // If the mode is `confirm`, use `DwModalConfirmContainerComponent`
                    DwModalConfirmContainerComponent
                : // If the mode is not `confirm`, use `DwModalContainerComponent`
                    DwModalContainerComponent;
            /** @type {?} */
            var containerPortal = new portal.ComponentPortal(ContainerComponent, config.dwViewContainerRef, injector);
            /** @type {?} */
            var containerRef = overlayRef.attach(containerPortal);
            return containerRef.instance;
        };
        /**
         * @private
         * @template T, R
         * @param {?} componentOrTemplateRef
         * @param {?} modalContainer
         * @param {?} overlayRef
         * @param {?} config
         * @return {?}
         */
        DwModalService.prototype.attachModalContent = /**
         * @private
         * @template T, R
         * @param {?} componentOrTemplateRef
         * @param {?} modalContainer
         * @param {?} overlayRef
         * @param {?} config
         * @return {?}
         */
        function (componentOrTemplateRef, modalContainer, overlayRef, config) {
            /** @type {?} */
            var modalRef = new DwModalRef(overlayRef, config, modalContainer);
            if (componentOrTemplateRef instanceof core.TemplateRef) {
                modalContainer.attachTemplatePortal(new portal.TemplatePortal(componentOrTemplateRef, (/** @type {?} */ (null)), (/** @type {?} */ ({ $implicit: config.dwComponentParams, modalRef: modalRef }))));
            }
            else if (util.isNotNil(componentOrTemplateRef) && typeof componentOrTemplateRef !== 'string') {
                /** @type {?} */
                var injector = this.createInjector(modalRef, config);
                /** @type {?} */
                var contentRef = modalContainer.attachComponentPortal(new portal.ComponentPortal(componentOrTemplateRef, config.dwViewContainerRef, injector));
                setContentInstanceParams(contentRef.instance, config.dwComponentParams);
                modalRef.componentInstance = contentRef.instance;
            }
            else {
                modalContainer.attachStringContent();
            }
            return modalRef;
        };
        /**
         * @private
         * @template T, R
         * @param {?} modalRef
         * @param {?} config
         * @return {?}
         */
        DwModalService.prototype.createInjector = /**
         * @private
         * @template T, R
         * @param {?} modalRef
         * @param {?} config
         * @return {?}
         */
        function (modalRef, config) {
            /** @type {?} */
            var userInjector = config && config.dwViewContainerRef && config.dwViewContainerRef.injector;
            /** @type {?} */
            var injectionTokens = new WeakMap([[DwModalRef, modalRef]]);
            return new portal.PortalInjector(userInjector || this.injector, injectionTokens);
        };
        /**
         * @private
         * @template T
         * @param {?=} options
         * @param {?=} confirmType
         * @return {?}
         */
        DwModalService.prototype.confirmFactory = /**
         * @private
         * @template T
         * @param {?=} options
         * @param {?=} confirmType
         * @return {?}
         */
        function (options, confirmType) {
            if (options === void 0) { options = {}; }
            /** @type {?} */
            var iconMap = {
                info: 'info-circle',
                success: 'check-circle',
                error: 'close-circle',
                warning: 'exclamation-circle'
            };
            if (!('dwIconType' in options)) {
                options.dwIconType = iconMap[confirmType];
            }
            if (!('dwCancelText' in options)) {
                // Remove the Cancel button if the user not specify a Cancel button
                options.dwCancelText = null;
            }
            return this.confirm(options, confirmType);
        };
        /**
         * @return {?}
         */
        DwModalService.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.closeModals(this.openModalsAtThisLevel);
            this.afterAllClosedAtThisLevel.complete();
        };
        DwModalService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwModalService.ctorParameters = function () { return [
            { type: overlay.Overlay },
            { type: core.Injector },
            { type: config.DwConfigService },
            { type: DwModalService, decorators: [{ type: core.Optional }, { type: core.SkipSelf }] }
        ]; };
        return DwModalService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.openModalsAtThisLevel;
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.afterAllClosedAtThisLevel;
        /** @type {?} */
        DwModalService.prototype.afterAllClose;
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.overlay;
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.injector;
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwModalService.prototype.parentModal;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-footer.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalFooterDirective = /** @class */ (function () {
        function DwModalFooterDirective(dwModalRef, templateRef) {
            this.dwModalRef = dwModalRef;
            this.templateRef = templateRef;
            if (this.dwModalRef) {
                this.dwModalRef.updateConfig({
                    dwFooter: this.templateRef
                });
            }
        }
        DwModalFooterDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dwModalFooter]',
                        exportAs: 'dwModalFooter'
                    },] }
        ];
        /** @nocollapse */
        DwModalFooterDirective.ctorParameters = function () { return [
            { type: DwModalRef, decorators: [{ type: core.Optional }] },
            { type: core.TemplateRef }
        ]; };
        return DwModalFooterDirective;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwModalFooterDirective.prototype.dwModalRef;
        /** @type {?} */
        DwModalFooterDirective.prototype.templateRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @template T, R
     */
    var DwModalComponent = /** @class */ (function () {
        function DwModalComponent(cdr, modal, viewContainerRef) {
            this.cdr = cdr;
            this.modal = modal;
            this.viewContainerRef = viewContainerRef;
            this.dwVisible = false;
            this.dwClosable = true;
            this.dwOkLoading = false;
            this.dwOkDisabled = false;
            this.dwCancelDisabled = false;
            this.dwCancelLoading = false;
            this.dwKeyboard = true;
            this.dwNoAnimation = false;
            this.dwZIndex = 1000;
            this.dwWidth = 520;
            this.dwCloseIcon = 'close';
            this.dwOkType = 'primary';
            this.dwIconType = 'question-circle'; // Confirm Modal ONLY
            // Confirm Modal ONLY
            this.dwModalType = 'default';
            this.dwAutofocus = 'auto';
            // TODO(@hsuanxyz) Input will not be supported
            this.dwOnOk = new core.EventEmitter();
            // TODO(@hsuanxyz) Input will not be supported
            this.dwOnCancel = new core.EventEmitter();
            this.dwAfterOpen = new core.EventEmitter();
            this.dwAfterClose = new core.EventEmitter();
            this.dwVisibleChange = new core.EventEmitter();
            this.modalRef = null;
        }
        Object.defineProperty(DwModalComponent.prototype, "modalFooter", {
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (value && value.templateRef) {
                    this.setFooterWithTemplate(value.templateRef);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwModalComponent.prototype, "afterOpen", {
            get: /**
             * @return {?}
             */
            function () {
                // Observable alias for dwAfterOpen
                return this.dwAfterOpen.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwModalComponent.prototype, "afterClose", {
            get: /**
             * @return {?}
             */
            function () {
                // Observable alias for dwAfterClose
                return this.dwAfterClose.asObservable();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwModalComponent.prototype.open = /**
         * @return {?}
         */
        function () {
            if (!this.dwVisible) {
                this.dwVisible = true;
                this.dwVisibleChange.emit(true);
            }
            if (!this.modalRef) {
                /** @type {?} */
                var config = this.getConfig();
                this.modalRef = this.modal.create(config);
            }
        };
        /**
         * @param {?=} result
         * @return {?}
         */
        DwModalComponent.prototype.close = /**
         * @param {?=} result
         * @return {?}
         */
        function (result) {
            if (this.dwVisible) {
                this.dwVisible = false;
                this.dwVisibleChange.emit(false);
            }
            if (this.modalRef) {
                this.modalRef.close(result);
                this.modalRef = null;
            }
        };
        /**
         * @param {?=} result
         * @return {?}
         */
        DwModalComponent.prototype.destroy = /**
         * @param {?=} result
         * @return {?}
         */
        function (result) {
            this.close(result);
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.triggerOk = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.modalRef) === null || _a === void 0 ? void 0 : _a.triggerOk();
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.triggerCancel = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.modalRef) === null || _a === void 0 ? void 0 : _a.triggerCancel();
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.getContentComponent = /**
         * @return {?}
         */
        function () {
            var _a;
            return (_a = this.modalRef) === null || _a === void 0 ? void 0 : _a.getContentComponent();
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.getElement = /**
         * @return {?}
         */
        function () {
            var _a;
            return (_a = this.modalRef) === null || _a === void 0 ? void 0 : _a.getElement();
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.getModalRef = /**
         * @return {?}
         */
        function () {
            return this.modalRef;
        };
        /**
         * @private
         * @param {?} templateRef
         * @return {?}
         */
        DwModalComponent.prototype.setFooterWithTemplate = /**
         * @private
         * @param {?} templateRef
         * @return {?}
         */
        function (templateRef) {
            var _this = this;
            this.dwFooter = templateRef;
            if (this.modalRef) {
                // If modalRef already created, set the footer in next tick
                Promise.resolve().then((/**
                 * @return {?}
                 */
                function () {
                    (/** @type {?} */ (_this.modalRef)).updateConfig({
                        dwFooter: _this.dwFooter
                    });
                }));
            }
            this.cdr.markForCheck();
        };
        /**
         * @private
         * @return {?}
         */
        DwModalComponent.prototype.getConfig = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var componentConfig = getConfigFromComponent(this);
            componentConfig.dwViewContainerRef = this.viewContainerRef;
            if (!this.dwContent) {
                componentConfig.dwContent = this.contentTemplateRef;
            }
            return componentConfig;
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwModalComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwVisible = changes.dwVisible, otherChanges = __rest(changes, ["dwVisible"]);
            if (Object.keys(otherChanges).length && this.modalRef) {
                this.modalRef.updateConfig(getConfigFromComponent(this));
            }
            if (dwVisible) {
                if (this.dwVisible) {
                    this.open();
                }
                else {
                    this.close();
                }
            }
        };
        /**
         * @return {?}
         */
        DwModalComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            var _a;
            (_a = this.modalRef) === null || _a === void 0 ? void 0 : _a._finishDialogClose();
        };
        DwModalComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-modal',
                        exportAs: 'dwModal',
                        template: " <ng-template><ng-content></ng-content></ng-template> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwModalComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: DwModalService },
            { type: core.ViewContainerRef }
        ]; };
        DwModalComponent.propDecorators = {
            dwMask: [{ type: core.Input }],
            dwMaskClosable: [{ type: core.Input }],
            dwCloseOnNavigation: [{ type: core.Input }],
            dwVisible: [{ type: core.Input }],
            dwClosable: [{ type: core.Input }],
            dwOkLoading: [{ type: core.Input }],
            dwOkDisabled: [{ type: core.Input }],
            dwCancelDisabled: [{ type: core.Input }],
            dwCancelLoading: [{ type: core.Input }],
            dwKeyboard: [{ type: core.Input }],
            dwNoAnimation: [{ type: core.Input }],
            dwContent: [{ type: core.Input }],
            dwComponentParams: [{ type: core.Input }],
            dwFooter: [{ type: core.Input }],
            dwGetContainer: [{ type: core.Input }],
            dwZIndex: [{ type: core.Input }],
            dwWidth: [{ type: core.Input }],
            dwWrapClassName: [{ type: core.Input }],
            dwClassName: [{ type: core.Input }],
            dwStyle: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            dwCloseIcon: [{ type: core.Input }],
            dwMaskStyle: [{ type: core.Input }],
            dwBodyStyle: [{ type: core.Input }],
            dwOkText: [{ type: core.Input }],
            dwCancelText: [{ type: core.Input }],
            dwOkType: [{ type: core.Input }],
            dwIconType: [{ type: core.Input }],
            dwModalType: [{ type: core.Input }],
            dwAutofocus: [{ type: core.Input }],
            dwOnOk: [{ type: core.Input }, { type: core.Output }],
            dwOnCancel: [{ type: core.Input }, { type: core.Output }],
            dwAfterOpen: [{ type: core.Output }],
            dwAfterClose: [{ type: core.Output }],
            dwVisibleChange: [{ type: core.Output }],
            contentTemplateRef: [{ type: core.ViewChild, args: [core.TemplateRef, { static: true },] }],
            modalFooter: [{ type: core.ContentChild, args: [DwModalFooterDirective,] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwMask", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwMaskClosable", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwCloseOnNavigation", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwVisible", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwClosable", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwOkLoading", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwOkDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwCancelDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwCancelLoading", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwModalComponent.prototype, "dwKeyboard", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwModalComponent.prototype, "dwNoAnimation", void 0);
        return DwModalComponent;
    }());
    if (false) {
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwMask;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwMaskClosable;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwCloseOnNavigation;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwVisible;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwClosable;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwOkLoading;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwOkDisabled;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwCancelDisabled;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwCancelLoading;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwKeyboard;
        /** @type {?} */
        DwModalComponent.ngAcceptInputType_dwNoAnimation;
        /** @type {?} */
        DwModalComponent.prototype.dwMask;
        /** @type {?} */
        DwModalComponent.prototype.dwMaskClosable;
        /** @type {?} */
        DwModalComponent.prototype.dwCloseOnNavigation;
        /** @type {?} */
        DwModalComponent.prototype.dwVisible;
        /** @type {?} */
        DwModalComponent.prototype.dwClosable;
        /** @type {?} */
        DwModalComponent.prototype.dwOkLoading;
        /** @type {?} */
        DwModalComponent.prototype.dwOkDisabled;
        /** @type {?} */
        DwModalComponent.prototype.dwCancelDisabled;
        /** @type {?} */
        DwModalComponent.prototype.dwCancelLoading;
        /** @type {?} */
        DwModalComponent.prototype.dwKeyboard;
        /** @type {?} */
        DwModalComponent.prototype.dwNoAnimation;
        /** @type {?} */
        DwModalComponent.prototype.dwContent;
        /** @type {?} */
        DwModalComponent.prototype.dwComponentParams;
        /** @type {?} */
        DwModalComponent.prototype.dwFooter;
        /** @type {?} */
        DwModalComponent.prototype.dwGetContainer;
        /** @type {?} */
        DwModalComponent.prototype.dwZIndex;
        /** @type {?} */
        DwModalComponent.prototype.dwWidth;
        /** @type {?} */
        DwModalComponent.prototype.dwWrapClassName;
        /** @type {?} */
        DwModalComponent.prototype.dwClassName;
        /** @type {?} */
        DwModalComponent.prototype.dwStyle;
        /** @type {?} */
        DwModalComponent.prototype.dwTitle;
        /** @type {?} */
        DwModalComponent.prototype.dwCloseIcon;
        /** @type {?} */
        DwModalComponent.prototype.dwMaskStyle;
        /** @type {?} */
        DwModalComponent.prototype.dwBodyStyle;
        /** @type {?} */
        DwModalComponent.prototype.dwOkText;
        /** @type {?} */
        DwModalComponent.prototype.dwCancelText;
        /** @type {?} */
        DwModalComponent.prototype.dwOkType;
        /** @type {?} */
        DwModalComponent.prototype.dwIconType;
        /** @type {?} */
        DwModalComponent.prototype.dwModalType;
        /** @type {?} */
        DwModalComponent.prototype.dwAutofocus;
        /** @type {?} */
        DwModalComponent.prototype.dwOnOk;
        /** @type {?} */
        DwModalComponent.prototype.dwOnCancel;
        /** @type {?} */
        DwModalComponent.prototype.dwAfterOpen;
        /** @type {?} */
        DwModalComponent.prototype.dwAfterClose;
        /** @type {?} */
        DwModalComponent.prototype.dwVisibleChange;
        /** @type {?} */
        DwModalComponent.prototype.contentTemplateRef;
        /**
         * @type {?}
         * @private
         */
        DwModalComponent.prototype.modalRef;
        /**
         * @type {?}
         * @private
         */
        DwModalComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwModalComponent.prototype.modal;
        /**
         * @type {?}
         * @private
         */
        DwModalComponent.prototype.viewContainerRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-close.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalCloseComponent = /** @class */ (function () {
        function DwModalCloseComponent(config) {
            this.config = config;
        }
        DwModalCloseComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'button[dw-modal-close]',
                        exportAs: 'DwModalCloseBuiltin',
                        template: "\n    <span class=\"ant-modal-close-x\">\n      <ng-container *dwStringTemplateOutlet=\"config.dwCloseIcon; let closeIcon\">\n        <i dw-icon [dwType]=\"closeIcon\" class=\"ant-modal-close-icon\"></i>\n      </ng-container>\n    </span>\n  ",
                        host: {
                            class: 'ant-modal-close',
                            'aria-label': 'Close'
                        },
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwModalCloseComponent.ctorParameters = function () { return [
            { type: ModalOptions }
        ]; };
        return DwModalCloseComponent;
    }());
    if (false) {
        /** @type {?} */
        DwModalCloseComponent.prototype.config;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-footer.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalFooterComponent = /** @class */ (function () {
        function DwModalFooterComponent(i18n, config) {
            var _this = this;
            this.i18n = i18n;
            this.config = config;
            this.buttonsFooter = false;
            this.buttons = [];
            this.cancelTriggered = new core.EventEmitter();
            this.okTriggered = new core.EventEmitter();
            this.destroy$ = new rxjs.Subject();
            if (Array.isArray(config.dwFooter)) {
                this.buttonsFooter = true;
                this.buttons = ((/** @type {?} */ (config.dwFooter))).map(mergeDefaultOption);
            }
            this.i18n.localeChange.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.locale = _this.i18n.getLocaleData('Modal');
            }));
        }
        /**
         * @return {?}
         */
        DwModalFooterComponent.prototype.onCancel = /**
         * @return {?}
         */
        function () {
            this.cancelTriggered.emit();
        };
        /**
         * @return {?}
         */
        DwModalFooterComponent.prototype.onOk = /**
         * @return {?}
         */
        function () {
            this.okTriggered.emit();
        };
        /**
         * Returns the value of the specified key.
         * If it is a function, run and return the return value of the function.
         * @deprecated Not support use function type.
         * @breaking-change 10.0.0
         */
        /**
         * Returns the value of the specified key.
         * If it is a function, run and return the return value of the function.
         * @deprecated Not support use function type.
         * \@breaking-change 10.0.0
         * @param {?} options
         * @param {?} prop
         * @return {?}
         */
        DwModalFooterComponent.prototype.getButtonCallableProp = /**
         * Returns the value of the specified key.
         * If it is a function, run and return the return value of the function.
         * @deprecated Not support use function type.
         * \@breaking-change 10.0.0
         * @param {?} options
         * @param {?} prop
         * @return {?}
         */
        function (options, prop) {
            /** @type {?} */
            var value = options[prop];
            /** @type {?} */
            var componentInstance = this.modalRef.getContentComponent();
            return typeof value === 'function' ? value.apply(options, componentInstance && [componentInstance]) : value;
        };
        /**
         * Run function based on the type and set its `loading` prop if needed.
         * @deprecated Should be set options' value by the user, not library.
         * @breaking-change 10.0.0
         */
        /**
         * Run function based on the type and set its `loading` prop if needed.
         * @deprecated Should be set options' value by the user, not library.
         * \@breaking-change 10.0.0
         * @param {?} options
         * @return {?}
         */
        DwModalFooterComponent.prototype.onButtonClick = /**
         * Run function based on the type and set its `loading` prop if needed.
         * @deprecated Should be set options' value by the user, not library.
         * \@breaking-change 10.0.0
         * @param {?} options
         * @return {?}
         */
        function (options) {
            /** @type {?} */
            var loading = this.getButtonCallableProp(options, 'loading');
            if (!loading) {
                /** @type {?} */
                var result = this.getButtonCallableProp(options, 'onClick');
                if (options.autoLoading && util.isPromise(result)) {
                    options.loading = true;
                    result.then((/**
                     * @return {?}
                     */
                    function () { return (options.loading = false); })).catch((/**
                     * @return {?}
                     */
                    function () { return (options.loading = false); }));
                }
            }
        };
        /**
         * @return {?}
         */
        DwModalFooterComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwModalFooterComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'div[dw-modal-footer]',
                        exportAs: 'DwModalFooterBuiltin',
                        template: "\n    <ng-container *ngIf=\"config.dwFooter; else defaultFooterButtons\">\n      <ng-container *dwStringTemplateOutlet=\"config.dwFooter\">\n        <div *ngIf=\"!buttonsFooter\" [innerHTML]=\"config.dwTitle\"></div>\n        <ng-container *ngIf=\"buttonsFooter\">\n          <button\n            *ngFor=\"let button of buttons\"\n            dw-button\n            (click)=\"onButtonClick(button)\"\n            [hidden]=\"!getButtonCallableProp(button, 'show')\"\n            [dwLoading]=\"getButtonCallableProp(button, 'loading')\"\n            [disabled]=\"getButtonCallableProp(button, 'disabled')\"\n            [dwType]=\"button.type!\"\n            [dwShape]=\"button.shape!\"\n            [dwSize]=\"button.size!\"\n            [dwGhost]=\"button.ghost!\"\n          >\n            {{ button.label }}\n          </button>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n    <ng-template #defaultFooterButtons>\n      <button\n        *ngIf=\"config.dwCancelText !== null\"\n        [attr.cdkFocusInitial]=\"config.dwAutofocus === 'cancel' || null\"\n        dw-button\n        (click)=\"onCancel()\"\n        [dwLoading]=\"!!config.dwCancelLoading\"\n        [disabled]=\"config.dwCancelDisabled\"\n      >\n        {{ config.dwCancelText || locale.cancelText }}\n      </button>\n      <button\n        *ngIf=\"config.dwOkText !== null\"\n        [attr.cdkFocusInitial]=\"config.dwAutofocus === 'ok' || null\"\n        dw-button\n        [dwType]=\"config.dwOkType!\"\n        (click)=\"onOk()\"\n        [dwLoading]=\"!!config.dwOkLoading\"\n        [disabled]=\"config.dwOkDisabled\"\n      >\n        {{ config.dwOkText || locale.okText }}\n      </button>\n    </ng-template>\n  ",
                        host: {
                            class: 'ant-modal-footer'
                        },
                        changeDetection: core.ChangeDetectionStrategy.Default
                    }] }
        ];
        /** @nocollapse */
        DwModalFooterComponent.ctorParameters = function () { return [
            { type: i18n.DwI18nService },
            { type: ModalOptions }
        ]; };
        DwModalFooterComponent.propDecorators = {
            cancelTriggered: [{ type: core.Output }],
            okTriggered: [{ type: core.Output }],
            modalRef: [{ type: core.Input }]
        };
        return DwModalFooterComponent;
    }());
    if (false) {
        /** @type {?} */
        DwModalFooterComponent.prototype.buttonsFooter;
        /** @type {?} */
        DwModalFooterComponent.prototype.buttons;
        /** @type {?} */
        DwModalFooterComponent.prototype.locale;
        /** @type {?} */
        DwModalFooterComponent.prototype.cancelTriggered;
        /** @type {?} */
        DwModalFooterComponent.prototype.okTriggered;
        /** @type {?} */
        DwModalFooterComponent.prototype.modalRef;
        /**
         * @type {?}
         * @private
         */
        DwModalFooterComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwModalFooterComponent.prototype.i18n;
        /** @type {?} */
        DwModalFooterComponent.prototype.config;
    }
    /**
     * @param {?} options
     * @return {?}
     */
    function mergeDefaultOption(options) {
        return __assign({ type: null, size: 'default', autoLoading: true, show: true, loading: false, disabled: false }, options);
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-title.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalTitleComponent = /** @class */ (function () {
        function DwModalTitleComponent(config) {
            this.config = config;
        }
        DwModalTitleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'div[dw-modal-title]',
                        exportAs: 'DwModalTitleBuiltin',
                        template: "\n    <div class=\"ant-modal-title\">\n      <ng-container *dwStringTemplateOutlet=\"config.dwTitle\">\n        <div [innerHTML]=\"config.dwTitle\"></div>\n      </ng-container>\n    </div>\n  ",
                        host: {
                            class: 'ant-modal-header'
                        },
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwModalTitleComponent.ctorParameters = function () { return [
            { type: ModalOptions }
        ]; };
        return DwModalTitleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwModalTitleComponent.prototype.config;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: modal.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwModalModule = /** @class */ (function () {
        function DwModalModule() {
        }
        DwModalModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            overlay.OverlayModule,
                            outlet.DwOutletModule,
                            portal.PortalModule,
                            i18n.DwI18nModule,
                            button.DwButtonModule,
                            icon.DwIconModule,
                            pipe.DwPipesModule,
                            noAnimation.DwNoAnimationModule
                        ],
                        exports: [DwModalComponent, DwModalFooterDirective],
                        providers: [DwModalService],
                        entryComponents: [DwModalContainerComponent, DwModalConfirmContainerComponent],
                        declarations: [
                            DwModalComponent,
                            DwModalFooterDirective,
                            DwModalCloseComponent,
                            DwModalFooterComponent,
                            DwModalTitleComponent,
                            DwModalContainerComponent,
                            DwModalConfirmContainerComponent,
                            DwModalComponent
                        ]
                    },] }
        ];
        return DwModalModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: modal-legacy-api.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @abstract
     * @template T, R
     */
    var   /**
     * @abstract
     * @template T, R
     */
    DwModalLegacyAPI = /** @class */ (function () {
        function DwModalLegacyAPI() {
        }
        return DwModalLegacyAPI;
    }());
    if (false) {
        /** @type {?} */
        DwModalLegacyAPI.prototype.afterOpen;
        /** @type {?} */
        DwModalLegacyAPI.prototype.afterClose;
        /**
         * @abstract
         * @return {?}
         */
        DwModalLegacyAPI.prototype.open = function () { };
        /**
         * @abstract
         * @param {?=} result
         * @return {?}
         */
        DwModalLegacyAPI.prototype.close = function (result) { };
        /**
         * @abstract
         * @param {?=} result
         * @return {?}
         */
        DwModalLegacyAPI.prototype.destroy = function (result) { };
        /**
         * Trigger the dwOnOk/dwOnCancel by manual
         * @abstract
         * @return {?}
         */
        DwModalLegacyAPI.prototype.triggerOk = function () { };
        /**
         * @abstract
         * @return {?}
         */
        DwModalLegacyAPI.prototype.triggerCancel = function () { };
        /**
         * Return the component instance of dwContent when specify dwContent as a Component
         * @abstract
         * @return {?}
         */
        DwModalLegacyAPI.prototype.getContentComponent = function () { };
        /**
         * Get the dom element of this Modal
         * @abstract
         * @return {?}
         */
        DwModalLegacyAPI.prototype.getElement = function () { };
    }

    exports.BaseModalContainer = BaseModalContainer;
    exports.DW_CONFIG_COMPONENT_NAME = DW_CONFIG_COMPONENT_NAME;
    exports.DwModalCloseComponent = DwModalCloseComponent;
    exports.DwModalComponent = DwModalComponent;
    exports.DwModalConfirmContainerComponent = DwModalConfirmContainerComponent;
    exports.DwModalContainerComponent = DwModalContainerComponent;
    exports.DwModalFooterComponent = DwModalFooterComponent;
    exports.DwModalFooterDirective = DwModalFooterDirective;
    exports.DwModalLegacyAPI = DwModalLegacyAPI;
    exports.DwModalModule = DwModalModule;
    exports.DwModalRef = DwModalRef;
    exports.DwModalService = DwModalService;
    exports.DwModalTitleComponent = DwModalTitleComponent;
    exports.FADE_CLASS_NAME_MAP = FADE_CLASS_NAME_MAP;
    exports.MODAL_MASK_CLASS_NAME = MODAL_MASK_CLASS_NAME;
    exports.ModalOptions = ModalOptions;
    exports.ZOOM_CLASS_NAME_MAP = ZOOM_CLASS_NAME_MAP;
    exports.applyConfigDefaults = applyConfigDefaults;
    exports.dwModalAnimations = dwModalAnimations;
    exports.getConfigFromComponent = getConfigFromComponent;
    exports.getValueWithConfig = getValueWithConfig;
    exports.setContentInstanceParams = setContentInstanceParams;
    exports.throwDwModalContentAlreadyAttachedError = throwDwModalContentAlreadyAttachedError;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-modal.umd.js.map
