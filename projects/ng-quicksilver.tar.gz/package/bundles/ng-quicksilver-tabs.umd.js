(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/util'), require('rxjs'), require('@angular/router'), require('@angular/cdk/observers'), require('@angular/cdk/platform'), require('@angular/common'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon'), require('@angular/cdk/bidi'), require('ng-quicksilver/core/services'), require('rxjs/operators'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/logger')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/tabs', ['exports', '@angular/core', 'ng-quicksilver/core/util', 'rxjs', '@angular/router', '@angular/cdk/observers', '@angular/cdk/platform', '@angular/common', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon', '@angular/cdk/bidi', 'ng-quicksilver/core/services', 'rxjs/operators', 'ng-quicksilver/core/config', 'ng-quicksilver/core/logger'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].tabs = {}), global.ng.core, global['ng-quicksilver'].core.util, global.rxjs, global.ng.router, global.ng.cdk.observers, global.ng.cdk.platform, global.ng.common, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon, global.ng.cdk.bidi, global['ng-quicksilver'].core.services, global.rxjs.operators, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.logger));
}(this, (function (exports, core, util, rxjs, router, observers, platform, common, outlet, icon, bidi, services, operators, config, logger) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tab-body.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTabBodyComponent = /** @class */ (function () {
        function DwTabBodyComponent() {
            this.content = null;
            this.active = false;
            this.forceRender = false;
        }
        DwTabBodyComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-tab-body]',
                        exportAs: 'dwTabBody',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-container *ngIf=\"active || forceRender\">\n      <ng-template [ngTemplateOutlet]=\"content\"></ng-template>\n    </ng-container>\n  ",
                        host: {
                            '[class.ant-tabs-tabpane-active]': 'active',
                            '[class.ant-tabs-tabpane-inactive]': '!active'
                        }
                    }] }
        ];
        DwTabBodyComponent.propDecorators = {
            content: [{ type: core.Input }],
            active: [{ type: core.Input }],
            forceRender: [{ type: core.Input }]
        };
        return DwTabBodyComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTabBodyComponent.prototype.content;
        /** @type {?} */
        DwTabBodyComponent.prototype.active;
        /** @type {?} */
        DwTabBodyComponent.prototype.forceRender;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tab-label.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTabLabelDirective = /** @class */ (function () {
        function DwTabLabelDirective(elementRef, renderer) {
            this.elementRef = elementRef;
            this.disabled = false;
            renderer.addClass(elementRef.nativeElement, 'ant-tabs-tab');
        }
        /**
         * @return {?}
         */
        DwTabLabelDirective.prototype.getOffsetLeft = /**
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement.offsetLeft;
        };
        /**
         * @return {?}
         */
        DwTabLabelDirective.prototype.getOffsetWidth = /**
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement.offsetWidth;
        };
        /**
         * @return {?}
         */
        DwTabLabelDirective.prototype.getOffsetTop = /**
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement.offsetTop;
        };
        /**
         * @return {?}
         */
        DwTabLabelDirective.prototype.getOffsetHeight = /**
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement.offsetHeight;
        };
        DwTabLabelDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-tab-label]',
                        exportAs: 'dwTabLabel',
                        host: {
                            '[class.ant-tabs-tab-disabled]': 'disabled'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwTabLabelDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        DwTabLabelDirective.propDecorators = {
            disabled: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabLabelDirective.prototype, "disabled", void 0);
        return DwTabLabelDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTabLabelDirective.ngAcceptInputType_disabled;
        /** @type {?} */
        DwTabLabelDirective.prototype.disabled;
        /** @type {?} */
        DwTabLabelDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tab-link.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * This component is for catching `routerLink` directive.
     */
    var DwTabLinkDirective = /** @class */ (function () {
        function DwTabLinkDirective(routerLink, routerLinkWithHref) {
            this.routerLink = routerLink;
            this.routerLinkWithHref = routerLinkWithHref;
        }
        DwTabLinkDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'a[dw-tab-link]',
                        exportAs: 'dwTabLink'
                    },] }
        ];
        /** @nocollapse */
        DwTabLinkDirective.ctorParameters = function () { return [
            { type: router.RouterLink, decorators: [{ type: core.Optional }, { type: core.Self }] },
            { type: router.RouterLinkWithHref, decorators: [{ type: core.Optional }, { type: core.Self }] }
        ]; };
        return DwTabLinkDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTabLinkDirective.prototype.routerLink;
        /** @type {?} */
        DwTabLinkDirective.prototype.routerLinkWithHref;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tab.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Decorates the `ng-template` tags and reads out the template from it.
     */
    var DwTabDirective = /** @class */ (function () {
        function DwTabDirective() {
        }
        DwTabDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-tab]',
                        exportAs: 'dwTab'
                    },] }
        ];
        return DwTabDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: tab.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTabComponent = /** @class */ (function () {
        function DwTabComponent(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.position = null;
            this.origin = null;
            this.isActive = false;
            this.stateChanges = new rxjs.Subject();
            this.dwForceRender = false;
            this.dwDisabled = false;
            this.dwClick = new core.EventEmitter();
            this.dwSelect = new core.EventEmitter();
            this.dwDeselect = new core.EventEmitter();
            this.renderer.addClass(elementRef.nativeElement, 'ant-tabs-tabpane');
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTabComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwTitle || changes.dwForceRender || changes.dwDisabled) {
                this.stateChanges.next();
            }
        };
        /**
         * @return {?}
         */
        DwTabComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.stateChanges.complete();
        };
        DwTabComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tab',
                        exportAs: 'dwTab',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-template #titleTpl>\n      <ng-content select=\"[dw-tab-link]\"></ng-content>\n    </ng-template>\n    <ng-template #bodyTpl>\n      <ng-content></ng-content>\n    </ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwTabComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        DwTabComponent.propDecorators = {
            content: [{ type: core.ViewChild, args: ['bodyTpl', { static: true },] }],
            title: [{ type: core.ViewChild, args: ['titleTpl', { static: true },] }],
            template: [{ type: core.ContentChild, args: [DwTabDirective, { static: false, read: core.TemplateRef },] }],
            linkDirective: [{ type: core.ContentChild, args: [DwTabLinkDirective, { static: false },] }],
            dwTitle: [{ type: core.Input }],
            dwRouterIdentifier: [{ type: core.Input }],
            dwForceRender: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwClick: [{ type: core.Output }],
            dwSelect: [{ type: core.Output }],
            dwDeselect: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabComponent.prototype, "dwForceRender", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabComponent.prototype, "dwDisabled", void 0);
        return DwTabComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTabComponent.ngAcceptInputType_dwForceRender;
        /** @type {?} */
        DwTabComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwTabComponent.prototype.position;
        /** @type {?} */
        DwTabComponent.prototype.origin;
        /** @type {?} */
        DwTabComponent.prototype.isActive;
        /** @type {?} */
        DwTabComponent.prototype.stateChanges;
        /** @type {?} */
        DwTabComponent.prototype.content;
        /** @type {?} */
        DwTabComponent.prototype.title;
        /** @type {?} */
        DwTabComponent.prototype.template;
        /** @type {?} */
        DwTabComponent.prototype.linkDirective;
        /** @type {?} */
        DwTabComponent.prototype.dwTitle;
        /** @type {?} */
        DwTabComponent.prototype.dwRouterIdentifier;
        /** @type {?} */
        DwTabComponent.prototype.dwForceRender;
        /** @type {?} */
        DwTabComponent.prototype.dwDisabled;
        /** @type {?} */
        DwTabComponent.prototype.dwClick;
        /** @type {?} */
        DwTabComponent.prototype.dwSelect;
        /** @type {?} */
        DwTabComponent.prototype.dwDeselect;
        /** @type {?} */
        DwTabComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTabComponent.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tabs-ink-bar.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTabsInkBarDirective = /** @class */ (function () {
        function DwTabsInkBarDirective(renderer, elementRef, ngZone) {
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.ngZone = ngZone;
            this.dwAnimated = false;
            this.dwPositionMode = 'horizontal';
            renderer.addClass(elementRef.nativeElement, 'ant-tabs-ink-bar');
        }
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.alignToElement = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            var _this = this;
            if (typeof requestAnimationFrame !== 'undefined') {
                this.ngZone.runOutsideAngular((/**
                 * @return {?}
                 */
                function () {
                    requestAnimationFrame((/**
                     * @return {?}
                     */
                    function () { return _this.setStyles(element); }));
                }));
            }
            else {
                this.setStyles(element);
            }
        };
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.setStyles = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            /** when horizontal remove height style and add transform left **/
            if (this.dwPositionMode === 'horizontal') {
                this.renderer.removeStyle(this.elementRef.nativeElement, 'height');
                this.renderer.setStyle(this.elementRef.nativeElement, 'transform', "translate3d(" + this.getLeftPosition(element) + ", 0px, 0px)");
                this.renderer.setStyle(this.elementRef.nativeElement, 'width', this.getElementWidth(element));
            }
            else {
                /** when vertical remove width style and add transform top **/
                this.renderer.removeStyle(this.elementRef.nativeElement, 'width');
                this.renderer.setStyle(this.elementRef.nativeElement, 'transform', "translate3d(0px, " + this.getTopPosition(element) + ", 0px)");
                this.renderer.setStyle(this.elementRef.nativeElement, 'height', this.getElementHeight(element));
            }
        };
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.getLeftPosition = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return element ? element.offsetLeft + 'px' : '0';
        };
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.getElementWidth = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return element ? element.offsetWidth + 'px' : '0';
        };
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.getTopPosition = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return element ? element.offsetTop + 'px' : '0';
        };
        /**
         * @param {?} element
         * @return {?}
         */
        DwTabsInkBarDirective.prototype.getElementHeight = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return element ? element.offsetHeight + 'px' : '0';
        };
        DwTabsInkBarDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-tabs-ink-bar]',
                        exportAs: 'dwTabsInkBar',
                        host: {
                            '[class.ant-tabs-ink-bar-animated]': 'dwAnimated',
                            '[class.ant-tabs-ink-bar-no-animated]': '!dwAnimated'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwTabsInkBarDirective.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef },
            { type: core.NgZone }
        ]; };
        DwTabsInkBarDirective.propDecorators = {
            dwAnimated: [{ type: core.Input }],
            dwPositionMode: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabsInkBarDirective.prototype, "dwAnimated", void 0);
        return DwTabsInkBarDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTabsInkBarDirective.ngAcceptInputType_dwAnimated;
        /** @type {?} */
        DwTabsInkBarDirective.prototype.dwAnimated;
        /** @type {?} */
        DwTabsInkBarDirective.prototype.dwPositionMode;
        /**
         * @type {?}
         * @private
         */
        DwTabsInkBarDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTabsInkBarDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTabsInkBarDirective.prototype.ngZone;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tabs-nav.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var EXAGGERATED_OVERSCROLL = 64;
    var DwTabsNavComponent = /** @class */ (function () {
        function DwTabsNavComponent(elementRef, ngZone, renderer, cdr, platform, resizeService, dir) {
            this.elementRef = elementRef;
            this.ngZone = ngZone;
            this.renderer = renderer;
            this.cdr = cdr;
            this.platform = platform;
            this.resizeService = resizeService;
            this.dir = dir;
            this._tabPositionMode = 'horizontal';
            this._scrollDistance = 0;
            this._selectedIndex = 0;
            this.destroy$ = new rxjs.Subject();
            this.showPaginationControls = false;
            this.disableScrollAfter = true;
            this.disableScrollBefore = true;
            this.selectedIndexChanged = false;
            this.realignInkBar = null;
            this.dwOnNextClick = new core.EventEmitter();
            this.dwOnPrevClick = new core.EventEmitter();
            this.dwAnimated = true;
            this.dwHideBar = false;
            this.dwShowPagination = true;
            this.dwType = 'line';
            this.dwTabPosition = 'top';
        }
        Object.defineProperty(DwTabsNavComponent.prototype, "dwPositionMode", {
            get: /**
             * @return {?}
             */
            function () {
                return this._tabPositionMode;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                var _this = this;
                this._tabPositionMode = value;
                this.alignInkBarToSelectedTab();
                if (this.dwShowPagination) {
                    Promise.resolve().then((/**
                     * @return {?}
                     */
                    function () {
                        _this.updatePagination();
                    }));
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabsNavComponent.prototype, "selectedIndex", {
            get: /**
             * @return {?}
             */
            function () {
                return this._selectedIndex;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.selectedIndexChanged = this._selectedIndex !== value;
                this._selectedIndex = value;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.onContentChanges = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var textContent = this.elementRef.nativeElement.textContent;
            // We need to diff the text content of the header, because the MutationObserver callback
            // will fire even if the text content didn't change which is inefficient and is prone
            // to infinite loops if a poorly constructed expression is passed in (see #14249).
            if (textContent !== this.currentTextContent) {
                this.currentTextContent = textContent;
                this.ngZone.run((/**
                 * @return {?}
                 */
                function () {
                    if (_this.dwShowPagination) {
                        _this.updatePagination();
                    }
                    _this.alignInkBarToSelectedTab();
                    _this.cdr.markForCheck();
                }));
            }
        };
        /**
         * @param {?} scrollDir
         * @return {?}
         */
        DwTabsNavComponent.prototype.scrollHeader = /**
         * @param {?} scrollDir
         * @return {?}
         */
        function (scrollDir) {
            if (scrollDir === 'before' && !this.disableScrollBefore) {
                this.dwOnPrevClick.emit();
            }
            else if (scrollDir === 'after' && !this.disableScrollAfter) {
                this.dwOnNextClick.emit();
            }
            // Move the scroll distance one-third the length of the tab list's viewport.
            this.scrollDistance += ((scrollDir === 'before' ? -1 : 1) * this.viewWidthHeightPix) / 3;
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.ngAfterContentChecked = /**
         * @return {?}
         */
        function () {
            if (this.tabLabelCount !== this.listOfDwTabLabelDirective.length) {
                if (this.dwShowPagination) {
                    this.updatePagination();
                }
                this.tabLabelCount = this.listOfDwTabLabelDirective.length;
                this.cdr.markForCheck();
            }
            if (this.selectedIndexChanged) {
                this.scrollToLabel(this._selectedIndex);
                if (this.dwShowPagination) {
                    this.checkScrollingControls();
                }
                this.alignInkBarToSelectedTab();
                this.selectedIndexChanged = false;
                this.cdr.markForCheck();
            }
            if (this.scrollDistanceChanged) {
                if (this.dwShowPagination) {
                    this.updateTabScrollPosition();
                }
                this.scrollDistanceChanged = false;
                this.cdr.markForCheck();
            }
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.realignInkBar = this.ngZone.runOutsideAngular((/**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var dirChange = _this.dir ? _this.dir.change : rxjs.of(null);
                /** @type {?} */
                var resize = typeof window !== 'undefined' ? _this.resizeService.subscribe().pipe(operators.takeUntil(_this.destroy$)) : rxjs.of(null);
                return rxjs.merge(dirChange, resize)
                    .pipe(operators.startWith(null))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    if (_this.dwShowPagination) {
                        _this.updatePagination();
                    }
                    _this.alignInkBarToSelectedTab();
                }));
            }));
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
            if (this.realignInkBar) {
                this.realignInkBar.unsubscribe();
            }
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.updateTabScrollPosition = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var scrollDistance = this.scrollDistance;
            if (this.dwPositionMode === 'horizontal') {
                /** @type {?} */
                var translateX = this.getLayoutDirection() === 'ltr' ? -scrollDistance : scrollDistance;
                this.renderer.setStyle(this.navListElement.nativeElement, 'transform', "translate3d(" + translateX + "px, 0, 0)");
            }
            else {
                this.renderer.setStyle(this.navListElement.nativeElement, 'transform', "translate3d(0," + -scrollDistance + "px, 0)");
            }
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.updatePagination = /**
         * @return {?}
         */
        function () {
            this.checkPaginationEnabled();
            this.checkScrollingControls();
            this.updateTabScrollPosition();
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.checkPaginationEnabled = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var isEnabled = this.tabListScrollWidthHeightPix > this.tabListScrollOffSetWidthHeight;
            if (!isEnabled) {
                this.scrollDistance = 0;
            }
            if (isEnabled !== this.showPaginationControls) {
                this.cdr.markForCheck();
            }
            this.showPaginationControls = isEnabled;
        };
        /**
         * @param {?} labelIndex
         * @return {?}
         */
        DwTabsNavComponent.prototype.scrollToLabel = /**
         * @param {?} labelIndex
         * @return {?}
         */
        function (labelIndex) {
            /** @type {?} */
            var selectedLabel = this.listOfDwTabLabelDirective ? this.listOfDwTabLabelDirective.toArray()[labelIndex] : null;
            if (selectedLabel) {
                // The view length is the visible width of the tab labels.
                /** @type {?} */
                var labelBeforePos = void 0;
                /** @type {?} */
                var labelAfterPos = void 0;
                if (this.dwPositionMode === 'horizontal') {
                    if (this.getLayoutDirection() === 'ltr') {
                        labelBeforePos = selectedLabel.getOffsetLeft();
                        labelAfterPos = labelBeforePos + selectedLabel.getOffsetWidth();
                    }
                    else {
                        labelAfterPos = this.navListElement.nativeElement.offsetWidth - selectedLabel.getOffsetLeft();
                        labelBeforePos = labelAfterPos - selectedLabel.getOffsetWidth();
                    }
                }
                else {
                    labelBeforePos = selectedLabel.getOffsetTop();
                    labelAfterPos = labelBeforePos + selectedLabel.getOffsetHeight();
                }
                /** @type {?} */
                var beforeVisiblePos = this.scrollDistance;
                /** @type {?} */
                var afterVisiblePos = this.scrollDistance + this.viewWidthHeightPix;
                if (labelBeforePos < beforeVisiblePos) {
                    // Scroll header to move label to the before direction
                    this.scrollDistance -= beforeVisiblePos - labelBeforePos + EXAGGERATED_OVERSCROLL;
                }
                else if (labelAfterPos > afterVisiblePos) {
                    // Scroll header to move label to the after direction
                    this.scrollDistance += labelAfterPos - afterVisiblePos + EXAGGERATED_OVERSCROLL;
                }
            }
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.checkScrollingControls = /**
         * @return {?}
         */
        function () {
            // Check if the pagination arrows should be activated.
            this.disableScrollBefore = this.scrollDistance === 0;
            this.disableScrollAfter = this.scrollDistance === this.getMaxScrollDistance();
            this.cdr.markForCheck();
        };
        /**
         * Determines what is the maximum length in pixels that can be set for the scroll distance. This
         * is equal to the difference in width between the tab list container and tab header container.
         *
         * This is an expensive call that forces a layout reflow to compute box and scroll metrics and
         * should be called sparingly.
         */
        /**
         * Determines what is the maximum length in pixels that can be set for the scroll distance. This
         * is equal to the difference in width between the tab list container and tab header container.
         *
         * This is an expensive call that forces a layout reflow to compute box and scroll metrics and
         * should be called sparingly.
         * @return {?}
         */
        DwTabsNavComponent.prototype.getMaxScrollDistance = /**
         * Determines what is the maximum length in pixels that can be set for the scroll distance. This
         * is equal to the difference in width between the tab list container and tab header container.
         *
         * This is an expensive call that forces a layout reflow to compute box and scroll metrics and
         * should be called sparingly.
         * @return {?}
         */
        function () {
            return this.tabListScrollWidthHeightPix - this.viewWidthHeightPix || 0;
        };
        Object.defineProperty(DwTabsNavComponent.prototype, "scrollDistance", {
            get: /**
             * @return {?}
             */
            function () {
                return this._scrollDistance;
            },
            /** Sets the distance in pixels that the tab header should be transformed in the X-axis. */
            set: /**
             * Sets the distance in pixels that the tab header should be transformed in the X-axis.
             * @param {?} v
             * @return {?}
             */
            function (v) {
                this._scrollDistance = Math.max(0, Math.min(this.getMaxScrollDistance(), v));
                // Mark that the scroll distance has changed so that after the view is checked, the CSS
                // transformation can move the header.
                this.scrollDistanceChanged = true;
                this.checkScrollingControls();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabsNavComponent.prototype, "viewWidthHeightPix", {
            get: /**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var PAGINATION_PIX = 0;
                if (this.showPaginationControls) {
                    PAGINATION_PIX = this.navContainerScrollPaddingPix;
                }
                if (this.dwPositionMode === 'horizontal') {
                    return this.navContainerElement.nativeElement.offsetWidth - PAGINATION_PIX;
                }
                else {
                    return this.navContainerElement.nativeElement.offsetHeight - PAGINATION_PIX;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabsNavComponent.prototype, "navContainerScrollPaddingPix", {
            get: /**
             * @return {?}
             */
            function () {
                if (this.platform.isBrowser) {
                    /** @type {?} */
                    var navContainer = this.navContainerElement.nativeElement;
                    /** @type {?} */
                    var originStyle = window.getComputedStyle
                        ? window.getComputedStyle(navContainer)
                        : ((/** @type {?} */ (navContainer))).currentStyle;
                    if (this.dwPositionMode === 'horizontal') {
                        return util.pxToNumber(originStyle.paddingLeft) + util.pxToNumber(originStyle.paddingRight);
                    }
                    else {
                        return util.pxToNumber(originStyle.paddingTop) + util.pxToNumber(originStyle.paddingBottom);
                    }
                }
                else {
                    return 0;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabsNavComponent.prototype, "tabListScrollWidthHeightPix", {
            get: /**
             * @return {?}
             */
            function () {
                if (this.dwPositionMode === 'horizontal') {
                    return this.navListElement.nativeElement.scrollWidth;
                }
                else {
                    return this.navListElement.nativeElement.scrollHeight;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabsNavComponent.prototype, "tabListScrollOffSetWidthHeight", {
            get: /**
             * @return {?}
             */
            function () {
                if (this.dwPositionMode === 'horizontal') {
                    return this.scrollListElement.nativeElement.offsetWidth;
                }
                else {
                    return this.elementRef.nativeElement.offsetHeight;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.getLayoutDirection = /**
         * @return {?}
         */
        function () {
            return this.dir && this.dir.value === 'rtl' ? 'rtl' : 'ltr';
        };
        /**
         * @return {?}
         */
        DwTabsNavComponent.prototype.alignInkBarToSelectedTab = /**
         * @return {?}
         */
        function () {
            if (this.dwType === 'line') {
                /** @type {?} */
                var selectedLabelWrapper = this.listOfDwTabLabelDirective && this.listOfDwTabLabelDirective.length
                    ? this.listOfDwTabLabelDirective.toArray()[this.selectedIndex].elementRef.nativeElement
                    : null;
                if (this.dwTabsInkBarDirective) {
                    this.dwTabsInkBarDirective.alignToElement(selectedLabelWrapper);
                }
            }
        };
        DwTabsNavComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tabs-nav',
                        exportAs: 'dwTabsNav',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div style=\"float:right;\" *ngIf=\"dwTabBarExtraContent\" class=\"ant-tabs-extra-content\">\n      <ng-template [ngTemplateOutlet]=\"dwTabBarExtraContent\"></ng-template>\n    </div>\n    <div class=\"ant-tabs-nav-container\" [class.ant-tabs-nav-container-scrolling]=\"showPaginationControls\" #navContainerElement>\n      <span\n        class=\"ant-tabs-tab-prev\"\n        (click)=\"scrollHeader('before')\"\n        [class.ant-tabs-tab-btn-disabled]=\"disableScrollBefore\"\n        [class.ant-tabs-tab-arrow-show]=\"showPaginationControls\"\n      >\n        <span class=\"ant-tabs-tab-prev-icon\">\n          <i dw-icon [dwType]=\"dwPositionMode === 'horizontal' ? 'left' : 'up'\" class=\"ant-tabs-tab-prev-icon-target\"></i>\n        </span>\n      </span>\n      <span\n        class=\"ant-tabs-tab-next\"\n        (click)=\"scrollHeader('after')\"\n        [class.ant-tabs-tab-btn-disabled]=\"disableScrollAfter\"\n        [class.ant-tabs-tab-arrow-show]=\"showPaginationControls\"\n      >\n        <span class=\"ant-tabs-tab-next-icon\">\n          <i dw-icon [dwType]=\"dwPositionMode === 'horizontal' ? 'right' : 'down'\" class=\"ant-tabs-tab-next-icon-target\"></i>\n        </span>\n      </span>\n      <div class=\"ant-tabs-nav-wrap\">\n        <div class=\"ant-tabs-nav-scroll\" #scrollListElement>\n          <div class=\"ant-tabs-nav\" [class.ant-tabs-nav-animated]=\"dwAnimated\" #navListElement (cdkObserveContent)=\"onContentChanges()\">\n            <div>\n              <ng-content></ng-content>\n            </div>\n            <div\n              dw-tabs-ink-bar\n              [hidden]=\"dwHideBar\"\n              [dwAnimated]=\"dwAnimated\"\n              [dwPositionMode]=\"dwPositionMode\"\n              style=\"display: block;\"\n            ></div>\n          </div>\n        </div>\n      </div>\n    </div>\n  ",
                        host: {
                            '[class.ant-tabs-bar]': 'true',
                            '[class.ant-tabs-card-bar]': "dwType === 'card'",
                            '[class.ant-tabs-top-bar]': "dwTabPosition === 'top'",
                            '[class.ant-tabs-bottom-bar]': "dwTabPosition === 'bottom'",
                            '[class.ant-tabs-left-bar]': "dwTabPosition === 'left'",
                            '[class.ant-tabs-right-bar]': "dwTabPosition === 'right'",
                            '[class.ant-tabs-small-bar]': "dwSize === 'small'",
                            '[class.ant-tabs-default-bar]': "dwSize === 'default'",
                            '[class.ant-tabs-large-bar]': "dwSize === 'large'"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTabsNavComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.NgZone },
            { type: core.Renderer2 },
            { type: core.ChangeDetectorRef },
            { type: platform.Platform },
            { type: services.DwResizeService },
            { type: bidi.Directionality, decorators: [{ type: core.Optional }] }
        ]; };
        DwTabsNavComponent.propDecorators = {
            listOfDwTabLabelDirective: [{ type: core.ContentChildren, args: [DwTabLabelDirective,] }],
            dwTabsInkBarDirective: [{ type: core.ViewChild, args: [DwTabsInkBarDirective, { static: true },] }],
            navContainerElement: [{ type: core.ViewChild, args: ['navContainerElement', { static: true },] }],
            navListElement: [{ type: core.ViewChild, args: ['navListElement', { static: true },] }],
            scrollListElement: [{ type: core.ViewChild, args: ['scrollListElement', { static: true },] }],
            dwOnNextClick: [{ type: core.Output }],
            dwOnPrevClick: [{ type: core.Output }],
            dwTabBarExtraContent: [{ type: core.Input }],
            dwAnimated: [{ type: core.Input }],
            dwHideBar: [{ type: core.Input }],
            dwShowPagination: [{ type: core.Input }],
            dwType: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwTabPosition: [{ type: core.Input }],
            dwPositionMode: [{ type: core.Input }],
            selectedIndex: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabsNavComponent.prototype, "dwAnimated", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabsNavComponent.prototype, "dwHideBar", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabsNavComponent.prototype, "dwShowPagination", void 0);
        return DwTabsNavComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTabsNavComponent.ngAcceptInputType_dwAnimated;
        /** @type {?} */
        DwTabsNavComponent.ngAcceptInputType_dwHideBar;
        /** @type {?} */
        DwTabsNavComponent.ngAcceptInputType_dwShowPagination;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype._tabPositionMode;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype._scrollDistance;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype._selectedIndex;
        /**
         * Cached text content of the header.
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.currentTextContent;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.destroy$;
        /** @type {?} */
        DwTabsNavComponent.prototype.showPaginationControls;
        /** @type {?} */
        DwTabsNavComponent.prototype.disableScrollAfter;
        /** @type {?} */
        DwTabsNavComponent.prototype.disableScrollBefore;
        /** @type {?} */
        DwTabsNavComponent.prototype.selectedIndexChanged;
        /** @type {?} */
        DwTabsNavComponent.prototype.realignInkBar;
        /** @type {?} */
        DwTabsNavComponent.prototype.tabLabelCount;
        /** @type {?} */
        DwTabsNavComponent.prototype.scrollDistanceChanged;
        /** @type {?} */
        DwTabsNavComponent.prototype.listOfDwTabLabelDirective;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwTabsInkBarDirective;
        /** @type {?} */
        DwTabsNavComponent.prototype.navContainerElement;
        /** @type {?} */
        DwTabsNavComponent.prototype.navListElement;
        /** @type {?} */
        DwTabsNavComponent.prototype.scrollListElement;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwOnNextClick;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwOnPrevClick;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwTabBarExtraContent;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwAnimated;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwHideBar;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwShowPagination;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwType;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwSize;
        /** @type {?} */
        DwTabsNavComponent.prototype.dwTabPosition;
        /** @type {?} */
        DwTabsNavComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.platform;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.resizeService;
        /**
         * @type {?}
         * @private
         */
        DwTabsNavComponent.prototype.dir;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: table.types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwAnimatedInterface() { }
    if (false) {
        /** @type {?} */
        DwAnimatedInterface.prototype.inkBar;
        /** @type {?} */
        DwAnimatedInterface.prototype.tabPane;
    }
    var DwTabChangeEvent = /** @class */ (function () {
        function DwTabChangeEvent() {
        }
        return DwTabChangeEvent;
    }());
    if (false) {
        /** @type {?} */
        DwTabChangeEvent.prototype.index;
        /** @type {?} */
        DwTabChangeEvent.prototype.tab;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tabset.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'tabs';
    var DwTabSetComponent = /** @class */ (function () {
        function DwTabSetComponent(dwConfigService, renderer, elementRef, cdr, router) {
            this.dwConfigService = dwConfigService;
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.cdr = cdr;
            this.router = router;
            this.indexToSelect = 0;
            this.el = this.elementRef.nativeElement;
            this._selectedIndex = null;
            /**
             * Subscription to tabs being added/removed.
             */
            this.tabsSubscription = rxjs.Subscription.EMPTY;
            /**
             * Subscription to changes in the tab labels.
             */
            this.tabLabelSubscription = rxjs.Subscription.EMPTY;
            this.destroy$ = new rxjs.Subject();
            this.tabPositionMode = 'horizontal';
            this.dwShowPagination = true;
            this.dwAnimated = true;
            this.dwHideAll = false;
            this.dwTabPosition = 'top';
            this.dwSize = 'default';
            this.dwTabBarGutter = undefined;
            this.dwTabBarStyle = null;
            this.dwType = 'line';
            this.dwLinkRouter = false;
            this.dwLinkExact = true;
            this.dwCanDeactivate = null;
            this.dwOnNextClick = new core.EventEmitter();
            this.dwOnPrevClick = new core.EventEmitter();
            this.dwSelectChange = new core.EventEmitter(true);
            this.dwSelectedIndexChange = new core.EventEmitter();
        }
        Object.defineProperty(DwTabSetComponent.prototype, "dwSelectedIndex", {
            get: /**
             * @return {?}
             */
            function () {
                return this._selectedIndex;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.indexToSelect = value ? util.toNumber(value, null) : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabSetComponent.prototype, "inkBarAnimated", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwAnimated === true || ((/** @type {?} */ (this.dwAnimated))).inkBar === true;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabSetComponent.prototype, "tabPaneAnimated", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwAnimated === true || ((/** @type {?} */ (this.dwAnimated))).tabPane === true;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTabSetComponent.prototype, "isAnimationDisabled", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwAnimated === false || ((/** @type {?} */ (this.dwAnimated))).tabPane === false;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} value
         * @return {?}
         */
        DwTabSetComponent.prototype.setPosition = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (this.tabContent) {
                if (value === 'bottom') {
                    this.renderer.insertBefore(this.el, this.tabContent.nativeElement, (/** @type {?} */ (this.dwTabsNavComponent)).elementRef.nativeElement);
                }
                else {
                    this.renderer.insertBefore(this.el, (/** @type {?} */ (this.dwTabsNavComponent)).elementRef.nativeElement, this.tabContent.nativeElement);
                }
            }
        };
        /**
         * @param {?} index
         * @param {?} disabled
         * @return {?}
         */
        DwTabSetComponent.prototype.clickLabel = /**
         * @param {?} index
         * @param {?} disabled
         * @return {?}
         */
        function (index, disabled) {
            var _this = this;
            if (!disabled) {
                if (this.dwSelectedIndex !== null && this.dwSelectedIndex !== index && typeof this.dwCanDeactivate === 'function') {
                    /** @type {?} */
                    var observable = util.wrapIntoObservable(this.dwCanDeactivate(this.dwSelectedIndex, index));
                    observable.pipe(operators.first(), operators.takeUntil(this.destroy$)).subscribe((/**
                     * @param {?} canChange
                     * @return {?}
                     */
                    function (canChange) { return canChange && _this.emitClickEvent(index); }));
                }
                else {
                    this.emitClickEvent(index);
                }
            }
        };
        /**
         * @private
         * @param {?} index
         * @return {?}
         */
        DwTabSetComponent.prototype.emitClickEvent = /**
         * @private
         * @param {?} index
         * @return {?}
         */
        function (index) {
            /** @type {?} */
            var tabs = this.listOfDwTabComponent.toArray();
            this.dwSelectedIndex = index;
            tabs[index].dwClick.emit();
            this.cdr.markForCheck();
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwTabSetComponent.prototype.createChangeEvent = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            /** @type {?} */
            var event = new DwTabChangeEvent();
            event.index = index;
            if (this.listOfDwTabComponent && this.listOfDwTabComponent.length) {
                event.tab = this.listOfDwTabComponent.toArray()[index];
                this.listOfDwTabComponent.forEach((/**
                 * @param {?} item
                 * @param {?} i
                 * @return {?}
                 */
                function (item, i) {
                    if (i !== index) {
                        item.dwDeselect.emit();
                    }
                }));
                event.tab.dwSelect.emit();
            }
            return event;
        };
        /** Clamps the given index to the bounds of 0 and the tabs length. */
        /**
         * Clamps the given index to the bounds of 0 and the tabs length.
         * @private
         * @param {?} index
         * @return {?}
         */
        DwTabSetComponent.prototype.clampTabIndex = /**
         * Clamps the given index to the bounds of 0 and the tabs length.
         * @private
         * @param {?} index
         * @return {?}
         */
        function (index) {
            // Note the `|| 0`, which ensures that values like NaN can't get through
            // and which would otherwise throw the component into an infinite loop
            // (since Math.max(NaN, 0) === NaN).
            return Math.min(this.listOfDwTabComponent.length - 1, Math.max(index || 0, 0));
        };
        /**
         * @private
         * @return {?}
         */
        DwTabSetComponent.prototype.subscribeToTabLabels = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.tabLabelSubscription) {
                this.tabLabelSubscription.unsubscribe();
            }
            this.tabLabelSubscription = rxjs.merge.apply(void 0, __spread(this.listOfDwTabComponent.map((/**
             * @param {?} tab
             * @return {?}
             */
            function (tab) { return tab.stateChanges; })))).subscribe((/**
             * @return {?}
             */
            function () { return _this.cdr.markForCheck(); }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTabSetComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwTabPosition = changes.dwTabPosition, dwType = changes.dwType;
            if (dwTabPosition) {
                if (this.dwTabPosition === 'top' || this.dwTabPosition === 'bottom') {
                    this.tabPositionMode = 'horizontal';
                }
                else {
                    this.tabPositionMode = 'vertical';
                }
                this.setPosition(this.dwTabPosition);
            }
            if (dwType) {
                if (this.dwType === 'card') {
                    this.dwAnimated = false;
                }
            }
        };
        /**
         * @return {?}
         */
        DwTabSetComponent.prototype.ngAfterContentChecked = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.listOfDwTabComponent && this.listOfDwTabComponent.length) {
                // Don't clamp the `indexToSelect` immediately in the setter because it can happen that
                // the amount of tabs changes before the actual change detection runs.
                /** @type {?} */
                var indexToSelect_1 = (this.indexToSelect = this.clampTabIndex(this.indexToSelect));
                // If there is a change in selected index, emit a change event. Should not trigger if
                // the selected index has not yet been initialized.
                if (this._selectedIndex !== indexToSelect_1) {
                    /** @type {?} */
                    var isFirstRun_1 = this._selectedIndex == null;
                    if (!isFirstRun_1) {
                        this.dwSelectChange.emit(this.createChangeEvent(indexToSelect_1));
                    }
                    // Changing these values after change detection has run
                    // since the checked content may contain references to them.
                    Promise.resolve().then((/**
                     * @return {?}
                     */
                    function () {
                        _this.listOfDwTabComponent.forEach((/**
                         * @param {?} tab
                         * @param {?} index
                         * @return {?}
                         */
                        function (tab, index) { return (tab.isActive = index === indexToSelect_1); }));
                        if (!isFirstRun_1) {
                            _this.dwSelectedIndexChange.emit(indexToSelect_1);
                        }
                    }));
                }
                // Setup the position for each tab and optionally setup an origin on the next selected tab.
                this.listOfDwTabComponent.forEach((/**
                 * @param {?} tab
                 * @param {?} index
                 * @return {?}
                 */
                function (tab, index) {
                    tab.position = index - indexToSelect_1;
                    // If there is already a selected tab, then set up an origin for the next selected tab
                    // if it doesn't have one already.
                    if (_this._selectedIndex != null && tab.position === 0 && !tab.origin) {
                        tab.origin = indexToSelect_1 - _this._selectedIndex;
                    }
                }));
                if (this._selectedIndex !== indexToSelect_1) {
                    this._selectedIndex = indexToSelect_1;
                    this.cdr.markForCheck();
                }
            }
        };
        /**
         * @return {?}
         */
        DwTabSetComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.subscribeToTabLabels();
            this.setPosition(this.dwTabPosition);
            if (this.dwLinkRouter) {
                if (!this.router) {
                    throw new Error(logger.PREFIX + " you should import 'RouterModule' if you want to use 'dwLinkRouter'!");
                }
                this.router.events
                    .pipe(operators.takeUntil(this.destroy$), operators.filter((/**
                 * @param {?} e
                 * @return {?}
                 */
                function (e) { return e instanceof router.NavigationEnd; })), operators.startWith(true))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.updateRouterActive();
                    _this.cdr.markForCheck();
                }));
            }
            // Subscribe to changes in the amount of tabs, in order to be
            // able to re-render the content as new tabs are added or removed.
            this.tabsSubscription = this.listOfDwTabComponent.changes.subscribe((/**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var indexToSelect = _this.clampTabIndex(_this.indexToSelect);
                // Maintain the previously-selected tab if a new tab is added or removed and there is no
                // explicit change that selects a different tab.
                if (indexToSelect === _this._selectedIndex) {
                    /** @type {?} */
                    var tabs = _this.listOfDwTabComponent.toArray();
                    for (var i = 0; i < tabs.length; i++) {
                        if (tabs[i].isActive) {
                            // Assign both to the `_indexToSelect` and `_selectedIndex` so we don't fire a changed
                            // event, otherwise the consumer may end up in an infinite loop in some edge cases like
                            // adding a tab within the `selectedIndexChange` event.
                            _this.indexToSelect = _this._selectedIndex = i;
                            break;
                        }
                    }
                }
                _this.subscribeToTabLabels();
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @return {?}
         */
        DwTabSetComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.tabsSubscription.unsubscribe();
            this.tabLabelSubscription.unsubscribe();
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @private
         * @return {?}
         */
        DwTabSetComponent.prototype.updateRouterActive = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.router.navigated) {
                /** @type {?} */
                var index = this.findShouldActiveTabIndex();
                if (index !== this._selectedIndex) {
                    this.dwSelectedIndex = index;
                    this.dwSelectedIndexChange.emit(index);
                }
                this.dwHideAll = index === -1;
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwTabSetComponent.prototype.findShouldActiveTabIndex = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var tabs = this.listOfDwTabComponent.toArray();
            /** @type {?} */
            var isActive = this.isLinkActive(this.router);
            return tabs.findIndex((/**
             * @param {?} tab
             * @return {?}
             */
            function (tab) {
                /** @type {?} */
                var c = tab.linkDirective;
                return c ? isActive(c.routerLink) || isActive(c.routerLinkWithHref) : false;
            }));
        };
        /**
         * @private
         * @param {?} router
         * @return {?}
         */
        DwTabSetComponent.prototype.isLinkActive = /**
         * @private
         * @param {?} router
         * @return {?}
         */
        function (router) {
            var _this = this;
            return (/**
             * @param {?=} link
             * @return {?}
             */
            function (link) { return (link ? router.isActive(link.urlTree, _this.dwLinkExact) : false); });
        };
        DwTabSetComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tabset',
                        exportAs: 'dwTabset',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <ng-container *ngIf=\"listOfDwTabComponent\">\n      <dw-tabs-nav\n        role=\"tablist\"\n        tabindex=\"0\"\n        [dwSize]=\"dwSize\"\n        [dwTabPosition]=\"dwTabPosition\"\n        [dwType]=\"dwType\"\n        [dwShowPagination]=\"dwShowPagination\"\n        [dwPositionMode]=\"tabPositionMode\"\n        [dwAnimated]=\"inkBarAnimated\"\n        [ngStyle]=\"dwTabBarStyle\"\n        [dwHideBar]=\"dwHideAll\"\n        [dwTabBarExtraContent]=\"dwTabBarExtraContent\"\n        [selectedIndex]=\"dwSelectedIndex!\"\n        (dwOnNextClick)=\"dwOnNextClick.emit()\"\n        (dwOnPrevClick)=\"dwOnPrevClick.emit()\"\n      >\n        <div\n          dw-tab-label\n          role=\"tab\"\n          [style.margin-right.px]=\"dwTabBarGutter\"\n          [class.ant-tabs-tab-active]=\"dwSelectedIndex == i && !dwHideAll\"\n          [disabled]=\"tab.dwDisabled\"\n          (click)=\"clickLabel(i, tab.dwDisabled)\"\n          *ngFor=\"let tab of listOfDwTabComponent; let i = index\"\n        >\n          <ng-container *dwStringTemplateOutlet=\"tab.dwTitle || tab.title\">{{ tab.dwTitle }}</ng-container>\n        </div>\n      </dw-tabs-nav>\n      <div\n        #tabContent\n        class=\"ant-tabs-content\"\n        [class.ant-tabs-top-content]=\"dwTabPosition === 'top'\"\n        [class.ant-tabs-bottom-content]=\"dwTabPosition === 'bottom'\"\n        [class.ant-tabs-left-content]=\"dwTabPosition === 'left'\"\n        [class.ant-tabs-right-content]=\"dwTabPosition === 'right'\"\n        [class.ant-tabs-content-animated]=\"tabPaneAnimated\"\n        [class.ant-tabs-card-content]=\"dwType === 'card'\"\n        [class.ant-tabs-content-no-animated]=\"!tabPaneAnimated\"\n        [style.margin-left.%]=\"tabPositionMode === 'horizontal' && tabPaneAnimated && -(dwSelectedIndex || 0) * 100\"\n      >\n        <div\n          dw-tab-body\n          class=\"ant-tabs-tabpane\"\n          *ngFor=\"let tab of listOfDwTabComponent; let i = index\"\n          [active]=\"dwSelectedIndex == i && !dwHideAll\"\n          [forceRender]=\"tab.dwForceRender\"\n          [content]=\"tab.template || tab.content\"\n        ></div>\n      </div>\n    </ng-container>\n  ",
                        host: {
                            '[class.ant-tabs]': "true",
                            '[class.ant-tabs-no-animation]': "isAnimationDisabled",
                            '[class.ant-tabs-line]': "dwType === 'line'",
                            '[class.ant-tabs-card]': "dwType === 'card'",
                            '[class.ant-tabs-top]': "dwTabPosition === 'top'",
                            '[class.ant-tabs-bottom]': "dwTabPosition === 'bottom'",
                            '[class.ant-tabs-left]': "dwTabPosition === 'left'",
                            '[class.ant-tabs-right]': "dwTabPosition === 'right'",
                            '[class.ant-tabs-vertical]': "dwTabPosition === 'left' || dwTabPosition === 'right'",
                            '[class.ant-tabs-large]': "dwSize === 'large'",
                            '[class.ant-tabs-small]': "dwSize === 'small'"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTabSetComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: core.Renderer2 },
            { type: core.ElementRef },
            { type: core.ChangeDetectorRef },
            { type: router.Router, decorators: [{ type: core.Optional }] }
        ]; };
        DwTabSetComponent.propDecorators = {
            listOfDwTabComponent: [{ type: core.ContentChildren, args: [DwTabComponent,] }],
            dwTabsNavComponent: [{ type: core.ViewChild, args: [DwTabsNavComponent, { static: false },] }],
            tabContent: [{ type: core.ViewChild, args: ['tabContent', { static: false },] }],
            dwTabBarExtraContent: [{ type: core.Input }],
            dwShowPagination: [{ type: core.Input }],
            dwAnimated: [{ type: core.Input }],
            dwHideAll: [{ type: core.Input }],
            dwTabPosition: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwTabBarGutter: [{ type: core.Input }],
            dwTabBarStyle: [{ type: core.Input }],
            dwType: [{ type: core.Input }],
            dwLinkRouter: [{ type: core.Input }],
            dwLinkExact: [{ type: core.Input }],
            dwCanDeactivate: [{ type: core.Input }],
            dwOnNextClick: [{ type: core.Output }],
            dwOnPrevClick: [{ type: core.Output }],
            dwSelectChange: [{ type: core.Output }],
            dwSelectedIndexChange: [{ type: core.Output }],
            dwSelectedIndex: [{ type: core.Input }]
        };
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTabSetComponent.prototype, "dwShowPagination", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Object)
        ], DwTabSetComponent.prototype, "dwAnimated", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTabSetComponent.prototype, "dwSize", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Number)
        ], DwTabSetComponent.prototype, "dwTabBarGutter", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTabSetComponent.prototype, "dwType", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabSetComponent.prototype, "dwLinkRouter", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTabSetComponent.prototype, "dwLinkExact", void 0);
        return DwTabSetComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTabSetComponent.ngAcceptInputType_dwLinkRouter;
        /** @type {?} */
        DwTabSetComponent.ngAcceptInputType_dwLinkExact;
        /** @type {?} */
        DwTabSetComponent.ngAcceptInputType_dwSelectedIndex;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.indexToSelect;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.el;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype._selectedIndex;
        /**
         * Subscription to tabs being added/removed.
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.tabsSubscription;
        /**
         * Subscription to changes in the tab labels.
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.tabLabelSubscription;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.destroy$;
        /** @type {?} */
        DwTabSetComponent.prototype.tabPositionMode;
        /** @type {?} */
        DwTabSetComponent.prototype.listOfDwTabComponent;
        /** @type {?} */
        DwTabSetComponent.prototype.dwTabsNavComponent;
        /** @type {?} */
        DwTabSetComponent.prototype.tabContent;
        /** @type {?} */
        DwTabSetComponent.prototype.dwTabBarExtraContent;
        /** @type {?} */
        DwTabSetComponent.prototype.dwShowPagination;
        /** @type {?} */
        DwTabSetComponent.prototype.dwAnimated;
        /** @type {?} */
        DwTabSetComponent.prototype.dwHideAll;
        /** @type {?} */
        DwTabSetComponent.prototype.dwTabPosition;
        /** @type {?} */
        DwTabSetComponent.prototype.dwSize;
        /** @type {?} */
        DwTabSetComponent.prototype.dwTabBarGutter;
        /** @type {?} */
        DwTabSetComponent.prototype.dwTabBarStyle;
        /** @type {?} */
        DwTabSetComponent.prototype.dwType;
        /** @type {?} */
        DwTabSetComponent.prototype.dwLinkRouter;
        /** @type {?} */
        DwTabSetComponent.prototype.dwLinkExact;
        /** @type {?} */
        DwTabSetComponent.prototype.dwCanDeactivate;
        /** @type {?} */
        DwTabSetComponent.prototype.dwOnNextClick;
        /** @type {?} */
        DwTabSetComponent.prototype.dwOnPrevClick;
        /** @type {?} */
        DwTabSetComponent.prototype.dwSelectChange;
        /** @type {?} */
        DwTabSetComponent.prototype.dwSelectedIndexChange;
        /** @type {?} */
        DwTabSetComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwTabSetComponent.prototype.router;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tabs.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTabsModule = /** @class */ (function () {
        function DwTabsModule() {
        }
        DwTabsModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [
                            DwTabComponent,
                            DwTabDirective,
                            DwTabSetComponent,
                            DwTabsNavComponent,
                            DwTabLabelDirective,
                            DwTabsInkBarDirective,
                            DwTabBodyComponent,
                            DwTabLinkDirective
                        ],
                        exports: [
                            DwTabComponent,
                            DwTabDirective,
                            DwTabSetComponent,
                            DwTabsNavComponent,
                            DwTabLabelDirective,
                            DwTabsInkBarDirective,
                            DwTabBodyComponent,
                            DwTabLinkDirective
                        ],
                        imports: [common.CommonModule, observers.ObserversModule, icon.DwIconModule, outlet.DwOutletModule, platform.PlatformModule]
                    },] }
        ];
        return DwTabsModule;
    }());

    exports.DwTabBodyComponent = DwTabBodyComponent;
    exports.DwTabChangeEvent = DwTabChangeEvent;
    exports.DwTabComponent = DwTabComponent;
    exports.DwTabDirective = DwTabDirective;
    exports.DwTabLabelDirective = DwTabLabelDirective;
    exports.DwTabLinkDirective = DwTabLinkDirective;
    exports.DwTabSetComponent = DwTabSetComponent;
    exports.DwTabsInkBarDirective = DwTabsInkBarDirective;
    exports.DwTabsModule = DwTabsModule;
    exports.DwTabsNavComponent = DwTabsNavComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-tabs.umd.js.map
