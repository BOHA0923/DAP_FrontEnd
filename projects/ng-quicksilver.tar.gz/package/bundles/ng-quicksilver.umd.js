(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/affix'), require('ng-quicksilver/alert'), require('ng-quicksilver/anchor'), require('ng-quicksilver/auto-complete'), require('ng-quicksilver/avatar'), require('ng-quicksilver/back-top'), require('ng-quicksilver/badge'), require('ng-quicksilver/breadcrumb'), require('ng-quicksilver/button'), require('ng-quicksilver/calendar'), require('ng-quicksilver/card'), require('ng-quicksilver/carousel'), require('ng-quicksilver/cascader'), require('ng-quicksilver/checkbox'), require('ng-quicksilver/collapse'), require('ng-quicksilver/comment'), require('ng-quicksilver/core/logger'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/trans-button'), require('ng-quicksilver/core/wave'), require('ng-quicksilver/date-picker'), require('ng-quicksilver/descriptions'), require('ng-quicksilver/divider'), require('ng-quicksilver/drawer'), require('ng-quicksilver/dropdown'), require('ng-quicksilver/empty'), require('ng-quicksilver/form'), require('ng-quicksilver/grid'), require('ng-quicksilver/i18n'), require('ng-quicksilver/icon'), require('ng-quicksilver/input'), require('ng-quicksilver/input-number'), require('ng-quicksilver/layout'), require('ng-quicksilver/list'), require('ng-quicksilver/mention'), require('ng-quicksilver/menu'), require('ng-quicksilver/message'), require('ng-quicksilver/modal'), require('ng-quicksilver/notification'), require('ng-quicksilver/page-header'), require('ng-quicksilver/pagination'), require('ng-quicksilver/popconfirm'), require('ng-quicksilver/popover'), require('ng-quicksilver/progress'), require('ng-quicksilver/radio'), require('ng-quicksilver/rate'), require('ng-quicksilver/result'), require('ng-quicksilver/select'), require('ng-quicksilver/skeleton'), require('ng-quicksilver/slider'), require('ng-quicksilver/spin'), require('ng-quicksilver/statistic'), require('ng-quicksilver/steps'), require('ng-quicksilver/switch'), require('ng-quicksilver/table'), require('ng-quicksilver/tabs'), require('ng-quicksilver/tag'), require('ng-quicksilver/time-picker'), require('ng-quicksilver/timeline'), require('ng-quicksilver/tooltip'), require('ng-quicksilver/transfer'), require('ng-quicksilver/tree'), require('ng-quicksilver/tree-select'), require('ng-quicksilver/typography'), require('ng-quicksilver/upload'), require('ng-quicksilver/version'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/environments'), require('ng-quicksilver/core/highlight'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/core/pipe'), require('ng-quicksilver/core/polyfill'), require('ng-quicksilver/core/resize-observers'), require('ng-quicksilver/core/services'), require('ng-quicksilver/core/testing'), require('ng-quicksilver/core/time'), require('ng-quicksilver/core/transition-patch'), require('ng-quicksilver/core/tree'), require('ng-quicksilver/core/types'), require('ng-quicksilver/core/util')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver', ['exports', '@angular/core', 'ng-quicksilver/affix', 'ng-quicksilver/alert', 'ng-quicksilver/anchor', 'ng-quicksilver/auto-complete', 'ng-quicksilver/avatar', 'ng-quicksilver/back-top', 'ng-quicksilver/badge', 'ng-quicksilver/breadcrumb', 'ng-quicksilver/button', 'ng-quicksilver/calendar', 'ng-quicksilver/card', 'ng-quicksilver/carousel', 'ng-quicksilver/cascader', 'ng-quicksilver/checkbox', 'ng-quicksilver/collapse', 'ng-quicksilver/comment', 'ng-quicksilver/core/logger', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/trans-button', 'ng-quicksilver/core/wave', 'ng-quicksilver/date-picker', 'ng-quicksilver/descriptions', 'ng-quicksilver/divider', 'ng-quicksilver/drawer', 'ng-quicksilver/dropdown', 'ng-quicksilver/empty', 'ng-quicksilver/form', 'ng-quicksilver/grid', 'ng-quicksilver/i18n', 'ng-quicksilver/icon', 'ng-quicksilver/input', 'ng-quicksilver/input-number', 'ng-quicksilver/layout', 'ng-quicksilver/list', 'ng-quicksilver/mention', 'ng-quicksilver/menu', 'ng-quicksilver/message', 'ng-quicksilver/modal', 'ng-quicksilver/notification', 'ng-quicksilver/page-header', 'ng-quicksilver/pagination', 'ng-quicksilver/popconfirm', 'ng-quicksilver/popover', 'ng-quicksilver/progress', 'ng-quicksilver/radio', 'ng-quicksilver/rate', 'ng-quicksilver/result', 'ng-quicksilver/select', 'ng-quicksilver/skeleton', 'ng-quicksilver/slider', 'ng-quicksilver/spin', 'ng-quicksilver/statistic', 'ng-quicksilver/steps', 'ng-quicksilver/switch', 'ng-quicksilver/table', 'ng-quicksilver/tabs', 'ng-quicksilver/tag', 'ng-quicksilver/time-picker', 'ng-quicksilver/timeline', 'ng-quicksilver/tooltip', 'ng-quicksilver/transfer', 'ng-quicksilver/tree', 'ng-quicksilver/tree-select', 'ng-quicksilver/typography', 'ng-quicksilver/upload', 'ng-quicksilver/version', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/config', 'ng-quicksilver/core/environments', 'ng-quicksilver/core/highlight', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/overlay', 'ng-quicksilver/core/pipe', 'ng-quicksilver/core/polyfill', 'ng-quicksilver/core/resize-observers', 'ng-quicksilver/core/services', 'ng-quicksilver/core/testing', 'ng-quicksilver/core/time', 'ng-quicksilver/core/transition-patch', 'ng-quicksilver/core/tree', 'ng-quicksilver/core/types', 'ng-quicksilver/core/util'], factory) :
    (global = global || self, factory(global['ng-quicksilver'] = {}, global.ng.core, global['ng-quicksilver'].affix, global['ng-quicksilver'].alert, global['ng-quicksilver'].anchor, global['ng-quicksilver']['auto-complete'], global['ng-quicksilver'].avatar, global['ng-quicksilver']['back-top'], global['ng-quicksilver'].badge, global['ng-quicksilver'].breadcrumb, global['ng-quicksilver'].button, global['ng-quicksilver'].calendar, global['ng-quicksilver'].card, global['ng-quicksilver'].carousel, global['ng-quicksilver'].cascader, global['ng-quicksilver'].checkbox, global['ng-quicksilver'].collapse, global['ng-quicksilver'].comment, global['ng-quicksilver'].core.logger, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core['trans-button'], global['ng-quicksilver'].core.wave, global['ng-quicksilver']['date-picker'], global['ng-quicksilver'].descriptions, global['ng-quicksilver'].divider, global['ng-quicksilver'].drawer, global['ng-quicksilver'].dropdown, global['ng-quicksilver'].empty, global['ng-quicksilver'].form, global['ng-quicksilver'].grid, global['ng-quicksilver'].i18n, global['ng-quicksilver'].icon, global['ng-quicksilver'].input, global['ng-quicksilver']['input-number'], global['ng-quicksilver'].layout, global['ng-quicksilver'].list, global['ng-quicksilver'].mention, global['ng-quicksilver'].menu, global['ng-quicksilver'].message, global['ng-quicksilver'].modal, global['ng-quicksilver'].notification, global['ng-quicksilver']['page-header'], global['ng-quicksilver'].pagination, global['ng-quicksilver'].popconfirm, global['ng-quicksilver'].popover, global['ng-quicksilver'].progress, global['ng-quicksilver'].radio, global['ng-quicksilver'].rate, global['ng-quicksilver'].result, global['ng-quicksilver'].select, global['ng-quicksilver'].skeleton, global['ng-quicksilver'].slider, global['ng-quicksilver'].spin, global['ng-quicksilver'].statistic, global['ng-quicksilver'].steps, global['ng-quicksilver'].switch, global['ng-quicksilver'].table, global['ng-quicksilver'].tabs, global['ng-quicksilver'].tag, global['ng-quicksilver']['time-picker'], global['ng-quicksilver'].timeline, global['ng-quicksilver'].tooltip, global['ng-quicksilver'].transfer, global['ng-quicksilver'].tree, global['ng-quicksilver']['tree-select'], global['ng-quicksilver'].typography, global['ng-quicksilver'].upload, global['ng-quicksilver'].version, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.environments, global['ng-quicksilver'].core.highlight, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].core.pipe, global['ng-quicksilver'].core.polyfill, global['ng-quicksilver'].core['resize-observers'], global['ng-quicksilver'].core.services, global['ng-quicksilver'].core.testing, global['ng-quicksilver'].core.time, global['ng-quicksilver'].core['transition-patch'], global['ng-quicksilver'].core.tree, global['ng-quicksilver'].core.types, global['ng-quicksilver'].core.util));
}(this, (function (exports, core, affix, alert, anchor, autoComplete, avatar, backTop, badge, breadcrumb, button, calendar, card, carousel, cascader, checkbox, collapse, comment, logger, noAnimation, transButton, wave, datePicker, descriptions, divider, drawer, dropdown, empty, form, grid, i18n, icon, input, inputNumber, layout, list, mention, menu, message, modal, notification, pageHeader, pagination, popconfirm, popover, progress, radio, rate, result, select, skeleton, slider, spin, statistic, steps, _switch, table, tabs, tag, timePicker, timeline, tooltip, transfer, tree, treeSelect, typography, upload, version, animation, config, environments, highlight, outlet, overlay, pipe, polyfill, resizeObservers, services, testing, time, transitionPatch, tree$1, types, util) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: ng-quicksilver.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NgQuicksilverModule = /** @class */ (function () {
        function NgQuicksilverModule() {
            logger.warnDeprecation("The `ng-quicksilver:` has been deprecated and will be removed in 10.0.0. Please use secondary entry instead.\ne.g. `import { DwButtonModule } from 'ng-quicksilver/button';`");
        }
        NgQuicksilverModule.decorators = [
            { type: core.NgModule, args: [{
                        exports: [
                            affix.DwAffixModule,
                            alert.DwAlertModule,
                            anchor.DwAnchorModule,
                            autoComplete.DwAutocompleteModule,
                            avatar.DwAvatarModule,
                            backTop.DwBackTopModule,
                            badge.DwBadgeModule,
                            button.DwButtonModule,
                            breadcrumb.DwBreadCrumbModule,
                            calendar.DwCalendarModule,
                            card.DwCardModule,
                            carousel.DwCarouselModule,
                            cascader.DwCascaderModule,
                            checkbox.DwCheckboxModule,
                            collapse.DwCollapseModule,
                            comment.DwCommentModule,
                            datePicker.DwDatePickerModule,
                            descriptions.DwDescriptionsModule,
                            divider.DwDividerModule,
                            drawer.DwDrawerModule,
                            dropdown.DwDropDownModule,
                            empty.DwEmptyModule,
                            form.DwFormModule,
                            grid.DwGridModule,
                            i18n.DwI18nModule,
                            icon.DwIconModule,
                            input.DwInputModule,
                            inputNumber.DwInputNumberModule,
                            layout.DwLayoutModule,
                            list.DwListModule,
                            mention.DwMentionModule,
                            menu.DwMenuModule,
                            message.DwMessageModule,
                            modal.DwModalModule,
                            noAnimation.DwNoAnimationModule,
                            notification.DwNotificationModule,
                            pageHeader.DwPageHeaderModule,
                            pagination.DwPaginationModule,
                            popconfirm.DwPopconfirmModule,
                            popover.DwPopoverModule,
                            progress.DwProgressModule,
                            radio.DwRadioModule,
                            rate.DwRateModule,
                            result.DwResultModule,
                            select.DwSelectModule,
                            skeleton.DwSkeletonModule,
                            slider.DwSliderModule,
                            spin.DwSpinModule,
                            statistic.DwStatisticModule,
                            steps.DwStepsModule,
                            _switch.DwSwitchModule,
                            table.DwTableModule,
                            tabs.DwTabsModule,
                            tag.DwTagModule,
                            timePicker.DwTimePickerModule,
                            timeline.DwTimelineModule,
                            tooltip.DwToolTipModule,
                            transButton.DwTransButtonModule,
                            transfer.DwTransferModule,
                            tree.DwTreeModule,
                            treeSelect.DwTreeSelectModule,
                            typography.DwTypographyModule,
                            upload.DwUploadModule,
                            wave.DwWaveModule
                        ]
                    },] }
        ];
        /** @nocollapse */
        NgQuicksilverModule.ctorParameters = function () { return []; };
        return NgQuicksilverModule;
    }());

    Object.defineProperty(exports, 'DwAffixComponent', {
        enumerable: true,
        get: function () {
            return affix.DwAffixComponent;
        }
    });
    Object.defineProperty(exports, 'DwAffixModule', {
        enumerable: true,
        get: function () {
            return affix.DwAffixModule;
        }
    });
    Object.defineProperty(exports, 'DwAlertComponent', {
        enumerable: true,
        get: function () {
            return alert.DwAlertComponent;
        }
    });
    Object.defineProperty(exports, 'DwAlertModule', {
        enumerable: true,
        get: function () {
            return alert.DwAlertModule;
        }
    });
    Object.defineProperty(exports, 'DwAnchorComponent', {
        enumerable: true,
        get: function () {
            return anchor.DwAnchorComponent;
        }
    });
    Object.defineProperty(exports, 'DwAnchorLinkComponent', {
        enumerable: true,
        get: function () {
            return anchor.DwAnchorLinkComponent;
        }
    });
    Object.defineProperty(exports, 'DwAnchorModule', {
        enumerable: true,
        get: function () {
            return anchor.DwAnchorModule;
        }
    });
    Object.defineProperty(exports, 'DW_AUTOCOMPLETE_VALUE_ACCESSOR', {
        enumerable: true,
        get: function () {
            return autoComplete.DW_AUTOCOMPLETE_VALUE_ACCESSOR;
        }
    });
    Object.defineProperty(exports, 'DwAutocompleteComponent', {
        enumerable: true,
        get: function () {
            return autoComplete.DwAutocompleteComponent;
        }
    });
    Object.defineProperty(exports, 'DwAutocompleteModule', {
        enumerable: true,
        get: function () {
            return autoComplete.DwAutocompleteModule;
        }
    });
    Object.defineProperty(exports, 'DwAutocompleteOptgroupComponent', {
        enumerable: true,
        get: function () {
            return autoComplete.DwAutocompleteOptgroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwAutocompleteOptionComponent', {
        enumerable: true,
        get: function () {
            return autoComplete.DwAutocompleteOptionComponent;
        }
    });
    Object.defineProperty(exports, 'DwAutocompleteTriggerDirective', {
        enumerable: true,
        get: function () {
            return autoComplete.DwAutocompleteTriggerDirective;
        }
    });
    Object.defineProperty(exports, 'DwOptionSelectionChange', {
        enumerable: true,
        get: function () {
            return autoComplete.DwOptionSelectionChange;
        }
    });
    Object.defineProperty(exports, 'getDwAutocompleteMissingPanelError', {
        enumerable: true,
        get: function () {
            return autoComplete.getDwAutocompleteMissingPanelError;
        }
    });
    Object.defineProperty(exports, 'DwAvatarComponent', {
        enumerable: true,
        get: function () {
            return avatar.DwAvatarComponent;
        }
    });
    Object.defineProperty(exports, 'DwAvatarModule', {
        enumerable: true,
        get: function () {
            return avatar.DwAvatarModule;
        }
    });
    Object.defineProperty(exports, 'DwBackTopComponent', {
        enumerable: true,
        get: function () {
            return backTop.DwBackTopComponent;
        }
    });
    Object.defineProperty(exports, 'DwBackTopModule', {
        enumerable: true,
        get: function () {
            return backTop.DwBackTopModule;
        }
    });
    Object.defineProperty(exports, 'DwBadgeComponent', {
        enumerable: true,
        get: function () {
            return badge.DwBadgeComponent;
        }
    });
    Object.defineProperty(exports, 'DwBadgeModule', {
        enumerable: true,
        get: function () {
            return badge.DwBadgeModule;
        }
    });
    Object.defineProperty(exports, 'DwBreadCrumbComponent', {
        enumerable: true,
        get: function () {
            return breadcrumb.DwBreadCrumbComponent;
        }
    });
    Object.defineProperty(exports, 'DwBreadCrumbItemComponent', {
        enumerable: true,
        get: function () {
            return breadcrumb.DwBreadCrumbItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwBreadCrumbModule', {
        enumerable: true,
        get: function () {
            return breadcrumb.DwBreadCrumbModule;
        }
    });
    Object.defineProperty(exports, 'DwBreadCrumbSeparatorComponent', {
        enumerable: true,
        get: function () {
            return breadcrumb.DwBreadCrumbSeparatorComponent;
        }
    });
    Object.defineProperty(exports, 'DwButtonComponent', {
        enumerable: true,
        get: function () {
            return button.DwButtonComponent;
        }
    });
    Object.defineProperty(exports, 'DwButtonGroupComponent', {
        enumerable: true,
        get: function () {
            return button.DwButtonGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwButtonModule', {
        enumerable: true,
        get: function () {
            return button.DwButtonModule;
        }
    });
    Object.defineProperty(exports, 'DwCalendarComponent', {
        enumerable: true,
        get: function () {
            return calendar.DwCalendarComponent;
        }
    });
    Object.defineProperty(exports, 'DwCalendarHeaderComponent', {
        enumerable: true,
        get: function () {
            return calendar.DwCalendarHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'DwCalendarModule', {
        enumerable: true,
        get: function () {
            return calendar.DwCalendarModule;
        }
    });
    Object.defineProperty(exports, 'DwDateCellDirective', {
        enumerable: true,
        get: function () {
            return calendar.DwDateCellDirective;
        }
    });
    Object.defineProperty(exports, 'DwDateFullCellDirective', {
        enumerable: true,
        get: function () {
            return calendar.DwDateFullCellDirective;
        }
    });
    Object.defineProperty(exports, 'DwMonthCellDirective', {
        enumerable: true,
        get: function () {
            return calendar.DwMonthCellDirective;
        }
    });
    Object.defineProperty(exports, 'DwMonthFullCellDirective', {
        enumerable: true,
        get: function () {
            return calendar.DwMonthFullCellDirective;
        }
    });
    Object.defineProperty(exports, 'DwCardComponent', {
        enumerable: true,
        get: function () {
            return card.DwCardComponent;
        }
    });
    Object.defineProperty(exports, 'DwCardGridDirective', {
        enumerable: true,
        get: function () {
            return card.DwCardGridDirective;
        }
    });
    Object.defineProperty(exports, 'DwCardLoadingComponent', {
        enumerable: true,
        get: function () {
            return card.DwCardLoadingComponent;
        }
    });
    Object.defineProperty(exports, 'DwCardMetaComponent', {
        enumerable: true,
        get: function () {
            return card.DwCardMetaComponent;
        }
    });
    Object.defineProperty(exports, 'DwCardModule', {
        enumerable: true,
        get: function () {
            return card.DwCardModule;
        }
    });
    Object.defineProperty(exports, 'DwCardTabComponent', {
        enumerable: true,
        get: function () {
            return card.DwCardTabComponent;
        }
    });
    Object.defineProperty(exports, 'DW_CAROUSEL_CUSTOM_STRATEGIES', {
        enumerable: true,
        get: function () {
            return carousel.DW_CAROUSEL_CUSTOM_STRATEGIES;
        }
    });
    Object.defineProperty(exports, 'DwCarouselBaseStrategy', {
        enumerable: true,
        get: function () {
            return carousel.DwCarouselBaseStrategy;
        }
    });
    Object.defineProperty(exports, 'DwCarouselComponent', {
        enumerable: true,
        get: function () {
            return carousel.DwCarouselComponent;
        }
    });
    Object.defineProperty(exports, 'DwCarouselContentDirective', {
        enumerable: true,
        get: function () {
            return carousel.DwCarouselContentDirective;
        }
    });
    Object.defineProperty(exports, 'DwCarouselModule', {
        enumerable: true,
        get: function () {
            return carousel.DwCarouselModule;
        }
    });
    Object.defineProperty(exports, 'DwCascaderComponent', {
        enumerable: true,
        get: function () {
            return cascader.DwCascaderComponent;
        }
    });
    Object.defineProperty(exports, 'DwCascaderModule', {
        enumerable: true,
        get: function () {
            return cascader.DwCascaderModule;
        }
    });
    Object.defineProperty(exports, 'DwCascaderOptionComponent', {
        enumerable: true,
        get: function () {
            return cascader.DwCascaderOptionComponent;
        }
    });
    Object.defineProperty(exports, 'DwCascaderService', {
        enumerable: true,
        get: function () {
            return cascader.DwCascaderService;
        }
    });
    Object.defineProperty(exports, 'isChildOption', {
        enumerable: true,
        get: function () {
            return cascader.isChildOption;
        }
    });
    Object.defineProperty(exports, 'isParentOption', {
        enumerable: true,
        get: function () {
            return cascader.isParentOption;
        }
    });
    Object.defineProperty(exports, 'isShowSearchObject', {
        enumerable: true,
        get: function () {
            return cascader.isShowSearchObject;
        }
    });
    Object.defineProperty(exports, 'DwCheckboxComponent', {
        enumerable: true,
        get: function () {
            return checkbox.DwCheckboxComponent;
        }
    });
    Object.defineProperty(exports, 'DwCheckboxGroupComponent', {
        enumerable: true,
        get: function () {
            return checkbox.DwCheckboxGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwCheckboxModule', {
        enumerable: true,
        get: function () {
            return checkbox.DwCheckboxModule;
        }
    });
    Object.defineProperty(exports, 'DwCheckboxWrapperComponent', {
        enumerable: true,
        get: function () {
            return checkbox.DwCheckboxWrapperComponent;
        }
    });
    Object.defineProperty(exports, 'DwCollapseComponent', {
        enumerable: true,
        get: function () {
            return collapse.DwCollapseComponent;
        }
    });
    Object.defineProperty(exports, 'DwCollapseModule', {
        enumerable: true,
        get: function () {
            return collapse.DwCollapseModule;
        }
    });
    Object.defineProperty(exports, 'DwCollapsePanelComponent', {
        enumerable: true,
        get: function () {
            return collapse.DwCollapsePanelComponent;
        }
    });
    Object.defineProperty(exports, 'DwCommentActionComponent', {
        enumerable: true,
        get: function () {
            return comment.DwCommentActionComponent;
        }
    });
    Object.defineProperty(exports, 'DwCommentActionHostDirective', {
        enumerable: true,
        get: function () {
            return comment.DwCommentActionHostDirective;
        }
    });
    Object.defineProperty(exports, 'DwCommentAvatarDirective', {
        enumerable: true,
        get: function () {
            return comment.DwCommentAvatarDirective;
        }
    });
    Object.defineProperty(exports, 'DwCommentComponent', {
        enumerable: true,
        get: function () {
            return comment.DwCommentComponent;
        }
    });
    Object.defineProperty(exports, 'DwCommentContentDirective', {
        enumerable: true,
        get: function () {
            return comment.DwCommentContentDirective;
        }
    });
    Object.defineProperty(exports, 'DwCommentModule', {
        enumerable: true,
        get: function () {
            return comment.DwCommentModule;
        }
    });
    Object.defineProperty(exports, 'PREFIX', {
        enumerable: true,
        get: function () {
            return logger.PREFIX;
        }
    });
    Object.defineProperty(exports, 'log', {
        enumerable: true,
        get: function () {
            return logger.log;
        }
    });
    Object.defineProperty(exports, 'warn', {
        enumerable: true,
        get: function () {
            return logger.warn;
        }
    });
    Object.defineProperty(exports, 'warnDeprecation', {
        enumerable: true,
        get: function () {
            return logger.warnDeprecation;
        }
    });
    Object.defineProperty(exports, 'DwNoAnimationDirective', {
        enumerable: true,
        get: function () {
            return noAnimation.DwNoAnimationDirective;
        }
    });
    Object.defineProperty(exports, 'DwNoAnimationModule', {
        enumerable: true,
        get: function () {
            return noAnimation.DwNoAnimationModule;
        }
    });
    Object.defineProperty(exports, 'DwTransButtonDirective', {
        enumerable: true,
        get: function () {
            return transButton.DwTransButtonDirective;
        }
    });
    Object.defineProperty(exports, 'DwTransButtonModule', {
        enumerable: true,
        get: function () {
            return transButton.DwTransButtonModule;
        }
    });
    Object.defineProperty(exports, 'DW_WAVE_GLOBAL_CONFIG', {
        enumerable: true,
        get: function () {
            return wave.DW_WAVE_GLOBAL_CONFIG;
        }
    });
    Object.defineProperty(exports, 'DW_WAVE_GLOBAL_CONFIG_FACTORY', {
        enumerable: true,
        get: function () {
            return wave.DW_WAVE_GLOBAL_CONFIG_FACTORY;
        }
    });
    Object.defineProperty(exports, 'DW_WAVE_GLOBAL_DEFAULT_CONFIG', {
        enumerable: true,
        get: function () {
            return wave.DW_WAVE_GLOBAL_DEFAULT_CONFIG;
        }
    });
    Object.defineProperty(exports, 'DwWaveDirective', {
        enumerable: true,
        get: function () {
            return wave.DwWaveDirective;
        }
    });
    Object.defineProperty(exports, 'DwWaveModule', {
        enumerable: true,
        get: function () {
            return wave.DwWaveModule;
        }
    });
    Object.defineProperty(exports, 'DwWaveRenderer', {
        enumerable: true,
        get: function () {
            return wave.DwWaveRenderer;
        }
    });
    Object.defineProperty(exports, 'DwDatePickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.DwDatePickerComponent;
        }
    });
    Object.defineProperty(exports, 'DwDatePickerModule', {
        enumerable: true,
        get: function () {
            return datePicker.DwDatePickerModule;
        }
    });
    Object.defineProperty(exports, 'DwMonthPickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.DwMonthPickerComponent;
        }
    });
    Object.defineProperty(exports, 'DwRangePickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.DwRangePickerComponent;
        }
    });
    Object.defineProperty(exports, 'DwWeekPickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.DwWeekPickerComponent;
        }
    });
    Object.defineProperty(exports, 'DwYearPickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.DwYearPickerComponent;
        }
    });
    Object.defineProperty(exports, 'LibPackerModule', {
        enumerable: true,
        get: function () {
            return datePicker.LibPackerModule;
        }
    });
    Object.defineProperty(exports, 'PREFIX_CLASS', {
        enumerable: true,
        get: function () {
            return datePicker.PREFIX_CLASS;
        }
    });
    Object.defineProperty(exports, 'getTimeConfig', {
        enumerable: true,
        get: function () {
            return datePicker.getTimeConfig;
        }
    });
    Object.defineProperty(exports, 'isAllowedDate', {
        enumerable: true,
        get: function () {
            return datePicker.isAllowedDate;
        }
    });
    Object.defineProperty(exports, 'isTimeValid', {
        enumerable: true,
        get: function () {
            return datePicker.isTimeValid;
        }
    });
    Object.defineProperty(exports, 'isTimeValidByConfig', {
        enumerable: true,
        get: function () {
            return datePicker.isTimeValidByConfig;
        }
    });
    Object.defineProperty(exports, 'transCompatFormat', {
        enumerable: true,
        get: function () {
            return datePicker.transCompatFormat;
        }
    });
    Object.defineProperty(exports, 'ɵAbstractPanelHeader', {
        enumerable: true,
        get: function () {
            return datePicker.ɵAbstractPanelHeader;
        }
    });
    Object.defineProperty(exports, 'ɵAbstractTable', {
        enumerable: true,
        get: function () {
            return datePicker.ɵAbstractTable;
        }
    });
    Object.defineProperty(exports, 'ɵCalendarFooterComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵCalendarFooterComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDateHeaderComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDateHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDatePickerService', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDatePickerService;
        }
    });
    Object.defineProperty(exports, 'ɵDateRangePopupComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDateRangePopupComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDateTableComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDateTableComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDecadeHeaderComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDecadeHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDecadeTableComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDecadeTableComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwPickerComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵDwPickerComponent;
        }
    });
    Object.defineProperty(exports, 'ɵInnerPopupComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵInnerPopupComponent;
        }
    });
    Object.defineProperty(exports, 'ɵMonthHeaderComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵMonthHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'ɵMonthTableComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵMonthTableComponent;
        }
    });
    Object.defineProperty(exports, 'ɵYearHeaderComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵYearHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'ɵYearTableComponent', {
        enumerable: true,
        get: function () {
            return datePicker.ɵYearTableComponent;
        }
    });
    Object.defineProperty(exports, 'DwDescriptionsComponent', {
        enumerable: true,
        get: function () {
            return descriptions.DwDescriptionsComponent;
        }
    });
    Object.defineProperty(exports, 'DwDescriptionsItemComponent', {
        enumerable: true,
        get: function () {
            return descriptions.DwDescriptionsItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwDescriptionsModule', {
        enumerable: true,
        get: function () {
            return descriptions.DwDescriptionsModule;
        }
    });
    Object.defineProperty(exports, 'DwDividerComponent', {
        enumerable: true,
        get: function () {
            return divider.DwDividerComponent;
        }
    });
    Object.defineProperty(exports, 'DwDividerModule', {
        enumerable: true,
        get: function () {
            return divider.DwDividerModule;
        }
    });
    Object.defineProperty(exports, 'DRAWER_ANIMATE_DURATION', {
        enumerable: true,
        get: function () {
            return drawer.DRAWER_ANIMATE_DURATION;
        }
    });
    Object.defineProperty(exports, 'DrawerBuilderForService', {
        enumerable: true,
        get: function () {
            return drawer.DrawerBuilderForService;
        }
    });
    Object.defineProperty(exports, 'DwDrawerComponent', {
        enumerable: true,
        get: function () {
            return drawer.DwDrawerComponent;
        }
    });
    Object.defineProperty(exports, 'DwDrawerModule', {
        enumerable: true,
        get: function () {
            return drawer.DwDrawerModule;
        }
    });
    Object.defineProperty(exports, 'DwDrawerRef', {
        enumerable: true,
        get: function () {
            return drawer.DwDrawerRef;
        }
    });
    Object.defineProperty(exports, 'DwDrawerService', {
        enumerable: true,
        get: function () {
            return drawer.DwDrawerService;
        }
    });
    Object.defineProperty(exports, 'DwDrawerServiceModule', {
        enumerable: true,
        get: function () {
            return drawer.DwDrawerServiceModule;
        }
    });
    Object.defineProperty(exports, 'DwContextMenuService', {
        enumerable: true,
        get: function () {
            return dropdown.DwContextMenuService;
        }
    });
    Object.defineProperty(exports, 'DwContextMenuServiceModule', {
        enumerable: true,
        get: function () {
            return dropdown.DwContextMenuServiceModule;
        }
    });
    Object.defineProperty(exports, 'DwDropDownADirective', {
        enumerable: true,
        get: function () {
            return dropdown.DwDropDownADirective;
        }
    });
    Object.defineProperty(exports, 'DwDropDownDirective', {
        enumerable: true,
        get: function () {
            return dropdown.DwDropDownDirective;
        }
    });
    Object.defineProperty(exports, 'DwDropDownModule', {
        enumerable: true,
        get: function () {
            return dropdown.DwDropDownModule;
        }
    });
    Object.defineProperty(exports, 'DwDropdownButtonDirective', {
        enumerable: true,
        get: function () {
            return dropdown.DwDropdownButtonDirective;
        }
    });
    Object.defineProperty(exports, 'DwDropdownMenuComponent', {
        enumerable: true,
        get: function () {
            return dropdown.DwDropdownMenuComponent;
        }
    });
    Object.defineProperty(exports, 'DW_EMPTY_COMPONENT_NAME', {
        enumerable: true,
        get: function () {
            return empty.DW_EMPTY_COMPONENT_NAME;
        }
    });
    Object.defineProperty(exports, 'DwEmbedEmptyComponent', {
        enumerable: true,
        get: function () {
            return empty.DwEmbedEmptyComponent;
        }
    });
    Object.defineProperty(exports, 'DwEmptyComponent', {
        enumerable: true,
        get: function () {
            return empty.DwEmptyComponent;
        }
    });
    Object.defineProperty(exports, 'DwEmptyDefaultComponent', {
        enumerable: true,
        get: function () {
            return empty.DwEmptyDefaultComponent;
        }
    });
    Object.defineProperty(exports, 'DwEmptyModule', {
        enumerable: true,
        get: function () {
            return empty.DwEmptyModule;
        }
    });
    Object.defineProperty(exports, 'DwEmptySimpleComponent', {
        enumerable: true,
        get: function () {
            return empty.DwEmptySimpleComponent;
        }
    });
    Object.defineProperty(exports, 'DwFormControlComponent', {
        enumerable: true,
        get: function () {
            return form.DwFormControlComponent;
        }
    });
    Object.defineProperty(exports, 'DwFormDirective', {
        enumerable: true,
        get: function () {
            return form.DwFormDirective;
        }
    });
    Object.defineProperty(exports, 'DwFormItemComponent', {
        enumerable: true,
        get: function () {
            return form.DwFormItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwFormLabelComponent', {
        enumerable: true,
        get: function () {
            return form.DwFormLabelComponent;
        }
    });
    Object.defineProperty(exports, 'DwFormModule', {
        enumerable: true,
        get: function () {
            return form.DwFormModule;
        }
    });
    Object.defineProperty(exports, 'DwFormSplitComponent', {
        enumerable: true,
        get: function () {
            return form.DwFormSplitComponent;
        }
    });
    Object.defineProperty(exports, 'DwFormTextComponent', {
        enumerable: true,
        get: function () {
            return form.DwFormTextComponent;
        }
    });
    Object.defineProperty(exports, 'DwColDirective', {
        enumerable: true,
        get: function () {
            return grid.DwColDirective;
        }
    });
    Object.defineProperty(exports, 'DwGridModule', {
        enumerable: true,
        get: function () {
            return grid.DwGridModule;
        }
    });
    Object.defineProperty(exports, 'DwRowDirective', {
        enumerable: true,
        get: function () {
            return grid.DwRowDirective;
        }
    });
    Object.defineProperty(exports, 'DATE_HELPER_SERVICE_FACTORY', {
        enumerable: true,
        get: function () {
            return i18n.DATE_HELPER_SERVICE_FACTORY;
        }
    });
    Object.defineProperty(exports, 'DW_DATE_CONFIG', {
        enumerable: true,
        get: function () {
            return i18n.DW_DATE_CONFIG;
        }
    });
    Object.defineProperty(exports, 'DW_DATE_CONFIG_DEFAULT', {
        enumerable: true,
        get: function () {
            return i18n.DW_DATE_CONFIG_DEFAULT;
        }
    });
    Object.defineProperty(exports, 'DW_DATE_FNS_COMPATIBLE', {
        enumerable: true,
        get: function () {
            return i18n.DW_DATE_FNS_COMPATIBLE;
        }
    });
    Object.defineProperty(exports, 'DW_DATE_LOCALE', {
        enumerable: true,
        get: function () {
            return i18n.DW_DATE_LOCALE;
        }
    });
    Object.defineProperty(exports, 'DW_I18N', {
        enumerable: true,
        get: function () {
            return i18n.DW_I18N;
        }
    });
    Object.defineProperty(exports, 'DateHelperByDateFns', {
        enumerable: true,
        get: function () {
            return i18n.DateHelperByDateFns;
        }
    });
    Object.defineProperty(exports, 'DateHelperByDatePipe', {
        enumerable: true,
        get: function () {
            return i18n.DateHelperByDatePipe;
        }
    });
    Object.defineProperty(exports, 'DateHelperService', {
        enumerable: true,
        get: function () {
            return i18n.DateHelperService;
        }
    });
    Object.defineProperty(exports, 'DwI18nModule', {
        enumerable: true,
        get: function () {
            return i18n.DwI18nModule;
        }
    });
    Object.defineProperty(exports, 'DwI18nPipe', {
        enumerable: true,
        get: function () {
            return i18n.DwI18nPipe;
        }
    });
    Object.defineProperty(exports, 'DwI18nService', {
        enumerable: true,
        get: function () {
            return i18n.DwI18nService;
        }
    });
    Object.defineProperty(exports, 'ar_EG', {
        enumerable: true,
        get: function () {
            return i18n.ar_EG;
        }
    });
    Object.defineProperty(exports, 'az_AZ', {
        enumerable: true,
        get: function () {
            return i18n.az_AZ;
        }
    });
    Object.defineProperty(exports, 'bg_BG', {
        enumerable: true,
        get: function () {
            return i18n.bg_BG;
        }
    });
    Object.defineProperty(exports, 'ca_ES', {
        enumerable: true,
        get: function () {
            return i18n.ca_ES;
        }
    });
    Object.defineProperty(exports, 'convertTokens', {
        enumerable: true,
        get: function () {
            return i18n.convertTokens;
        }
    });
    Object.defineProperty(exports, 'cs_CZ', {
        enumerable: true,
        get: function () {
            return i18n.cs_CZ;
        }
    });
    Object.defineProperty(exports, 'da_DK', {
        enumerable: true,
        get: function () {
            return i18n.da_DK;
        }
    });
    Object.defineProperty(exports, 'de_DE', {
        enumerable: true,
        get: function () {
            return i18n.de_DE;
        }
    });
    Object.defineProperty(exports, 'el_GR', {
        enumerable: true,
        get: function () {
            return i18n.el_GR;
        }
    });
    Object.defineProperty(exports, 'en_GB', {
        enumerable: true,
        get: function () {
            return i18n.en_GB;
        }
    });
    Object.defineProperty(exports, 'en_US', {
        enumerable: true,
        get: function () {
            return i18n.en_US;
        }
    });
    Object.defineProperty(exports, 'es_ES', {
        enumerable: true,
        get: function () {
            return i18n.es_ES;
        }
    });
    Object.defineProperty(exports, 'et_EE', {
        enumerable: true,
        get: function () {
            return i18n.et_EE;
        }
    });
    Object.defineProperty(exports, 'fa_IR', {
        enumerable: true,
        get: function () {
            return i18n.fa_IR;
        }
    });
    Object.defineProperty(exports, 'fi_FI', {
        enumerable: true,
        get: function () {
            return i18n.fi_FI;
        }
    });
    Object.defineProperty(exports, 'fr_BE', {
        enumerable: true,
        get: function () {
            return i18n.fr_BE;
        }
    });
    Object.defineProperty(exports, 'fr_FR', {
        enumerable: true,
        get: function () {
            return i18n.fr_FR;
        }
    });
    Object.defineProperty(exports, 'he_IL', {
        enumerable: true,
        get: function () {
            return i18n.he_IL;
        }
    });
    Object.defineProperty(exports, 'hi_IN', {
        enumerable: true,
        get: function () {
            return i18n.hi_IN;
        }
    });
    Object.defineProperty(exports, 'hr_HR', {
        enumerable: true,
        get: function () {
            return i18n.hr_HR;
        }
    });
    Object.defineProperty(exports, 'hu_HU', {
        enumerable: true,
        get: function () {
            return i18n.hu_HU;
        }
    });
    Object.defineProperty(exports, 'hy_AM', {
        enumerable: true,
        get: function () {
            return i18n.hy_AM;
        }
    });
    Object.defineProperty(exports, 'id_ID', {
        enumerable: true,
        get: function () {
            return i18n.id_ID;
        }
    });
    Object.defineProperty(exports, 'is_IS', {
        enumerable: true,
        get: function () {
            return i18n.is_IS;
        }
    });
    Object.defineProperty(exports, 'it_IT', {
        enumerable: true,
        get: function () {
            return i18n.it_IT;
        }
    });
    Object.defineProperty(exports, 'ja_JP', {
        enumerable: true,
        get: function () {
            return i18n.ja_JP;
        }
    });
    Object.defineProperty(exports, 'ka_GE', {
        enumerable: true,
        get: function () {
            return i18n.ka_GE;
        }
    });
    Object.defineProperty(exports, 'kn_IN', {
        enumerable: true,
        get: function () {
            return i18n.kn_IN;
        }
    });
    Object.defineProperty(exports, 'ko_KR', {
        enumerable: true,
        get: function () {
            return i18n.ko_KR;
        }
    });
    Object.defineProperty(exports, 'ku_IQ', {
        enumerable: true,
        get: function () {
            return i18n.ku_IQ;
        }
    });
    Object.defineProperty(exports, 'lv_LV', {
        enumerable: true,
        get: function () {
            return i18n.lv_LV;
        }
    });
    Object.defineProperty(exports, 'mergeDateConfig', {
        enumerable: true,
        get: function () {
            return i18n.mergeDateConfig;
        }
    });
    Object.defineProperty(exports, 'mk_MK', {
        enumerable: true,
        get: function () {
            return i18n.mk_MK;
        }
    });
    Object.defineProperty(exports, 'mn_MN', {
        enumerable: true,
        get: function () {
            return i18n.mn_MN;
        }
    });
    Object.defineProperty(exports, 'ms_MY', {
        enumerable: true,
        get: function () {
            return i18n.ms_MY;
        }
    });
    Object.defineProperty(exports, 'nb_NO', {
        enumerable: true,
        get: function () {
            return i18n.nb_NO;
        }
    });
    Object.defineProperty(exports, 'ne_NP', {
        enumerable: true,
        get: function () {
            return i18n.ne_NP;
        }
    });
    Object.defineProperty(exports, 'nl_BE', {
        enumerable: true,
        get: function () {
            return i18n.nl_BE;
        }
    });
    Object.defineProperty(exports, 'nl_NL', {
        enumerable: true,
        get: function () {
            return i18n.nl_NL;
        }
    });
    Object.defineProperty(exports, 'pl_PL', {
        enumerable: true,
        get: function () {
            return i18n.pl_PL;
        }
    });
    Object.defineProperty(exports, 'pt_BR', {
        enumerable: true,
        get: function () {
            return i18n.pt_BR;
        }
    });
    Object.defineProperty(exports, 'pt_PT', {
        enumerable: true,
        get: function () {
            return i18n.pt_PT;
        }
    });
    Object.defineProperty(exports, 'ro_RO', {
        enumerable: true,
        get: function () {
            return i18n.ro_RO;
        }
    });
    Object.defineProperty(exports, 'ru_RU', {
        enumerable: true,
        get: function () {
            return i18n.ru_RU;
        }
    });
    Object.defineProperty(exports, 'sk_SK', {
        enumerable: true,
        get: function () {
            return i18n.sk_SK;
        }
    });
    Object.defineProperty(exports, 'sl_SI', {
        enumerable: true,
        get: function () {
            return i18n.sl_SI;
        }
    });
    Object.defineProperty(exports, 'sr_RS', {
        enumerable: true,
        get: function () {
            return i18n.sr_RS;
        }
    });
    Object.defineProperty(exports, 'sv_SE', {
        enumerable: true,
        get: function () {
            return i18n.sv_SE;
        }
    });
    Object.defineProperty(exports, 'ta_IN', {
        enumerable: true,
        get: function () {
            return i18n.ta_IN;
        }
    });
    Object.defineProperty(exports, 'th_TH', {
        enumerable: true,
        get: function () {
            return i18n.th_TH;
        }
    });
    Object.defineProperty(exports, 'tr_TR', {
        enumerable: true,
        get: function () {
            return i18n.tr_TR;
        }
    });
    Object.defineProperty(exports, 'uk_UA', {
        enumerable: true,
        get: function () {
            return i18n.uk_UA;
        }
    });
    Object.defineProperty(exports, 'vi_VN', {
        enumerable: true,
        get: function () {
            return i18n.vi_VN;
        }
    });
    Object.defineProperty(exports, 'zh_CN', {
        enumerable: true,
        get: function () {
            return i18n.zh_CN;
        }
    });
    Object.defineProperty(exports, 'zh_TW', {
        enumerable: true,
        get: function () {
            return i18n.zh_TW;
        }
    });
    Object.defineProperty(exports, 'DEFAULT_TWOTONE_COLOR', {
        enumerable: true,
        get: function () {
            return icon.DEFAULT_TWOTONE_COLOR;
        }
    });
    Object.defineProperty(exports, 'DW_ICONS', {
        enumerable: true,
        get: function () {
            return icon.DW_ICONS;
        }
    });
    Object.defineProperty(exports, 'DW_ICONS_PATCH', {
        enumerable: true,
        get: function () {
            return icon.DW_ICONS_PATCH;
        }
    });
    Object.defineProperty(exports, 'DW_ICON_DEFAULT_TWOTONE_COLOR', {
        enumerable: true,
        get: function () {
            return icon.DW_ICON_DEFAULT_TWOTONE_COLOR;
        }
    });
    Object.defineProperty(exports, 'DwIconDirective', {
        enumerable: true,
        get: function () {
            return icon.DwIconDirective;
        }
    });
    Object.defineProperty(exports, 'DwIconModule', {
        enumerable: true,
        get: function () {
            return icon.DwIconModule;
        }
    });
    Object.defineProperty(exports, 'DwIconPatchService', {
        enumerable: true,
        get: function () {
            return icon.DwIconPatchService;
        }
    });
    Object.defineProperty(exports, 'DwIconService', {
        enumerable: true,
        get: function () {
            return icon.DwIconService;
        }
    });
    Object.defineProperty(exports, 'DwAutosizeDirective', {
        enumerable: true,
        get: function () {
            return input.DwAutosizeDirective;
        }
    });
    Object.defineProperty(exports, 'DwInputDirective', {
        enumerable: true,
        get: function () {
            return input.DwInputDirective;
        }
    });
    Object.defineProperty(exports, 'DwInputGroupComponent', {
        enumerable: true,
        get: function () {
            return input.DwInputGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwInputGroupSlotComponent', {
        enumerable: true,
        get: function () {
            return input.DwInputGroupSlotComponent;
        }
    });
    Object.defineProperty(exports, 'DwInputGroupWhitSuffixOrPrefixDirective', {
        enumerable: true,
        get: function () {
            return input.DwInputGroupWhitSuffixOrPrefixDirective;
        }
    });
    Object.defineProperty(exports, 'DwInputModule', {
        enumerable: true,
        get: function () {
            return input.DwInputModule;
        }
    });
    Object.defineProperty(exports, 'DwInputNumberComponent', {
        enumerable: true,
        get: function () {
            return inputNumber.DwInputNumberComponent;
        }
    });
    Object.defineProperty(exports, 'DwInputNumberModule', {
        enumerable: true,
        get: function () {
            return inputNumber.DwInputNumberModule;
        }
    });
    Object.defineProperty(exports, 'DwContentComponent', {
        enumerable: true,
        get: function () {
            return layout.DwContentComponent;
        }
    });
    Object.defineProperty(exports, 'DwFooterComponent', {
        enumerable: true,
        get: function () {
            return layout.DwFooterComponent;
        }
    });
    Object.defineProperty(exports, 'DwHeaderComponent', {
        enumerable: true,
        get: function () {
            return layout.DwHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'DwLayoutComponent', {
        enumerable: true,
        get: function () {
            return layout.DwLayoutComponent;
        }
    });
    Object.defineProperty(exports, 'DwLayoutModule', {
        enumerable: true,
        get: function () {
            return layout.DwLayoutModule;
        }
    });
    Object.defineProperty(exports, 'DwSiderComponent', {
        enumerable: true,
        get: function () {
            return layout.DwSiderComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwSiderTriggerComponent', {
        enumerable: true,
        get: function () {
            return layout.ɵDwSiderTriggerComponent;
        }
    });
    Object.defineProperty(exports, 'DwListComponent', {
        enumerable: true,
        get: function () {
            return list.DwListComponent;
        }
    });
    Object.defineProperty(exports, 'DwListEmptyComponent', {
        enumerable: true,
        get: function () {
            return list.DwListEmptyComponent;
        }
    });
    Object.defineProperty(exports, 'DwListFooterComponent', {
        enumerable: true,
        get: function () {
            return list.DwListFooterComponent;
        }
    });
    Object.defineProperty(exports, 'DwListGridDirective', {
        enumerable: true,
        get: function () {
            return list.DwListGridDirective;
        }
    });
    Object.defineProperty(exports, 'DwListHeaderComponent', {
        enumerable: true,
        get: function () {
            return list.DwListHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemActionComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemActionComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemActionsComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemActionsComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemExtraComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemExtraComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemMetaAvatarComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemMetaAvatarComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemMetaComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemMetaComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemMetaDescriptionComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemMetaDescriptionComponent;
        }
    });
    Object.defineProperty(exports, 'DwListItemMetaTitleComponent', {
        enumerable: true,
        get: function () {
            return list.DwListItemMetaTitleComponent;
        }
    });
    Object.defineProperty(exports, 'DwListLoadMoreDirective', {
        enumerable: true,
        get: function () {
            return list.DwListLoadMoreDirective;
        }
    });
    Object.defineProperty(exports, 'DwListModule', {
        enumerable: true,
        get: function () {
            return list.DwListModule;
        }
    });
    Object.defineProperty(exports, 'DwListPaginationComponent', {
        enumerable: true,
        get: function () {
            return list.DwListPaginationComponent;
        }
    });
    Object.defineProperty(exports, 'DW_MENTION_TRIGGER_ACCESSOR', {
        enumerable: true,
        get: function () {
            return mention.DW_MENTION_TRIGGER_ACCESSOR;
        }
    });
    Object.defineProperty(exports, 'DwMentionComponent', {
        enumerable: true,
        get: function () {
            return mention.DwMentionComponent;
        }
    });
    Object.defineProperty(exports, 'DwMentionModule', {
        enumerable: true,
        get: function () {
            return mention.DwMentionModule;
        }
    });
    Object.defineProperty(exports, 'DwMentionService', {
        enumerable: true,
        get: function () {
            return mention.DwMentionService;
        }
    });
    Object.defineProperty(exports, 'DwMentionSuggestionDirective', {
        enumerable: true,
        get: function () {
            return mention.DwMentionSuggestionDirective;
        }
    });
    Object.defineProperty(exports, 'DwMentionTriggerDirective', {
        enumerable: true,
        get: function () {
            return mention.DwMentionTriggerDirective;
        }
    });
    Object.defineProperty(exports, 'DwIsMenuInsideDropDownToken', {
        enumerable: true,
        get: function () {
            return menu.DwIsMenuInsideDropDownToken;
        }
    });
    Object.defineProperty(exports, 'DwMenuDirective', {
        enumerable: true,
        get: function () {
            return menu.DwMenuDirective;
        }
    });
    Object.defineProperty(exports, 'DwMenuDividerDirective', {
        enumerable: true,
        get: function () {
            return menu.DwMenuDividerDirective;
        }
    });
    Object.defineProperty(exports, 'DwMenuGroupComponent', {
        enumerable: true,
        get: function () {
            return menu.DwMenuGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwMenuItemDirective', {
        enumerable: true,
        get: function () {
            return menu.DwMenuItemDirective;
        }
    });
    Object.defineProperty(exports, 'DwMenuModule', {
        enumerable: true,
        get: function () {
            return menu.DwMenuModule;
        }
    });
    Object.defineProperty(exports, 'DwMenuServiceLocalToken', {
        enumerable: true,
        get: function () {
            return menu.DwMenuServiceLocalToken;
        }
    });
    Object.defineProperty(exports, 'DwSubMenuComponent', {
        enumerable: true,
        get: function () {
            return menu.DwSubMenuComponent;
        }
    });
    Object.defineProperty(exports, 'DwSubMenuTitleComponent', {
        enumerable: true,
        get: function () {
            return menu.DwSubMenuTitleComponent;
        }
    });
    Object.defineProperty(exports, 'DwSubmenuInlineChildComponent', {
        enumerable: true,
        get: function () {
            return menu.DwSubmenuInlineChildComponent;
        }
    });
    Object.defineProperty(exports, 'DwSubmenuNoneInlineChildComponent', {
        enumerable: true,
        get: function () {
            return menu.DwSubmenuNoneInlineChildComponent;
        }
    });
    Object.defineProperty(exports, 'DwSubmenuService', {
        enumerable: true,
        get: function () {
            return menu.DwSubmenuService;
        }
    });
    Object.defineProperty(exports, 'MenuDropDownTokenFactory', {
        enumerable: true,
        get: function () {
            return menu.MenuDropDownTokenFactory;
        }
    });
    Object.defineProperty(exports, 'MenuGroupFactory', {
        enumerable: true,
        get: function () {
            return menu.MenuGroupFactory;
        }
    });
    Object.defineProperty(exports, 'MenuService', {
        enumerable: true,
        get: function () {
            return menu.MenuService;
        }
    });
    Object.defineProperty(exports, 'MenuServiceFactory', {
        enumerable: true,
        get: function () {
            return menu.MenuServiceFactory;
        }
    });
    Object.defineProperty(exports, 'DwMNComponent', {
        enumerable: true,
        get: function () {
            return message.DwMNComponent;
        }
    });
    Object.defineProperty(exports, 'DwMNContainerComponent', {
        enumerable: true,
        get: function () {
            return message.DwMNContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwMNService', {
        enumerable: true,
        get: function () {
            return message.DwMNService;
        }
    });
    Object.defineProperty(exports, 'DwMessageComponent', {
        enumerable: true,
        get: function () {
            return message.DwMessageComponent;
        }
    });
    Object.defineProperty(exports, 'DwMessageContainerComponent', {
        enumerable: true,
        get: function () {
            return message.DwMessageContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwMessageModule', {
        enumerable: true,
        get: function () {
            return message.DwMessageModule;
        }
    });
    Object.defineProperty(exports, 'DwMessageService', {
        enumerable: true,
        get: function () {
            return message.DwMessageService;
        }
    });
    Object.defineProperty(exports, 'DwMessageServiceModule', {
        enumerable: true,
        get: function () {
            return message.DwMessageServiceModule;
        }
    });
    Object.defineProperty(exports, 'BaseModalContainer', {
        enumerable: true,
        get: function () {
            return modal.BaseModalContainer;
        }
    });
    Object.defineProperty(exports, 'DW_CONFIG_COMPONENT_NAME', {
        enumerable: true,
        get: function () {
            return modal.DW_CONFIG_COMPONENT_NAME;
        }
    });
    Object.defineProperty(exports, 'DwModalCloseComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalCloseComponent;
        }
    });
    Object.defineProperty(exports, 'DwModalComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalComponent;
        }
    });
    Object.defineProperty(exports, 'DwModalConfirmContainerComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalConfirmContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwModalContainerComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwModalFooterComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalFooterComponent;
        }
    });
    Object.defineProperty(exports, 'DwModalFooterDirective', {
        enumerable: true,
        get: function () {
            return modal.DwModalFooterDirective;
        }
    });
    Object.defineProperty(exports, 'DwModalLegacyAPI', {
        enumerable: true,
        get: function () {
            return modal.DwModalLegacyAPI;
        }
    });
    Object.defineProperty(exports, 'DwModalModule', {
        enumerable: true,
        get: function () {
            return modal.DwModalModule;
        }
    });
    Object.defineProperty(exports, 'DwModalRef', {
        enumerable: true,
        get: function () {
            return modal.DwModalRef;
        }
    });
    Object.defineProperty(exports, 'DwModalService', {
        enumerable: true,
        get: function () {
            return modal.DwModalService;
        }
    });
    Object.defineProperty(exports, 'DwModalTitleComponent', {
        enumerable: true,
        get: function () {
            return modal.DwModalTitleComponent;
        }
    });
    Object.defineProperty(exports, 'FADE_CLASS_NAME_MAP', {
        enumerable: true,
        get: function () {
            return modal.FADE_CLASS_NAME_MAP;
        }
    });
    Object.defineProperty(exports, 'MODAL_MASK_CLASS_NAME', {
        enumerable: true,
        get: function () {
            return modal.MODAL_MASK_CLASS_NAME;
        }
    });
    Object.defineProperty(exports, 'ModalOptions', {
        enumerable: true,
        get: function () {
            return modal.ModalOptions;
        }
    });
    Object.defineProperty(exports, 'ZOOM_CLASS_NAME_MAP', {
        enumerable: true,
        get: function () {
            return modal.ZOOM_CLASS_NAME_MAP;
        }
    });
    Object.defineProperty(exports, 'applyConfigDefaults', {
        enumerable: true,
        get: function () {
            return modal.applyConfigDefaults;
        }
    });
    Object.defineProperty(exports, 'dwModalAnimations', {
        enumerable: true,
        get: function () {
            return modal.dwModalAnimations;
        }
    });
    Object.defineProperty(exports, 'getConfigFromComponent', {
        enumerable: true,
        get: function () {
            return modal.getConfigFromComponent;
        }
    });
    Object.defineProperty(exports, 'getValueWithConfig', {
        enumerable: true,
        get: function () {
            return modal.getValueWithConfig;
        }
    });
    Object.defineProperty(exports, 'setContentInstanceParams', {
        enumerable: true,
        get: function () {
            return modal.setContentInstanceParams;
        }
    });
    Object.defineProperty(exports, 'throwDwModalContentAlreadyAttachedError', {
        enumerable: true,
        get: function () {
            return modal.throwDwModalContentAlreadyAttachedError;
        }
    });
    Object.defineProperty(exports, 'DwNotificationComponent', {
        enumerable: true,
        get: function () {
            return notification.DwNotificationComponent;
        }
    });
    Object.defineProperty(exports, 'DwNotificationContainerComponent', {
        enumerable: true,
        get: function () {
            return notification.DwNotificationContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwNotificationModule', {
        enumerable: true,
        get: function () {
            return notification.DwNotificationModule;
        }
    });
    Object.defineProperty(exports, 'DwNotificationService', {
        enumerable: true,
        get: function () {
            return notification.DwNotificationService;
        }
    });
    Object.defineProperty(exports, 'DwNotificationServiceModule', {
        enumerable: true,
        get: function () {
            return notification.DwNotificationServiceModule;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderAvatarDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderAvatarDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderBreadcrumbDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderBreadcrumbDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderComponent', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderComponent;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderContentDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderContentDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderExtraDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderExtraDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderFooterDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderFooterDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderModule', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderModule;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderSubtitleDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderSubtitleDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderTagDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderTagDirective;
        }
    });
    Object.defineProperty(exports, 'DwPageHeaderTitleDirective', {
        enumerable: true,
        get: function () {
            return pageHeader.DwPageHeaderTitleDirective;
        }
    });
    Object.defineProperty(exports, 'DwPaginationComponent', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationComponent;
        }
    });
    Object.defineProperty(exports, 'DwPaginationDefaultComponent', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationDefaultComponent;
        }
    });
    Object.defineProperty(exports, 'DwPaginationItemComponent', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwPaginationModule', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationModule;
        }
    });
    Object.defineProperty(exports, 'DwPaginationOptionsComponent', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationOptionsComponent;
        }
    });
    Object.defineProperty(exports, 'DwPaginationSimpleComponent', {
        enumerable: true,
        get: function () {
            return pagination.DwPaginationSimpleComponent;
        }
    });
    Object.defineProperty(exports, 'DwPopconfirmComponent', {
        enumerable: true,
        get: function () {
            return popconfirm.DwPopconfirmComponent;
        }
    });
    Object.defineProperty(exports, 'DwPopconfirmDirective', {
        enumerable: true,
        get: function () {
            return popconfirm.DwPopconfirmDirective;
        }
    });
    Object.defineProperty(exports, 'DwPopconfirmModule', {
        enumerable: true,
        get: function () {
            return popconfirm.DwPopconfirmModule;
        }
    });
    Object.defineProperty(exports, 'DwPopoverComponent', {
        enumerable: true,
        get: function () {
            return popover.DwPopoverComponent;
        }
    });
    Object.defineProperty(exports, 'DwPopoverDirective', {
        enumerable: true,
        get: function () {
            return popover.DwPopoverDirective;
        }
    });
    Object.defineProperty(exports, 'DwPopoverModule', {
        enumerable: true,
        get: function () {
            return popover.DwPopoverModule;
        }
    });
    Object.defineProperty(exports, 'DwProgressComponent', {
        enumerable: true,
        get: function () {
            return progress.DwProgressComponent;
        }
    });
    Object.defineProperty(exports, 'DwProgressModule', {
        enumerable: true,
        get: function () {
            return progress.DwProgressModule;
        }
    });
    Object.defineProperty(exports, 'DwRadioButtonDirective', {
        enumerable: true,
        get: function () {
            return radio.DwRadioButtonDirective;
        }
    });
    Object.defineProperty(exports, 'DwRadioComponent', {
        enumerable: true,
        get: function () {
            return radio.DwRadioComponent;
        }
    });
    Object.defineProperty(exports, 'DwRadioGroupComponent', {
        enumerable: true,
        get: function () {
            return radio.DwRadioGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwRadioModule', {
        enumerable: true,
        get: function () {
            return radio.DwRadioModule;
        }
    });
    Object.defineProperty(exports, 'DwRadioService', {
        enumerable: true,
        get: function () {
            return radio.DwRadioService;
        }
    });
    Object.defineProperty(exports, 'DwRateComponent', {
        enumerable: true,
        get: function () {
            return rate.DwRateComponent;
        }
    });
    Object.defineProperty(exports, 'DwRateItemComponent', {
        enumerable: true,
        get: function () {
            return rate.DwRateItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwRateModule', {
        enumerable: true,
        get: function () {
            return rate.DwRateModule;
        }
    });
    Object.defineProperty(exports, 'DwResultComponent', {
        enumerable: true,
        get: function () {
            return result.DwResultComponent;
        }
    });
    Object.defineProperty(exports, 'DwResultContentDirective', {
        enumerable: true,
        get: function () {
            return result.DwResultContentDirective;
        }
    });
    Object.defineProperty(exports, 'DwResultExtraDirective', {
        enumerable: true,
        get: function () {
            return result.DwResultExtraDirective;
        }
    });
    Object.defineProperty(exports, 'DwResultIconDirective', {
        enumerable: true,
        get: function () {
            return result.DwResultIconDirective;
        }
    });
    Object.defineProperty(exports, 'DwResultModule', {
        enumerable: true,
        get: function () {
            return result.DwResultModule;
        }
    });
    Object.defineProperty(exports, 'DwResultSubtitleDirective', {
        enumerable: true,
        get: function () {
            return result.DwResultSubtitleDirective;
        }
    });
    Object.defineProperty(exports, 'DwResultTitleDirective', {
        enumerable: true,
        get: function () {
            return result.DwResultTitleDirective;
        }
    });
    Object.defineProperty(exports, 'ɵDwResultNotFoundComponent', {
        enumerable: true,
        get: function () {
            return result.ɵDwResultNotFoundComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwResultServerErrorComponent', {
        enumerable: true,
        get: function () {
            return result.ɵDwResultServerErrorComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwResultUnauthorizedComponent', {
        enumerable: true,
        get: function () {
            return result.ɵDwResultUnauthorizedComponent;
        }
    });
    Object.defineProperty(exports, 'DwOptionComponent', {
        enumerable: true,
        get: function () {
            return select.DwOptionComponent;
        }
    });
    Object.defineProperty(exports, 'DwOptionContainerComponent', {
        enumerable: true,
        get: function () {
            return select.DwOptionContainerComponent;
        }
    });
    Object.defineProperty(exports, 'DwOptionGroupComponent', {
        enumerable: true,
        get: function () {
            return select.DwOptionGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwOptionItemComponent', {
        enumerable: true,
        get: function () {
            return select.DwOptionItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwOptionItemGroupComponent', {
        enumerable: true,
        get: function () {
            return select.DwOptionItemGroupComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectArrowComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectArrowComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectClearComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectClearComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectItemComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectModule', {
        enumerable: true,
        get: function () {
            return select.DwSelectModule;
        }
    });
    Object.defineProperty(exports, 'DwSelectPlaceholderComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectPlaceholderComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectSearchComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectSearchComponent;
        }
    });
    Object.defineProperty(exports, 'DwSelectTopControlComponent', {
        enumerable: true,
        get: function () {
            return select.DwSelectTopControlComponent;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonComponent', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonComponent;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonElementAvatarComponent', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonElementAvatarComponent;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonElementButtonComponent', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonElementButtonComponent;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonElementDirective', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonElementDirective;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonElementInputComponent', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonElementInputComponent;
        }
    });
    Object.defineProperty(exports, 'DwSkeletonModule', {
        enumerable: true,
        get: function () {
            return skeleton.DwSkeletonModule;
        }
    });
    Object.defineProperty(exports, 'DwMarks', {
        enumerable: true,
        get: function () {
            return slider.DwMarks;
        }
    });
    Object.defineProperty(exports, 'DwSliderComponent', {
        enumerable: true,
        get: function () {
            return slider.DwSliderComponent;
        }
    });
    Object.defineProperty(exports, 'DwSliderModule', {
        enumerable: true,
        get: function () {
            return slider.DwSliderModule;
        }
    });
    Object.defineProperty(exports, 'ɵDwSliderHandleComponent', {
        enumerable: true,
        get: function () {
            return slider.ɵDwSliderHandleComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwSliderMarksComponent', {
        enumerable: true,
        get: function () {
            return slider.ɵDwSliderMarksComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwSliderService', {
        enumerable: true,
        get: function () {
            return slider.ɵDwSliderService;
        }
    });
    Object.defineProperty(exports, 'ɵDwSliderStepComponent', {
        enumerable: true,
        get: function () {
            return slider.ɵDwSliderStepComponent;
        }
    });
    Object.defineProperty(exports, 'ɵDwSliderTrackComponent', {
        enumerable: true,
        get: function () {
            return slider.ɵDwSliderTrackComponent;
        }
    });
    Object.defineProperty(exports, 'DwSpinComponent', {
        enumerable: true,
        get: function () {
            return spin.DwSpinComponent;
        }
    });
    Object.defineProperty(exports, 'DwSpinModule', {
        enumerable: true,
        get: function () {
            return spin.DwSpinModule;
        }
    });
    Object.defineProperty(exports, 'DwCountdownComponent', {
        enumerable: true,
        get: function () {
            return statistic.DwCountdownComponent;
        }
    });
    Object.defineProperty(exports, 'DwStatisticComponent', {
        enumerable: true,
        get: function () {
            return statistic.DwStatisticComponent;
        }
    });
    Object.defineProperty(exports, 'DwStatisticModule', {
        enumerable: true,
        get: function () {
            return statistic.DwStatisticModule;
        }
    });
    Object.defineProperty(exports, 'DwStatisticNumberComponent', {
        enumerable: true,
        get: function () {
            return statistic.DwStatisticNumberComponent;
        }
    });
    Object.defineProperty(exports, 'DwStepComponent', {
        enumerable: true,
        get: function () {
            return steps.DwStepComponent;
        }
    });
    Object.defineProperty(exports, 'DwStepsComponent', {
        enumerable: true,
        get: function () {
            return steps.DwStepsComponent;
        }
    });
    Object.defineProperty(exports, 'DwStepsModule', {
        enumerable: true,
        get: function () {
            return steps.DwStepsModule;
        }
    });
    Object.defineProperty(exports, 'DwSwitchComponent', {
        enumerable: true,
        get: function () {
            return _switch.DwSwitchComponent;
        }
    });
    Object.defineProperty(exports, 'DwSwitchModule', {
        enumerable: true,
        get: function () {
            return _switch.DwSwitchModule;
        }
    });
    Object.defineProperty(exports, 'DwCellAlignDirective', {
        enumerable: true,
        get: function () {
            return table.DwCellAlignDirective;
        }
    });
    Object.defineProperty(exports, 'DwCellBreakWordDirective', {
        enumerable: true,
        get: function () {
            return table.DwCellBreakWordDirective;
        }
    });
    Object.defineProperty(exports, 'DwCellEllipsisDirective', {
        enumerable: true,
        get: function () {
            return table.DwCellEllipsisDirective;
        }
    });
    Object.defineProperty(exports, 'DwCellFixedDirective', {
        enumerable: true,
        get: function () {
            return table.DwCellFixedDirective;
        }
    });
    Object.defineProperty(exports, 'DwFilterTriggerComponent', {
        enumerable: true,
        get: function () {
            return table.DwFilterTriggerComponent;
        }
    });
    Object.defineProperty(exports, 'DwRowExpandButtonDirective', {
        enumerable: true,
        get: function () {
            return table.DwRowExpandButtonDirective;
        }
    });
    Object.defineProperty(exports, 'DwRowIndentDirective', {
        enumerable: true,
        get: function () {
            return table.DwRowIndentDirective;
        }
    });
    Object.defineProperty(exports, 'DwTableCellDirective', {
        enumerable: true,
        get: function () {
            return table.DwTableCellDirective;
        }
    });
    Object.defineProperty(exports, 'DwTableComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableContentComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableContentComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableDataService', {
        enumerable: true,
        get: function () {
            return table.DwTableDataService;
        }
    });
    Object.defineProperty(exports, 'DwTableFilterComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableFilterComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableFixedRowComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableFixedRowComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableInnerDefaultComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableInnerDefaultComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableInnerScrollComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableInnerScrollComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableModule', {
        enumerable: true,
        get: function () {
            return table.DwTableModule;
        }
    });
    Object.defineProperty(exports, 'DwTableSelectionComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableSelectionComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableSortersComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableSortersComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableStyleService', {
        enumerable: true,
        get: function () {
            return table.DwTableStyleService;
        }
    });
    Object.defineProperty(exports, 'DwTableTitleFooterComponent', {
        enumerable: true,
        get: function () {
            return table.DwTableTitleFooterComponent;
        }
    });
    Object.defineProperty(exports, 'DwTableVirtualScrollDirective', {
        enumerable: true,
        get: function () {
            return table.DwTableVirtualScrollDirective;
        }
    });
    Object.defineProperty(exports, 'DwTbodyComponent', {
        enumerable: true,
        get: function () {
            return table.DwTbodyComponent;
        }
    });
    Object.defineProperty(exports, 'DwTdAddOnComponent', {
        enumerable: true,
        get: function () {
            return table.DwTdAddOnComponent;
        }
    });
    Object.defineProperty(exports, 'DwThAddOnComponent', {
        enumerable: true,
        get: function () {
            return table.DwThAddOnComponent;
        }
    });
    Object.defineProperty(exports, 'DwThMeasureDirective', {
        enumerable: true,
        get: function () {
            return table.DwThMeasureDirective;
        }
    });
    Object.defineProperty(exports, 'DwThSelectionComponent', {
        enumerable: true,
        get: function () {
            return table.DwThSelectionComponent;
        }
    });
    Object.defineProperty(exports, 'DwTheadComponent', {
        enumerable: true,
        get: function () {
            return table.DwTheadComponent;
        }
    });
    Object.defineProperty(exports, 'DwTrDirective', {
        enumerable: true,
        get: function () {
            return table.DwTrDirective;
        }
    });
    Object.defineProperty(exports, 'DwTrExpandDirective', {
        enumerable: true,
        get: function () {
            return table.DwTrExpandDirective;
        }
    });
    Object.defineProperty(exports, 'DwTrMeasureComponent', {
        enumerable: true,
        get: function () {
            return table.DwTrMeasureComponent;
        }
    });
    Object.defineProperty(exports, 'DwTabBodyComponent', {
        enumerable: true,
        get: function () {
            return tabs.DwTabBodyComponent;
        }
    });
    Object.defineProperty(exports, 'DwTabChangeEvent', {
        enumerable: true,
        get: function () {
            return tabs.DwTabChangeEvent;
        }
    });
    Object.defineProperty(exports, 'DwTabComponent', {
        enumerable: true,
        get: function () {
            return tabs.DwTabComponent;
        }
    });
    Object.defineProperty(exports, 'DwTabDirective', {
        enumerable: true,
        get: function () {
            return tabs.DwTabDirective;
        }
    });
    Object.defineProperty(exports, 'DwTabLabelDirective', {
        enumerable: true,
        get: function () {
            return tabs.DwTabLabelDirective;
        }
    });
    Object.defineProperty(exports, 'DwTabLinkDirective', {
        enumerable: true,
        get: function () {
            return tabs.DwTabLinkDirective;
        }
    });
    Object.defineProperty(exports, 'DwTabSetComponent', {
        enumerable: true,
        get: function () {
            return tabs.DwTabSetComponent;
        }
    });
    Object.defineProperty(exports, 'DwTabsInkBarDirective', {
        enumerable: true,
        get: function () {
            return tabs.DwTabsInkBarDirective;
        }
    });
    Object.defineProperty(exports, 'DwTabsModule', {
        enumerable: true,
        get: function () {
            return tabs.DwTabsModule;
        }
    });
    Object.defineProperty(exports, 'DwTabsNavComponent', {
        enumerable: true,
        get: function () {
            return tabs.DwTabsNavComponent;
        }
    });
    Object.defineProperty(exports, 'DwTagComponent', {
        enumerable: true,
        get: function () {
            return tag.DwTagComponent;
        }
    });
    Object.defineProperty(exports, 'DwTagModule', {
        enumerable: true,
        get: function () {
            return tag.DwTagModule;
        }
    });
    Object.defineProperty(exports, 'DwTimePickerComponent', {
        enumerable: true,
        get: function () {
            return timePicker.DwTimePickerComponent;
        }
    });
    Object.defineProperty(exports, 'DwTimePickerModule', {
        enumerable: true,
        get: function () {
            return timePicker.DwTimePickerModule;
        }
    });
    Object.defineProperty(exports, 'DwTimePickerPanelComponent', {
        enumerable: true,
        get: function () {
            return timePicker.DwTimePickerPanelComponent;
        }
    });
    Object.defineProperty(exports, 'DwTimeValueAccessorDirective', {
        enumerable: true,
        get: function () {
            return timePicker.DwTimeValueAccessorDirective;
        }
    });
    Object.defineProperty(exports, 'DwTimelineComponent', {
        enumerable: true,
        get: function () {
            return timeline.DwTimelineComponent;
        }
    });
    Object.defineProperty(exports, 'DwTimelineItemComponent', {
        enumerable: true,
        get: function () {
            return timeline.DwTimelineItemComponent;
        }
    });
    Object.defineProperty(exports, 'DwTimelineModule', {
        enumerable: true,
        get: function () {
            return timeline.DwTimelineModule;
        }
    });
    Object.defineProperty(exports, 'TimelineService', {
        enumerable: true,
        get: function () {
            return timeline.TimelineService;
        }
    });
    Object.defineProperty(exports, 'DwToolTipComponent', {
        enumerable: true,
        get: function () {
            return tooltip.DwToolTipComponent;
        }
    });
    Object.defineProperty(exports, 'DwToolTipModule', {
        enumerable: true,
        get: function () {
            return tooltip.DwToolTipModule;
        }
    });
    Object.defineProperty(exports, 'DwTooltipBaseComponent', {
        enumerable: true,
        get: function () {
            return tooltip.DwTooltipBaseComponent;
        }
    });
    Object.defineProperty(exports, 'DwTooltipBaseDirective', {
        enumerable: true,
        get: function () {
            return tooltip.DwTooltipBaseDirective;
        }
    });
    Object.defineProperty(exports, 'DwTooltipDirective', {
        enumerable: true,
        get: function () {
            return tooltip.DwTooltipDirective;
        }
    });
    Object.defineProperty(exports, 'isTooltipEmpty', {
        enumerable: true,
        get: function () {
            return tooltip.isTooltipEmpty;
        }
    });
    Object.defineProperty(exports, 'DwTransferComponent', {
        enumerable: true,
        get: function () {
            return transfer.DwTransferComponent;
        }
    });
    Object.defineProperty(exports, 'DwTransferListComponent', {
        enumerable: true,
        get: function () {
            return transfer.DwTransferListComponent;
        }
    });
    Object.defineProperty(exports, 'DwTransferModule', {
        enumerable: true,
        get: function () {
            return transfer.DwTransferModule;
        }
    });
    Object.defineProperty(exports, 'DwTransferSearchComponent', {
        enumerable: true,
        get: function () {
            return transfer.DwTransferSearchComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeIndentComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeIndentComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeModule', {
        enumerable: true,
        get: function () {
            return tree.DwTreeModule;
        }
    });
    Object.defineProperty(exports, 'DwTreeNode', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNode;
        }
    });
    Object.defineProperty(exports, 'DwTreeNodeCheckboxComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNodeCheckboxComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeNodeComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNodeComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeNodeSwitcherComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNodeSwitcherComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeNodeTitleComponent', {
        enumerable: true,
        get: function () {
            return tree.DwTreeNodeTitleComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeService', {
        enumerable: true,
        get: function () {
            return tree.DwTreeService;
        }
    });
    Object.defineProperty(exports, 'DwTreeServiceFactory', {
        enumerable: true,
        get: function () {
            return tree.DwTreeServiceFactory;
        }
    });
    Object.defineProperty(exports, 'DwTreeSelectComponent', {
        enumerable: true,
        get: function () {
            return treeSelect.DwTreeSelectComponent;
        }
    });
    Object.defineProperty(exports, 'DwTreeSelectModule', {
        enumerable: true,
        get: function () {
            return treeSelect.DwTreeSelectModule;
        }
    });
    Object.defineProperty(exports, 'DwTreeSelectService', {
        enumerable: true,
        get: function () {
            return treeSelect.DwTreeSelectService;
        }
    });
    Object.defineProperty(exports, 'higherOrderServiceFactory', {
        enumerable: true,
        get: function () {
            return treeSelect.higherOrderServiceFactory;
        }
    });
    Object.defineProperty(exports, 'DwTextCopyComponent', {
        enumerable: true,
        get: function () {
            return typography.DwTextCopyComponent;
        }
    });
    Object.defineProperty(exports, 'DwTextEditComponent', {
        enumerable: true,
        get: function () {
            return typography.DwTextEditComponent;
        }
    });
    Object.defineProperty(exports, 'DwTypographyComponent', {
        enumerable: true,
        get: function () {
            return typography.DwTypographyComponent;
        }
    });
    Object.defineProperty(exports, 'DwTypographyModule', {
        enumerable: true,
        get: function () {
            return typography.DwTypographyModule;
        }
    });
    Object.defineProperty(exports, 'DwShowUploadListInterface', {
        enumerable: true,
        get: function () {
            return upload.DwShowUploadListInterface;
        }
    });
    Object.defineProperty(exports, 'DwUploadBtnComponent', {
        enumerable: true,
        get: function () {
            return upload.DwUploadBtnComponent;
        }
    });
    Object.defineProperty(exports, 'DwUploadComponent', {
        enumerable: true,
        get: function () {
            return upload.DwUploadComponent;
        }
    });
    Object.defineProperty(exports, 'DwUploadListComponent', {
        enumerable: true,
        get: function () {
            return upload.DwUploadListComponent;
        }
    });
    Object.defineProperty(exports, 'DwUploadModule', {
        enumerable: true,
        get: function () {
            return upload.DwUploadModule;
        }
    });
    Object.defineProperty(exports, 'VERSION', {
        enumerable: true,
        get: function () {
            return version.VERSION;
        }
    });
    Object.defineProperty(exports, 'AnimationCurves', {
        enumerable: true,
        get: function () {
            return animation.AnimationCurves;
        }
    });
    Object.defineProperty(exports, 'AnimationDuration', {
        enumerable: true,
        get: function () {
            return animation.AnimationDuration;
        }
    });
    Object.defineProperty(exports, 'collapseMotion', {
        enumerable: true,
        get: function () {
            return animation.collapseMotion;
        }
    });
    Object.defineProperty(exports, 'fadeMotion', {
        enumerable: true,
        get: function () {
            return animation.fadeMotion;
        }
    });
    Object.defineProperty(exports, 'helpMotion', {
        enumerable: true,
        get: function () {
            return animation.helpMotion;
        }
    });
    Object.defineProperty(exports, 'moveUpMotion', {
        enumerable: true,
        get: function () {
            return animation.moveUpMotion;
        }
    });
    Object.defineProperty(exports, 'notificationMotion', {
        enumerable: true,
        get: function () {
            return animation.notificationMotion;
        }
    });
    Object.defineProperty(exports, 'slideAlertMotion', {
        enumerable: true,
        get: function () {
            return animation.slideAlertMotion;
        }
    });
    Object.defineProperty(exports, 'slideMotion', {
        enumerable: true,
        get: function () {
            return animation.slideMotion;
        }
    });
    Object.defineProperty(exports, 'treeCollapseMotion', {
        enumerable: true,
        get: function () {
            return animation.treeCollapseMotion;
        }
    });
    Object.defineProperty(exports, 'zoomBadgeMotion', {
        enumerable: true,
        get: function () {
            return animation.zoomBadgeMotion;
        }
    });
    Object.defineProperty(exports, 'zoomBigMotion', {
        enumerable: true,
        get: function () {
            return animation.zoomBigMotion;
        }
    });
    Object.defineProperty(exports, 'zoomMotion', {
        enumerable: true,
        get: function () {
            return animation.zoomMotion;
        }
    });
    Object.defineProperty(exports, 'DW_CONFIG', {
        enumerable: true,
        get: function () {
            return config.DW_CONFIG;
        }
    });
    Object.defineProperty(exports, 'DwConfigService', {
        enumerable: true,
        get: function () {
            return config.DwConfigService;
        }
    });
    Object.defineProperty(exports, 'WithConfig', {
        enumerable: true,
        get: function () {
            return config.WithConfig;
        }
    });
    Object.defineProperty(exports, 'environment', {
        enumerable: true,
        get: function () {
            return environments.environment;
        }
    });
    Object.defineProperty(exports, 'DwHighlightModule', {
        enumerable: true,
        get: function () {
            return highlight.DwHighlightModule;
        }
    });
    Object.defineProperty(exports, 'DwHighlightPipe', {
        enumerable: true,
        get: function () {
            return highlight.DwHighlightPipe;
        }
    });
    Object.defineProperty(exports, 'DwOutletModule', {
        enumerable: true,
        get: function () {
            return outlet.DwOutletModule;
        }
    });
    Object.defineProperty(exports, 'DwStringTemplateOutletDirective', {
        enumerable: true,
        get: function () {
            return outlet.DwStringTemplateOutletDirective;
        }
    });
    Object.defineProperty(exports, 'DEFAULT_CASCADER_POSITIONS', {
        enumerable: true,
        get: function () {
            return overlay.DEFAULT_CASCADER_POSITIONS;
        }
    });
    Object.defineProperty(exports, 'DEFAULT_MENTION_BOTTOM_POSITIONS', {
        enumerable: true,
        get: function () {
            return overlay.DEFAULT_MENTION_BOTTOM_POSITIONS;
        }
    });
    Object.defineProperty(exports, 'DEFAULT_MENTION_TOP_POSITIONS', {
        enumerable: true,
        get: function () {
            return overlay.DEFAULT_MENTION_TOP_POSITIONS;
        }
    });
    Object.defineProperty(exports, 'DEFAULT_TOOLTIP_POSITIONS', {
        enumerable: true,
        get: function () {
            return overlay.DEFAULT_TOOLTIP_POSITIONS;
        }
    });
    Object.defineProperty(exports, 'DwConnectedOverlayDirective', {
        enumerable: true,
        get: function () {
            return overlay.DwConnectedOverlayDirective;
        }
    });
    Object.defineProperty(exports, 'DwOverlayModule', {
        enumerable: true,
        get: function () {
            return overlay.DwOverlayModule;
        }
    });
    Object.defineProperty(exports, 'POSITION_MAP', {
        enumerable: true,
        get: function () {
            return overlay.POSITION_MAP;
        }
    });
    Object.defineProperty(exports, 'getPlacementName', {
        enumerable: true,
        get: function () {
            return overlay.getPlacementName;
        }
    });
    Object.defineProperty(exports, 'DwPipesModule', {
        enumerable: true,
        get: function () {
            return pipe.DwPipesModule;
        }
    });
    Object.defineProperty(exports, 'DwTimeRangePipe', {
        enumerable: true,
        get: function () {
            return pipe.DwTimeRangePipe;
        }
    });
    Object.defineProperty(exports, 'DwToCssUnitPipe', {
        enumerable: true,
        get: function () {
            return pipe.DwToCssUnitPipe;
        }
    });
    Object.defineProperty(exports, 'cancelRequestAnimationFrame', {
        enumerable: true,
        get: function () {
            return polyfill.cancelRequestAnimationFrame;
        }
    });
    Object.defineProperty(exports, 'reqAnimFrame', {
        enumerable: true,
        get: function () {
            return polyfill.reqAnimFrame;
        }
    });
    Object.defineProperty(exports, 'DwResizeObserver', {
        enumerable: true,
        get: function () {
            return resizeObservers.DwResizeObserver;
        }
    });
    Object.defineProperty(exports, 'DwResizeObserversModule', {
        enumerable: true,
        get: function () {
            return resizeObservers.DwResizeObserversModule;
        }
    });
    Object.defineProperty(exports, 'ɵa', {
        enumerable: true,
        get: function () {
            return resizeObservers.ɵa;
        }
    });
    Object.defineProperty(exports, 'DwBreakpointEnum', {
        enumerable: true,
        get: function () {
            return services.DwBreakpointEnum;
        }
    });
    Object.defineProperty(exports, 'DwBreakpointService', {
        enumerable: true,
        get: function () {
            return services.DwBreakpointService;
        }
    });
    Object.defineProperty(exports, 'DwDragService', {
        enumerable: true,
        get: function () {
            return services.DwDragService;
        }
    });
    Object.defineProperty(exports, 'DwResizeService', {
        enumerable: true,
        get: function () {
            return services.DwResizeService;
        }
    });
    Object.defineProperty(exports, 'DwScrollService', {
        enumerable: true,
        get: function () {
            return services.DwScrollService;
        }
    });
    Object.defineProperty(exports, 'DwSingletonService', {
        enumerable: true,
        get: function () {
            return services.DwSingletonService;
        }
    });
    Object.defineProperty(exports, 'gridResponsiveMap', {
        enumerable: true,
        get: function () {
            return services.gridResponsiveMap;
        }
    });
    Object.defineProperty(exports, 'siderResponsiveMap', {
        enumerable: true,
        get: function () {
            return services.siderResponsiveMap;
        }
    });
    Object.defineProperty(exports, 'FakeViewportRuler', {
        enumerable: true,
        get: function () {
            return testing.FakeViewportRuler;
        }
    });
    Object.defineProperty(exports, 'MockNgZone', {
        enumerable: true,
        get: function () {
            return testing.MockNgZone;
        }
    });
    Object.defineProperty(exports, 'createFakeEvent', {
        enumerable: true,
        get: function () {
            return testing.createFakeEvent;
        }
    });
    Object.defineProperty(exports, 'createKeyboardEvent', {
        enumerable: true,
        get: function () {
            return testing.createKeyboardEvent;
        }
    });
    Object.defineProperty(exports, 'createMouseEvent', {
        enumerable: true,
        get: function () {
            return testing.createMouseEvent;
        }
    });
    Object.defineProperty(exports, 'createTouchEvent', {
        enumerable: true,
        get: function () {
            return testing.createTouchEvent;
        }
    });
    Object.defineProperty(exports, 'dispatchEvent', {
        enumerable: true,
        get: function () {
            return testing.dispatchEvent;
        }
    });
    Object.defineProperty(exports, 'dispatchFakeEvent', {
        enumerable: true,
        get: function () {
            return testing.dispatchFakeEvent;
        }
    });
    Object.defineProperty(exports, 'dispatchKeyboardEvent', {
        enumerable: true,
        get: function () {
            return testing.dispatchKeyboardEvent;
        }
    });
    Object.defineProperty(exports, 'dispatchMouseEvent', {
        enumerable: true,
        get: function () {
            return testing.dispatchMouseEvent;
        }
    });
    Object.defineProperty(exports, 'dispatchTouchEvent', {
        enumerable: true,
        get: function () {
            return testing.dispatchTouchEvent;
        }
    });
    Object.defineProperty(exports, 'typeInElement', {
        enumerable: true,
        get: function () {
            return testing.typeInElement;
        }
    });
    Object.defineProperty(exports, 'wrappedErrorMessage', {
        enumerable: true,
        get: function () {
            return testing.wrappedErrorMessage;
        }
    });
    Object.defineProperty(exports, 'ɵcreateComponentBed', {
        enumerable: true,
        get: function () {
            return testing.ɵcreateComponentBed;
        }
    });
    Object.defineProperty(exports, 'CandyDate', {
        enumerable: true,
        get: function () {
            return time.CandyDate;
        }
    });
    Object.defineProperty(exports, 'cloneDate', {
        enumerable: true,
        get: function () {
            return time.cloneDate;
        }
    });
    Object.defineProperty(exports, 'normalizeRangeValue', {
        enumerable: true,
        get: function () {
            return time.normalizeRangeValue;
        }
    });
    Object.defineProperty(exports, 'sortRangeValue', {
        enumerable: true,
        get: function () {
            return time.sortRangeValue;
        }
    });
    Object.defineProperty(exports, 'timeUnits', {
        enumerable: true,
        get: function () {
            return time.timeUnits;
        }
    });
    Object.defineProperty(exports, 'ɵDwTransitionPatchDirective', {
        enumerable: true,
        get: function () {
            return transitionPatch.ɵDwTransitionPatchDirective;
        }
    });
    Object.defineProperty(exports, 'ɵDwTransitionPatchModule', {
        enumerable: true,
        get: function () {
            return transitionPatch.ɵDwTransitionPatchModule;
        }
    });
    Object.defineProperty(exports, 'DwTreeBase', {
        enumerable: true,
        get: function () {
            return tree$1.DwTreeBase;
        }
    });
    Object.defineProperty(exports, 'DwTreeBaseService', {
        enumerable: true,
        get: function () {
            return tree$1.DwTreeBaseService;
        }
    });
    Object.defineProperty(exports, 'DwTreeHigherOrderServiceToken', {
        enumerable: true,
        get: function () {
            return tree$1.DwTreeHigherOrderServiceToken;
        }
    });
    Object.defineProperty(exports, 'flattenTreeData', {
        enumerable: true,
        get: function () {
            return tree$1.flattenTreeData;
        }
    });
    Object.defineProperty(exports, 'getKey', {
        enumerable: true,
        get: function () {
            return tree$1.getKey;
        }
    });
    Object.defineProperty(exports, 'getPosition', {
        enumerable: true,
        get: function () {
            return tree$1.getPosition;
        }
    });
    Object.defineProperty(exports, 'isCheckDisabled', {
        enumerable: true,
        get: function () {
            return tree$1.isCheckDisabled;
        }
    });
    Object.defineProperty(exports, 'isInArray', {
        enumerable: true,
        get: function () {
            return tree$1.isInArray;
        }
    });
    Object.defineProperty(exports, 'InputBoolean', {
        enumerable: true,
        get: function () {
            return util.InputBoolean;
        }
    });
    Object.defineProperty(exports, 'InputCssPixel', {
        enumerable: true,
        get: function () {
            return util.InputCssPixel;
        }
    });
    Object.defineProperty(exports, 'InputNumber', {
        enumerable: true,
        get: function () {
            return util.InputNumber;
        }
    });
    Object.defineProperty(exports, 'arraysEqual', {
        enumerable: true,
        get: function () {
            return util.arraysEqual;
        }
    });
    Object.defineProperty(exports, 'createDebugEle', {
        enumerable: true,
        get: function () {
            return util.createDebugEle;
        }
    });
    Object.defineProperty(exports, 'ensureInBounds', {
        enumerable: true,
        get: function () {
            return util.ensureInBounds;
        }
    });
    Object.defineProperty(exports, 'ensureNumberInRange', {
        enumerable: true,
        get: function () {
            return util.ensureNumberInRange;
        }
    });
    Object.defineProperty(exports, 'filterNotEmptyNode', {
        enumerable: true,
        get: function () {
            return util.filterNotEmptyNode;
        }
    });
    Object.defineProperty(exports, 'getCaretCoordinates', {
        enumerable: true,
        get: function () {
            return util.getCaretCoordinates;
        }
    });
    Object.defineProperty(exports, 'getElementOffset', {
        enumerable: true,
        get: function () {
            return util.getElementOffset;
        }
    });
    Object.defineProperty(exports, 'getEventPosition', {
        enumerable: true,
        get: function () {
            return util.getEventPosition;
        }
    });
    Object.defineProperty(exports, 'getMentions', {
        enumerable: true,
        get: function () {
            return util.getMentions;
        }
    });
    Object.defineProperty(exports, 'getPercent', {
        enumerable: true,
        get: function () {
            return util.getPercent;
        }
    });
    Object.defineProperty(exports, 'getPrecision', {
        enumerable: true,
        get: function () {
            return util.getPrecision;
        }
    });
    Object.defineProperty(exports, 'getRegExp', {
        enumerable: true,
        get: function () {
            return util.getRegExp;
        }
    });
    Object.defineProperty(exports, 'getRepeatedElement', {
        enumerable: true,
        get: function () {
            return util.getRepeatedElement;
        }
    });
    Object.defineProperty(exports, 'getStyleAsText', {
        enumerable: true,
        get: function () {
            return util.getStyleAsText;
        }
    });
    Object.defineProperty(exports, 'inNextTick', {
        enumerable: true,
        get: function () {
            return util.inNextTick;
        }
    });
    Object.defineProperty(exports, 'isComponent', {
        enumerable: true,
        get: function () {
            return util.isComponent;
        }
    });
    Object.defineProperty(exports, 'isEmpty', {
        enumerable: true,
        get: function () {
            return util.isEmpty;
        }
    });
    Object.defineProperty(exports, 'isInteger', {
        enumerable: true,
        get: function () {
            return util.isInteger;
        }
    });
    Object.defineProperty(exports, 'isNil', {
        enumerable: true,
        get: function () {
            return util.isNil;
        }
    });
    Object.defineProperty(exports, 'isNonEmptyString', {
        enumerable: true,
        get: function () {
            return util.isNonEmptyString;
        }
    });
    Object.defineProperty(exports, 'isNotNil', {
        enumerable: true,
        get: function () {
            return util.isNotNil;
        }
    });
    Object.defineProperty(exports, 'isPromise', {
        enumerable: true,
        get: function () {
            return util.isPromise;
        }
    });
    Object.defineProperty(exports, 'isStyleSupport', {
        enumerable: true,
        get: function () {
            return util.isStyleSupport;
        }
    });
    Object.defineProperty(exports, 'isTemplateRef', {
        enumerable: true,
        get: function () {
            return util.isTemplateRef;
        }
    });
    Object.defineProperty(exports, 'isTouchEvent', {
        enumerable: true,
        get: function () {
            return util.isTouchEvent;
        }
    });
    Object.defineProperty(exports, 'measure', {
        enumerable: true,
        get: function () {
            return util.measure;
        }
    });
    Object.defineProperty(exports, 'measureScrollbar', {
        enumerable: true,
        get: function () {
            return util.measureScrollbar;
        }
    });
    Object.defineProperty(exports, 'padEnd', {
        enumerable: true,
        get: function () {
            return util.padEnd;
        }
    });
    Object.defineProperty(exports, 'padStart', {
        enumerable: true,
        get: function () {
            return util.padStart;
        }
    });
    Object.defineProperty(exports, 'properties', {
        enumerable: true,
        get: function () {
            return util.properties;
        }
    });
    Object.defineProperty(exports, 'pxToNumber', {
        enumerable: true,
        get: function () {
            return util.pxToNumber;
        }
    });
    Object.defineProperty(exports, 'scrollIntoView', {
        enumerable: true,
        get: function () {
            return util.scrollIntoView;
        }
    });
    Object.defineProperty(exports, 'shallowCopyArray', {
        enumerable: true,
        get: function () {
            return util.shallowCopyArray;
        }
    });
    Object.defineProperty(exports, 'shallowEqual', {
        enumerable: true,
        get: function () {
            return util.shallowEqual;
        }
    });
    Object.defineProperty(exports, 'silentEvent', {
        enumerable: true,
        get: function () {
            return util.silentEvent;
        }
    });
    Object.defineProperty(exports, 'toArray', {
        enumerable: true,
        get: function () {
            return util.toArray;
        }
    });
    Object.defineProperty(exports, 'toBoolean', {
        enumerable: true,
        get: function () {
            return util.toBoolean;
        }
    });
    Object.defineProperty(exports, 'toCssPixel', {
        enumerable: true,
        get: function () {
            return util.toCssPixel;
        }
    });
    Object.defineProperty(exports, 'toNumber', {
        enumerable: true,
        get: function () {
            return util.toNumber;
        }
    });
    Object.defineProperty(exports, 'valueFunctionProp', {
        enumerable: true,
        get: function () {
            return util.valueFunctionProp;
        }
    });
    Object.defineProperty(exports, 'wrapIntoObservable', {
        enumerable: true,
        get: function () {
            return util.wrapIntoObservable;
        }
    });
    exports.NgQuicksilverModule = NgQuicksilverModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver.umd.js.map
