(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/steps', ['exports', '@angular/core', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/common', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].steps = {}), global.ng.core, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.common, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon));
}(this, (function (exports, core, util, rxjs, operators, common, outlet, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: step.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwStepComponent = /** @class */ (function () {
        function DwStepComponent(cdr) {
            this.cdr = cdr;
            this.dwDisabled = false;
            this.isCustomStatus = false;
            this._status = 'wait';
            this.oldAPIIcon = true;
            // Set by parent.
            this.direction = 'horizontal';
            this.index = 0;
            this.last = false;
            this.outStatus = 'process';
            this.showProcessDot = false;
            this.clickable = false;
            this.click$ = new rxjs.Subject();
            this._currentIndex = 0;
        }
        Object.defineProperty(DwStepComponent.prototype, "dwStatus", {
            get: /**
             * @return {?}
             */
            function () {
                return this._status;
            },
            set: /**
             * @param {?} status
             * @return {?}
             */
            function (status) {
                this._status = status;
                this.isCustomStatus = true;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwStepComponent.prototype, "dwIcon", {
            get: /**
             * @return {?}
             */
            function () {
                return this._icon;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (!(value instanceof core.TemplateRef)) {
                    this.oldAPIIcon = typeof value === 'string' && value.indexOf('anticon') > -1;
                }
                else {
                }
                this._icon = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwStepComponent.prototype, "currentIndex", {
            get: /**
             * @return {?}
             */
            function () {
                return this._currentIndex;
            },
            set: /**
             * @param {?} current
             * @return {?}
             */
            function (current) {
                this._currentIndex = current;
                if (!this.isCustomStatus) {
                    this._status = current > this.index ? 'finish' : current === this.index ? this.outStatus || '' : 'wait';
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwStepComponent.prototype.onClick = /**
         * @return {?}
         */
        function () {
            if (this.clickable && this.currentIndex !== this.index && !this.dwDisabled) {
                this.click$.next(this.index);
            }
        };
        /**
         * @return {?}
         */
        DwStepComponent.prototype.markForCheck = /**
         * @return {?}
         */
        function () {
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwStepComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.click$.complete();
        };
        DwStepComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-step',
                        exportAs: 'dwStep',
                        preserveWhitespaces: false,
                        template: "\n    <div\n      class=\"ant-steps-item-container\"\n      [attr.role]=\"clickable && !dwDisabled ? 'button' : null\"\n      [tabindex]=\"clickable && !dwDisabled ? 0 : null\"\n      (click)=\"onClick()\"\n    >\n      <div class=\"ant-steps-item-tail\" *ngIf=\"last !== true\"></div>\n      <div class=\"ant-steps-item-icon\">\n        <ng-template [ngIf]=\"!showProcessDot\">\n          <span class=\"ant-steps-icon\" *ngIf=\"dwStatus === 'finish' && !dwIcon\"><i dw-icon dwType=\"check\"></i></span>\n          <span class=\"ant-steps-icon\" *ngIf=\"dwStatus === 'error'\"><i dw-icon dwType=\"close\"></i></span>\n          <span class=\"ant-steps-icon\" *ngIf=\"(dwStatus === 'process' || dwStatus === 'wait') && !dwIcon\">{{ index + 1 }}</span>\n          <span class=\"ant-steps-icon\" *ngIf=\"dwIcon\">\n            <ng-container *dwStringTemplateOutlet=\"dwIcon; let icon\">\n              <i dw-icon [dwType]=\"!oldAPIIcon && icon\" [ngClass]=\"oldAPIIcon && icon\"></i>\n            </ng-container>\n          </span>\n        </ng-template>\n        <ng-template [ngIf]=\"showProcessDot\">\n          <span class=\"ant-steps-icon\">\n            <ng-template #processDotTemplate>\n              <span class=\"ant-steps-icon-dot\"></span>\n            </ng-template>\n            <ng-template\n              [ngTemplateOutlet]=\"customProcessTemplate || processDotTemplate\"\n              [ngTemplateOutletContext]=\"{\n                $implicit: processDotTemplate,\n                status: dwStatus,\n                index: index\n              }\"\n            >\n            </ng-template>\n          </span>\n        </ng-template>\n      </div>\n      <div class=\"ant-steps-item-content\">\n        <div class=\"ant-steps-item-title\">\n          <ng-container *dwStringTemplateOutlet=\"dwTitle\">{{ dwTitle }}</ng-container>\n          <div *ngIf=\"dwSubtitle\" class=\"ant-steps-item-subtitle\">\n            <ng-container *dwStringTemplateOutlet=\"dwSubtitle\">{{ dwSubtitle }}</ng-container>\n          </div>\n        </div>\n        <div class=\"ant-steps-item-description\">\n          <ng-container *dwStringTemplateOutlet=\"dwDescription\">{{ dwDescription }}</ng-container>\n        </div>\n      </div>\n    </div>\n  ",
                        host: {
                            class: 'ant-steps-item',
                            '[class.ant-steps-item-wait]': 'dwStatus === "wait"',
                            '[class.ant-steps-item-process]': 'dwStatus === "process"',
                            '[class.ant-steps-item-finish]': 'dwStatus === "finish"',
                            '[class.ant-steps-item-error]': 'dwStatus === "error"',
                            '[class.ant-steps-item-active]': 'currentIndex === index',
                            '[class.ant-steps-item-disabled]': 'dwDisabled',
                            '[class.ant-steps-item-custom]': '!!dwIcon',
                            '[class.ant-steps-next-error]': '(outStatus === "error") && (currentIndex === index + 1)'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwStepComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef }
        ]; };
        DwStepComponent.propDecorators = {
            processDotTemplate: [{ type: core.ViewChild, args: ['processDotTemplate', { static: false },] }],
            dwTitle: [{ type: core.Input }],
            dwSubtitle: [{ type: core.Input }],
            dwDescription: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwStatus: [{ type: core.Input }],
            dwIcon: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwStepComponent.prototype, "dwDisabled", void 0);
        return DwStepComponent;
    }());
    if (false) {
        /** @type {?} */
        DwStepComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwStepComponent.prototype.processDotTemplate;
        /** @type {?} */
        DwStepComponent.prototype.dwTitle;
        /** @type {?} */
        DwStepComponent.prototype.dwSubtitle;
        /** @type {?} */
        DwStepComponent.prototype.dwDescription;
        /** @type {?} */
        DwStepComponent.prototype.dwDisabled;
        /** @type {?} */
        DwStepComponent.prototype.isCustomStatus;
        /**
         * @type {?}
         * @private
         */
        DwStepComponent.prototype._status;
        /** @type {?} */
        DwStepComponent.prototype.oldAPIIcon;
        /**
         * @type {?}
         * @private
         */
        DwStepComponent.prototype._icon;
        /** @type {?} */
        DwStepComponent.prototype.customProcessTemplate;
        /** @type {?} */
        DwStepComponent.prototype.direction;
        /** @type {?} */
        DwStepComponent.prototype.index;
        /** @type {?} */
        DwStepComponent.prototype.last;
        /** @type {?} */
        DwStepComponent.prototype.outStatus;
        /** @type {?} */
        DwStepComponent.prototype.showProcessDot;
        /** @type {?} */
        DwStepComponent.prototype.clickable;
        /** @type {?} */
        DwStepComponent.prototype.click$;
        /**
         * @type {?}
         * @private
         */
        DwStepComponent.prototype._currentIndex;
        /**
         * @type {?}
         * @private
         */
        DwStepComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: steps.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwStepsComponent = /** @class */ (function () {
        function DwStepsComponent() {
            this.dwCurrent = 0;
            this.dwDirection = 'horizontal';
            this.dwLabelPlacement = 'horizontal';
            this.dwType = 'default';
            this.dwSize = 'default';
            this.dwStartIndex = 0;
            this.dwStatus = 'process';
            this.dwIndexChange = new core.EventEmitter();
            this.destroy$ = new rxjs.Subject();
            this.showProcessDot = false;
            this.classMap = {};
        }
        Object.defineProperty(DwStepsComponent.prototype, "dwProgressDot", {
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (value instanceof core.TemplateRef) {
                    this.showProcessDot = true;
                    this.customProcessDotTemplate = value;
                }
                else {
                    this.showProcessDot = util.toBoolean(value);
                }
                this.updateChildrenSteps();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} changes
         * @return {?}
         */
        DwStepsComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwStartIndex || changes.dwDirection || changes.dwStatus || changes.dwCurrent) {
                this.updateChildrenSteps();
            }
            if (changes.dwDirection || changes.dwProgressDot || changes.dwLabelPlacement || changes.dwSize) {
                this.setClassMap();
            }
        };
        /**
         * @return {?}
         */
        DwStepsComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.setClassMap();
            this.updateChildrenSteps();
        };
        /**
         * @return {?}
         */
        DwStepsComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
            if (this.indexChangeSubscription) {
                this.indexChangeSubscription.unsubscribe();
            }
        };
        /**
         * @return {?}
         */
        DwStepsComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.steps) {
                this.steps.changes.pipe(operators.startWith(null), operators.takeUntil(this.destroy$)).subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.updateChildrenSteps();
                }));
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwStepsComponent.prototype.updateChildrenSteps = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.steps) {
                /** @type {?} */
                var length_1 = this.steps.length;
                this.steps.toArray().forEach((/**
                 * @param {?} step
                 * @param {?} index
                 * @return {?}
                 */
                function (step, index) {
                    Promise.resolve().then((/**
                     * @return {?}
                     */
                    function () {
                        step.outStatus = _this.dwStatus;
                        step.showProcessDot = _this.showProcessDot;
                        if (_this.customProcessDotTemplate) {
                            step.customProcessTemplate = _this.customProcessDotTemplate;
                        }
                        step.clickable = _this.dwIndexChange.observers.length > 0;
                        step.direction = _this.dwDirection;
                        step.index = index + _this.dwStartIndex;
                        step.currentIndex = _this.dwCurrent;
                        step.last = length_1 === index + 1;
                        step.markForCheck();
                    }));
                }));
                if (this.indexChangeSubscription) {
                    this.indexChangeSubscription.unsubscribe();
                }
                this.indexChangeSubscription = rxjs.merge.apply(void 0, __spread(this.steps.map((/**
                 * @param {?} step
                 * @return {?}
                 */
                function (step) { return step.click$; })))).subscribe((/**
                 * @param {?} index
                 * @return {?}
                 */
                function (index) { return _this.dwIndexChange.emit(index); }));
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwStepsComponent.prototype.setClassMap = /**
         * @private
         * @return {?}
         */
        function () {
            var _a;
            this.classMap = (_a = {},
                _a["ant-steps-" + this.dwDirection] = true,
                _a["ant-steps-label-horizontal"] = this.dwDirection === 'horizontal',
                _a["ant-steps-label-vertical"] = (this.showProcessDot || this.dwLabelPlacement === 'vertical') && this.dwDirection === 'horizontal',
                _a["ant-steps-dot"] = this.showProcessDot,
                _a['ant-steps-small'] = this.dwSize === 'small',
                _a['ant-steps-navigation'] = this.dwType === 'navigation',
                _a);
        };
        DwStepsComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        preserveWhitespaces: false,
                        selector: 'dw-steps',
                        exportAs: 'dwSteps',
                        template: "\n    <div class=\"ant-steps\" [ngClass]=\"classMap\">\n      <ng-content></ng-content>\n    </div>\n  "
                    }] }
        ];
        DwStepsComponent.propDecorators = {
            steps: [{ type: core.ContentChildren, args: [DwStepComponent,] }],
            dwCurrent: [{ type: core.Input }],
            dwDirection: [{ type: core.Input }],
            dwLabelPlacement: [{ type: core.Input }],
            dwType: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwStartIndex: [{ type: core.Input }],
            dwStatus: [{ type: core.Input }],
            dwProgressDot: [{ type: core.Input }],
            dwIndexChange: [{ type: core.Output }]
        };
        return DwStepsComponent;
    }());
    if (false) {
        /** @type {?} */
        DwStepsComponent.ngAcceptInputType_dwProgressDot;
        /** @type {?} */
        DwStepsComponent.prototype.steps;
        /** @type {?} */
        DwStepsComponent.prototype.dwCurrent;
        /** @type {?} */
        DwStepsComponent.prototype.dwDirection;
        /** @type {?} */
        DwStepsComponent.prototype.dwLabelPlacement;
        /** @type {?} */
        DwStepsComponent.prototype.dwType;
        /** @type {?} */
        DwStepsComponent.prototype.dwSize;
        /** @type {?} */
        DwStepsComponent.prototype.dwStartIndex;
        /** @type {?} */
        DwStepsComponent.prototype.dwStatus;
        /** @type {?} */
        DwStepsComponent.prototype.dwIndexChange;
        /**
         * @type {?}
         * @private
         */
        DwStepsComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwStepsComponent.prototype.indexChangeSubscription;
        /** @type {?} */
        DwStepsComponent.prototype.showProcessDot;
        /** @type {?} */
        DwStepsComponent.prototype.customProcessDotTemplate;
        /** @type {?} */
        DwStepsComponent.prototype.classMap;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: steps.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwStepsModule = /** @class */ (function () {
        function DwStepsModule() {
        }
        DwStepsModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, icon.DwIconModule, outlet.DwOutletModule],
                        exports: [DwStepsComponent, DwStepComponent],
                        declarations: [DwStepsComponent, DwStepComponent]
                    },] }
        ];
        return DwStepsModule;
    }());

    exports.DwStepComponent = DwStepComponent;
    exports.DwStepsComponent = DwStepsComponent;
    exports.DwStepsModule = DwStepsModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-steps.umd.js.map
