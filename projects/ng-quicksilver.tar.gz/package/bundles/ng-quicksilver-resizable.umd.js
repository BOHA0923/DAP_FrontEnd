(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core'), require('@angular/cdk/platform'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/resizable', ['exports', '@angular/common', '@angular/core', '@angular/cdk/platform', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].resizable = {}), global.ng.common, global.ng.core, global.ng.cdk.platform, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators));
}(this, (function (exports, common, core, platform, util, rxjs, operators) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resizable-utils.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} event
     * @return {?}
     */
    function getEventWithPoint(event) {
        return util.isTouchEvent(event) ? event.touches[0] || event.changedTouches[0] : ((/** @type {?} */ (event)));
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resizable.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwResizableService = /** @class */ (function () {
        function DwResizableService(ngZone, document) {
            this.ngZone = ngZone;
            this.listeners = new Map();
            this.handleMouseDown$ = new rxjs.Subject();
            this.documentMouseUp$ = new rxjs.Subject();
            this.documentMouseMove$ = new rxjs.Subject();
            this.mouseEntered$ = new rxjs.Subject();
            this.document = document;
        }
        /**
         * @param {?} event
         * @return {?}
         */
        DwResizableService.prototype.startResizing = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            var _this = this;
            /** @type {?} */
            var _isTouchEvent = util.isTouchEvent(event);
            this.clearListeners();
            /** @type {?} */
            var moveEvent = _isTouchEvent ? 'touchmove' : 'mousemove';
            /** @type {?} */
            var upEvent = _isTouchEvent ? 'touchend' : 'mouseup';
            /** @type {?} */
            var moveEventHandler = (/**
             * @param {?} e
             * @return {?}
             */
            function (e) {
                _this.documentMouseMove$.next(e);
            });
            /** @type {?} */
            var upEventHandler = (/**
             * @param {?} e
             * @return {?}
             */
            function (e) {
                _this.documentMouseUp$.next(e);
                _this.clearListeners();
            });
            this.listeners.set(moveEvent, moveEventHandler);
            this.listeners.set(upEvent, upEventHandler);
            this.ngZone.runOutsideAngular((/**
             * @return {?}
             */
            function () {
                _this.listeners.forEach((/**
                 * @param {?} handler
                 * @param {?} name
                 * @return {?}
                 */
                function (handler, name) {
                    _this.document.addEventListener(name, (/** @type {?} */ (handler)));
                }));
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwResizableService.prototype.clearListeners = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            this.listeners.forEach((/**
             * @param {?} handler
             * @param {?} name
             * @return {?}
             */
            function (handler, name) {
                _this.document.removeEventListener(name, (/** @type {?} */ (handler)));
            }));
            this.listeners.clear();
        };
        /**
         * @return {?}
         */
        DwResizableService.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.handleMouseDown$.complete();
            this.documentMouseUp$.complete();
            this.documentMouseMove$.complete();
            this.mouseEntered$.complete();
            this.clearListeners();
        };
        DwResizableService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwResizableService.ctorParameters = function () { return [
            { type: core.NgZone },
            { type: undefined, decorators: [{ type: core.Inject, args: [common.DOCUMENT,] }] }
        ]; };
        return DwResizableService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwResizableService.prototype.document;
        /**
         * @type {?}
         * @private
         */
        DwResizableService.prototype.listeners;
        /** @type {?} */
        DwResizableService.prototype.handleMouseDown$;
        /** @type {?} */
        DwResizableService.prototype.documentMouseUp$;
        /** @type {?} */
        DwResizableService.prototype.documentMouseMove$;
        /** @type {?} */
        DwResizableService.prototype.mouseEntered$;
        /**
         * @type {?}
         * @private
         */
        DwResizableService.prototype.ngZone;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resizable.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwResizeEvent() { }
    if (false) {
        /** @type {?|undefined} */
        DwResizeEvent.prototype.width;
        /** @type {?|undefined} */
        DwResizeEvent.prototype.height;
        /** @type {?|undefined} */
        DwResizeEvent.prototype.col;
        /** @type {?|undefined} */
        DwResizeEvent.prototype.mouseEvent;
    }
    var DwResizableDirective = /** @class */ (function () {
        function DwResizableDirective(elementRef, renderer, dwResizableService, platform, ngZone) {
            var _this = this;
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.dwResizableService = dwResizableService;
            this.platform = platform;
            this.ngZone = ngZone;
            this.dwBounds = 'parent';
            this.dwMinHeight = 40;
            this.dwMinWidth = 40;
            this.dwGridColumnCount = -1;
            this.dwMaxColumn = -1;
            this.dwMinColumn = -1;
            this.dwLockAspectRatio = false;
            this.dwPreview = false;
            this.dwDisabled = false;
            this.dwResize = new core.EventEmitter();
            this.dwResizeEnd = new core.EventEmitter();
            this.dwResizeStart = new core.EventEmitter();
            this.resizing = false;
            this.currentHandleEvent = null;
            this.ghostElement = null;
            this.sizeCache = null;
            this.destroy$ = new rxjs.Subject();
            this.dwResizableService.handleMouseDown$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                if (_this.dwDisabled) {
                    return;
                }
                _this.resizing = true;
                _this.dwResizableService.startResizing(event.mouseEvent);
                _this.currentHandleEvent = event;
                _this.setCursor();
                _this.dwResizeStart.emit({
                    mouseEvent: event.mouseEvent
                });
                _this.elRect = _this.el.getBoundingClientRect();
            }));
            this.dwResizableService.documentMouseUp$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                if (_this.resizing) {
                    _this.resizing = false;
                    _this.dwResizableService.documentMouseUp$.next();
                    _this.endResize(event);
                }
            }));
            this.dwResizableService.documentMouseMove$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                if (_this.resizing) {
                    _this.resize(event);
                }
            }));
        }
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.onMouseenter = /**
         * @return {?}
         */
        function () {
            this.dwResizableService.mouseEntered$.next(true);
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.onMouseleave = /**
         * @return {?}
         */
        function () {
            this.dwResizableService.mouseEntered$.next(false);
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.setPosition = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var position = getComputedStyle(this.el).position;
            if (position === 'static' || !position) {
                this.renderer.setStyle(this.el, 'position', 'relative');
            }
        };
        /**
         * @param {?} width
         * @param {?} height
         * @param {?} ratio
         * @return {?}
         */
        DwResizableDirective.prototype.calcSize = /**
         * @param {?} width
         * @param {?} height
         * @param {?} ratio
         * @return {?}
         */
        function (width, height, ratio) {
            /** @type {?} */
            var newWidth;
            /** @type {?} */
            var newHeight;
            /** @type {?} */
            var maxWidth;
            /** @type {?} */
            var maxHeight;
            /** @type {?} */
            var col = 0;
            /** @type {?} */
            var spanWidth = 0;
            /** @type {?} */
            var minWidth = this.dwMinWidth;
            /** @type {?} */
            var boundWidth = Infinity;
            /** @type {?} */
            var boundHeight = Infinity;
            if (this.dwBounds === 'parent') {
                /** @type {?} */
                var parent_1 = this.renderer.parentNode(this.el);
                if (parent_1 instanceof HTMLElement) {
                    /** @type {?} */
                    var parentRect = parent_1.getBoundingClientRect();
                    boundWidth = parentRect.width;
                    boundHeight = parentRect.height;
                }
            }
            else if (this.dwBounds === 'window') {
                if (typeof window !== 'undefined') {
                    boundWidth = window.innerWidth;
                    boundHeight = window.innerHeight;
                }
            }
            else if (this.dwBounds && this.dwBounds.nativeElement && this.dwBounds.nativeElement instanceof HTMLElement) {
                /** @type {?} */
                var boundsRect = this.dwBounds.nativeElement.getBoundingClientRect();
                boundWidth = boundsRect.width;
                boundHeight = boundsRect.height;
            }
            maxWidth = util.ensureInBounds((/** @type {?} */ (this.dwMaxWidth)), boundWidth);
            maxHeight = util.ensureInBounds((/** @type {?} */ (this.dwMaxHeight)), boundHeight);
            if (this.dwGridColumnCount !== -1) {
                spanWidth = maxWidth / this.dwGridColumnCount;
                minWidth = this.dwMinColumn !== -1 ? spanWidth * this.dwMinColumn : minWidth;
                maxWidth = this.dwMaxColumn !== -1 ? spanWidth * this.dwMaxColumn : maxWidth;
            }
            if (ratio !== -1) {
                if (/(left|right)/i.test((/** @type {?} */ (this.currentHandleEvent)).direction)) {
                    newWidth = Math.min(Math.max(width, minWidth), maxWidth);
                    newHeight = Math.min(Math.max(newWidth / ratio, this.dwMinHeight), maxHeight);
                    if (newHeight >= maxHeight || newHeight <= this.dwMinHeight) {
                        newWidth = Math.min(Math.max(newHeight * ratio, minWidth), maxWidth);
                    }
                }
                else {
                    newHeight = Math.min(Math.max(height, this.dwMinHeight), maxHeight);
                    newWidth = Math.min(Math.max(newHeight * ratio, minWidth), maxWidth);
                    if (newWidth >= maxWidth || newWidth <= minWidth) {
                        newHeight = Math.min(Math.max(newWidth / ratio, this.dwMinHeight), maxHeight);
                    }
                }
            }
            else {
                newWidth = Math.min(Math.max(width, minWidth), maxWidth);
                newHeight = Math.min(Math.max(height, this.dwMinHeight), maxHeight);
            }
            if (this.dwGridColumnCount !== -1) {
                col = Math.round(newWidth / spanWidth);
                newWidth = col * spanWidth;
            }
            return {
                col: col,
                width: newWidth,
                height: newHeight
            };
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.setCursor = /**
         * @return {?}
         */
        function () {
            switch ((/** @type {?} */ (this.currentHandleEvent)).direction) {
                case 'left':
                case 'right':
                    this.renderer.setStyle(document.body, 'cursor', 'ew-resize');
                    break;
                case 'top':
                case 'bottom':
                    this.renderer.setStyle(document.body, 'cursor', 'ns-resize');
                    break;
                case 'topLeft':
                case 'bottomRight':
                    this.renderer.setStyle(document.body, 'cursor', 'nwse-resize');
                    break;
                case 'topRight':
                case 'bottomLeft':
                    this.renderer.setStyle(document.body, 'cursor', 'nesw-resize');
                    break;
            }
            this.renderer.setStyle(document.body, 'user-select', 'none');
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwResizableDirective.prototype.resize = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            var _this = this;
            /** @type {?} */
            var elRect = this.elRect;
            /** @type {?} */
            var resizeEvent = getEventWithPoint(event);
            /** @type {?} */
            var handleEvent = getEventWithPoint((/** @type {?} */ (this.currentHandleEvent)).mouseEvent);
            /** @type {?} */
            var width = elRect.width;
            /** @type {?} */
            var height = elRect.height;
            /** @type {?} */
            var ratio = this.dwLockAspectRatio ? width / height : -1;
            switch ((/** @type {?} */ (this.currentHandleEvent)).direction) {
                case 'bottomRight':
                    width = resizeEvent.clientX - elRect.left;
                    height = resizeEvent.clientY - elRect.top;
                    break;
                case 'bottomLeft':
                    width = elRect.width + handleEvent.clientX - resizeEvent.clientX;
                    height = resizeEvent.clientY - elRect.top;
                    break;
                case 'topRight':
                    width = resizeEvent.clientX - elRect.left;
                    height = elRect.height + handleEvent.clientY - resizeEvent.clientY;
                    break;
                case 'topLeft':
                    width = elRect.width + handleEvent.clientX - resizeEvent.clientX;
                    height = elRect.height + handleEvent.clientY - resizeEvent.clientY;
                    break;
                case 'top':
                    height = elRect.height + handleEvent.clientY - resizeEvent.clientY;
                    break;
                case 'right':
                    width = resizeEvent.clientX - elRect.left;
                    break;
                case 'bottom':
                    height = resizeEvent.clientY - elRect.top;
                    break;
                case 'left':
                    width = elRect.width + handleEvent.clientX - resizeEvent.clientX;
            }
            /** @type {?} */
            var size = this.calcSize(width, height, ratio);
            this.sizeCache = __assign({}, size);
            this.ngZone.run((/**
             * @return {?}
             */
            function () {
                _this.dwResize.emit(__assign(__assign({}, size), { mouseEvent: event }));
            }));
            if (this.dwPreview) {
                this.previewResize(size);
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwResizableDirective.prototype.endResize = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            var _this = this;
            this.renderer.setStyle(document.body, 'cursor', '');
            this.renderer.setStyle(document.body, 'user-select', '');
            this.removeGhostElement();
            /** @type {?} */
            var size = this.sizeCache
                ? __assign({}, this.sizeCache) : {
                width: this.elRect.width,
                height: this.elRect.height
            };
            this.ngZone.run((/**
             * @return {?}
             */
            function () {
                _this.dwResizeEnd.emit(__assign(__assign({}, size), { mouseEvent: event }));
            }));
            this.sizeCache = null;
            this.currentHandleEvent = null;
        };
        /**
         * @param {?} __0
         * @return {?}
         */
        DwResizableDirective.prototype.previewResize = /**
         * @param {?} __0
         * @return {?}
         */
        function (_a) {
            var width = _a.width, height = _a.height;
            this.createGhostElement();
            this.renderer.setStyle(this.ghostElement, 'width', width + "px");
            this.renderer.setStyle(this.ghostElement, 'height', height + "px");
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.createGhostElement = /**
         * @return {?}
         */
        function () {
            if (!this.ghostElement) {
                this.ghostElement = this.renderer.createElement('div');
                this.renderer.setAttribute(this.ghostElement, 'class', 'dw-resizable-preview');
            }
            this.renderer.appendChild(this.el, this.ghostElement);
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.removeGhostElement = /**
         * @return {?}
         */
        function () {
            if (this.ghostElement) {
                this.renderer.removeChild(this.el, this.ghostElement);
            }
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            if (this.platform.isBrowser) {
                this.el = this.elementRef.nativeElement;
                this.setPosition();
            }
        };
        /**
         * @return {?}
         */
        DwResizableDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.ghostElement = null;
            this.sizeCache = null;
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwResizableDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-resizable]',
                        exportAs: 'dwResizable',
                        providers: [DwResizableService],
                        host: {
                            '[class.dw-resizable]': 'true',
                            '[class.dw-resizable-resizing]': 'resizing',
                            '[class.dw-resizable-disabled]': 'dwDisabled',
                            '(mouseenter)': 'onMouseenter()',
                            '(mouseleave)': 'onMouseleave()'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwResizableDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: DwResizableService },
            { type: platform.Platform },
            { type: core.NgZone }
        ]; };
        DwResizableDirective.propDecorators = {
            dwBounds: [{ type: core.Input }],
            dwMaxHeight: [{ type: core.Input }],
            dwMaxWidth: [{ type: core.Input }],
            dwMinHeight: [{ type: core.Input }],
            dwMinWidth: [{ type: core.Input }],
            dwGridColumnCount: [{ type: core.Input }],
            dwMaxColumn: [{ type: core.Input }],
            dwMinColumn: [{ type: core.Input }],
            dwLockAspectRatio: [{ type: core.Input }],
            dwPreview: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwResize: [{ type: core.Output }],
            dwResizeEnd: [{ type: core.Output }],
            dwResizeStart: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwResizableDirective.prototype, "dwLockAspectRatio", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwResizableDirective.prototype, "dwPreview", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwResizableDirective.prototype, "dwDisabled", void 0);
        return DwResizableDirective;
    }());
    if (false) {
        /** @type {?} */
        DwResizableDirective.ngAcceptInputType_dwLockAspectRatio;
        /** @type {?} */
        DwResizableDirective.ngAcceptInputType_dwPreview;
        /** @type {?} */
        DwResizableDirective.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwResizableDirective.prototype.dwBounds;
        /** @type {?} */
        DwResizableDirective.prototype.dwMaxHeight;
        /** @type {?} */
        DwResizableDirective.prototype.dwMaxWidth;
        /** @type {?} */
        DwResizableDirective.prototype.dwMinHeight;
        /** @type {?} */
        DwResizableDirective.prototype.dwMinWidth;
        /** @type {?} */
        DwResizableDirective.prototype.dwGridColumnCount;
        /** @type {?} */
        DwResizableDirective.prototype.dwMaxColumn;
        /** @type {?} */
        DwResizableDirective.prototype.dwMinColumn;
        /** @type {?} */
        DwResizableDirective.prototype.dwLockAspectRatio;
        /** @type {?} */
        DwResizableDirective.prototype.dwPreview;
        /** @type {?} */
        DwResizableDirective.prototype.dwDisabled;
        /** @type {?} */
        DwResizableDirective.prototype.dwResize;
        /** @type {?} */
        DwResizableDirective.prototype.dwResizeEnd;
        /** @type {?} */
        DwResizableDirective.prototype.dwResizeStart;
        /** @type {?} */
        DwResizableDirective.prototype.resizing;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.elRect;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.currentHandleEvent;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.ghostElement;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.el;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.sizeCache;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.dwResizableService;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.platform;
        /**
         * @type {?}
         * @private
         */
        DwResizableDirective.prototype.ngZone;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resize-handle.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwResizeHandleMouseDownEvent = /** @class */ (function () {
        function DwResizeHandleMouseDownEvent(direction, mouseEvent) {
            this.direction = direction;
            this.mouseEvent = mouseEvent;
        }
        return DwResizeHandleMouseDownEvent;
    }());
    if (false) {
        /** @type {?} */
        DwResizeHandleMouseDownEvent.prototype.direction;
        /** @type {?} */
        DwResizeHandleMouseDownEvent.prototype.mouseEvent;
    }
    var DwResizeHandleComponent = /** @class */ (function () {
        function DwResizeHandleComponent(dwResizableService, cdr) {
            this.dwResizableService = dwResizableService;
            this.cdr = cdr;
            this.dwDirection = 'bottomRight';
            this.dwMouseDown = new core.EventEmitter();
            this.entered = false;
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @return {?}
         */
        DwResizeHandleComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.dwResizableService.mouseEntered$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} entered
             * @return {?}
             */
            function (entered) {
                _this.entered = entered;
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwResizeHandleComponent.prototype.onMousedown = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.dwResizableService.handleMouseDown$.next(new DwResizeHandleMouseDownEvent(this.dwDirection, event));
        };
        /**
         * @return {?}
         */
        DwResizeHandleComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwResizeHandleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-resize-handle, [dw-resize-handle]',
                        exportAs: 'dwResizeHandle',
                        template: " <ng-content></ng-content> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        host: {
                            '[class.dw-resizable-handle]': 'true',
                            '[class.dw-resizable-handle-top]': "dwDirection === 'top'",
                            '[class.dw-resizable-handle-right]': "dwDirection === 'right'",
                            '[class.dw-resizable-handle-bottom]': "dwDirection === 'bottom'",
                            '[class.dw-resizable-handle-left]': "dwDirection === 'left'",
                            '[class.dw-resizable-handle-topRight]': "dwDirection === 'topRight'",
                            '[class.dw-resizable-handle-bottomRight]': "dwDirection === 'bottomRight'",
                            '[class.dw-resizable-handle-bottomLeft]': "dwDirection === 'bottomLeft'",
                            '[class.dw-resizable-handle-topLeft]': "dwDirection === 'topLeft'",
                            '[class.dw-resizable-handle-box-hover]': 'entered',
                            '(mousedown)': 'onMousedown($event)',
                            '(touchstart)': 'onMousedown($event)'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwResizeHandleComponent.ctorParameters = function () { return [
            { type: DwResizableService },
            { type: core.ChangeDetectorRef }
        ]; };
        DwResizeHandleComponent.propDecorators = {
            dwDirection: [{ type: core.Input }],
            dwMouseDown: [{ type: core.Output }]
        };
        return DwResizeHandleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwResizeHandleComponent.prototype.dwDirection;
        /** @type {?} */
        DwResizeHandleComponent.prototype.dwMouseDown;
        /** @type {?} */
        DwResizeHandleComponent.prototype.entered;
        /**
         * @type {?}
         * @private
         */
        DwResizeHandleComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwResizeHandleComponent.prototype.dwResizableService;
        /**
         * @type {?}
         * @private
         */
        DwResizeHandleComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resize-handles.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DEFAULT_RESIZE_DIRECTION = [
        'bottomRight',
        'topRight',
        'bottomLeft',
        'topLeft',
        'bottom',
        'right',
        'top',
        'left'
    ];
    var DwResizeHandlesComponent = /** @class */ (function () {
        function DwResizeHandlesComponent() {
            this.dwDirections = DEFAULT_RESIZE_DIRECTION;
            this.directions = new Set(this.dwDirections);
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwResizeHandlesComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwDirections) {
                this.directions = new Set(changes.dwDirections.currentValue);
            }
        };
        DwResizeHandlesComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-resize-handles',
                        exportAs: 'dwResizeHandles',
                        template: " <dw-resize-handle *ngFor=\"let dir of directions\" [dwDirection]=\"dir\"></dw-resize-handle> ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwResizeHandlesComponent.ctorParameters = function () { return []; };
        DwResizeHandlesComponent.propDecorators = {
            dwDirections: [{ type: core.Input }]
        };
        return DwResizeHandlesComponent;
    }());
    if (false) {
        /** @type {?} */
        DwResizeHandlesComponent.prototype.dwDirections;
        /** @type {?} */
        DwResizeHandlesComponent.prototype.directions;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resizable.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwResizableModule = /** @class */ (function () {
        function DwResizableModule() {
        }
        DwResizableModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule],
                        declarations: [DwResizableDirective, DwResizeHandleComponent, DwResizeHandlesComponent],
                        exports: [DwResizableDirective, DwResizeHandleComponent, DwResizeHandlesComponent]
                    },] }
        ];
        return DwResizableModule;
    }());

    exports.DEFAULT_RESIZE_DIRECTION = DEFAULT_RESIZE_DIRECTION;
    exports.DwResizableDirective = DwResizableDirective;
    exports.DwResizableModule = DwResizableModule;
    exports.DwResizableService = DwResizableService;
    exports.DwResizeHandleComponent = DwResizeHandleComponent;
    exports.DwResizeHandleMouseDownEvent = DwResizeHandleMouseDownEvent;
    exports.DwResizeHandlesComponent = DwResizeHandlesComponent;
    exports.getEventWithPoint = getEventWithPoint;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-resizable.umd.js.map
