(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/keycodes'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/core/config'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/util'), require('@angular/common'), require('ng-quicksilver/icon'), require('ng-quicksilver/tooltip')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/rate', ['exports', '@angular/cdk/keycodes', '@angular/core', '@angular/forms', 'ng-quicksilver/core/config', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/util', '@angular/common', 'ng-quicksilver/icon', 'ng-quicksilver/tooltip'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].rate = {}), global.ng.cdk.keycodes, global.ng.core, global.ng.forms, global['ng-quicksilver'].core.config, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core.util, global.ng.common, global['ng-quicksilver'].icon, global['ng-quicksilver'].tooltip));
}(this, (function (exports, keycodes, core, forms, config, rxjs, operators, util, common, icon, tooltip) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: rate.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'rate';
    var DwRateComponent = /** @class */ (function () {
        function DwRateComponent(dwConfigService, renderer, cdr) {
            this.dwConfigService = dwConfigService;
            this.renderer = renderer;
            this.cdr = cdr;
            this.dwAllowClear = true;
            this.dwAllowHalf = false;
            this.dwDisabled = false;
            this.dwAutoFocus = false;
            this.dwCount = 5;
            this.dwTooltips = [];
            this.dwOnBlur = new core.EventEmitter();
            this.dwOnFocus = new core.EventEmitter();
            this.dwOnHoverChange = new core.EventEmitter();
            this.dwOnKeyDown = new core.EventEmitter();
            this.classMap = {};
            this.starArray = [];
            this.starStyleArray = [];
            this.destroy$ = new rxjs.Subject();
            this.hasHalf = false;
            this.hoverValue = 0;
            this.isFocused = false;
            this._value = 0;
            this.onChange = (/**
             * @return {?}
             */
            function () { return null; });
            this.onTouched = (/**
             * @return {?}
             */
            function () { return null; });
        }
        Object.defineProperty(DwRateComponent.prototype, "dwValue", {
            get: /**
             * @return {?}
             */
            function () {
                return this._value;
            },
            set: /**
             * @param {?} input
             * @return {?}
             */
            function (input) {
                if (this._value === input) {
                    return;
                }
                this._value = input;
                this.hasHalf = !Number.isInteger(input);
                this.hoverValue = Math.ceil(input);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} changes
         * @return {?}
         */
        DwRateComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwAutoFocus = changes.dwAutoFocus, dwCount = changes.dwCount, dwValue = changes.dwValue;
            if (dwAutoFocus && !dwAutoFocus.isFirstChange()) {
                /** @type {?} */
                var el = (/** @type {?} */ (this.ulElement)).nativeElement;
                if (this.dwAutoFocus && !this.dwDisabled) {
                    this.renderer.setAttribute(el, 'autofocus', 'autofocus');
                }
                else {
                    this.renderer.removeAttribute(el, 'autofocus');
                }
            }
            if (dwCount) {
                this.updateStarArray();
            }
            if (dwValue) {
                this.updateStarStyle();
            }
        };
        /**
         * @return {?}
         */
        DwRateComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.dwConfigService
                .getConfigChangeEventForComponent(DW_CONFIG_COMPONENT_NAME)
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @return {?}
             */
            function () { return _this.cdr.markForCheck(); }));
        };
        /**
         * @return {?}
         */
        DwRateComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @param {?} index
         * @param {?} isHalf
         * @return {?}
         */
        DwRateComponent.prototype.onItemClick = /**
         * @param {?} index
         * @param {?} isHalf
         * @return {?}
         */
        function (index, isHalf) {
            if (this.dwDisabled) {
                return;
            }
            this.hoverValue = index + 1;
            /** @type {?} */
            var actualValue = isHalf ? index + 0.5 : index + 1;
            if (this.dwValue === actualValue) {
                if (this.dwAllowClear) {
                    this.dwValue = 0;
                    this.onChange(this.dwValue);
                }
            }
            else {
                this.dwValue = actualValue;
                this.onChange(this.dwValue);
            }
            this.updateStarStyle();
        };
        /**
         * @param {?} index
         * @param {?} isHalf
         * @return {?}
         */
        DwRateComponent.prototype.onItemHover = /**
         * @param {?} index
         * @param {?} isHalf
         * @return {?}
         */
        function (index, isHalf) {
            if (this.dwDisabled || (this.hoverValue === index + 1 && isHalf === this.hasHalf)) {
                return;
            }
            this.hoverValue = index + 1;
            this.hasHalf = isHalf;
            this.dwOnHoverChange.emit(this.hoverValue);
            this.updateStarStyle();
        };
        /**
         * @return {?}
         */
        DwRateComponent.prototype.onRateLeave = /**
         * @return {?}
         */
        function () {
            this.hasHalf = !Number.isInteger(this.dwValue);
            this.hoverValue = Math.ceil(this.dwValue);
            this.updateStarStyle();
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwRateComponent.prototype.onFocus = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            this.isFocused = true;
            this.dwOnFocus.emit(e);
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwRateComponent.prototype.onBlur = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            this.isFocused = false;
            this.dwOnBlur.emit(e);
        };
        /**
         * @return {?}
         */
        DwRateComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            (/** @type {?} */ (this.ulElement)).nativeElement.focus();
        };
        /**
         * @return {?}
         */
        DwRateComponent.prototype.blur = /**
         * @return {?}
         */
        function () {
            (/** @type {?} */ (this.ulElement)).nativeElement.blur();
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwRateComponent.prototype.onKeyDown = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            /** @type {?} */
            var oldVal = this.dwValue;
            if (e.keyCode === keycodes.RIGHT_ARROW && this.dwValue < this.dwCount) {
                this.dwValue += this.dwAllowHalf ? 0.5 : 1;
            }
            else if (e.keyCode === keycodes.LEFT_ARROW && this.dwValue > 0) {
                this.dwValue -= this.dwAllowHalf ? 0.5 : 1;
            }
            if (oldVal !== this.dwValue) {
                this.onChange(this.dwValue);
                this.dwOnKeyDown.emit(e);
                this.updateStarStyle();
                this.cdr.markForCheck();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwRateComponent.prototype.updateStarArray = /**
         * @private
         * @return {?}
         */
        function () {
            this.starArray = Array(this.dwCount)
                .fill(0)
                .map((/**
             * @param {?} _
             * @param {?} i
             * @return {?}
             */
            function (_, i) { return i; }));
            this.updateStarStyle();
        };
        /**
         * @private
         * @return {?}
         */
        DwRateComponent.prototype.updateStarStyle = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            this.starStyleArray = this.starArray.map((/**
             * @param {?} i
             * @return {?}
             */
            function (i) {
                var _a;
                /** @type {?} */
                var prefix = 'ant-rate-star';
                /** @type {?} */
                var value = i + 1;
                return _a = {},
                    _a[prefix + "-full"] = value < _this.hoverValue || (!_this.hasHalf && value === _this.hoverValue),
                    _a[prefix + "-half"] = _this.hasHalf && value === _this.hoverValue,
                    _a[prefix + "-active"] = _this.hasHalf && value === _this.hoverValue,
                    _a[prefix + "-zero"] = value > _this.hoverValue,
                    _a[prefix + "-focused"] = _this.hasHalf && value === _this.hoverValue && _this.isFocused,
                    _a;
            }));
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwRateComponent.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.dwValue = value || 0;
            this.updateStarArray();
            this.cdr.markForCheck();
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwRateComponent.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            this.dwDisabled = isDisabled;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwRateComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwRateComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        DwRateComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-rate',
                        exportAs: 'dwRate',
                        preserveWhitespaces: false,
                        template: "\n    <ul\n      #ulElement\n      class=\"ant-rate\"\n      [class.ant-rate-disabled]=\"dwDisabled\"\n      [ngClass]=\"classMap\"\n      (blur)=\"onBlur($event)\"\n      (focus)=\"onFocus($event)\"\n      (keydown)=\"onKeyDown($event); $event.preventDefault()\"\n      (mouseleave)=\"onRateLeave(); $event.stopPropagation()\"\n      [tabindex]=\"dwDisabled ? -1 : 1\"\n    >\n      <li\n        *ngFor=\"let star of starArray; let i = index\"\n        class=\"ant-rate-star\"\n        [ngClass]=\"starStyleArray[i] || ''\"\n        dw-tooltip\n        [dwTooltipTitle]=\"dwTooltips[i]\"\n      >\n        <div\n          dw-rate-item\n          [allowHalf]=\"dwAllowHalf\"\n          [character]=\"dwCharacter\"\n          (itemHover)=\"onItemHover(i, $event)\"\n          (itemClick)=\"onItemClick(i, $event)\"\n        ></div>\n      </li>\n    </ul>\n  ",
                        providers: [
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwRateComponent; })),
                                multi: true
                            }
                        ]
                    }] }
        ];
        /** @nocollapse */
        DwRateComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: core.Renderer2 },
            { type: core.ChangeDetectorRef }
        ]; };
        DwRateComponent.propDecorators = {
            ulElement: [{ type: core.ViewChild, args: ['ulElement', { static: false },] }],
            dwAllowClear: [{ type: core.Input }],
            dwAllowHalf: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwAutoFocus: [{ type: core.Input }],
            dwCharacter: [{ type: core.Input }],
            dwCount: [{ type: core.Input }],
            dwTooltips: [{ type: core.Input }],
            dwOnBlur: [{ type: core.Output }],
            dwOnFocus: [{ type: core.Output }],
            dwOnHoverChange: [{ type: core.Output }],
            dwOnKeyDown: [{ type: core.Output }]
        };
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwRateComponent.prototype, "dwAllowClear", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwRateComponent.prototype, "dwAllowHalf", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwRateComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwRateComponent.prototype, "dwAutoFocus", void 0);
        __decorate([
            util.InputNumber(),
            __metadata("design:type", Number)
        ], DwRateComponent.prototype, "dwCount", void 0);
        return DwRateComponent;
    }());
    if (false) {
        /** @type {?} */
        DwRateComponent.ngAcceptInputType_dwAllowClear;
        /** @type {?} */
        DwRateComponent.ngAcceptInputType_dwAllowHalf;
        /** @type {?} */
        DwRateComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwRateComponent.ngAcceptInputType_dwAutoFocus;
        /** @type {?} */
        DwRateComponent.ngAcceptInputType_dwCount;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.ulElement;
        /** @type {?} */
        DwRateComponent.prototype.dwAllowClear;
        /** @type {?} */
        DwRateComponent.prototype.dwAllowHalf;
        /** @type {?} */
        DwRateComponent.prototype.dwDisabled;
        /** @type {?} */
        DwRateComponent.prototype.dwAutoFocus;
        /** @type {?} */
        DwRateComponent.prototype.dwCharacter;
        /** @type {?} */
        DwRateComponent.prototype.dwCount;
        /** @type {?} */
        DwRateComponent.prototype.dwTooltips;
        /** @type {?} */
        DwRateComponent.prototype.dwOnBlur;
        /** @type {?} */
        DwRateComponent.prototype.dwOnFocus;
        /** @type {?} */
        DwRateComponent.prototype.dwOnHoverChange;
        /** @type {?} */
        DwRateComponent.prototype.dwOnKeyDown;
        /** @type {?} */
        DwRateComponent.prototype.classMap;
        /** @type {?} */
        DwRateComponent.prototype.starArray;
        /** @type {?} */
        DwRateComponent.prototype.starStyleArray;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.hasHalf;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.hoverValue;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.isFocused;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype._value;
        /** @type {?} */
        DwRateComponent.prototype.onChange;
        /** @type {?} */
        DwRateComponent.prototype.onTouched;
        /** @type {?} */
        DwRateComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwRateComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: rate-item.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwRateItemComponent = /** @class */ (function () {
        function DwRateItemComponent() {
            this.allowHalf = false;
            this.itemHover = new core.EventEmitter();
            this.itemClick = new core.EventEmitter();
        }
        /**
         * @param {?} isHalf
         * @return {?}
         */
        DwRateItemComponent.prototype.hoverRate = /**
         * @param {?} isHalf
         * @return {?}
         */
        function (isHalf) {
            this.itemHover.next(isHalf && this.allowHalf);
        };
        /**
         * @param {?} isHalf
         * @return {?}
         */
        DwRateItemComponent.prototype.clickRate = /**
         * @param {?} isHalf
         * @return {?}
         */
        function (isHalf) {
            this.itemClick.next(isHalf && this.allowHalf);
        };
        DwRateItemComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: '[dw-rate-item]',
                        exportAs: 'dwRateItem',
                        template: "\n    <div class=\"ant-rate-star-second\" (mouseover)=\"hoverRate(false); $event.stopPropagation()\" (click)=\"clickRate(false)\">\n      <ng-template [ngTemplateOutlet]=\"character || defaultCharacter\"></ng-template>\n    </div>\n    <div class=\"ant-rate-star-first\" (mouseover)=\"hoverRate(true); $event.stopPropagation()\" (click)=\"clickRate(true)\">\n      <ng-template [ngTemplateOutlet]=\"character || defaultCharacter\"></ng-template>\n    </div>\n\n    <ng-template #defaultCharacter>\n      <i dw-icon dwType=\"star\" dwTheme=\"fill\"></i>\n    </ng-template>\n  "
                    }] }
        ];
        DwRateItemComponent.propDecorators = {
            character: [{ type: core.Input }],
            allowHalf: [{ type: core.Input }],
            itemHover: [{ type: core.Output }],
            itemClick: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwRateItemComponent.prototype, "allowHalf", void 0);
        return DwRateItemComponent;
    }());
    if (false) {
        /** @type {?} */
        DwRateItemComponent.ngAcceptInputType_allowHalf;
        /** @type {?} */
        DwRateItemComponent.prototype.character;
        /** @type {?} */
        DwRateItemComponent.prototype.allowHalf;
        /** @type {?} */
        DwRateItemComponent.prototype.itemHover;
        /** @type {?} */
        DwRateItemComponent.prototype.itemClick;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: rate.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwRateModule = /** @class */ (function () {
        function DwRateModule() {
        }
        DwRateModule.decorators = [
            { type: core.NgModule, args: [{
                        exports: [DwRateComponent],
                        declarations: [DwRateComponent, DwRateItemComponent],
                        imports: [common.CommonModule, icon.DwIconModule, tooltip.DwToolTipModule]
                    },] }
        ];
        return DwRateModule;
    }());

    exports.DwRateComponent = DwRateComponent;
    exports.DwRateItemComponent = DwRateItemComponent;
    exports.DwRateModule = DwRateModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-rate.umd.js.map
