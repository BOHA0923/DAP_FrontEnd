(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/router'), require('@angular/cdk/overlay'), require('@angular/cdk/platform'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/core/animation'), require('@angular/common'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/menu', ['exports', '@angular/core', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/router', '@angular/cdk/overlay', '@angular/cdk/platform', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/overlay', 'ng-quicksilver/core/animation', '@angular/common', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].menu = {}), global.ng.core, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.router, global.ng.cdk.overlay, global.ng.cdk.platform, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].core.animation, global.ng.common, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon));
}(this, (function (exports, core, util, rxjs, operators, router, overlay, platform, noAnimation, overlay$1, animation, common, outlet, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var MenuService = /** @class */ (function () {
        function MenuService() {
            /**
             * all descendant menu click *
             */
            this.descendantMenuItemClick$ = new rxjs.Subject();
            /**
             * child menu item click *
             */
            this.childMenuItemClick$ = new rxjs.Subject();
            this.theme$ = new rxjs.BehaviorSubject('light');
            this.mode$ = new rxjs.BehaviorSubject('vertical');
            this.inlineIndent$ = new rxjs.BehaviorSubject(24);
            this.isChildSubMenuOpen$ = new rxjs.BehaviorSubject(false);
        }
        /**
         * @param {?} menu
         * @return {?}
         */
        MenuService.prototype.onDescendantMenuItemClick = /**
         * @param {?} menu
         * @return {?}
         */
        function (menu) {
            this.descendantMenuItemClick$.next(menu);
        };
        /**
         * @param {?} menu
         * @return {?}
         */
        MenuService.prototype.onChildMenuItemClick = /**
         * @param {?} menu
         * @return {?}
         */
        function (menu) {
            this.childMenuItemClick$.next(menu);
        };
        /**
         * @param {?} mode
         * @return {?}
         */
        MenuService.prototype.setMode = /**
         * @param {?} mode
         * @return {?}
         */
        function (mode) {
            this.mode$.next(mode);
        };
        /**
         * @param {?} theme
         * @return {?}
         */
        MenuService.prototype.setTheme = /**
         * @param {?} theme
         * @return {?}
         */
        function (theme) {
            this.theme$.next(theme);
        };
        /**
         * @param {?} indent
         * @return {?}
         */
        MenuService.prototype.setInlineIndent = /**
         * @param {?} indent
         * @return {?}
         */
        function (indent) {
            this.inlineIndent$.next(indent);
        };
        MenuService.decorators = [
            { type: core.Injectable }
        ];
        return MenuService;
    }());
    if (false) {
        /**
         * all descendant menu click *
         * @type {?}
         */
        MenuService.prototype.descendantMenuItemClick$;
        /**
         * child menu item click *
         * @type {?}
         */
        MenuService.prototype.childMenuItemClick$;
        /** @type {?} */
        MenuService.prototype.theme$;
        /** @type {?} */
        MenuService.prototype.mode$;
        /** @type {?} */
        MenuService.prototype.inlineIndent$;
        /** @type {?} */
        MenuService.prototype.isChildSubMenuOpen$;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu.token.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DwIsMenuInsideDropDownToken = new core.InjectionToken('DwIsInDropDownMenuToken');
    /** @type {?} */
    var DwMenuServiceLocalToken = new core.InjectionToken('DwMenuServiceLocalToken');

    /**
     * @fileoverview added by tsickle
     * Generated from: submenu.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSubmenuService = /** @class */ (function () {
        function DwSubmenuService(dwHostSubmenuService, dwMenuService, isMenuInsideDropDown) {
            var _this = this;
            this.dwHostSubmenuService = dwHostSubmenuService;
            this.dwMenuService = dwMenuService;
            this.isMenuInsideDropDown = isMenuInsideDropDown;
            this.mode$ = this.dwMenuService.mode$.pipe(operators.map((/**
             * @param {?} mode
             * @return {?}
             */
            function (mode) {
                if (mode === 'inline') {
                    return 'inline';
                    /** if inside another submenu, set the mode to vertical **/
                }
                else if (mode === 'vertical' || _this.dwHostSubmenuService) {
                    return 'vertical';
                }
                else {
                    return 'horizontal';
                }
            })));
            this.level = 1;
            this.isCurrentSubMenuOpen$ = new rxjs.BehaviorSubject(false);
            this.isChildSubMenuOpen$ = new rxjs.BehaviorSubject(false);
            /**
             * submenu title & overlay mouse enter status *
             */
            this.isMouseEnterTitleOrOverlay$ = new rxjs.Subject();
            this.childMenuItemClick$ = new rxjs.Subject();
            if (this.dwHostSubmenuService) {
                this.level = this.dwHostSubmenuService.level + 1;
            }
            /**
             * close if menu item clicked *
             * @type {?}
             */
            var isClosedByMenuItemClick = this.childMenuItemClick$.pipe(operators.flatMap((/**
             * @return {?}
             */
            function () { return _this.mode$; })), operators.filter((/**
             * @param {?} mode
             * @return {?}
             */
            function (mode) { return mode !== 'inline' || _this.isMenuInsideDropDown; })), operators.mapTo(false));
            /** @type {?} */
            var isCurrentSubmenuOpen$ = rxjs.merge(this.isMouseEnterTitleOrOverlay$, isClosedByMenuItemClick);
            /**
             * combine the child submenu status with current submenu status to calculate host submenu open *
             * @type {?}
             */
            var isSubMenuOpenWithDebounce$ = rxjs.combineLatest([this.isChildSubMenuOpen$, isCurrentSubmenuOpen$]).pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), isChildSubMenuOpen = _b[0], isCurrentSubmenuOpen = _b[1];
                return isChildSubMenuOpen || isCurrentSubmenuOpen;
            })), operators.auditTime(150), operators.distinctUntilChanged());
            isSubMenuOpenWithDebounce$.pipe(operators.distinctUntilChanged()).subscribe((/**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                _this.setOpenStateWithoutDebounce(data);
                if (_this.dwHostSubmenuService) {
                    /** set parent submenu's child submenu open status **/
                    _this.dwHostSubmenuService.isChildSubMenuOpen$.next(data);
                }
                else {
                    _this.dwMenuService.isChildSubMenuOpen$.next(data);
                }
            }));
        }
        /**
         * menu item inside submenu clicked
         * @param menu
         */
        /**
         * menu item inside submenu clicked
         * @param {?} menu
         * @return {?}
         */
        DwSubmenuService.prototype.onChildMenuItemClick = /**
         * menu item inside submenu clicked
         * @param {?} menu
         * @return {?}
         */
        function (menu) {
            this.childMenuItemClick$.next(menu);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSubmenuService.prototype.setOpenStateWithoutDebounce = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.isCurrentSubMenuOpen$.next(value);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSubmenuService.prototype.setMouseEnterTitleOrOverlayState = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.isMouseEnterTitleOrOverlay$.next(value);
        };
        DwSubmenuService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwSubmenuService.ctorParameters = function () { return [
            { type: DwSubmenuService, decorators: [{ type: core.SkipSelf }, { type: core.Optional }] },
            { type: MenuService },
            { type: Boolean, decorators: [{ type: core.Inject, args: [DwIsMenuInsideDropDownToken,] }] }
        ]; };
        return DwSubmenuService;
    }());
    if (false) {
        /** @type {?} */
        DwSubmenuService.prototype.mode$;
        /** @type {?} */
        DwSubmenuService.prototype.level;
        /** @type {?} */
        DwSubmenuService.prototype.isCurrentSubMenuOpen$;
        /**
         * @type {?}
         * @private
         */
        DwSubmenuService.prototype.isChildSubMenuOpen$;
        /**
         * submenu title & overlay mouse enter status *
         * @type {?}
         * @private
         */
        DwSubmenuService.prototype.isMouseEnterTitleOrOverlay$;
        /**
         * @type {?}
         * @private
         */
        DwSubmenuService.prototype.childMenuItemClick$;
        /**
         * @type {?}
         * @private
         */
        DwSubmenuService.prototype.dwHostSubmenuService;
        /** @type {?} */
        DwSubmenuService.prototype.dwMenuService;
        /** @type {?} */
        DwSubmenuService.prototype.isMenuInsideDropDown;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu-item.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwMenuItemDirective = /** @class */ (function () {
        function DwMenuItemDirective(dwMenuService, cdr, dwSubmenuService, isMenuInsideDropDown, routerLink, routerLinkWithHref, router$1) {
            var _this = this;
            this.dwMenuService = dwMenuService;
            this.cdr = cdr;
            this.dwSubmenuService = dwSubmenuService;
            this.isMenuInsideDropDown = isMenuInsideDropDown;
            this.routerLink = routerLink;
            this.routerLinkWithHref = routerLinkWithHref;
            this.router = router$1;
            this.destroy$ = new rxjs.Subject();
            this.level = this.dwSubmenuService ? this.dwSubmenuService.level + 1 : 1;
            this.selected$ = new rxjs.Subject();
            this.inlinePaddingLeft = null;
            this.dwDisabled = false;
            this.dwSelected = false;
            this.dwMatchRouterExact = false;
            this.dwMatchRouter = false;
            if (router$1) {
                (/** @type {?} */ (this.router)).events.pipe(operators.takeUntil(this.destroy$), operators.filter((/**
                 * @param {?} e
                 * @return {?}
                 */
                function (e) { return e instanceof router.NavigationEnd; }))).subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.updateRouterActive();
                }));
            }
        }
        /** clear all item selected status except this */
        /**
         * clear all item selected status except this
         * @param {?} e
         * @return {?}
         */
        DwMenuItemDirective.prototype.clickMenuItem = /**
         * clear all item selected status except this
         * @param {?} e
         * @return {?}
         */
        function (e) {
            if (this.dwDisabled) {
                e.preventDefault();
                e.stopPropagation();
            }
            else {
                this.dwMenuService.onDescendantMenuItemClick(this);
                if (this.dwSubmenuService) {
                    /** menu item inside the submenu **/
                    this.dwSubmenuService.onChildMenuItemClick(this);
                }
                else {
                    /** menu item inside the root menu **/
                    this.dwMenuService.onChildMenuItemClick(this);
                }
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwMenuItemDirective.prototype.setSelectedState = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.dwSelected = value;
            this.selected$.next(value);
        };
        /**
         * @private
         * @return {?}
         */
        DwMenuItemDirective.prototype.updateRouterActive = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.listOfRouterLink || !this.listOfRouterLinkWithHref || !this.router || !this.router.navigated || !this.dwMatchRouter) {
                return;
            }
            Promise.resolve().then((/**
             * @return {?}
             */
            function () {
                /** @type {?} */
                var hasActiveLinks = _this.hasActiveLinks();
                if (_this.dwSelected !== hasActiveLinks) {
                    _this.dwSelected = hasActiveLinks;
                    _this.setSelectedState(_this.dwSelected);
                    _this.cdr.markForCheck();
                }
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwMenuItemDirective.prototype.hasActiveLinks = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var isActiveCheckFn = this.isLinkActive((/** @type {?} */ (this.router)));
            return ((this.routerLink && isActiveCheckFn(this.routerLink)) ||
                (this.routerLinkWithHref && isActiveCheckFn(this.routerLinkWithHref)) ||
                this.listOfRouterLink.some(isActiveCheckFn) ||
                this.listOfRouterLinkWithHref.some(isActiveCheckFn));
        };
        /**
         * @private
         * @param {?} router
         * @return {?}
         */
        DwMenuItemDirective.prototype.isLinkActive = /**
         * @private
         * @param {?} router
         * @return {?}
         */
        function (router) {
            var _this = this;
            return (/**
             * @param {?} link
             * @return {?}
             */
            function (link) { return router.isActive(link.urlTree, _this.dwMatchRouterExact); });
        };
        /**
         * @return {?}
         */
        DwMenuItemDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** store origin padding in padding */
            rxjs.combineLatest([this.dwMenuService.mode$, this.dwMenuService.inlineIndent$])
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), mode = _b[0], inlineIndent = _b[1];
                _this.inlinePaddingLeft = mode === 'inline' ? _this.level * inlineIndent : null;
            }));
        };
        /**
         * @return {?}
         */
        DwMenuItemDirective.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.listOfRouterLink.changes.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () { return _this.updateRouterActive(); }));
            this.listOfRouterLinkWithHref.changes.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () { return _this.updateRouterActive(); }));
            this.updateRouterActive();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwMenuItemDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwSelected) {
                this.setSelectedState(this.dwSelected);
            }
        };
        /**
         * @return {?}
         */
        DwMenuItemDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwMenuItemDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-menu-item]',
                        exportAs: 'dwMenuItem',
                        host: {
                            '[class.ant-dropdown-menu-item]': "isMenuInsideDropDown",
                            '[class.ant-dropdown-menu-item-selected]': "isMenuInsideDropDown && dwSelected",
                            '[class.ant-dropdown-menu-item-disabled]': "isMenuInsideDropDown && dwDisabled",
                            '[class.ant-menu-item]': "!isMenuInsideDropDown",
                            '[class.ant-menu-item-selected]': "!isMenuInsideDropDown && dwSelected",
                            '[class.ant-menu-item-disabled]': "!isMenuInsideDropDown && dwDisabled",
                            '[style.paddingLeft.px]': 'dwPaddingLeft || inlinePaddingLeft',
                            '(click)': 'clickMenuItem($event)'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwMenuItemDirective.ctorParameters = function () { return [
            { type: MenuService },
            { type: core.ChangeDetectorRef },
            { type: DwSubmenuService, decorators: [{ type: core.Optional }] },
            { type: Boolean, decorators: [{ type: core.Inject, args: [DwIsMenuInsideDropDownToken,] }] },
            { type: router.RouterLink, decorators: [{ type: core.Optional }] },
            { type: router.RouterLinkWithHref, decorators: [{ type: core.Optional }] },
            { type: router.Router, decorators: [{ type: core.Optional }] }
        ]; };
        DwMenuItemDirective.propDecorators = {
            dwPaddingLeft: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwSelected: [{ type: core.Input }],
            dwMatchRouterExact: [{ type: core.Input }],
            dwMatchRouter: [{ type: core.Input }],
            listOfRouterLink: [{ type: core.ContentChildren, args: [router.RouterLink, { descendants: true },] }],
            listOfRouterLinkWithHref: [{ type: core.ContentChildren, args: [router.RouterLinkWithHref, { descendants: true },] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuItemDirective.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuItemDirective.prototype, "dwSelected", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuItemDirective.prototype, "dwMatchRouterExact", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuItemDirective.prototype, "dwMatchRouter", void 0);
        return DwMenuItemDirective;
    }());
    if (false) {
        /** @type {?} */
        DwMenuItemDirective.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwMenuItemDirective.ngAcceptInputType_dwSelected;
        /** @type {?} */
        DwMenuItemDirective.ngAcceptInputType_dwMatchRouterExact;
        /** @type {?} */
        DwMenuItemDirective.ngAcceptInputType_dwMatchRouter;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.destroy$;
        /** @type {?} */
        DwMenuItemDirective.prototype.level;
        /** @type {?} */
        DwMenuItemDirective.prototype.selected$;
        /** @type {?} */
        DwMenuItemDirective.prototype.inlinePaddingLeft;
        /** @type {?} */
        DwMenuItemDirective.prototype.dwPaddingLeft;
        /** @type {?} */
        DwMenuItemDirective.prototype.dwDisabled;
        /** @type {?} */
        DwMenuItemDirective.prototype.dwSelected;
        /** @type {?} */
        DwMenuItemDirective.prototype.dwMatchRouterExact;
        /** @type {?} */
        DwMenuItemDirective.prototype.dwMatchRouter;
        /** @type {?} */
        DwMenuItemDirective.prototype.listOfRouterLink;
        /** @type {?} */
        DwMenuItemDirective.prototype.listOfRouterLinkWithHref;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.dwMenuService;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.dwSubmenuService;
        /** @type {?} */
        DwMenuItemDirective.prototype.isMenuInsideDropDown;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.routerLink;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.routerLinkWithHref;
        /**
         * @type {?}
         * @private
         */
        DwMenuItemDirective.prototype.router;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: submenu.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var listOfVerticalPositions = [
        overlay$1.POSITION_MAP.rightTop,
        overlay$1.POSITION_MAP.right,
        overlay$1.POSITION_MAP.rightBottom,
        overlay$1.POSITION_MAP.leftTop,
        overlay$1.POSITION_MAP.left,
        overlay$1.POSITION_MAP.leftBottom
    ];
    /** @type {?} */
    var listOfHorizontalPositions = [overlay$1.POSITION_MAP.bottomLeft];
    var DwSubMenuComponent = /** @class */ (function () {
        function DwSubMenuComponent(dwMenuService, cdr, dwSubmenuService, platform, isMenuInsideDropDown, noAnimation) {
            this.dwMenuService = dwMenuService;
            this.cdr = cdr;
            this.dwSubmenuService = dwSubmenuService;
            this.platform = platform;
            this.isMenuInsideDropDown = isMenuInsideDropDown;
            this.noAnimation = noAnimation;
            this.dwMenuClassName = '';
            this.dwPaddingLeft = null;
            this.dwTitle = null;
            this.dwIcon = null;
            this.dwOpen = false;
            this.dwDisabled = false;
            this.dwOpenChange = new core.EventEmitter();
            this.cdkOverlayOrigin = null;
            this.listOfDwSubMenuComponent = null;
            this.listOfDwMenuItemDirective = null;
            this.level = this.dwSubmenuService.level;
            this.destroy$ = new rxjs.Subject();
            this.position = 'right';
            this.triggerWidth = null;
            this.theme = 'light';
            this.mode = 'vertical';
            this.inlinePaddingLeft = null;
            this.overlayPositions = listOfVerticalPositions;
            this.isSelected = false;
            this.isActive = false;
        }
        /** set the submenu host open status directly **/
        /**
         * set the submenu host open status directly *
         * @param {?} open
         * @return {?}
         */
        DwSubMenuComponent.prototype.setOpenStateWithoutDebounce = /**
         * set the submenu host open status directly *
         * @param {?} open
         * @return {?}
         */
        function (open) {
            this.dwSubmenuService.setOpenStateWithoutDebounce(open);
        };
        /**
         * @return {?}
         */
        DwSubMenuComponent.prototype.toggleSubMenu = /**
         * @return {?}
         */
        function () {
            this.setOpenStateWithoutDebounce(!this.dwOpen);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwSubMenuComponent.prototype.setMouseEnterState = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.isActive = value;
            if (this.mode !== 'inline') {
                this.dwSubmenuService.setMouseEnterTitleOrOverlayState(value);
            }
        };
        /**
         * @return {?}
         */
        DwSubMenuComponent.prototype.setTriggerWidth = /**
         * @return {?}
         */
        function () {
            if (this.mode === 'horizontal' && this.platform.isBrowser && this.cdkOverlayOrigin) {
                /** TODO: fast dom **/
                this.triggerWidth = (/** @type {?} */ (this.cdkOverlayOrigin)).nativeElement.getBoundingClientRect().width;
            }
        };
        /**
         * @param {?} position
         * @return {?}
         */
        DwSubMenuComponent.prototype.onPositionChange = /**
         * @param {?} position
         * @return {?}
         */
        function (position) {
            /** @type {?} */
            var placement = overlay$1.getPlacementName(position);
            if (placement === 'rightTop' || placement === 'rightBottom' || placement === 'right') {
                this.position = 'right';
            }
            else if (placement === 'leftTop' || placement === 'leftBottom' || placement === 'left') {
                this.position = 'left';
            }
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwSubMenuComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** submenu theme update **/
            this.dwMenuService.theme$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} theme
             * @return {?}
             */
            function (theme) {
                _this.theme = theme;
                _this.cdr.markForCheck();
            }));
            /** submenu mode update **/
            this.dwSubmenuService.mode$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} mode
             * @return {?}
             */
            function (mode) {
                _this.mode = mode;
                if (mode === 'horizontal') {
                    _this.overlayPositions = listOfHorizontalPositions;
                }
                else if (mode === 'vertical') {
                    _this.overlayPositions = listOfVerticalPositions;
                }
                _this.cdr.markForCheck();
            }));
            /** inlineIndent update **/
            rxjs.combineLatest([this.dwSubmenuService.mode$, this.dwMenuService.inlineIndent$])
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), mode = _b[0], inlineIndent = _b[1];
                _this.inlinePaddingLeft = mode === 'inline' ? _this.level * inlineIndent : null;
                _this.cdr.markForCheck();
            }));
            /** current submenu open status **/
            this.dwSubmenuService.isCurrentSubMenuOpen$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} open
             * @return {?}
             */
            function (open) {
                _this.isActive = open;
                if (open !== _this.dwOpen) {
                    _this.setTriggerWidth();
                    _this.dwOpen = open;
                    _this.dwOpenChange.emit(_this.dwOpen);
                    _this.cdr.markForCheck();
                }
            }));
        };
        /**
         * @return {?}
         */
        DwSubMenuComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.setTriggerWidth();
            /** @type {?} */
            var listOfDwMenuItemDirective = this.listOfDwMenuItemDirective;
            /** @type {?} */
            var changes = (/** @type {?} */ (listOfDwMenuItemDirective)).changes;
            /** @type {?} */
            var mergedObservable = rxjs.merge.apply(void 0, __spread([changes], (/** @type {?} */ (listOfDwMenuItemDirective)).map((/**
             * @param {?} menu
             * @return {?}
             */
            function (menu) { return menu.selected$; }))));
            changes
                .pipe(operators.startWith(listOfDwMenuItemDirective), operators.switchMap((/**
             * @return {?}
             */
            function () { return mergedObservable; })), operators.startWith(true), operators.map((/**
             * @return {?}
             */
            function () { return (/** @type {?} */ (listOfDwMenuItemDirective)).some((/**
             * @param {?} e
             * @return {?}
             */
            function (e) { return e.dwSelected; })); })), operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} selected
             * @return {?}
             */
            function (selected) {
                _this.isSelected = selected;
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSubMenuComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwOpen = changes.dwOpen;
            if (dwOpen) {
                this.dwSubmenuService.setOpenStateWithoutDebounce(this.dwOpen);
                this.setTriggerWidth();
            }
        };
        /**
         * @return {?}
         */
        DwSubMenuComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwSubMenuComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-submenu]',
                        exportAs: 'dwSubmenu',
                        providers: [DwSubmenuService],
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        template: "\n    <div\n      dw-submenu-title\n      cdkOverlayOrigin\n      #origin=\"cdkOverlayOrigin\"\n      [dwIcon]=\"dwIcon\"\n      [dwTitle]=\"dwTitle\"\n      [mode]=\"mode\"\n      [dwDisabled]=\"dwDisabled\"\n      [isMenuInsideDropDown]=\"isMenuInsideDropDown\"\n      [paddingLeft]=\"dwPaddingLeft || inlinePaddingLeft\"\n      (subMenuMouseState)=\"setMouseEnterState($event)\"\n      (toggleSubMenu)=\"toggleSubMenu()\"\n    >\n      <ng-content select=\"[title]\" *ngIf=\"!dwTitle\"></ng-content>\n    </div>\n    <div\n      *ngIf=\"mode === 'inline'; else nonInlineTemplate\"\n      dw-submenu-inline-child\n      [mode]=\"mode\"\n      [dwOpen]=\"dwOpen\"\n      [@.disabled]=\"noAnimation?.dwNoAnimation\"\n      [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n      [menuClass]=\"dwMenuClassName\"\n      [templateOutlet]=\"subMenuTemplate\"\n    ></div>\n    <ng-template #nonInlineTemplate>\n      <ng-template\n        cdkConnectedOverlay\n        (positionChange)=\"onPositionChange($event)\"\n        [cdkConnectedOverlayPositions]=\"overlayPositions\"\n        [cdkConnectedOverlayOrigin]=\"origin\"\n        [cdkConnectedOverlayWidth]=\"triggerWidth!\"\n        [cdkConnectedOverlayOpen]=\"dwOpen\"\n        [cdkConnectedOverlayTransformOriginOn]=\"'.ant-menu-submenu'\"\n      >\n        <div\n          dw-submenu-none-inline-child\n          [theme]=\"theme\"\n          [mode]=\"mode\"\n          [dwOpen]=\"dwOpen\"\n          [position]=\"position\"\n          [dwDisabled]=\"dwDisabled\"\n          [isMenuInsideDropDown]=\"isMenuInsideDropDown\"\n          [templateOutlet]=\"subMenuTemplate\"\n          [menuClass]=\"dwMenuClassName\"\n          [@.disabled]=\"noAnimation?.dwNoAnimation\"\n          [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n          (subMenuMouseState)=\"setMouseEnterState($event)\"\n        ></div>\n      </ng-template>\n    </ng-template>\n\n    <ng-template #subMenuTemplate>\n      <ng-content></ng-content>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-dropdown-menu-submenu]': "isMenuInsideDropDown",
                            '[class.ant-dropdown-menu-submenu-disabled]': "isMenuInsideDropDown && dwDisabled",
                            '[class.ant-dropdown-menu-submenu-open]': "isMenuInsideDropDown && dwOpen",
                            '[class.ant-dropdown-menu-submenu-selected]': "isMenuInsideDropDown && isSelected",
                            '[class.ant-dropdown-menu-submenu-vertical]': "isMenuInsideDropDown && mode === 'vertical'",
                            '[class.ant-dropdown-menu-submenu-horizontal]': "isMenuInsideDropDown && mode === 'horizontal'",
                            '[class.ant-dropdown-menu-submenu-inline]': "isMenuInsideDropDown && mode === 'inline'",
                            '[class.ant-dropdown-menu-submenu-active]': "isMenuInsideDropDown && isActive",
                            '[class.ant-menu-submenu]': "!isMenuInsideDropDown",
                            '[class.ant-menu-submenu-disabled]': "!isMenuInsideDropDown && dwDisabled",
                            '[class.ant-menu-submenu-open]': "!isMenuInsideDropDown && dwOpen",
                            '[class.ant-menu-submenu-selected]': "!isMenuInsideDropDown && isSelected",
                            '[class.ant-menu-submenu-vertical]': "!isMenuInsideDropDown && mode === 'vertical'",
                            '[class.ant-menu-submenu-horizontal]': "!isMenuInsideDropDown && mode === 'horizontal'",
                            '[class.ant-menu-submenu-inline]': "!isMenuInsideDropDown && mode === 'inline'",
                            '[class.ant-menu-submenu-active]': "!isMenuInsideDropDown && isActive"
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSubMenuComponent.ctorParameters = function () { return [
            { type: MenuService },
            { type: core.ChangeDetectorRef },
            { type: DwSubmenuService },
            { type: platform.Platform },
            { type: Boolean, decorators: [{ type: core.Inject, args: [DwIsMenuInsideDropDownToken,] }] },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwSubMenuComponent.propDecorators = {
            dwMenuClassName: [{ type: core.Input }],
            dwPaddingLeft: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            dwIcon: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwOpenChange: [{ type: core.Output }],
            cdkOverlayOrigin: [{ type: core.ViewChild, args: [overlay.CdkOverlayOrigin, { static: true, read: core.ElementRef },] }],
            listOfDwSubMenuComponent: [{ type: core.ContentChildren, args: [DwSubMenuComponent, { descendants: true },] }],
            listOfDwMenuItemDirective: [{ type: core.ContentChildren, args: [DwMenuItemDirective, { descendants: true },] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSubMenuComponent.prototype, "dwOpen", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwSubMenuComponent.prototype, "dwDisabled", void 0);
        return DwSubMenuComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSubMenuComponent.ngAcceptInputType_dwOpen;
        /** @type {?} */
        DwSubMenuComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwMenuClassName;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwPaddingLeft;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwTitle;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwIcon;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwOpen;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwDisabled;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwOpenChange;
        /** @type {?} */
        DwSubMenuComponent.prototype.cdkOverlayOrigin;
        /** @type {?} */
        DwSubMenuComponent.prototype.listOfDwSubMenuComponent;
        /** @type {?} */
        DwSubMenuComponent.prototype.listOfDwMenuItemDirective;
        /**
         * @type {?}
         * @private
         */
        DwSubMenuComponent.prototype.level;
        /**
         * @type {?}
         * @private
         */
        DwSubMenuComponent.prototype.destroy$;
        /** @type {?} */
        DwSubMenuComponent.prototype.position;
        /** @type {?} */
        DwSubMenuComponent.prototype.triggerWidth;
        /** @type {?} */
        DwSubMenuComponent.prototype.theme;
        /** @type {?} */
        DwSubMenuComponent.prototype.mode;
        /** @type {?} */
        DwSubMenuComponent.prototype.inlinePaddingLeft;
        /** @type {?} */
        DwSubMenuComponent.prototype.overlayPositions;
        /** @type {?} */
        DwSubMenuComponent.prototype.isSelected;
        /** @type {?} */
        DwSubMenuComponent.prototype.isActive;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwMenuService;
        /**
         * @type {?}
         * @private
         */
        DwSubMenuComponent.prototype.cdr;
        /** @type {?} */
        DwSubMenuComponent.prototype.dwSubmenuService;
        /**
         * @type {?}
         * @private
         */
        DwSubMenuComponent.prototype.platform;
        /** @type {?} */
        DwSubMenuComponent.prototype.isMenuInsideDropDown;
        /** @type {?} */
        DwSubMenuComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} serviceInsideDropDown
     * @param {?} serviceOutsideDropDown
     * @return {?}
     */
    function MenuServiceFactory(serviceInsideDropDown, serviceOutsideDropDown) {
        return serviceInsideDropDown ? serviceInsideDropDown : serviceOutsideDropDown;
    }
    /**
     * @param {?} isMenuInsideDropDownToken
     * @return {?}
     */
    function MenuDropDownTokenFactory(isMenuInsideDropDownToken) {
        return isMenuInsideDropDownToken ? isMenuInsideDropDownToken : false;
    }
    var DwMenuDirective = /** @class */ (function () {
        function DwMenuDirective(dwMenuService, isMenuInsideDropDown, cdr) {
            this.dwMenuService = dwMenuService;
            this.isMenuInsideDropDown = isMenuInsideDropDown;
            this.cdr = cdr;
            this.dwInlineIndent = 24;
            this.dwTheme = 'light';
            this.dwMode = 'vertical';
            this.dwInlineCollapsed = false;
            this.dwSelectable = !this.isMenuInsideDropDown;
            this.dwClick = new core.EventEmitter();
            this.actualMode = 'vertical';
            this.inlineCollapsed$ = new rxjs.BehaviorSubject(this.dwInlineCollapsed);
            this.mode$ = new rxjs.BehaviorSubject(this.dwMode);
            this.destroy$ = new rxjs.Subject();
            this.listOfOpenedDwSubMenuComponent = [];
        }
        /**
         * @param {?} inlineCollapsed
         * @return {?}
         */
        DwMenuDirective.prototype.setInlineCollapsed = /**
         * @param {?} inlineCollapsed
         * @return {?}
         */
        function (inlineCollapsed) {
            this.dwInlineCollapsed = inlineCollapsed;
            this.inlineCollapsed$.next(inlineCollapsed);
        };
        /**
         * @return {?}
         */
        DwMenuDirective.prototype.updateInlineCollapse = /**
         * @return {?}
         */
        function () {
            if (this.listOfDwMenuItemDirective) {
                if (this.dwInlineCollapsed) {
                    this.listOfOpenedDwSubMenuComponent = this.listOfDwSubMenuComponent.filter((/**
                     * @param {?} submenu
                     * @return {?}
                     */
                    function (submenu) { return submenu.dwOpen; }));
                    this.listOfDwSubMenuComponent.forEach((/**
                     * @param {?} submenu
                     * @return {?}
                     */
                    function (submenu) { return submenu.setOpenStateWithoutDebounce(false); }));
                }
                else {
                    this.listOfOpenedDwSubMenuComponent.forEach((/**
                     * @param {?} submenu
                     * @return {?}
                     */
                    function (submenu) { return submenu.setOpenStateWithoutDebounce(true); }));
                    this.listOfOpenedDwSubMenuComponent = [];
                }
            }
        };
        /**
         * @return {?}
         */
        DwMenuDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            rxjs.combineLatest([this.inlineCollapsed$, this.mode$])
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), inlineCollapsed = _b[0], mode = _b[1];
                _this.actualMode = inlineCollapsed ? 'vertical' : mode;
                _this.dwMenuService.setMode(_this.actualMode);
                _this.cdr.markForCheck();
            }));
            this.dwMenuService.descendantMenuItemClick$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} menu
             * @return {?}
             */
            function (menu) {
                _this.dwClick.emit(menu);
                if (_this.dwSelectable && !menu.dwMatchRouter) {
                    _this.listOfDwMenuItemDirective.forEach((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return item.setSelectedState(item === menu); }));
                }
            }));
        };
        /**
         * @return {?}
         */
        DwMenuDirective.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.inlineCollapsed$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.updateInlineCollapse();
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwMenuDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwInlineCollapsed = changes.dwInlineCollapsed, dwInlineIndent = changes.dwInlineIndent, dwTheme = changes.dwTheme, dwMode = changes.dwMode;
            if (dwInlineCollapsed) {
                this.inlineCollapsed$.next(this.dwInlineCollapsed);
            }
            if (dwInlineIndent) {
                this.dwMenuService.setInlineIndent(this.dwInlineIndent);
            }
            if (dwTheme) {
                this.dwMenuService.setTheme(this.dwTheme);
            }
            if (dwMode) {
                this.mode$.next(this.dwMode);
                if (!changes.dwMode.isFirstChange() && this.listOfDwSubMenuComponent) {
                    this.listOfDwSubMenuComponent.forEach((/**
                     * @param {?} submenu
                     * @return {?}
                     */
                    function (submenu) { return submenu.setOpenStateWithoutDebounce(false); }));
                }
            }
        };
        /**
         * @return {?}
         */
        DwMenuDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwMenuDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-menu]',
                        exportAs: 'dwMenu',
                        providers: [
                            {
                                provide: DwMenuServiceLocalToken,
                                useClass: MenuService
                            },
                            /** use the top level service **/
                            {
                                provide: MenuService,
                                useFactory: MenuServiceFactory,
                                deps: [[new core.SkipSelf(), new core.Optional(), MenuService], DwMenuServiceLocalToken]
                            },
                            /** check if menu inside dropdown-menu component **/
                            {
                                provide: DwIsMenuInsideDropDownToken,
                                useFactory: MenuDropDownTokenFactory,
                                deps: [[new core.SkipSelf(), new core.Optional(), DwIsMenuInsideDropDownToken]]
                            }
                        ],
                        host: {
                            '[class.ant-dropdown-menu]': "isMenuInsideDropDown",
                            '[class.ant-dropdown-menu-root]': "isMenuInsideDropDown",
                            '[class.ant-dropdown-menu-light]': "isMenuInsideDropDown && dwTheme === 'light'",
                            '[class.ant-dropdown-menu-dark]': "isMenuInsideDropDown && dwTheme === 'dark'",
                            '[class.ant-dropdown-menu-vertical]': "isMenuInsideDropDown && actualMode === 'vertical'",
                            '[class.ant-dropdown-menu-horizontal]': "isMenuInsideDropDown && actualMode === 'horizontal'",
                            '[class.ant-dropdown-menu-inline]': "isMenuInsideDropDown && actualMode === 'inline'",
                            '[class.ant-dropdown-menu-inline-collapsed]': "isMenuInsideDropDown && dwInlineCollapsed",
                            '[class.ant-menu]': "!isMenuInsideDropDown",
                            '[class.ant-menu-root]': "!isMenuInsideDropDown",
                            '[class.ant-menu-light]': "!isMenuInsideDropDown && dwTheme === 'light'",
                            '[class.ant-menu-dark]': "!isMenuInsideDropDown && dwTheme === 'dark'",
                            '[class.ant-menu-vertical]': "!isMenuInsideDropDown && actualMode === 'vertical'",
                            '[class.ant-menu-horizontal]': "!isMenuInsideDropDown && actualMode === 'horizontal'",
                            '[class.ant-menu-inline]': "!isMenuInsideDropDown && actualMode === 'inline'",
                            '[class.ant-menu-inline-collapsed]': "!isMenuInsideDropDown && dwInlineCollapsed"
                        }
                    },] }
        ];
        /** @nocollapse */
        DwMenuDirective.ctorParameters = function () { return [
            { type: MenuService },
            { type: Boolean, decorators: [{ type: core.Inject, args: [DwIsMenuInsideDropDownToken,] }] },
            { type: core.ChangeDetectorRef }
        ]; };
        DwMenuDirective.propDecorators = {
            listOfDwMenuItemDirective: [{ type: core.ContentChildren, args: [DwMenuItemDirective, { descendants: true },] }],
            listOfDwSubMenuComponent: [{ type: core.ContentChildren, args: [DwSubMenuComponent, { descendants: true },] }],
            dwInlineIndent: [{ type: core.Input }],
            dwTheme: [{ type: core.Input }],
            dwMode: [{ type: core.Input }],
            dwInlineCollapsed: [{ type: core.Input }],
            dwSelectable: [{ type: core.Input }],
            dwClick: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuDirective.prototype, "dwInlineCollapsed", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwMenuDirective.prototype, "dwSelectable", void 0);
        return DwMenuDirective;
    }());
    if (false) {
        /** @type {?} */
        DwMenuDirective.ngAcceptInputType_dwInlineCollapsed;
        /** @type {?} */
        DwMenuDirective.ngAcceptInputType_dwSelectable;
        /** @type {?} */
        DwMenuDirective.prototype.listOfDwMenuItemDirective;
        /** @type {?} */
        DwMenuDirective.prototype.listOfDwSubMenuComponent;
        /** @type {?} */
        DwMenuDirective.prototype.dwInlineIndent;
        /** @type {?} */
        DwMenuDirective.prototype.dwTheme;
        /** @type {?} */
        DwMenuDirective.prototype.dwMode;
        /** @type {?} */
        DwMenuDirective.prototype.dwInlineCollapsed;
        /** @type {?} */
        DwMenuDirective.prototype.dwSelectable;
        /** @type {?} */
        DwMenuDirective.prototype.dwClick;
        /** @type {?} */
        DwMenuDirective.prototype.actualMode;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.inlineCollapsed$;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.mode$;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.listOfOpenedDwSubMenuComponent;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.dwMenuService;
        /** @type {?} */
        DwMenuDirective.prototype.isMenuInsideDropDown;
        /**
         * @type {?}
         * @private
         */
        DwMenuDirective.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu-group.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} isMenuInsideDropDownToken
     * @return {?}
     */
    function MenuGroupFactory(isMenuInsideDropDownToken) {
        return isMenuInsideDropDownToken ? isMenuInsideDropDownToken : false;
    }
    var DwMenuGroupComponent = /** @class */ (function () {
        function DwMenuGroupComponent(elementRef, renderer, isMenuInsideDropDown) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.isMenuInsideDropDown = isMenuInsideDropDown;
            /** @type {?} */
            var className = this.isMenuInsideDropDown ? 'ant-dropdown-menu-item-group' : 'ant-menu-item-group';
            this.renderer.addClass(elementRef.nativeElement, className);
        }
        /**
         * @return {?}
         */
        DwMenuGroupComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var ulElement = (/** @type {?} */ (this.titleElement)).nativeElement.nextElementSibling;
            if (ulElement) {
                /**
                 * add classname to ul *
                 * @type {?}
                 */
                var className = this.isMenuInsideDropDown ? 'ant-dropdown-menu-item-group-list' : 'ant-menu-item-group-list';
                this.renderer.addClass(ulElement, className);
            }
        };
        DwMenuGroupComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-menu-group]',
                        exportAs: 'dwMenuGroup',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        providers: [
                            /** check if menu inside dropdown-menu component **/
                            {
                                provide: DwIsMenuInsideDropDownToken,
                                useFactory: MenuGroupFactory,
                                deps: [[new core.SkipSelf(), new core.Optional(), DwIsMenuInsideDropDownToken]]
                            }
                        ],
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div\n      [class.ant-menu-item-group-title]=\"!isMenuInsideDropDown\"\n      [class.ant-dropdown-menu-item-group-title]=\"isMenuInsideDropDown\"\n      #titleElement\n    >\n      <ng-container *dwStringTemplateOutlet=\"dwTitle\">{{ dwTitle }}</ng-container>\n      <ng-content select=\"[title]\" *ngIf=\"!dwTitle\"></ng-content>\n    </div>\n    <ng-content></ng-content>\n  ",
                        preserveWhitespaces: false
                    }] }
        ];
        /** @nocollapse */
        DwMenuGroupComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: Boolean, decorators: [{ type: core.Inject, args: [DwIsMenuInsideDropDownToken,] }] }
        ]; };
        DwMenuGroupComponent.propDecorators = {
            dwTitle: [{ type: core.Input }],
            titleElement: [{ type: core.ViewChild, args: ['titleElement',] }]
        };
        return DwMenuGroupComponent;
    }());
    if (false) {
        /** @type {?} */
        DwMenuGroupComponent.prototype.dwTitle;
        /** @type {?} */
        DwMenuGroupComponent.prototype.titleElement;
        /** @type {?} */
        DwMenuGroupComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwMenuGroupComponent.prototype.renderer;
        /** @type {?} */
        DwMenuGroupComponent.prototype.isMenuInsideDropDown;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu-divider.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwMenuDividerDirective = /** @class */ (function () {
        function DwMenuDividerDirective(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.renderer.addClass(elementRef.nativeElement, 'ant-dropdown-menu-item-divider');
        }
        DwMenuDividerDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-menu-divider]',
                        exportAs: 'dwMenuDivider'
                    },] }
        ];
        /** @nocollapse */
        DwMenuDividerDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        return DwMenuDividerDirective;
    }());
    if (false) {
        /** @type {?} */
        DwMenuDividerDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwMenuDividerDirective.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: submenu-title.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSubMenuTitleComponent = /** @class */ (function () {
        function DwSubMenuTitleComponent() {
            this.dwIcon = null;
            this.dwTitle = null;
            this.isMenuInsideDropDown = false;
            this.dwDisabled = false;
            this.paddingLeft = null;
            this.mode = 'vertical';
            this.toggleSubMenu = new core.EventEmitter();
            this.subMenuMouseState = new core.EventEmitter();
        }
        /**
         * @param {?} state
         * @return {?}
         */
        DwSubMenuTitleComponent.prototype.setMouseState = /**
         * @param {?} state
         * @return {?}
         */
        function (state) {
            if (!this.dwDisabled) {
                this.subMenuMouseState.next(state);
            }
        };
        /**
         * @return {?}
         */
        DwSubMenuTitleComponent.prototype.clickTitle = /**
         * @return {?}
         */
        function () {
            if (this.mode === 'inline' && !this.dwDisabled) {
                this.toggleSubMenu.emit();
            }
        };
        DwSubMenuTitleComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-submenu-title]',
                        exportAs: 'dwSubmenuTitle',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <i dw-icon [dwType]=\"dwIcon\" *ngIf=\"dwIcon\"></i>\n    <ng-container *dwStringTemplateOutlet=\"dwTitle\">\n      <span>{{ dwTitle }}</span>\n    </ng-container>\n    <ng-content></ng-content>\n    <span *ngIf=\"isMenuInsideDropDown; else notDropdownTpl\" class=\"ant-dropdown-menu-submenu-arrow\">\n      <i dw-icon dwType=\"right\" class=\"ant-dropdown-menu-submenu-arrow-icon\"></i>\n    </span>\n    <ng-template #notDropdownTpl>\n      <i class=\"ant-menu-submenu-arrow\"></i>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-dropdown-menu-submenu-title]': 'isMenuInsideDropDown',
                            '[class.ant-menu-submenu-title]': '!isMenuInsideDropDown',
                            '[style.paddingLeft.px]': 'paddingLeft',
                            '(click)': 'clickTitle()',
                            '(mouseenter)': 'setMouseState(true)',
                            '(mouseleave)': 'setMouseState(false)'
                        }
                    }] }
        ];
        DwSubMenuTitleComponent.propDecorators = {
            dwIcon: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            isMenuInsideDropDown: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            paddingLeft: [{ type: core.Input }],
            mode: [{ type: core.Input }],
            toggleSubMenu: [{ type: core.Output }],
            subMenuMouseState: [{ type: core.Output }]
        };
        return DwSubMenuTitleComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.dwIcon;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.dwTitle;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.isMenuInsideDropDown;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.dwDisabled;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.paddingLeft;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.mode;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.toggleSubMenu;
        /** @type {?} */
        DwSubMenuTitleComponent.prototype.subMenuMouseState;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: submenu-inline-child.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSubmenuInlineChildComponent = /** @class */ (function () {
        function DwSubmenuInlineChildComponent(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.templateOutlet = null;
            this.menuClass = '';
            this.mode = 'vertical';
            this.dwOpen = false;
            this.listOfCacheClassName = [];
            this.expandState = 'collapsed';
        }
        /**
         * @return {?}
         */
        DwSubmenuInlineChildComponent.prototype.calcMotionState = /**
         * @return {?}
         */
        function () {
            if (this.dwOpen) {
                this.expandState = 'expanded';
            }
            else {
                this.expandState = 'collapsed';
            }
        };
        /**
         * @return {?}
         */
        DwSubmenuInlineChildComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.calcMotionState();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSubmenuInlineChildComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var _this = this;
            var mode = changes.mode, dwOpen = changes.dwOpen, menuClass = changes.menuClass;
            if (mode || dwOpen) {
                this.calcMotionState();
            }
            if (menuClass) {
                if (this.listOfCacheClassName.length) {
                    this.listOfCacheClassName
                        .filter((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return !!item; }))
                        .forEach((/**
                     * @param {?} className
                     * @return {?}
                     */
                    function (className) {
                        _this.renderer.removeClass(_this.elementRef.nativeElement, className);
                    }));
                }
                if (this.menuClass) {
                    this.listOfCacheClassName = this.menuClass.split(' ');
                    this.listOfCacheClassName
                        .filter((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return !!item; }))
                        .forEach((/**
                     * @param {?} className
                     * @return {?}
                     */
                    function (className) {
                        _this.renderer.addClass(_this.elementRef.nativeElement, className);
                    }));
                }
            }
        };
        DwSubmenuInlineChildComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-submenu-inline-child]',
                        animations: [animation.collapseMotion],
                        exportAs: 'dwSubmenuInlineChild',
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: " <ng-template [ngTemplateOutlet]=\"templateOutlet\"></ng-template> ",
                        host: {
                            '[class.ant-menu]': 'true',
                            '[class.ant-menu-inline]': 'true',
                            '[class.ant-menu-sub]': 'true',
                            '[@collapseMotion]': 'expandState'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwSubmenuInlineChildComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        DwSubmenuInlineChildComponent.propDecorators = {
            templateOutlet: [{ type: core.Input }],
            menuClass: [{ type: core.Input }],
            mode: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }]
        };
        return DwSubmenuInlineChildComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.templateOutlet;
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.menuClass;
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.mode;
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.dwOpen;
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.listOfCacheClassName;
        /** @type {?} */
        DwSubmenuInlineChildComponent.prototype.expandState;
        /**
         * @type {?}
         * @private
         */
        DwSubmenuInlineChildComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwSubmenuInlineChildComponent.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: submenu-non-inline-child.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwSubmenuNoneInlineChildComponent = /** @class */ (function () {
        function DwSubmenuNoneInlineChildComponent() {
            this.menuClass = '';
            this.theme = 'light';
            this.templateOutlet = null;
            this.isMenuInsideDropDown = false;
            this.mode = 'vertical';
            this.position = 'right';
            this.dwDisabled = false;
            this.dwOpen = false;
            this.subMenuMouseState = new core.EventEmitter();
            this.expandState = 'collapsed';
        }
        /**
         * @param {?} state
         * @return {?}
         */
        DwSubmenuNoneInlineChildComponent.prototype.setMouseState = /**
         * @param {?} state
         * @return {?}
         */
        function (state) {
            if (!this.dwDisabled) {
                this.subMenuMouseState.next(state);
            }
        };
        /**
         * @return {?}
         */
        DwSubmenuNoneInlineChildComponent.prototype.calcMotionState = /**
         * @return {?}
         */
        function () {
            if (this.dwOpen) {
                if (this.mode === 'horizontal') {
                    this.expandState = 'bottom';
                }
                else if (this.mode === 'vertical') {
                    this.expandState = 'active';
                }
            }
            else {
                this.expandState = 'collapsed';
            }
        };
        /**
         * @return {?}
         */
        DwSubmenuNoneInlineChildComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.calcMotionState();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwSubmenuNoneInlineChildComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var mode = changes.mode, dwOpen = changes.dwOpen;
            if (mode || dwOpen) {
                this.calcMotionState();
            }
        };
        DwSubmenuNoneInlineChildComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[dw-submenu-none-inline-child]',
                        exportAs: 'dwSubmenuNoneInlineChild',
                        encapsulation: core.ViewEncapsulation.None,
                        animations: [animation.zoomBigMotion, animation.slideMotion],
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <div\n      [class.ant-dropdown-menu]=\"isMenuInsideDropDown\"\n      [class.ant-menu]=\"!isMenuInsideDropDown\"\n      [class.ant-dropdown-menu-vertical]=\"isMenuInsideDropDown\"\n      [class.ant-menu-vertical]=\"!isMenuInsideDropDown\"\n      [class.ant-dropdown-menu-sub]=\"isMenuInsideDropDown\"\n      [class.ant-menu-sub]=\"!isMenuInsideDropDown\"\n      [ngClass]=\"menuClass\"\n    >\n      <ng-template [ngTemplateOutlet]=\"templateOutlet\"></ng-template>\n    </div>\n  ",
                        host: {
                            '[class.ant-menu-submenu]': 'true',
                            '[class.ant-menu-submenu-popup]': 'true',
                            '[class.ant-menu-light]': "theme === 'light'",
                            '[class.ant-menu-dark]': "theme === 'dark'",
                            '[class.ant-menu-submenu-placement-bottom]': "mode === 'horizontal'",
                            '[class.ant-menu-submenu-placement-right]': "mode === 'vertical' && position === 'right'",
                            '[class.ant-menu-submenu-placement-left]': "mode === 'vertical' && position === 'left'",
                            '[@slideMotion]': 'expandState',
                            '[@zoomBigMotion]': 'expandState',
                            '(mouseenter)': 'setMouseState(true)',
                            '(mouseleave)': 'setMouseState(false)'
                        }
                    }] }
        ];
        DwSubmenuNoneInlineChildComponent.propDecorators = {
            menuClass: [{ type: core.Input }],
            theme: [{ type: core.Input }],
            templateOutlet: [{ type: core.Input }],
            isMenuInsideDropDown: [{ type: core.Input }],
            mode: [{ type: core.Input }],
            position: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            subMenuMouseState: [{ type: core.Output }]
        };
        return DwSubmenuNoneInlineChildComponent;
    }());
    if (false) {
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.menuClass;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.theme;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.templateOutlet;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.isMenuInsideDropDown;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.mode;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.position;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.dwDisabled;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.dwOpen;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.subMenuMouseState;
        /** @type {?} */
        DwSubmenuNoneInlineChildComponent.prototype.expandState;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: menu.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwMenuModule = /** @class */ (function () {
        function DwMenuModule() {
        }
        DwMenuModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, platform.PlatformModule, overlay.OverlayModule, icon.DwIconModule, noAnimation.DwNoAnimationModule, outlet.DwOutletModule],
                        declarations: [
                            DwMenuDirective,
                            DwMenuItemDirective,
                            DwSubMenuComponent,
                            DwMenuDividerDirective,
                            DwMenuGroupComponent,
                            DwSubMenuTitleComponent,
                            DwSubmenuInlineChildComponent,
                            DwSubmenuNoneInlineChildComponent
                        ],
                        exports: [DwMenuDirective, DwMenuItemDirective, DwSubMenuComponent, DwMenuDividerDirective, DwMenuGroupComponent]
                    },] }
        ];
        return DwMenuModule;
    }());

    exports.DwIsMenuInsideDropDownToken = DwIsMenuInsideDropDownToken;
    exports.DwMenuDirective = DwMenuDirective;
    exports.DwMenuDividerDirective = DwMenuDividerDirective;
    exports.DwMenuGroupComponent = DwMenuGroupComponent;
    exports.DwMenuItemDirective = DwMenuItemDirective;
    exports.DwMenuModule = DwMenuModule;
    exports.DwMenuServiceLocalToken = DwMenuServiceLocalToken;
    exports.DwSubMenuComponent = DwSubMenuComponent;
    exports.DwSubMenuTitleComponent = DwSubMenuTitleComponent;
    exports.DwSubmenuInlineChildComponent = DwSubmenuInlineChildComponent;
    exports.DwSubmenuNoneInlineChildComponent = DwSubmenuNoneInlineChildComponent;
    exports.DwSubmenuService = DwSubmenuService;
    exports.MenuDropDownTokenFactory = MenuDropDownTokenFactory;
    exports.MenuGroupFactory = MenuGroupFactory;
    exports.MenuService = MenuService;
    exports.MenuServiceFactory = MenuServiceFactory;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-menu.umd.js.map
