(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/element-patch', ['exports', '@angular/core', '@angular/common'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core['element-patch'] = {}), global.ng.core, global.ng.common));
}(this, (function (exports, core, common) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: element-patch.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * A patch directive to select the element of a component.
     */
    var DwElementPatchDirective = /** @class */ (function () {
        function DwElementPatchDirective(elementRef) {
            this.elementRef = elementRef;
        }
        DwElementPatchDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-element]',
                        exportAs: 'dwElement'
                    },] }
        ];
        /** @nocollapse */
        DwElementPatchDirective.ctorParameters = function () { return [
            { type: core.ElementRef }
        ]; };
        return DwElementPatchDirective;
    }());
    if (false) {
        /** @type {?} */
        DwElementPatchDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: element-patch.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwElementPatchModule = /** @class */ (function () {
        function DwElementPatchModule() {
        }
        DwElementPatchModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule],
                        declarations: [DwElementPatchDirective],
                        exports: [DwElementPatchDirective]
                    },] }
        ];
        return DwElementPatchModule;
    }());

    exports.DwElementPatchDirective = DwElementPatchDirective;
    exports.DwElementPatchModule = DwElementPatchModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-element-patch.umd.js.map
