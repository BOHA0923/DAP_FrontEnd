(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/config', ['exports', '@angular/core', 'rxjs', 'rxjs/operators'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core.config = {}), global.ng.core, global.rxjs, global.rxjs.operators));
}(this, (function (exports, core, rxjs, operators) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: config.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwConfig() { }
    if (false) {
        /** @type {?|undefined} */
        DwConfig.prototype.affix;
        /** @type {?|undefined} */
        DwConfig.prototype.select;
        /** @type {?|undefined} */
        DwConfig.prototype.alert;
        /** @type {?|undefined} */
        DwConfig.prototype.anchor;
        /** @type {?|undefined} */
        DwConfig.prototype.avatar;
        /** @type {?|undefined} */
        DwConfig.prototype.backTop;
        /** @type {?|undefined} */
        DwConfig.prototype.badge;
        /** @type {?|undefined} */
        DwConfig.prototype.button;
        /** @type {?|undefined} */
        DwConfig.prototype.card;
        /** @type {?|undefined} */
        DwConfig.prototype.carousel;
        /** @type {?|undefined} */
        DwConfig.prototype.cascader;
        /** @type {?|undefined} */
        DwConfig.prototype.codeEditor;
        /** @type {?|undefined} */
        DwConfig.prototype.collapse;
        /** @type {?|undefined} */
        DwConfig.prototype.collapsePanel;
        /** @type {?|undefined} */
        DwConfig.prototype.datePicker;
        /** @type {?|undefined} */
        DwConfig.prototype.descriptions;
        /** @type {?|undefined} */
        DwConfig.prototype.drawer;
        /** @type {?|undefined} */
        DwConfig.prototype.empty;
        /** @type {?|undefined} */
        DwConfig.prototype.form;
        /** @type {?|undefined} */
        DwConfig.prototype.icon;
        /** @type {?|undefined} */
        DwConfig.prototype.message;
        /** @type {?|undefined} */
        DwConfig.prototype.modal;
        /** @type {?|undefined} */
        DwConfig.prototype.notification;
        /** @type {?|undefined} */
        DwConfig.prototype.pageHeader;
        /** @type {?|undefined} */
        DwConfig.prototype.progress;
        /** @type {?|undefined} */
        DwConfig.prototype.rate;
        /** @type {?|undefined} */
        DwConfig.prototype.space;
        /** @type {?|undefined} */
        DwConfig.prototype.spin;
        /** @type {?|undefined} */
        DwConfig.prototype.switch;
        /** @type {?|undefined} */
        DwConfig.prototype.table;
        /** @type {?|undefined} */
        DwConfig.prototype.tabs;
        /** @type {?|undefined} */
        DwConfig.prototype.timePicker;
        /** @type {?|undefined} */
        DwConfig.prototype.tree;
        /** @type {?|undefined} */
        DwConfig.prototype.treeSelect;
        /** @type {?|undefined} */
        DwConfig.prototype.typography;
    }
    /**
     * @record
     */
    function SelectConfig() { }
    if (false) {
        /** @type {?|undefined} */
        SelectConfig.prototype.dwBorderless;
        /** @type {?|undefined} */
        SelectConfig.prototype.dwSuffixIcon;
    }
    /**
     * @record
     */
    function AffixConfig() { }
    if (false) {
        /** @type {?|undefined} */
        AffixConfig.prototype.dwOffsetBottom;
        /** @type {?|undefined} */
        AffixConfig.prototype.dwOffsetTop;
    }
    /**
     * @record
     */
    function AlertConfig() { }
    if (false) {
        /** @type {?|undefined} */
        AlertConfig.prototype.dwCloseable;
        /** @type {?|undefined} */
        AlertConfig.prototype.dwShowIcon;
    }
    /**
     * @record
     */
    function AvatarConfig() { }
    if (false) {
        /** @type {?|undefined} */
        AvatarConfig.prototype.dwShape;
        /** @type {?|undefined} */
        AvatarConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function AnchorConfig() { }
    if (false) {
        /** @type {?|undefined} */
        AnchorConfig.prototype.dwBounds;
        /** @type {?|undefined} */
        AnchorConfig.prototype.dwOffsetBottom;
        /** @type {?|undefined} */
        AnchorConfig.prototype.dwOffsetTop;
        /** @type {?|undefined} */
        AnchorConfig.prototype.dwShowInkInFixed;
    }
    /**
     * @record
     */
    function BackTopConfig() { }
    if (false) {
        /** @type {?|undefined} */
        BackTopConfig.prototype.dwVisibilityHeight;
    }
    /**
     * @record
     */
    function BadgeConfig() { }
    if (false) {
        /** @type {?|undefined} */
        BadgeConfig.prototype.dwColor;
        /** @type {?|undefined} */
        BadgeConfig.prototype.dwOverflowCount;
        /** @type {?|undefined} */
        BadgeConfig.prototype.dwShowZero;
    }
    /**
     * @record
     */
    function ButtonConfig() { }
    if (false) {
        /** @type {?|undefined} */
        ButtonConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function CodeEditorConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CodeEditorConfig.prototype.assetsRoot;
        /** @type {?|undefined} */
        CodeEditorConfig.prototype.defaultEditorOption;
        /** @type {?|undefined} */
        CodeEditorConfig.prototype.useStaticLoading;
        /**
         * @return {?}
         */
        CodeEditorConfig.prototype.onLoad = function () { };
        /**
         * @return {?}
         */
        CodeEditorConfig.prototype.onFirstEditorInit = function () { };
        /**
         * @return {?}
         */
        CodeEditorConfig.prototype.onInit = function () { };
    }
    /**
     * @record
     */
    function CardConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CardConfig.prototype.dwSize;
        /** @type {?|undefined} */
        CardConfig.prototype.dwHoverable;
        /** @type {?|undefined} */
        CardConfig.prototype.dwBordered;
    }
    /**
     * @record
     */
    function CarouselConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwAutoPlay;
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwAutoPlaySpeed;
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwDots;
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwEffect;
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwEnableSwipe;
        /** @type {?|undefined} */
        CarouselConfig.prototype.dwVertical;
    }
    /**
     * @record
     */
    function CascaderConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CascaderConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function CollapseConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CollapseConfig.prototype.dwAccordion;
        /** @type {?|undefined} */
        CollapseConfig.prototype.dwBordered;
    }
    /**
     * @record
     */
    function CollapsePanelConfig() { }
    if (false) {
        /** @type {?|undefined} */
        CollapsePanelConfig.prototype.dwShowArrow;
    }
    /**
     * @record
     */
    function DatePickerConfig() { }
    if (false) {
        /** @type {?|undefined} */
        DatePickerConfig.prototype.dwSeparator;
        /** @type {?|undefined} */
        DatePickerConfig.prototype.dwSuffixIcon;
    }
    /**
     * @record
     */
    function DescriptionsConfig() { }
    if (false) {
        /** @type {?|undefined} */
        DescriptionsConfig.prototype.dwBorder;
        /** @type {?|undefined} */
        DescriptionsConfig.prototype.dwColumn;
        /** @type {?|undefined} */
        DescriptionsConfig.prototype.dwSize;
        /** @type {?|undefined} */
        DescriptionsConfig.prototype.dwColon;
    }
    /**
     * @record
     */
    function DrawerConfig() { }
    if (false) {
        /** @type {?|undefined} */
        DrawerConfig.prototype.dwMask;
        /** @type {?|undefined} */
        DrawerConfig.prototype.dwMaskClosable;
        /** @type {?|undefined} */
        DrawerConfig.prototype.dwCloseOnNavigation;
    }
    /**
     * @record
     */
    function EmptyConfig() { }
    if (false) {
        /** @type {?|undefined} */
        EmptyConfig.prototype.dwDefaultEmptyContent;
    }
    /**
     * @record
     */
    function FormConfig() { }
    if (false) {
        /** @type {?|undefined} */
        FormConfig.prototype.dwNoColon;
        /** @type {?|undefined} */
        FormConfig.prototype.dwAutoTips;
    }
    /**
     * @record
     */
    function IconConfig() { }
    if (false) {
        /** @type {?|undefined} */
        IconConfig.prototype.dwTheme;
        /** @type {?|undefined} */
        IconConfig.prototype.dwTwotoneColor;
    }
    /**
     * @record
     */
    function MessageConfig() { }
    if (false) {
        /** @type {?|undefined} */
        MessageConfig.prototype.dwAnimate;
        /** @type {?|undefined} */
        MessageConfig.prototype.dwDuration;
        /** @type {?|undefined} */
        MessageConfig.prototype.dwMaxStack;
        /** @type {?|undefined} */
        MessageConfig.prototype.dwPauseOnHover;
        /** @type {?|undefined} */
        MessageConfig.prototype.dwTop;
    }
    /**
     * @record
     */
    function ModalConfig() { }
    if (false) {
        /** @type {?|undefined} */
        ModalConfig.prototype.dwMask;
        /** @type {?|undefined} */
        ModalConfig.prototype.dwMaskClosable;
        /** @type {?|undefined} */
        ModalConfig.prototype.dwCloseOnNavigation;
    }
    /**
     * @record
     */
    function NotificationConfig() { }
    if (false) {
        /** @type {?|undefined} */
        NotificationConfig.prototype.dwTop;
        /** @type {?|undefined} */
        NotificationConfig.prototype.dwBottom;
        /** @type {?|undefined} */
        NotificationConfig.prototype.dwPlacement;
    }
    /**
     * @record
     */
    function PageHeaderConfig() { }
    if (false) {
        /** @type {?} */
        PageHeaderConfig.prototype.dwGhost;
    }
    /**
     * @record
     */
    function ProgressConfig() { }
    if (false) {
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwGapDegree;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwGapPosition;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwShowInfo;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwStrokeSwitch;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwStrokeWidth;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwSize;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwStrokeLinecap;
        /** @type {?|undefined} */
        ProgressConfig.prototype.dwStrokeColor;
    }
    /**
     * @record
     */
    function RateConfig() { }
    if (false) {
        /** @type {?|undefined} */
        RateConfig.prototype.dwAllowClear;
        /** @type {?|undefined} */
        RateConfig.prototype.dwAllowHalf;
    }
    /**
     * @record
     */
    function SpaceConfig() { }
    if (false) {
        /** @type {?|undefined} */
        SpaceConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function SpinConfig() { }
    if (false) {
        /** @type {?|undefined} */
        SpinConfig.prototype.dwIndicator;
    }
    /**
     * @record
     */
    function SwitchConfig() { }
    if (false) {
        /** @type {?} */
        SwitchConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function TableConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TableConfig.prototype.dwBordered;
        /** @type {?|undefined} */
        TableConfig.prototype.dwSize;
        /** @type {?|undefined} */
        TableConfig.prototype.dwShowQuickJumper;
        /** @type {?|undefined} */
        TableConfig.prototype.dwLoadingIndicator;
        /** @type {?|undefined} */
        TableConfig.prototype.dwShowSizeChanger;
        /** @type {?|undefined} */
        TableConfig.prototype.dwSimple;
        /** @type {?|undefined} */
        TableConfig.prototype.dwHideOnSinglePage;
    }
    /**
     * @record
     */
    function TabsConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TabsConfig.prototype.dwAnimated;
        /** @type {?|undefined} */
        TabsConfig.prototype.dwSize;
        /** @type {?|undefined} */
        TabsConfig.prototype.dwType;
        /** @type {?|undefined} */
        TabsConfig.prototype.dwTabBarGutter;
        /** @type {?|undefined} */
        TabsConfig.prototype.dwShowPagination;
    }
    /**
     * @record
     */
    function TimePickerConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwAllowEmpty;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwClearText;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwFormat;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwHourStep;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwMinuteStep;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwSecondStep;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwPopupClassName;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwUse12Hours;
        /** @type {?|undefined} */
        TimePickerConfig.prototype.dwSuffixIcon;
    }
    /**
     * @record
     */
    function TreeConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TreeConfig.prototype.dwBlockNode;
        /** @type {?|undefined} */
        TreeConfig.prototype.dwShowIcon;
        /** @type {?|undefined} */
        TreeConfig.prototype.dwHideUnMatched;
    }
    /**
     * @record
     */
    function TreeSelectConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TreeSelectConfig.prototype.dwShowIcon;
        /** @type {?|undefined} */
        TreeSelectConfig.prototype.dwShowLine;
        /** @type {?|undefined} */
        TreeSelectConfig.prototype.dwDropdownMatchSelectWidth;
        /** @type {?|undefined} */
        TreeSelectConfig.prototype.dwHideUnMatched;
        /** @type {?|undefined} */
        TreeSelectConfig.prototype.dwSize;
    }
    /**
     * @record
     */
    function TypographyConfig() { }
    if (false) {
        /** @type {?|undefined} */
        TypographyConfig.prototype.dwEllipsisRows;
    }
    /**
     * User should provide an object implements this interface to set global configurations.
     * @type {?}
     */
    var DW_CONFIG = new core.InjectionToken('dw-config');

    /**
     * @fileoverview added by tsickle
     * Generated from: config.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var isDefined = (/**
     * @param {?=} value
     * @return {?}
     */
    function (value) {
        return value !== undefined;
    });
    var ɵ0 = isDefined;
    var DwConfigService = /** @class */ (function () {
        function DwConfigService(defaultConfig) {
            this.configUpdated$ = new rxjs.Subject();
            this.config = defaultConfig || {};
        }
        /**
         * @template T
         * @param {?} componentName
         * @return {?}
         */
        DwConfigService.prototype.getConfigForComponent = /**
         * @template T
         * @param {?} componentName
         * @return {?}
         */
        function (componentName) {
            return this.config[componentName];
        };
        /**
         * @param {?} componentName
         * @return {?}
         */
        DwConfigService.prototype.getConfigChangeEventForComponent = /**
         * @param {?} componentName
         * @return {?}
         */
        function (componentName) {
            return this.configUpdated$.pipe(operators.filter((/**
             * @param {?} n
             * @return {?}
             */
            function (n) { return n === componentName; })), operators.mapTo(undefined));
        };
        /**
         * @template T
         * @param {?} componentName
         * @param {?} value
         * @return {?}
         */
        DwConfigService.prototype.set = /**
         * @template T
         * @param {?} componentName
         * @param {?} value
         * @return {?}
         */
        function (componentName, value) {
            this.config[componentName] = __assign(__assign({}, this.config[componentName]), value);
            this.configUpdated$.next(componentName);
        };
        DwConfigService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        DwConfigService.ctorParameters = function () { return [
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [DW_CONFIG,] }] }
        ]; };
        /** @nocollapse */ DwConfigService.ɵprov = core.ɵɵdefineInjectable({ factory: function DwConfigService_Factory() { return new DwConfigService(core.ɵɵinject(DW_CONFIG, 8)); }, token: DwConfigService, providedIn: "root" });
        return DwConfigService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwConfigService.prototype.configUpdated$;
        /**
         * Global config holding property.
         * @type {?}
         * @private
         */
        DwConfigService.prototype.config;
    }
    // tslint:disable:no-invalid-this
    /**
     * This decorator is used to decorate properties. If a property is decorated, it would try to load default value from
     * config.
     * @template T
     * @param {?} componentName
     * @return {?}
     */
    // tslint:disable-next-line:typedef
    function WithConfig(componentName) {
        return (/**
         * @param {?} target
         * @param {?} propName
         * @param {?=} originalDescriptor
         * @return {?}
         */
        function ConfigDecorator(target, propName, originalDescriptor) {
            /** @type {?} */
            var privatePropName = "$$__assignedValue__" + propName;
            Object.defineProperty(target, privatePropName, {
                configurable: true,
                writable: true,
                enumerable: false
            });
            return {
                get: /**
                 * @return {?}
                 */
                function () {
                    /** @type {?} */
                    var originalValue = (originalDescriptor === null || originalDescriptor === void 0 ? void 0 : originalDescriptor.get) ? originalDescriptor.get.bind(this)() : this[privatePropName];
                    /** @type {?} */
                    var assignedByUser = ((this.assignmentCount || {})[propName] || 0) > 1;
                    if (assignedByUser && isDefined(originalValue)) {
                        return originalValue;
                    }
                    /** @type {?} */
                    var componentConfig = this.dwConfigService.getConfigForComponent(componentName) || {};
                    /** @type {?} */
                    var configValue = componentConfig[propName];
                    /** @type {?} */
                    var ret = isDefined(configValue) ? configValue : originalValue;
                    return ret;
                },
                set: /**
                 * @param {?=} value
                 * @return {?}
                 */
                function (value) {
                    // If the value is assigned, we consider the newly assigned value as 'assigned by user'.
                    this.assignmentCount = this.assignmentCount || {};
                    this.assignmentCount[propName] = (this.assignmentCount[propName] || 0) + 1;
                    if (originalDescriptor === null || originalDescriptor === void 0 ? void 0 : originalDescriptor.set) {
                        originalDescriptor.set.bind(this)(value);
                    }
                    else {
                        this[privatePropName] = value;
                    }
                },
                configurable: true,
                enumerable: true
            };
        });
    }

    exports.DW_CONFIG = DW_CONFIG;
    exports.DwConfigService = DwConfigService;
    exports.WithConfig = WithConfig;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-config.umd.js.map
