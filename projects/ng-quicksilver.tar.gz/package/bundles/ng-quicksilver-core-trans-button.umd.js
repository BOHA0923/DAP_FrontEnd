(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/trans-button', ['exports', '@angular/common', '@angular/core'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core['trans-button'] = {}), global.ng.common, global.ng.core));
}(this, (function (exports, common, core) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-trans-button.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTransButtonDirective = /** @class */ (function () {
        function DwTransButtonDirective() {
        }
        DwTransButtonDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'button[dw-trans-button]',
                        host: {
                            '[style.border]': '"0"',
                            '[style.background]': '"transparent"',
                            '[style.padding]': '"0"',
                            '[style.line-height]': '"inherit"'
                        }
                    },] }
        ];
        return DwTransButtonDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-trans-button.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTransButtonModule = /** @class */ (function () {
        function DwTransButtonModule() {
        }
        DwTransButtonModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [DwTransButtonDirective],
                        exports: [DwTransButtonDirective],
                        imports: [common.CommonModule]
                    },] }
        ];
        return DwTransButtonModule;
    }());

    exports.DwTransButtonDirective = DwTransButtonDirective;
    exports.DwTransButtonModule = DwTransButtonModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-trans-button.umd.js.map
