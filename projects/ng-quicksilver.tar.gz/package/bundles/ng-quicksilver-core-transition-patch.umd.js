(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/platform'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/transition-patch', ['exports', '@angular/cdk/platform', '@angular/core'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core['transition-patch'] = {}), global.ng.cdk.platform, global.ng.core));
}(this, (function (exports, platform, core) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: transition-patch.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * hack the bug
     * angular router change with unexpected transition trigger after calling applicationRef.attachView
     * https://github.com/angular/angular/issues/34718
     */
    var DwTransitionPatchDirective = /** @class */ (function () {
        function DwTransitionPatchDirective(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.hidden = null;
            this.renderer.setAttribute(this.elementRef.nativeElement, 'hidden', '');
        }
        /**
         * @return {?}
         */
        DwTransitionPatchDirective.prototype.setHiddenAttribute = /**
         * @return {?}
         */
        function () {
            if (this.hidden === true) {
                this.renderer.setAttribute(this.elementRef.nativeElement, 'hidden', '');
            }
            else if (this.hidden === false || this.hidden === null) {
                this.renderer.removeAttribute(this.elementRef.nativeElement, 'hidden');
            }
            else if (typeof this.hidden === 'string') {
                this.renderer.setAttribute(this.elementRef.nativeElement, 'hidden', this.hidden);
            }
        };
        /**
         * @return {?}
         */
        DwTransitionPatchDirective.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            this.setHiddenAttribute();
        };
        /**
         * @return {?}
         */
        DwTransitionPatchDirective.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            this.setHiddenAttribute();
        };
        DwTransitionPatchDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-button],dw-button-group,[dw-icon],[dw-menu-item],[dw-submenu],dw-select-top-control,dw-select-placeholder'
                    },] }
        ];
        /** @nocollapse */
        DwTransitionPatchDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        DwTransitionPatchDirective.propDecorators = {
            hidden: [{ type: core.Input }]
        };
        return DwTransitionPatchDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTransitionPatchDirective.prototype.hidden;
        /**
         * @type {?}
         * @private
         */
        DwTransitionPatchDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTransitionPatchDirective.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: transition-patch.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTransitionPatchModule = /** @class */ (function () {
        function DwTransitionPatchModule() {
        }
        DwTransitionPatchModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [platform.PlatformModule],
                        exports: [DwTransitionPatchDirective],
                        declarations: [DwTransitionPatchDirective]
                    },] }
        ];
        return DwTransitionPatchModule;
    }());

    exports.ɵDwTransitionPatchDirective = DwTransitionPatchDirective;
    exports.ɵDwTransitionPatchModule = DwTransitionPatchModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-transition-patch.umd.js.map
