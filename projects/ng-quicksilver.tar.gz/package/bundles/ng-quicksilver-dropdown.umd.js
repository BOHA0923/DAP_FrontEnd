(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/keycodes'), require('@angular/cdk/overlay'), require('@angular/cdk/platform'), require('@angular/cdk/portal'), require('@angular/core'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/core/util'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('@angular/forms'), require('ng-quicksilver/button'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/icon'), require('ng-quicksilver/menu'), require('ng-quicksilver/core/animation')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/dropdown', ['exports', '@angular/cdk/keycodes', '@angular/cdk/overlay', '@angular/cdk/platform', '@angular/cdk/portal', '@angular/core', 'ng-quicksilver/core/overlay', 'ng-quicksilver/core/util', 'rxjs', 'rxjs/operators', '@angular/common', '@angular/forms', 'ng-quicksilver/button', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/icon', 'ng-quicksilver/menu', 'ng-quicksilver/core/animation'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].dropdown = {}), global.ng.cdk.keycodes, global.ng.cdk.overlay, global.ng.cdk.platform, global.ng.cdk.portal, global.ng.core, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].core.util, global.rxjs, global.rxjs.operators, global.ng.common, global.ng.forms, global['ng-quicksilver'].button, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].icon, global['ng-quicksilver'].menu, global['ng-quicksilver'].core.animation));
}(this, (function (exports, keycodes, overlay, platform, portal, core, overlay$1, util, rxjs, operators, common, forms, button, noAnimation, outlet, icon, menu, animation) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: dropdown.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var listOfPositions = [overlay$1.POSITION_MAP.bottomLeft, overlay$1.POSITION_MAP.bottomRight, overlay$1.POSITION_MAP.topRight, overlay$1.POSITION_MAP.topLeft];
    var DwDropDownDirective = /** @class */ (function () {
        function DwDropDownDirective(elementRef, overlay, renderer, viewContainerRef, platform) {
            this.elementRef = elementRef;
            this.overlay = overlay;
            this.renderer = renderer;
            this.viewContainerRef = viewContainerRef;
            this.platform = platform;
            this.overlayRef = null;
            this.destroy$ = new rxjs.Subject();
            this.positionStrategy = this.overlay
                .position()
                .flexibleConnectedTo(this.elementRef.nativeElement)
                .withLockedPosition()
                .withTransformOriginOn('.ant-dropdown');
            this.inputVisible$ = new rxjs.BehaviorSubject(false);
            this.dwTrigger$ = new rxjs.BehaviorSubject('hover');
            this.overlayClose$ = new rxjs.Subject();
            this.dwDropdownMenu = null;
            this.dwTrigger = 'hover';
            this.dwMatchWidthElement = null;
            this.dwBackdrop = true;
            this.dwClickHide = true;
            this.dwDisabled = false;
            this.dwVisible = false;
            this.dwOverlayClassName = '';
            this.dwOverlayStyle = {};
            this.dwPlacement = 'bottomLeft';
            this.dwVisibleChange = new core.EventEmitter();
        }
        /**
         * @template T
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        DwDropDownDirective.prototype.setDropdownMenuValue = /**
         * @template T
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        function (key, value) {
            if (this.dwDropdownMenu) {
                this.dwDropdownMenu.setValue(key, value);
            }
        };
        /**
         * @return {?}
         */
        DwDropDownDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () { };
        /**
         * @return {?}
         */
        DwDropDownDirective.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.dwDropdownMenu) {
                /** @type {?} */
                var nativeElement_1 = this.elementRef.nativeElement;
                /**
                 * host mouse state *
                 * @type {?}
                 */
                var hostMouseState$ = rxjs.merge(rxjs.fromEvent(nativeElement_1, 'mouseenter').pipe(operators.mapTo(true)), rxjs.fromEvent(nativeElement_1, 'mouseleave').pipe(operators.mapTo(false)));
                /**
                 * menu mouse state *
                 * @type {?}
                 */
                var menuMouseState$ = this.dwDropdownMenu.mouseState$;
                /**
                 * merged mouse state *
                 * @type {?}
                 */
                var mergedMouseState$_1 = rxjs.merge(menuMouseState$, hostMouseState$);
                /**
                 * host click state *
                 * @type {?}
                 */
                var hostClickState$_1 = rxjs.fromEvent(nativeElement_1, 'click').pipe(operators.mapTo(true));
                /**
                 * visible state switch by dwTrigger *
                 * @type {?}
                 */
                var visibleStateByTrigger$ = this.dwTrigger$.pipe(operators.switchMap((/**
                 * @param {?} trigger
                 * @return {?}
                 */
                function (trigger) {
                    if (trigger === 'hover') {
                        return mergedMouseState$_1;
                    }
                    else if (trigger === 'click') {
                        return hostClickState$_1;
                    }
                    else {
                        return rxjs.EMPTY;
                    }
                })));
                /** @type {?} */
                var descendantMenuItemClick$ = this.dwDropdownMenu.descendantMenuItemClick$.pipe(operators.filter((/**
                 * @return {?}
                 */
                function () { return _this.dwClickHide; })), operators.mapTo(false));
                /** @type {?} */
                var domTriggerVisible$ = rxjs.merge(visibleStateByTrigger$, descendantMenuItemClick$, this.overlayClose$).pipe(operators.filter((/**
                 * @return {?}
                 */
                function () { return !_this.dwDisabled; })));
                /** @type {?} */
                var visible$ = rxjs.merge(this.inputVisible$, domTriggerVisible$);
                rxjs.combineLatest([visible$, this.dwDropdownMenu.isChildSubMenuOpen$])
                    .pipe(operators.map((/**
                 * @param {?} __0
                 * @return {?}
                 */
                function (_a) {
                    var _b = __read(_a, 2), visible = _b[0], sub = _b[1];
                    return visible || sub;
                })), operators.auditTime(150), operators.distinctUntilChanged(), operators.filter((/**
                 * @return {?}
                 */
                function () { return _this.platform.isBrowser; })), operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @param {?} visible
                 * @return {?}
                 */
                function (visible) {
                    /** @type {?} */
                    var element = _this.dwMatchWidthElement ? _this.dwMatchWidthElement.nativeElement : nativeElement_1;
                    /** @type {?} */
                    var triggerWidth = element.getBoundingClientRect().width;
                    if (_this.dwVisible !== visible) {
                        _this.dwVisibleChange.emit(visible);
                    }
                    _this.dwVisible = visible;
                    if (visible) {
                        /** set up overlayRef **/
                        if (!_this.overlayRef) {
                            /** new overlay **/
                            _this.overlayRef = _this.overlay.create({
                                positionStrategy: _this.positionStrategy,
                                minWidth: triggerWidth,
                                disposeOnNavigation: true,
                                hasBackdrop: _this.dwTrigger === 'click',
                                backdropClass: _this.dwBackdrop ? undefined : 'dw-overlay-transparent-backdrop',
                                scrollStrategy: _this.overlay.scrollStrategies.reposition()
                            });
                            rxjs.merge(_this.overlayRef.backdropClick(), _this.overlayRef.detachments(), _this.overlayRef.keydownEvents().pipe(operators.filter((/**
                             * @param {?} e
                             * @return {?}
                             */
                            function (e) { return e.keyCode === keycodes.ESCAPE && !keycodes.hasModifierKey(e); }))))
                                .pipe(operators.mapTo(false), operators.takeUntil(_this.destroy$))
                                .subscribe(_this.overlayClose$);
                        }
                        else {
                            /**
                             * update overlay config *
                             * @type {?}
                             */
                            var overlayConfig = _this.overlayRef.getConfig();
                            overlayConfig.minWidth = triggerWidth;
                            overlayConfig.hasBackdrop = _this.dwTrigger === 'click';
                        }
                        /** open dropdown with animation **/
                        _this.positionStrategy.withPositions(__spread([overlay$1.POSITION_MAP[_this.dwPlacement]], listOfPositions));
                        /** reset portal if needed **/
                        if (!_this.portal || _this.portal.templateRef !== (/** @type {?} */ (_this.dwDropdownMenu)).templateRef) {
                            _this.portal = new portal.TemplatePortal((/** @type {?} */ (_this.dwDropdownMenu)).templateRef, _this.viewContainerRef);
                        }
                        _this.overlayRef.attach(_this.portal);
                    }
                    else {
                        /** detach overlayRef if needed **/
                        if (_this.overlayRef) {
                            _this.overlayRef.detach();
                        }
                    }
                }));
            }
        };
        /**
         * @return {?}
         */
        DwDropDownDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
            if (this.overlayRef) {
                this.overlayRef.dispose();
                this.overlayRef = null;
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwDropDownDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwVisible = changes.dwVisible, dwDisabled = changes.dwDisabled, dwOverlayClassName = changes.dwOverlayClassName, dwOverlayStyle = changes.dwOverlayStyle, dwTrigger = changes.dwTrigger;
            if (dwTrigger) {
                this.dwTrigger$.next(this.dwTrigger);
            }
            if (dwVisible) {
                this.inputVisible$.next(this.dwVisible);
            }
            if (dwDisabled) {
                /** @type {?} */
                var nativeElement = this.elementRef.nativeElement;
                if (this.dwDisabled) {
                    this.renderer.setAttribute(nativeElement, 'disabled', '');
                    this.inputVisible$.next(false);
                }
                else {
                    this.renderer.removeAttribute(nativeElement, 'disabled');
                }
            }
            if (dwOverlayClassName) {
                this.setDropdownMenuValue('dwOverlayClassName', this.dwOverlayClassName);
            }
            if (dwOverlayStyle) {
                this.setDropdownMenuValue('dwOverlayStyle', this.dwOverlayStyle);
            }
        };
        DwDropDownDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-dropdown]',
                        exportAs: 'dwDropdown',
                        host: {
                            '[class.ant-dropdown-trigger]': 'true'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwDropDownDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: overlay.Overlay },
            { type: core.Renderer2 },
            { type: core.ViewContainerRef },
            { type: platform.Platform }
        ]; };
        DwDropDownDirective.propDecorators = {
            dwDropdownMenu: [{ type: core.Input }],
            dwTrigger: [{ type: core.Input }],
            dwMatchWidthElement: [{ type: core.Input }],
            dwBackdrop: [{ type: core.Input }],
            dwClickHide: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwVisible: [{ type: core.Input }],
            dwOverlayClassName: [{ type: core.Input }],
            dwOverlayStyle: [{ type: core.Input }],
            dwPlacement: [{ type: core.Input }],
            dwVisibleChange: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwDropDownDirective.prototype, "dwBackdrop", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwDropDownDirective.prototype, "dwClickHide", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwDropDownDirective.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwDropDownDirective.prototype, "dwVisible", void 0);
        return DwDropDownDirective;
    }());
    if (false) {
        /** @type {?} */
        DwDropDownDirective.ngAcceptInputType_dwBackdrop;
        /** @type {?} */
        DwDropDownDirective.ngAcceptInputType_dwClickHide;
        /** @type {?} */
        DwDropDownDirective.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwDropDownDirective.ngAcceptInputType_dwVisible;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.portal;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.overlayRef;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.positionStrategy;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.inputVisible$;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.dwTrigger$;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.overlayClose$;
        /** @type {?} */
        DwDropDownDirective.prototype.dwDropdownMenu;
        /** @type {?} */
        DwDropDownDirective.prototype.dwTrigger;
        /** @type {?} */
        DwDropDownDirective.prototype.dwMatchWidthElement;
        /** @type {?} */
        DwDropDownDirective.prototype.dwBackdrop;
        /** @type {?} */
        DwDropDownDirective.prototype.dwClickHide;
        /** @type {?} */
        DwDropDownDirective.prototype.dwDisabled;
        /** @type {?} */
        DwDropDownDirective.prototype.dwVisible;
        /** @type {?} */
        DwDropDownDirective.prototype.dwOverlayClassName;
        /** @type {?} */
        DwDropDownDirective.prototype.dwOverlayStyle;
        /** @type {?} */
        DwDropDownDirective.prototype.dwPlacement;
        /** @type {?} */
        DwDropDownDirective.prototype.dwVisibleChange;
        /** @type {?} */
        DwDropDownDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.overlay;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.viewContainerRef;
        /**
         * @type {?}
         * @private
         */
        DwDropDownDirective.prototype.platform;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: context-menu.service.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwContextMenuServiceModule = /** @class */ (function () {
        function DwContextMenuServiceModule() {
        }
        DwContextMenuServiceModule.decorators = [
            { type: core.NgModule }
        ];
        return DwContextMenuServiceModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: dropdown-a.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDropDownADirective = /** @class */ (function () {
        function DwDropDownADirective() {
        }
        DwDropDownADirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'a[dw-dropdown]',
                        host: {
                            '[class.ant-dropdown-link]': 'true'
                        }
                    },] }
        ];
        return DwDropDownADirective;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: dropdown-button.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDropdownButtonDirective = /** @class */ (function () {
        function DwDropdownButtonDirective(renderer, dwButtonGroupComponent, elementRef) {
            this.renderer = renderer;
            this.dwButtonGroupComponent = dwButtonGroupComponent;
            this.elementRef = elementRef;
        }
        /**
         * @return {?}
         */
        DwDropdownButtonDirective.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var parentElement = this.renderer.parentNode(this.elementRef.nativeElement);
            if (this.dwButtonGroupComponent && parentElement) {
                this.renderer.addClass(parentElement, 'ant-dropdown-button');
            }
        };
        DwDropdownButtonDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-button][dw-dropdown]'
                    },] }
        ];
        /** @nocollapse */
        DwDropdownButtonDirective.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: button.DwButtonGroupComponent, decorators: [{ type: core.Host }, { type: core.Optional }] },
            { type: core.ElementRef }
        ]; };
        return DwDropdownButtonDirective;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwDropdownButtonDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwDropdownButtonDirective.prototype.dwButtonGroupComponent;
        /**
         * @type {?}
         * @private
         */
        DwDropdownButtonDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: dropdown-menu.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDropdownMenuComponent = /** @class */ (function () {
        function DwDropdownMenuComponent(cdr, elementRef, renderer, viewContainerRef, dwMenuService, noAnimation) {
            this.cdr = cdr;
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.viewContainerRef = viewContainerRef;
            this.dwMenuService = dwMenuService;
            this.noAnimation = noAnimation;
            this.mouseState$ = new rxjs.BehaviorSubject(false);
            this.isChildSubMenuOpen$ = this.dwMenuService.isChildSubMenuOpen$;
            this.descendantMenuItemClick$ = this.dwMenuService.descendantMenuItemClick$;
            this.dwOverlayClassName = '';
            this.dwOverlayStyle = {};
        }
        /**
         * @param {?} visible
         * @return {?}
         */
        DwDropdownMenuComponent.prototype.setMouseState = /**
         * @param {?} visible
         * @return {?}
         */
        function (visible) {
            this.mouseState$.next(visible);
        };
        /**
         * @template T
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        DwDropdownMenuComponent.prototype.setValue = /**
         * @template T
         * @param {?} key
         * @param {?} value
         * @return {?}
         */
        function (key, value) {
            this[key] = value;
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwDropdownMenuComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            this.renderer.removeChild(this.renderer.parentNode(this.elementRef.nativeElement), this.elementRef.nativeElement);
        };
        DwDropdownMenuComponent.decorators = [
            { type: core.Component, args: [{
                        selector: "dw-dropdown-menu",
                        exportAs: "dwDropdownMenu",
                        animations: [animation.slideMotion],
                        providers: [
                            menu.MenuService,
                            /** menu is inside dropdown-menu component **/
                            {
                                provide: menu.DwIsMenuInsideDropDownToken,
                                useValue: true
                            }
                        ],
                        template: "\n    <ng-template>\n      <div\n        class=\"ant-dropdown\"\n        [ngClass]=\"dwOverlayClassName\"\n        [ngStyle]=\"dwOverlayStyle\"\n        [@slideMotion]=\"'enter'\"\n        [@.disabled]=\"noAnimation?.dwNoAnimation\"\n        [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n        (mouseenter)=\"setMouseState(true)\"\n        (mouseleave)=\"setMouseState(false)\"\n      >\n        <ng-content></ng-content>\n      </div>\n    </ng-template>\n  ",
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwDropdownMenuComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: core.ViewContainerRef },
            { type: menu.MenuService },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwDropdownMenuComponent.propDecorators = {
            templateRef: [{ type: core.ViewChild, args: [core.TemplateRef, { static: true },] }]
        };
        return DwDropdownMenuComponent;
    }());
    if (false) {
        /** @type {?} */
        DwDropdownMenuComponent.prototype.mouseState$;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.isChildSubMenuOpen$;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.descendantMenuItemClick$;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.dwOverlayClassName;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.dwOverlayStyle;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.templateRef;
        /**
         * @type {?}
         * @private
         */
        DwDropdownMenuComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwDropdownMenuComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwDropdownMenuComponent.prototype.renderer;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.viewContainerRef;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.dwMenuService;
        /** @type {?} */
        DwDropdownMenuComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: dropdown.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDropDownModule = /** @class */ (function () {
        function DwDropDownModule() {
        }
        DwDropDownModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            overlay.OverlayModule,
                            forms.FormsModule,
                            button.DwButtonModule,
                            menu.DwMenuModule,
                            icon.DwIconModule,
                            noAnimation.DwNoAnimationModule,
                            platform.PlatformModule,
                            overlay$1.DwOverlayModule,
                            DwContextMenuServiceModule,
                            outlet.DwOutletModule
                        ],
                        entryComponents: [DwDropdownMenuComponent],
                        declarations: [DwDropDownDirective, DwDropDownADirective, DwDropdownMenuComponent, DwDropdownButtonDirective],
                        exports: [menu.DwMenuModule, DwDropDownDirective, DwDropDownADirective, DwDropdownMenuComponent, DwDropdownButtonDirective]
                    },] }
        ];
        return DwDropDownModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: context-menu.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var listOfPositions$1 = [
        new overlay.ConnectionPositionPair({ originX: 'start', originY: 'top' }, { overlayX: 'start', overlayY: 'top' }),
        new overlay.ConnectionPositionPair({ originX: 'start', originY: 'top' }, { overlayX: 'start', overlayY: 'bottom' }),
        new overlay.ConnectionPositionPair({ originX: 'start', originY: 'top' }, { overlayX: 'end', overlayY: 'bottom' }),
        new overlay.ConnectionPositionPair({ originX: 'start', originY: 'top' }, { overlayX: 'end', overlayY: 'top' })
    ];
    var DwContextMenuService = /** @class */ (function () {
        function DwContextMenuService(overlay) {
            this.overlay = overlay;
            this.overlayRef = null;
            this.closeSubscription = rxjs.Subscription.EMPTY;
        }
        /**
         * @param {?} $event
         * @param {?} dwDropdownMenuComponent
         * @return {?}
         */
        DwContextMenuService.prototype.create = /**
         * @param {?} $event
         * @param {?} dwDropdownMenuComponent
         * @return {?}
         */
        function ($event, dwDropdownMenuComponent) {
            var _this = this;
            this.close(true);
            var x = $event.x, y = $event.y;
            if ($event instanceof MouseEvent) {
                $event.preventDefault();
            }
            /** @type {?} */
            var positionStrategy = this.overlay
                .position()
                .flexibleConnectedTo({ x: x, y: y })
                .withPositions(listOfPositions$1)
                .withTransformOriginOn('.ant-dropdown');
            this.overlayRef = this.overlay.create({
                positionStrategy: positionStrategy,
                disposeOnNavigation: true,
                scrollStrategy: this.overlay.scrollStrategies.close()
            });
            this.closeSubscription = rxjs.merge(dwDropdownMenuComponent.descendantMenuItemClick$, rxjs.fromEvent(document, 'click').pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return !!_this.overlayRef && !_this.overlayRef.overlayElement.contains((/** @type {?} */ (event.target))); })), 
            /** handle firefox contextmenu event **/
            operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return event.button !== 2; })), operators.take(1))).subscribe((/**
             * @return {?}
             */
            function () {
                _this.close();
            }));
            this.overlayRef.attach(new portal.TemplatePortal(dwDropdownMenuComponent.templateRef, dwDropdownMenuComponent.viewContainerRef));
        };
        /**
         * @param {?=} clear
         * @return {?}
         */
        DwContextMenuService.prototype.close = /**
         * @param {?=} clear
         * @return {?}
         */
        function (clear) {
            if (clear === void 0) { clear = false; }
            if (this.overlayRef) {
                this.overlayRef.detach();
                if (clear) {
                    this.overlayRef.dispose();
                }
                this.overlayRef = null;
                this.closeSubscription.unsubscribe();
            }
        };
        DwContextMenuService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: DwContextMenuServiceModule
                    },] }
        ];
        /** @nocollapse */
        DwContextMenuService.ctorParameters = function () { return [
            { type: overlay.Overlay }
        ]; };
        /** @nocollapse */ DwContextMenuService.ɵprov = core.ɵɵdefineInjectable({ factory: function DwContextMenuService_Factory() { return new DwContextMenuService(core.ɵɵinject(overlay.Overlay)); }, token: DwContextMenuService, providedIn: DwContextMenuServiceModule });
        return DwContextMenuService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwContextMenuService.prototype.overlayRef;
        /**
         * @type {?}
         * @private
         */
        DwContextMenuService.prototype.closeSubscription;
        /**
         * @type {?}
         * @private
         */
        DwContextMenuService.prototype.overlay;
    }

    exports.DwContextMenuService = DwContextMenuService;
    exports.DwContextMenuServiceModule = DwContextMenuServiceModule;
    exports.DwDropDownADirective = DwDropDownADirective;
    exports.DwDropDownDirective = DwDropDownDirective;
    exports.DwDropDownModule = DwDropDownModule;
    exports.DwDropdownButtonDirective = DwDropdownButtonDirective;
    exports.DwDropdownMenuComponent = DwDropdownMenuComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-dropdown.umd.js.map
