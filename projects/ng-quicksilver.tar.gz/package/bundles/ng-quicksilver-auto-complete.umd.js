(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/overlay'), require('@angular/common'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/input'), require('ng-quicksilver/core/util'), require('@angular/cdk/keycodes'), require('@angular/cdk/portal'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/animation')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/auto-complete', ['exports', '@angular/cdk/overlay', '@angular/common', '@angular/core', '@angular/forms', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/input', 'ng-quicksilver/core/util', '@angular/cdk/keycodes', '@angular/cdk/portal', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/animation'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver']['auto-complete'] = {}), global.ng.cdk.overlay, global.ng.common, global.ng.core, global.ng.forms, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].input, global['ng-quicksilver'].core.util, global.ng.cdk.keycodes, global.ng.cdk.portal, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core.animation));
}(this, (function (exports, overlay, common, core, forms, noAnimation, outlet, input, util, keycodes, portal, rxjs, operators, animation) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: autocomplete-optgroup.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwAutocompleteOptgroupComponent = /** @class */ (function () {
        function DwAutocompleteOptgroupComponent() {
        }
        DwAutocompleteOptgroupComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-auto-optgroup',
                        exportAs: 'dwAutoOptgroup',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div class=\"ant-select-item ant-select-item-group\">\n      <ng-container *dwStringTemplateOutlet=\"dwLabel\">{{ dwLabel }}</ng-container>\n    </div>\n    <ng-content select=\"dw-auto-option\"></ng-content>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwAutocompleteOptgroupComponent.ctorParameters = function () { return []; };
        DwAutocompleteOptgroupComponent.propDecorators = {
            dwLabel: [{ type: core.Input }]
        };
        return DwAutocompleteOptgroupComponent;
    }());
    if (false) {
        /** @type {?} */
        DwAutocompleteOptgroupComponent.prototype.dwLabel;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: autocomplete-option.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwOptionSelectionChange = /** @class */ (function () {
        function DwOptionSelectionChange(source, isUserInput) {
            if (isUserInput === void 0) { isUserInput = false; }
            this.source = source;
            this.isUserInput = isUserInput;
        }
        return DwOptionSelectionChange;
    }());
    if (false) {
        /** @type {?} */
        DwOptionSelectionChange.prototype.source;
        /** @type {?} */
        DwOptionSelectionChange.prototype.isUserInput;
    }
    var DwAutocompleteOptionComponent = /** @class */ (function () {
        function DwAutocompleteOptionComponent(changeDetectorRef, element, dwAutocompleteOptgroupComponent) {
            this.changeDetectorRef = changeDetectorRef;
            this.element = element;
            this.dwAutocompleteOptgroupComponent = dwAutocompleteOptgroupComponent;
            this.dwDisabled = false;
            this.selectionChange = new core.EventEmitter();
            this.mouseEntered = new core.EventEmitter();
            this.active = false;
            this.selected = false;
        }
        /**
         * @param {?=} emit
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.select = /**
         * @param {?=} emit
         * @return {?}
         */
        function (emit) {
            if (emit === void 0) { emit = true; }
            this.selected = true;
            this.changeDetectorRef.markForCheck();
            if (emit) {
                this.emitSelectionChangeEvent();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.onMouseEnter = /**
         * @return {?}
         */
        function () {
            this.mouseEntered.emit(this);
        };
        /**
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.deselect = /**
         * @return {?}
         */
        function () {
            this.selected = false;
            this.changeDetectorRef.markForCheck();
            this.emitSelectionChangeEvent();
        };
        /** Git display label */
        /**
         * Git display label
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.getLabel = /**
         * Git display label
         * @return {?}
         */
        function () {
            return this.dwLabel || this.dwValue.toString();
        };
        /** Set active (only styles) */
        /**
         * Set active (only styles)
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.setActiveStyles = /**
         * Set active (only styles)
         * @return {?}
         */
        function () {
            if (!this.active) {
                this.active = true;
                this.changeDetectorRef.markForCheck();
            }
        };
        /** Unset active (only styles) */
        /**
         * Unset active (only styles)
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.setInactiveStyles = /**
         * Unset active (only styles)
         * @return {?}
         */
        function () {
            if (this.active) {
                this.active = false;
                this.changeDetectorRef.markForCheck();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.scrollIntoViewIfNeeded = /**
         * @return {?}
         */
        function () {
            util.scrollIntoView(this.element.nativeElement);
        };
        /**
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.selectViaInteraction = /**
         * @return {?}
         */
        function () {
            if (!this.dwDisabled) {
                this.selected = !this.selected;
                if (this.selected) {
                    this.setActiveStyles();
                }
                else {
                    this.setInactiveStyles();
                }
                this.emitSelectionChangeEvent(true);
                this.changeDetectorRef.markForCheck();
            }
        };
        /**
         * @private
         * @param {?=} isUserInput
         * @return {?}
         */
        DwAutocompleteOptionComponent.prototype.emitSelectionChangeEvent = /**
         * @private
         * @param {?=} isUserInput
         * @return {?}
         */
        function (isUserInput) {
            if (isUserInput === void 0) { isUserInput = false; }
            this.selectionChange.emit(new DwOptionSelectionChange(this, isUserInput));
        };
        DwAutocompleteOptionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-auto-option',
                        exportAs: 'dwAutoOption',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div class=\"ant-select-item-option-content\">\n      <ng-content></ng-content>\n    </div>\n  ",
                        host: {
                            role: 'menuitem',
                            class: 'ant-select-item ant-select-item-option',
                            '[class.ant-select-item-option-grouped]': 'dwAutocompleteOptgroupComponent',
                            '[class.ant-select-item-option-selected]': 'selected',
                            '[class.ant-select-item-option-active]': 'active',
                            '[class.ant-select-item-option-disabled]': 'dwDisabled',
                            '[attr.aria-selected]': 'selected.toString()',
                            '[attr.aria-disabled]': 'dwDisabled.toString()',
                            '(click)': 'selectViaInteraction()',
                            '(mouseenter)': 'onMouseEnter()',
                            '(mousedown)': '$event.preventDefault()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwAutocompleteOptionComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: core.ElementRef },
            { type: DwAutocompleteOptgroupComponent, decorators: [{ type: core.Optional }] }
        ]; };
        DwAutocompleteOptionComponent.propDecorators = {
            dwValue: [{ type: core.Input }],
            dwLabel: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            selectionChange: [{ type: core.Output }],
            mouseEntered: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwAutocompleteOptionComponent.prototype, "dwDisabled", void 0);
        return DwAutocompleteOptionComponent;
    }());
    if (false) {
        /** @type {?} */
        DwAutocompleteOptionComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.dwValue;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.dwLabel;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.dwDisabled;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.selectionChange;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.mouseEntered;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.active;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.selected;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteOptionComponent.prototype.changeDetectorRef;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteOptionComponent.prototype.element;
        /** @type {?} */
        DwAutocompleteOptionComponent.prototype.dwAutocompleteOptgroupComponent;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: autocomplete.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function AutocompleteDataSourceItem() { }
    if (false) {
        /** @type {?} */
        AutocompleteDataSourceItem.prototype.value;
        /** @type {?} */
        AutocompleteDataSourceItem.prototype.label;
    }
    var DwAutocompleteComponent = /** @class */ (function () {
        function DwAutocompleteComponent(changeDetectorRef, ngZone, noAnimation) {
            var _this = this;
            this.changeDetectorRef = changeDetectorRef;
            this.ngZone = ngZone;
            this.noAnimation = noAnimation;
            this.dwOverlayClassName = '';
            this.dwOverlayStyle = {};
            this.dwDefaultActiveFirstOption = true;
            this.dwBackfill = false;
            this.compareWith = (/**
             * @param {?} o1
             * @param {?} o2
             * @return {?}
             */
            function (o1, o2) { return o1 === o2; });
            this.selectionChange = new core.EventEmitter();
            this.showPanel = true;
            this.isOpen = false;
            this.activeItemIndex = -1;
            this.selectionChangeSubscription = rxjs.Subscription.EMPTY;
            this.optionMouseEnterSubscription = rxjs.Subscription.EMPTY;
            this.dataSourceChangeSubscription = rxjs.Subscription.EMPTY;
            /**
             * Options changes listener
             */
            this.optionSelectionChanges = rxjs.defer((/**
             * @return {?}
             */
            function () {
                if (_this.options) {
                    return rxjs.merge.apply(void 0, __spread(_this.options.map((/**
                     * @param {?} option
                     * @return {?}
                     */
                    function (option) { return option.selectionChange; }))));
                }
                return _this.ngZone.onStable.asObservable().pipe(operators.take(1), operators.switchMap((/**
                 * @return {?}
                 */
                function () { return _this.optionSelectionChanges; })));
            }));
            this.optionMouseEnter = rxjs.defer((/**
             * @return {?}
             */
            function () {
                if (_this.options) {
                    return rxjs.merge.apply(void 0, __spread(_this.options.map((/**
                     * @param {?} option
                     * @return {?}
                     */
                    function (option) { return option.mouseEntered; }))));
                }
                return _this.ngZone.onStable.asObservable().pipe(operators.take(1), operators.switchMap((/**
                 * @return {?}
                 */
                function () { return _this.optionMouseEnter; })));
            }));
        }
        Object.defineProperty(DwAutocompleteComponent.prototype, "options", {
            /**
             * Options accessor, its source may be content or dataSource
             */
            get: /**
             * Options accessor, its source may be content or dataSource
             * @return {?}
             */
            function () {
                // first dataSource
                if (this.dwDataSource) {
                    return this.fromDataSourceOptions;
                }
                else {
                    return this.fromContentOptions;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            if (!this.dwDataSource) {
                this.optionsInit();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            if (this.dwDataSource) {
                this.optionsInit();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.dataSourceChangeSubscription.unsubscribe();
            this.selectionChangeSubscription.unsubscribe();
            this.optionMouseEnterSubscription.unsubscribe();
        };
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.setVisibility = /**
         * @return {?}
         */
        function () {
            this.showPanel = !!this.options.length;
            this.changeDetectorRef.markForCheck();
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwAutocompleteComponent.prototype.setActiveItem = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            /** @type {?} */
            var activeItem = this.options.toArray()[index];
            if (activeItem && !activeItem.active) {
                this.activeItem = activeItem;
                this.activeItemIndex = index;
                this.clearSelectedOptions(this.activeItem);
                this.activeItem.setActiveStyles();
                this.changeDetectorRef.markForCheck();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.setNextItemActive = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var nextIndex = this.activeItemIndex + 1 <= this.options.length - 1 ? this.activeItemIndex + 1 : 0;
            this.setActiveItem(nextIndex);
        };
        /**
         * @return {?}
         */
        DwAutocompleteComponent.prototype.setPreviousItemActive = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var previousIndex = this.activeItemIndex - 1 < 0 ? this.options.length - 1 : this.activeItemIndex - 1;
            this.setActiveItem(previousIndex);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwAutocompleteComponent.prototype.getOptionIndex = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            return (/** @type {?} */ (this.options.reduce((/**
             * @param {?} result
             * @param {?} current
             * @param {?} index
             * @return {?}
             */
            function (result, current, index) {
                return result === -1 ? (_this.compareWith(value, current.dwValue) ? index : -1) : result;
            }), -1)));
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwAutocompleteComponent.prototype.getOption = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            return this.options.find((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return _this.compareWith(value, item.dwValue); })) || null;
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteComponent.prototype.optionsInit = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            this.setVisibility();
            this.subscribeOptionChanges();
            /** @type {?} */
            var changes = this.dwDataSource ? this.fromDataSourceOptions.changes : this.fromContentOptions.changes;
            // async
            this.dataSourceChangeSubscription = changes.subscribe((/**
             * @param {?} e
             * @return {?}
             */
            function (e) {
                if (!e.dirty && _this.isOpen) {
                    setTimeout((/**
                     * @return {?}
                     */
                    function () { return _this.setVisibility(); }));
                }
                _this.subscribeOptionChanges();
            }));
        };
        /**
         * Clear the status of options
         */
        /**
         * Clear the status of options
         * @param {?=} skip
         * @param {?=} deselect
         * @return {?}
         */
        DwAutocompleteComponent.prototype.clearSelectedOptions = /**
         * Clear the status of options
         * @param {?=} skip
         * @param {?=} deselect
         * @return {?}
         */
        function (skip, deselect) {
            if (deselect === void 0) { deselect = false; }
            this.options.forEach((/**
             * @param {?} option
             * @return {?}
             */
            function (option) {
                if (option !== skip) {
                    if (deselect) {
                        option.deselect();
                    }
                    option.setInactiveStyles();
                }
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteComponent.prototype.subscribeOptionChanges = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            this.selectionChangeSubscription.unsubscribe();
            this.selectionChangeSubscription = this.optionSelectionChanges
                .pipe(operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) { return event.isUserInput; })))
                .subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                event.source.select();
                event.source.setActiveStyles();
                _this.activeItem = event.source;
                _this.activeItemIndex = _this.getOptionIndex(_this.activeItem.dwValue);
                _this.clearSelectedOptions(event.source, true);
                _this.selectionChange.emit(event.source);
            }));
            this.optionMouseEnterSubscription.unsubscribe();
            this.optionMouseEnterSubscription = this.optionMouseEnter.subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                event.setActiveStyles();
                _this.activeItem = event;
                _this.activeItemIndex = _this.getOptionIndex(_this.activeItem.dwValue);
                _this.clearSelectedOptions(event);
            }));
        };
        DwAutocompleteComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-autocomplete',
                        exportAs: 'dwAutocomplete',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <ng-template>\n      <div\n        #panel\n        class=\"ant-select-dropdown ant-select-dropdown-placement-bottomLeft\"\n        [class.ant-select-dropdown-hidden]=\"!showPanel\"\n        [ngClass]=\"dwOverlayClassName\"\n        [ngStyle]=\"dwOverlayStyle\"\n        [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n        [@slideMotion]=\"'enter'\"\n        [@.disabled]=\"noAnimation?.dwNoAnimation\"\n      >\n        <div style=\"max-height: 256px; overflow-y: auto; overflow-anchor: none;\">\n          <div style=\"display: flex; flex-direction: column;\">\n            <ng-template *ngTemplateOutlet=\"dwDataSource ? optionsTemplate : contentTemplate\"></ng-template>\n          </div>\n        </div>\n      </div>\n      <ng-template #contentTemplate>\n        <ng-content></ng-content>\n      </ng-template>\n      <ng-template #optionsTemplate>\n        <dw-auto-option\n          *ngFor=\"let option of dwDataSource!\"\n          [dwValue]=\"option\"\n          [dwLabel]=\"option && $any(option).label ? $any(option).label : $any(option)\"\n        >\n          {{ option && $any(option).label ? $any(option).label : $any(option) }}\n        </dw-auto-option>\n      </ng-template>\n    </ng-template>\n  ",
                        animations: [animation.slideMotion]
                    }] }
        ];
        /** @nocollapse */
        DwAutocompleteComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: core.NgZone },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwAutocompleteComponent.propDecorators = {
            dwWidth: [{ type: core.Input }],
            dwOverlayClassName: [{ type: core.Input }],
            dwOverlayStyle: [{ type: core.Input }],
            dwDefaultActiveFirstOption: [{ type: core.Input }],
            dwBackfill: [{ type: core.Input }],
            compareWith: [{ type: core.Input }],
            dwDataSource: [{ type: core.Input }],
            selectionChange: [{ type: core.Output }],
            fromContentOptions: [{ type: core.ContentChildren, args: [DwAutocompleteOptionComponent, { descendants: true },] }],
            fromDataSourceOptions: [{ type: core.ViewChildren, args: [DwAutocompleteOptionComponent,] }],
            template: [{ type: core.ViewChild, args: [core.TemplateRef, { static: false },] }],
            panel: [{ type: core.ViewChild, args: ['panel', { static: false },] }],
            content: [{ type: core.ViewChild, args: ['content', { static: false },] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwAutocompleteComponent.prototype, "dwDefaultActiveFirstOption", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwAutocompleteComponent.prototype, "dwBackfill", void 0);
        return DwAutocompleteComponent;
    }());
    if (false) {
        /** @type {?} */
        DwAutocompleteComponent.ngAcceptInputType_dwDefaultActiveFirstOption;
        /** @type {?} */
        DwAutocompleteComponent.ngAcceptInputType_dwBackfill;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwWidth;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwOverlayClassName;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwOverlayStyle;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwDefaultActiveFirstOption;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwBackfill;
        /** @type {?} */
        DwAutocompleteComponent.prototype.compareWith;
        /** @type {?} */
        DwAutocompleteComponent.prototype.dwDataSource;
        /** @type {?} */
        DwAutocompleteComponent.prototype.selectionChange;
        /** @type {?} */
        DwAutocompleteComponent.prototype.showPanel;
        /** @type {?} */
        DwAutocompleteComponent.prototype.isOpen;
        /** @type {?} */
        DwAutocompleteComponent.prototype.activeItem;
        /**
         * Provided by content
         * @type {?}
         */
        DwAutocompleteComponent.prototype.fromContentOptions;
        /**
         * Provided by dataSource
         * @type {?}
         */
        DwAutocompleteComponent.prototype.fromDataSourceOptions;
        /**
         * cdk-overlay
         * @type {?}
         */
        DwAutocompleteComponent.prototype.template;
        /** @type {?} */
        DwAutocompleteComponent.prototype.panel;
        /** @type {?} */
        DwAutocompleteComponent.prototype.content;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.activeItemIndex;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.selectionChangeSubscription;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.optionMouseEnterSubscription;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.dataSourceChangeSubscription;
        /**
         * Options changes listener
         * @type {?}
         */
        DwAutocompleteComponent.prototype.optionSelectionChanges;
        /** @type {?} */
        DwAutocompleteComponent.prototype.optionMouseEnter;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.changeDetectorRef;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteComponent.prototype.ngZone;
        /** @type {?} */
        DwAutocompleteComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: autocomplete-trigger.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_AUTOCOMPLETE_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: core.forwardRef((/**
         * @return {?}
         */
        function () { return DwAutocompleteTriggerDirective; })),
        multi: true
    };
    /**
     * @return {?}
     */
    function getDwAutocompleteMissingPanelError() {
        return Error('Attempting to open an undefined instance of `dw-autocomplete`. ' +
            'Make sure that the id passed to the `dwAutocomplete` is correct and that ' +
            "you're attempting to open it after the ngAfterContentInit hook.");
    }
    var DwAutocompleteTriggerDirective = /** @class */ (function () {
        function DwAutocompleteTriggerDirective(elementRef, overlay, viewContainerRef, dwInputGroupWhitSuffixOrPrefixDirective, document) {
            this.elementRef = elementRef;
            this.overlay = overlay;
            this.viewContainerRef = viewContainerRef;
            this.dwInputGroupWhitSuffixOrPrefixDirective = dwInputGroupWhitSuffixOrPrefixDirective;
            this.document = document;
            this.onChange = (/**
             * @return {?}
             */
            function () { });
            this.onTouched = (/**
             * @return {?}
             */
            function () { });
            this.panelOpen = false;
            this.destroy$ = new rxjs.Subject();
            this.overlayRef = null;
            this.portal = null;
            this.previousValue = null;
        }
        Object.defineProperty(DwAutocompleteTriggerDirective.prototype, "activeOption", {
            /** Current active option */
            get: /**
             * Current active option
             * @return {?}
             */
            function () {
                if (this.dwAutocomplete && this.dwAutocomplete.options.length) {
                    return this.dwAutocomplete.activeItem;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroyPanel();
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            Promise.resolve(null).then((/**
             * @return {?}
             */
            function () { return _this.setTriggerValue(value); }));
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            /** @type {?} */
            var element = this.elementRef.nativeElement;
            element.disabled = isDisabled;
            this.closePanel();
        };
        /**
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.openPanel = /**
         * @return {?}
         */
        function () {
            this.previousValue = this.elementRef.nativeElement.value;
            this.attachOverlay();
            this.updateStatus();
        };
        /**
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.closePanel = /**
         * @return {?}
         */
        function () {
            if (this.panelOpen) {
                this.dwAutocomplete.isOpen = this.panelOpen = false;
                if (this.overlayRef && this.overlayRef.hasAttached()) {
                    this.selectionChangeSubscription.unsubscribe();
                    this.overlayBackdropClickSubscription.unsubscribe();
                    this.optionsChangeSubscription.unsubscribe();
                    this.overlayRef.dispose();
                    this.overlayRef = null;
                    this.portal = null;
                }
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.handleKeydown = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            /** @type {?} */
            var keyCode = event.keyCode;
            /** @type {?} */
            var isArrowKey = keyCode === keycodes.UP_ARROW || keyCode === keycodes.DOWN_ARROW;
            if (keyCode === keycodes.ESCAPE) {
                event.preventDefault();
            }
            if (this.panelOpen && (keyCode === keycodes.ESCAPE || keyCode === keycodes.TAB)) {
                // Reset value when tab / ESC close
                if (this.activeOption && this.activeOption.getLabel() !== this.previousValue) {
                    this.setTriggerValue(this.previousValue);
                }
                this.closePanel();
            }
            else if (this.panelOpen && keyCode === keycodes.ENTER) {
                if (this.dwAutocomplete.showPanel && this.activeOption) {
                    event.preventDefault();
                    this.activeOption.selectViaInteraction();
                }
            }
            else if (this.panelOpen && isArrowKey && this.dwAutocomplete.showPanel) {
                event.stopPropagation();
                event.preventDefault();
                if (keyCode === keycodes.UP_ARROW) {
                    this.dwAutocomplete.setPreviousItemActive();
                }
                else {
                    this.dwAutocomplete.setNextItemActive();
                }
                if (this.activeOption) {
                    this.activeOption.scrollIntoViewIfNeeded();
                }
                this.doBackfill();
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.handleInput = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            /** @type {?} */
            var target = (/** @type {?} */ (event.target));
            /** @type {?} */
            var document = (/** @type {?} */ (this.document));
            /** @type {?} */
            var value = target.value;
            if (target.type === 'number') {
                value = value === '' ? null : parseFloat(value);
            }
            if (this.previousValue !== value) {
                this.previousValue = value;
                this.onChange(value);
                if (this.canOpen() && document.activeElement === event.target) {
                    this.openPanel();
                }
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.handleFocus = /**
         * @return {?}
         */
        function () {
            if (this.canOpen()) {
                this.openPanel();
            }
        };
        /**
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.handleBlur = /**
         * @return {?}
         */
        function () {
            this.onTouched();
        };
        /**
         * Subscription data source changes event
         */
        /**
         * Subscription data source changes event
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.subscribeOptionsChange = /**
         * Subscription data source changes event
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var optionChanges = this.dwAutocomplete.options.changes.pipe(operators.tap((/**
             * @return {?}
             */
            function () { return _this.positionStrategy.reapplyLastPosition(); })), operators.delay(0));
            return optionChanges.subscribe((/**
             * @return {?}
             */
            function () {
                _this.resetActiveItem();
                if (_this.panelOpen) {
                    (/** @type {?} */ (_this.overlayRef)).updatePosition();
                }
            }));
        };
        /**
         * Subscription option changes event and set the value
         */
        /**
         * Subscription option changes event and set the value
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.subscribeSelectionChange = /**
         * Subscription option changes event and set the value
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            return this.dwAutocomplete.selectionChange.subscribe((/**
             * @param {?} option
             * @return {?}
             */
            function (option) {
                _this.setValueAndClose(option);
            }));
        };
        /**
         * Subscription external click and close panel
         */
        /**
         * Subscription external click and close panel
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.subscribeOverlayBackdropClick = /**
         * Subscription external click and close panel
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            return rxjs.merge(rxjs.fromEvent(this.document, 'click'), rxjs.fromEvent(this.document, 'touchend')).subscribe((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                /** @type {?} */
                var clickTarget = (/** @type {?} */ (event.target));
                // Make sure is not self
                if (clickTarget !== _this.elementRef.nativeElement && !(/** @type {?} */ (_this.overlayRef)).overlayElement.contains(clickTarget) && _this.panelOpen) {
                    _this.closePanel();
                }
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.attachOverlay = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            if (!this.dwAutocomplete) {
                throw getDwAutocompleteMissingPanelError();
            }
            if (!this.portal && this.dwAutocomplete.template) {
                this.portal = new portal.TemplatePortal(this.dwAutocomplete.template, this.viewContainerRef);
            }
            if (!this.overlayRef) {
                this.overlayRef = this.overlay.create(this.getOverlayConfig());
            }
            if (this.overlayRef && !this.overlayRef.hasAttached()) {
                this.overlayRef.attach(this.portal);
                this.selectionChangeSubscription = this.subscribeSelectionChange();
                this.overlayBackdropClickSubscription = this.subscribeOverlayBackdropClick();
                this.optionsChangeSubscription = this.subscribeOptionsChange();
                this.overlayRef
                    .detachments()
                    .pipe(operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.closePanel();
                }));
            }
            this.dwAutocomplete.isOpen = this.panelOpen = true;
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.updateStatus = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.overlayRef) {
                this.overlayRef.updateSize({ width: this.dwAutocomplete.dwWidth || this.getHostWidth() });
            }
            this.dwAutocomplete.setVisibility();
            this.resetActiveItem();
            if (this.activeOption) {
                this.activeOption.scrollIntoViewIfNeeded();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.destroyPanel = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.overlayRef) {
                this.closePanel();
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.getOverlayConfig = /**
         * @private
         * @return {?}
         */
        function () {
            return new overlay.OverlayConfig({
                positionStrategy: this.getOverlayPosition(),
                disposeOnNavigation: true,
                scrollStrategy: this.overlay.scrollStrategies.reposition(),
                // default host element width
                width: this.dwAutocomplete.dwWidth || this.getHostWidth()
            });
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.getConnectedElement = /**
         * @private
         * @return {?}
         */
        function () {
            return this.dwInputGroupWhitSuffixOrPrefixDirective ? this.dwInputGroupWhitSuffixOrPrefixDirective.elementRef : this.elementRef;
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.getHostWidth = /**
         * @private
         * @return {?}
         */
        function () {
            return this.getConnectedElement().nativeElement.getBoundingClientRect().width;
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.getOverlayPosition = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var positions = [
                new overlay.ConnectionPositionPair({ originX: 'start', originY: 'bottom' }, { overlayX: 'start', overlayY: 'top' }),
                new overlay.ConnectionPositionPair({ originX: 'start', originY: 'top' }, { overlayX: 'start', overlayY: 'bottom' })
            ];
            this.positionStrategy = this.overlay
                .position()
                .flexibleConnectedTo(this.getConnectedElement())
                .withFlexibleDimensions(false)
                .withPush(false)
                .withPositions(positions)
                .withTransformOriginOn('.ant-select-dropdown');
            return this.positionStrategy;
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.resetActiveItem = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var index = this.dwAutocomplete.getOptionIndex(this.previousValue);
            this.dwAutocomplete.clearSelectedOptions(null, true);
            if (index !== -1) {
                this.dwAutocomplete.setActiveItem(index);
                this.dwAutocomplete.activeItem.select(false);
            }
            else {
                this.dwAutocomplete.setActiveItem(this.dwAutocomplete.dwDefaultActiveFirstOption ? 0 : -1);
            }
        };
        /**
         * @private
         * @param {?} option
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.setValueAndClose = /**
         * @private
         * @param {?} option
         * @return {?}
         */
        function (option) {
            /** @type {?} */
            var value = option.dwValue;
            this.setTriggerValue(option.getLabel());
            this.onChange(value);
            this.elementRef.nativeElement.focus();
            this.closePanel();
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.setTriggerValue = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            /** @type {?} */
            var option = this.dwAutocomplete.getOption(value);
            /** @type {?} */
            var displayValue = option ? option.getLabel() : value;
            this.elementRef.nativeElement.value = displayValue != null ? displayValue : '';
            if (!this.dwAutocomplete.dwBackfill) {
                this.previousValue = displayValue;
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.doBackfill = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.dwAutocomplete.dwBackfill && this.dwAutocomplete.activeItem) {
                this.setTriggerValue(this.dwAutocomplete.activeItem.getLabel());
            }
        };
        /**
         * @private
         * @return {?}
         */
        DwAutocompleteTriggerDirective.prototype.canOpen = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var element = this.elementRef.nativeElement;
            return !element.readOnly && !element.disabled;
        };
        DwAutocompleteTriggerDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: "input[dwAutocomplete], textarea[dwAutocomplete]",
                        exportAs: 'dwAutocompleteTrigger',
                        providers: [DW_AUTOCOMPLETE_VALUE_ACCESSOR],
                        host: {
                            autocomplete: 'off',
                            'aria-autocomplete': 'list',
                            '(focusin)': 'handleFocus()',
                            '(blur)': 'handleBlur()',
                            '(input)': 'handleInput($event)',
                            '(keydown)': 'handleKeydown($event)'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwAutocompleteTriggerDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: overlay.Overlay },
            { type: core.ViewContainerRef },
            { type: input.DwInputGroupWhitSuffixOrPrefixDirective, decorators: [{ type: core.Optional }] },
            { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [common.DOCUMENT,] }] }
        ]; };
        DwAutocompleteTriggerDirective.propDecorators = {
            dwAutocomplete: [{ type: core.Input }]
        };
        return DwAutocompleteTriggerDirective;
    }());
    if (false) {
        /**
         * Bind dwAutocomplete component
         * @type {?}
         */
        DwAutocompleteTriggerDirective.prototype.dwAutocomplete;
        /** @type {?} */
        DwAutocompleteTriggerDirective.prototype.onChange;
        /** @type {?} */
        DwAutocompleteTriggerDirective.prototype.onTouched;
        /** @type {?} */
        DwAutocompleteTriggerDirective.prototype.panelOpen;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.overlayRef;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.portal;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.positionStrategy;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.previousValue;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.selectionChangeSubscription;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.optionsChangeSubscription;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.overlayBackdropClickSubscription;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.overlay;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.viewContainerRef;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.dwInputGroupWhitSuffixOrPrefixDirective;
        /**
         * @type {?}
         * @private
         */
        DwAutocompleteTriggerDirective.prototype.document;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: autocomplete.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwAutocompleteModule = /** @class */ (function () {
        function DwAutocompleteModule() {
        }
        DwAutocompleteModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [DwAutocompleteComponent, DwAutocompleteOptionComponent, DwAutocompleteTriggerDirective, DwAutocompleteOptgroupComponent],
                        exports: [DwAutocompleteComponent, DwAutocompleteOptionComponent, DwAutocompleteTriggerDirective, DwAutocompleteOptgroupComponent],
                        imports: [common.CommonModule, overlay.OverlayModule, forms.FormsModule, outlet.DwOutletModule, noAnimation.DwNoAnimationModule, input.DwInputModule]
                    },] }
        ];
        return DwAutocompleteModule;
    }());

    exports.DW_AUTOCOMPLETE_VALUE_ACCESSOR = DW_AUTOCOMPLETE_VALUE_ACCESSOR;
    exports.DwAutocompleteComponent = DwAutocompleteComponent;
    exports.DwAutocompleteModule = DwAutocompleteModule;
    exports.DwAutocompleteOptgroupComponent = DwAutocompleteOptgroupComponent;
    exports.DwAutocompleteOptionComponent = DwAutocompleteOptionComponent;
    exports.DwAutocompleteTriggerDirective = DwAutocompleteTriggerDirective;
    exports.DwOptionSelectionChange = DwOptionSelectionChange;
    exports.getDwAutocompleteMissingPanelError = getDwAutocompleteMissingPanelError;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-auto-complete.umd.js.map
