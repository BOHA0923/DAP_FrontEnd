(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/portal'), require('@angular/core'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/config'), require('ng-quicksilver/i18n'), require('@angular/common'), require('ng-quicksilver/core/outlet')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/empty', ['exports', '@angular/cdk/portal', '@angular/core', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/config', 'ng-quicksilver/i18n', '@angular/common', 'ng-quicksilver/core/outlet'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].empty = {}), global.ng.cdk.portal, global.ng.core, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core.config, global['ng-quicksilver'].i18n, global.ng.common, global['ng-quicksilver'].core.outlet));
}(this, (function (exports, portal, core, rxjs, operators, config, i18n, common, outlet) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: config.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_EMPTY_COMPONENT_NAME = new core.InjectionToken('dw-empty-component-name');

    /**
     * @fileoverview added by tsickle
     * Generated from: embed-empty.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} componentName
     * @return {?}
     */
    function getEmptySize(componentName) {
        switch (componentName) {
            case 'table':
            case 'list':
                return 'normal';
            case 'select':
            case 'tree-select':
            case 'cascader':
            case 'transfer':
                return 'small';
            default:
                return '';
        }
    }
    var DwEmbedEmptyComponent = /** @class */ (function () {
        function DwEmbedEmptyComponent(configService, viewContainerRef, cdr, injector) {
            this.configService = configService;
            this.viewContainerRef = viewContainerRef;
            this.cdr = cdr;
            this.injector = injector;
            this.contentType = 'string';
            this.size = '';
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwComponentName) {
                this.size = getEmptySize(changes.dwComponentName.currentValue);
            }
            if (changes.specificContent && !changes.specificContent.isFirstChange()) {
                this.content = changes.specificContent.currentValue;
                this.renderEmpty();
            }
        };
        /**
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.subscribeDefaultEmptyContentChange();
        };
        /**
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @private
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.renderEmpty = /**
         * @private
         * @return {?}
         */
        function () {
            /** @type {?} */
            var content = this.content;
            if (typeof content === 'string') {
                this.contentType = 'string';
            }
            else if (content instanceof core.TemplateRef) {
                /** @type {?} */
                var context = (/** @type {?} */ ({ $implicit: this.dwComponentName }));
                this.contentType = 'template';
                this.contentPortal = new portal.TemplatePortal(content, this.viewContainerRef, context);
            }
            else if (content instanceof core.Type) {
                /** @type {?} */
                var context = new WeakMap([[DW_EMPTY_COMPONENT_NAME, this.dwComponentName]]);
                /** @type {?} */
                var injector = new portal.PortalInjector(this.injector, context);
                this.contentType = 'component';
                this.contentPortal = new portal.ComponentPortal(content, this.viewContainerRef, injector);
            }
            else {
                this.contentType = 'string';
                this.contentPortal = undefined;
            }
            this.cdr.detectChanges();
        };
        /**
         * @private
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.subscribeDefaultEmptyContentChange = /**
         * @private
         * @return {?}
         */
        function () {
            var _this = this;
            this.configService
                .getConfigChangeEventForComponent('empty')
                .pipe(operators.startWith(true), operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @return {?}
             */
            function () {
                _this.content = _this.specificContent || _this.getUserDefaultEmptyContent();
                _this.renderEmpty();
            }));
        };
        /**
         * @private
         * @return {?}
         */
        DwEmbedEmptyComponent.prototype.getUserDefaultEmptyContent = /**
         * @private
         * @return {?}
         */
        function () {
            return (this.configService.getConfigForComponent('empty') || {}).dwDefaultEmptyContent;
        };
        DwEmbedEmptyComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-embed-empty',
                        exportAs: 'dwEmbedEmpty',
                        template: "\n    <ng-container *ngIf=\"!content && specificContent !== null\" [ngSwitch]=\"size\">\n      <dw-empty *ngSwitchCase=\"'normal'\" class=\"ant-empty-normal\" [dwNotFoundImage]=\"'simple'\"></dw-empty>\n      <dw-empty *ngSwitchCase=\"'small'\" class=\"ant-empty-small\" [dwNotFoundImage]=\"'simple'\"></dw-empty>\n      <dw-empty *ngSwitchDefault></dw-empty>\n    </ng-container>\n    <ng-container *ngIf=\"content\">\n      <ng-template *ngIf=\"contentType !== 'string'\" [cdkPortalOutlet]=\"contentPortal\"></ng-template>\n      <ng-container *ngIf=\"contentType === 'string'\">\n        {{ content }}\n      </ng-container>\n    </ng-container>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwEmbedEmptyComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: core.ViewContainerRef },
            { type: core.ChangeDetectorRef },
            { type: core.Injector }
        ]; };
        DwEmbedEmptyComponent.propDecorators = {
            dwComponentName: [{ type: core.Input }],
            specificContent: [{ type: core.Input }]
        };
        return DwEmbedEmptyComponent;
    }());
    if (false) {
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.dwComponentName;
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.specificContent;
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.content;
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.contentType;
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.contentPortal;
        /** @type {?} */
        DwEmbedEmptyComponent.prototype.size;
        /**
         * @type {?}
         * @private
         */
        DwEmbedEmptyComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwEmbedEmptyComponent.prototype.configService;
        /**
         * @type {?}
         * @private
         */
        DwEmbedEmptyComponent.prototype.viewContainerRef;
        /**
         * @type {?}
         * @private
         */
        DwEmbedEmptyComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwEmbedEmptyComponent.prototype.injector;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: empty.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DwEmptyDefaultImages = (/** @type {?} */ (['default', 'simple']));
    var DwEmptyComponent = /** @class */ (function () {
        function DwEmptyComponent(i18n, cdr) {
            this.i18n = i18n;
            this.cdr = cdr;
            this.dwNotFoundImage = 'default';
            this.isContentString = false;
            this.isImageBuildIn = true;
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwEmptyComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwNotFoundContent = changes.dwNotFoundContent, dwNotFoundImage = changes.dwNotFoundImage;
            if (dwNotFoundContent) {
                /** @type {?} */
                var content = dwNotFoundContent.currentValue;
                this.isContentString = typeof content === 'string';
            }
            if (dwNotFoundImage) {
                /** @type {?} */
                var image_1 = dwNotFoundImage.currentValue || 'default';
                this.isImageBuildIn = DwEmptyDefaultImages.findIndex((/**
                 * @param {?} i
                 * @return {?}
                 */
                function (i) { return i === image_1; })) > -1;
            }
        };
        /**
         * @return {?}
         */
        DwEmptyComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.i18n.localeChange.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.locale = _this.i18n.getLocaleData('Empty');
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @return {?}
         */
        DwEmptyComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwEmptyComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-empty',
                        exportAs: 'dwEmpty',
                        template: "\n    <div class=\"ant-empty-image\">\n      <ng-container *ngIf=\"!isImageBuildIn\">\n        <ng-container *dwStringTemplateOutlet=\"dwNotFoundImage\">\n          <img [src]=\"dwNotFoundImage\" [alt]=\"isContentString ? dwNotFoundContent : 'empty'\" />\n        </ng-container>\n      </ng-container>\n      <dw-empty-default *ngIf=\"isImageBuildIn && dwNotFoundImage !== 'simple'\"></dw-empty-default>\n      <dw-empty-simple *ngIf=\"isImageBuildIn && dwNotFoundImage === 'simple'\"></dw-empty-simple>\n    </div>\n    <p class=\"ant-empty-description\" *ngIf=\"dwNotFoundContent !== null\">\n      <ng-container *dwStringTemplateOutlet=\"dwNotFoundContent\">\n        {{ isContentString ? dwNotFoundContent : locale['description'] }}\n      </ng-container>\n    </p>\n    <div class=\"ant-empty-footer\" *ngIf=\"dwNotFoundFooter\">\n      <ng-container *dwStringTemplateOutlet=\"dwNotFoundFooter\">\n        {{ dwNotFoundFooter }}\n      </ng-container>\n    </div>\n  ",
                        host: {
                            class: 'ant-empty'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwEmptyComponent.ctorParameters = function () { return [
            { type: i18n.DwI18nService },
            { type: core.ChangeDetectorRef }
        ]; };
        DwEmptyComponent.propDecorators = {
            dwNotFoundImage: [{ type: core.Input }],
            dwNotFoundContent: [{ type: core.Input }],
            dwNotFoundFooter: [{ type: core.Input }]
        };
        return DwEmptyComponent;
    }());
    if (false) {
        /** @type {?} */
        DwEmptyComponent.prototype.dwNotFoundImage;
        /** @type {?} */
        DwEmptyComponent.prototype.dwNotFoundContent;
        /** @type {?} */
        DwEmptyComponent.prototype.dwNotFoundFooter;
        /** @type {?} */
        DwEmptyComponent.prototype.isContentString;
        /** @type {?} */
        DwEmptyComponent.prototype.isImageBuildIn;
        /** @type {?} */
        DwEmptyComponent.prototype.locale;
        /**
         * @type {?}
         * @private
         */
        DwEmptyComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwEmptyComponent.prototype.i18n;
        /**
         * @type {?}
         * @private
         */
        DwEmptyComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: partial/default.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwEmptyDefaultComponent = /** @class */ (function () {
        function DwEmptyDefaultComponent() {
        }
        DwEmptyDefaultComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-empty-default',
                        exportAs: 'dwEmptyDefault',
                        template: "\n    <svg class=\"ant-empty-img-default\" width=\"184\" height=\"152\" viewBox=\"0 0 184 152\" xmlns=\"http://www.w3.org/2000/svg\">\n      <g fill=\"none\" fill-rule=\"evenodd\">\n        <g transform=\"translate(24 31.67)\">\n          <ellipse class=\"ant-empty-img-default-ellipse\" cx=\"67.797\" cy=\"106.89\" rx=\"67.797\" ry=\"12.668\" />\n          <path\n            class=\"ant-empty-img-default-path-1\"\n            d=\"M122.034 69.674L98.109 40.229c-1.148-1.386-2.826-2.225-4.593-2.225h-51.44c-1.766 0-3.444.839-4.592 2.225L13.56 69.674v15.383h108.475V69.674z\"\n          />\n          <path\n            class=\"ant-empty-img-default-path-2\"\n            d=\"M101.537 86.214L80.63 61.102c-1.001-1.207-2.507-1.867-4.048-1.867H31.724c-1.54 0-3.047.66-4.048 1.867L6.769 86.214v13.792h94.768V86.214z\"\n            transform=\"translate(13.56)\"\n          />\n          <path\n            class=\"ant-empty-img-default-path-3\"\n            d=\"M33.83 0h67.933a4 4 0 0 1 4 4v93.344a4 4 0 0 1-4 4H33.83a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4z\"\n          />\n          <path\n            class=\"ant-empty-img-default-path-4\"\n            d=\"M42.678 9.953h50.237a2 2 0 0 1 2 2V36.91a2 2 0 0 1-2 2H42.678a2 2 0 0 1-2-2V11.953a2 2 0 0 1 2-2zM42.94 49.767h49.713a2.262 2.262 0 1 1 0 4.524H42.94a2.262 2.262 0 0 1 0-4.524zM42.94 61.53h49.713a2.262 2.262 0 1 1 0 4.525H42.94a2.262 2.262 0 0 1 0-4.525zM121.813 105.032c-.775 3.071-3.497 5.36-6.735 5.36H20.515c-3.238 0-5.96-2.29-6.734-5.36a7.309 7.309 0 0 1-.222-1.79V69.675h26.318c2.907 0 5.25 2.448 5.25 5.42v.04c0 2.971 2.37 5.37 5.277 5.37h34.785c2.907 0 5.277-2.421 5.277-5.393V75.1c0-2.972 2.343-5.426 5.25-5.426h26.318v33.569c0 .617-.077 1.216-.221 1.789z\"\n          />\n        </g>\n        <path\n          class=\"ant-empty-img-default-path-5\"\n          d=\"M149.121 33.292l-6.83 2.65a1 1 0 0 1-1.317-1.23l1.937-6.207c-2.589-2.944-4.109-6.534-4.109-10.408C138.802 8.102 148.92 0 161.402 0 173.881 0 184 8.102 184 18.097c0 9.995-10.118 18.097-22.599 18.097-4.528 0-8.744-1.066-12.28-2.902z\"\n        />\n        <g class=\"ant-empty-img-default-g\" transform=\"translate(149.65 15.383)\">\n          <ellipse cx=\"20.654\" cy=\"3.167\" rx=\"2.849\" ry=\"2.815\" />\n          <path d=\"M5.698 5.63H0L2.898.704zM9.259.704h4.985V5.63H9.259z\" />\n        </g>\n      </g>\n    </svg>\n  "
                    }] }
        ];
        return DwEmptyDefaultComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: partial/simple.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwEmptySimpleComponent = /** @class */ (function () {
        function DwEmptySimpleComponent() {
        }
        DwEmptySimpleComponent.decorators = [
            { type: core.Component, args: [{
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        selector: 'dw-empty-simple',
                        exportAs: 'dwEmptySimple',
                        template: "\n    <svg class=\"ant-empty-img-simple\" width=\"64\" height=\"41\" viewBox=\"0 0 64 41\" xmlns=\"http://www.w3.org/2000/svg\">\n      <g transform=\"translate(0 1)\" fill=\"none\" fill-rule=\"evenodd\">\n        <ellipse class=\"ant-empty-img-simple-ellipse\" cx=\"32\" cy=\"33\" rx=\"32\" ry=\"7\" />\n        <g class=\"ant-empty-img-simple-g\" fill-rule=\"nonzero\">\n          <path d=\"M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z\" />\n          <path\n            d=\"M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z\"\n            class=\"ant-empty-img-simple-path\"\n          />\n        </g>\n      </g>\n    </svg>\n  "
                    }] }
        ];
        return DwEmptySimpleComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: empty.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwEmptyModule = /** @class */ (function () {
        function DwEmptyModule() {
        }
        DwEmptyModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, portal.PortalModule, outlet.DwOutletModule, i18n.DwI18nModule],
                        declarations: [DwEmptyComponent, DwEmbedEmptyComponent, DwEmptyDefaultComponent, DwEmptySimpleComponent],
                        exports: [DwEmptyComponent, DwEmbedEmptyComponent]
                    },] }
        ];
        return DwEmptyModule;
    }());

    exports.DW_EMPTY_COMPONENT_NAME = DW_EMPTY_COMPONENT_NAME;
    exports.DwEmbedEmptyComponent = DwEmbedEmptyComponent;
    exports.DwEmptyComponent = DwEmptyComponent;
    exports.DwEmptyDefaultComponent = DwEmptyDefaultComponent;
    exports.DwEmptyModule = DwEmptyModule;
    exports.DwEmptySimpleComponent = DwEmptySimpleComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-empty.umd.js.map
