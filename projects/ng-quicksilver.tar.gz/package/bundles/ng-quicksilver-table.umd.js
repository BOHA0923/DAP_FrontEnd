(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/platform'), require('@angular/cdk/scrolling'), require('@angular/common'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/button'), require('ng-quicksilver/checkbox'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/resize-observers'), require('ng-quicksilver/dropdown'), require('ng-quicksilver/empty'), require('ng-quicksilver/i18n'), require('ng-quicksilver/icon'), require('ng-quicksilver/menu'), require('ng-quicksilver/pagination'), require('ng-quicksilver/radio'), require('ng-quicksilver/spin'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/util'), require('ng-quicksilver/core/logger'), require('ng-quicksilver/core/services'), require('ng-quicksilver/core/config')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/table', ['exports', '@angular/cdk/platform', '@angular/cdk/scrolling', '@angular/common', '@angular/core', '@angular/forms', 'ng-quicksilver/button', 'ng-quicksilver/checkbox', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/resize-observers', 'ng-quicksilver/dropdown', 'ng-quicksilver/empty', 'ng-quicksilver/i18n', 'ng-quicksilver/icon', 'ng-quicksilver/menu', 'ng-quicksilver/pagination', 'ng-quicksilver/radio', 'ng-quicksilver/spin', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/util', 'ng-quicksilver/core/logger', 'ng-quicksilver/core/services', 'ng-quicksilver/core/config'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].table = {}), global.ng.cdk.platform, global.ng.cdk.scrolling, global.ng.common, global.ng.core, global.ng.forms, global['ng-quicksilver'].button, global['ng-quicksilver'].checkbox, global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core['resize-observers'], global['ng-quicksilver'].dropdown, global['ng-quicksilver'].empty, global['ng-quicksilver'].i18n, global['ng-quicksilver'].icon, global['ng-quicksilver'].menu, global['ng-quicksilver'].pagination, global['ng-quicksilver'].radio, global['ng-quicksilver'].spin, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core.util, global['ng-quicksilver'].core.logger, global['ng-quicksilver'].core.services, global['ng-quicksilver'].core.config));
}(this, (function (exports, platform, scrolling, common, core, forms, button, checkbox, outlet, resizeObservers, dropdown, empty, i18n, icon, menu, pagination, radio, spin, rxjs, operators, util, logger, services, config) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/filter-trigger.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwFilterTriggerComponent = /** @class */ (function () {
        function DwFilterTriggerComponent(cdr) {
            this.cdr = cdr;
            this.dwActive = false;
            this.dwVisible = false;
            this.dwVisibleChange = new core.EventEmitter();
        }
        /**
         * @param {?} visible
         * @return {?}
         */
        DwFilterTriggerComponent.prototype.onVisibleChange = /**
         * @param {?} visible
         * @return {?}
         */
        function (visible) {
            this.dwVisible = visible;
            this.dwVisibleChange.next(visible);
        };
        /**
         * @param {?} $event
         * @return {?}
         */
        DwFilterTriggerComponent.prototype.onFilterClick = /**
         * @param {?} $event
         * @return {?}
         */
        function ($event) {
            $event.stopPropagation();
        };
        /**
         * @return {?}
         */
        DwFilterTriggerComponent.prototype.hide = /**
         * @return {?}
         */
        function () {
            this.dwVisible = false;
            this.cdr.markForCheck();
        };
        /**
         * @return {?}
         */
        DwFilterTriggerComponent.prototype.show = /**
         * @return {?}
         */
        function () {
            this.dwVisible = true;
            this.cdr.markForCheck();
        };
        DwFilterTriggerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-filter-trigger',
                        exportAs: "dwFilterTrigger",
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <span\n      dw-dropdown\n      class=\"ant-table-filter-trigger\"\n      dwTrigger=\"click\"\n      dwPlacement=\"bottomRight\"\n      [dwClickHide]=\"false\"\n      [dwDropdownMenu]=\"dwDropdownMenu\"\n      [class.active]=\"dwActive\"\n      [class.ant-table-filter-open]=\"dwVisible\"\n      [dwVisible]=\"dwVisible\"\n      (dwVisibleChange)=\"onVisibleChange($event)\"\n      (click)=\"onFilterClick($event)\"\n    >\n      <ng-content></ng-content>\n    </span>\n  ",
                        host: {
                            '[class.ant-table-filter-trigger-container]': 'true',
                            '[class.ant-table-filter-trigger-container-open]': 'dwVisible'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwFilterTriggerComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef }
        ]; };
        DwFilterTriggerComponent.propDecorators = {
            dwActive: [{ type: core.Input }],
            dwDropdownMenu: [{ type: core.Input }],
            dwVisible: [{ type: core.Input }],
            dwVisibleChange: [{ type: core.Output }]
        };
        return DwFilterTriggerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwFilterTriggerComponent.prototype.dwActive;
        /** @type {?} */
        DwFilterTriggerComponent.prototype.dwDropdownMenu;
        /** @type {?} */
        DwFilterTriggerComponent.prototype.dwVisible;
        /** @type {?} */
        DwFilterTriggerComponent.prototype.dwVisibleChange;
        /**
         * @type {?}
         * @private
         */
        DwFilterTriggerComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/filter.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function DwThItemInterface() { }
    if (false) {
        /** @type {?} */
        DwThItemInterface.prototype.text;
        /** @type {?} */
        DwThItemInterface.prototype.value;
        /** @type {?} */
        DwThItemInterface.prototype.checked;
    }
    var DwTableFilterComponent = /** @class */ (function () {
        function DwTableFilterComponent(cdr, i18n) {
            this.cdr = cdr;
            this.i18n = i18n;
            this.contentTemplate = null;
            this.customFilter = false;
            this.extraTemplate = null;
            this.filterMultiple = true;
            this.listOfFilter = [];
            this.filterChange = new core.EventEmitter();
            this.destroy$ = new rxjs.Subject();
            this.isChanged = false;
            this.isChecked = false;
            this.isVisible = false;
            this.listOfParsedFilter = [];
        }
        /**
         * @param {?} _
         * @param {?} item
         * @return {?}
         */
        DwTableFilterComponent.prototype.trackByValue = /**
         * @param {?} _
         * @param {?} item
         * @return {?}
         */
        function (_, item) {
            return item.value;
        };
        /**
         * @param {?} filter
         * @return {?}
         */
        DwTableFilterComponent.prototype.check = /**
         * @param {?} filter
         * @return {?}
         */
        function (filter) {
            this.isChanged = true;
            if (this.filterMultiple) {
                this.listOfParsedFilter = this.listOfParsedFilter.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    if (item === filter) {
                        return __assign(__assign({}, item), { checked: !filter.checked });
                    }
                    else {
                        return item;
                    }
                }));
                filter.checked = !filter.checked;
            }
            else {
                this.listOfParsedFilter = this.listOfParsedFilter.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    return __assign(__assign({}, item), { checked: item === filter });
                }));
            }
            this.isChecked = this.getCheckedStatus(this.listOfParsedFilter);
        };
        /**
         * @return {?}
         */
        DwTableFilterComponent.prototype.confirm = /**
         * @return {?}
         */
        function () {
            this.isVisible = false;
            this.emitFilterData();
        };
        /**
         * @return {?}
         */
        DwTableFilterComponent.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.isChanged = true;
            this.isVisible = false;
            this.listOfParsedFilter = this.parseListOfFilter(this.listOfFilter, true);
            this.isChecked = this.getCheckedStatus(this.listOfParsedFilter);
            this.emitFilterData();
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTableFilterComponent.prototype.onVisibleChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.isVisible = value;
            if (!value) {
                this.emitFilterData();
            }
        };
        /**
         * @return {?}
         */
        DwTableFilterComponent.prototype.emitFilterData = /**
         * @return {?}
         */
        function () {
            if (this.isChanged) {
                /** @type {?} */
                var listOfChecked = this.listOfParsedFilter.filter((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.checked; })).map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.value; }));
                if (this.filterMultiple) {
                    this.filterChange.emit(listOfChecked);
                }
                else {
                    this.filterChange.emit(listOfChecked.length > 0 ? listOfChecked[0] : null);
                }
                this.isChanged = false;
            }
        };
        /**
         * @param {?} listOfFilter
         * @param {?=} reset
         * @return {?}
         */
        DwTableFilterComponent.prototype.parseListOfFilter = /**
         * @param {?} listOfFilter
         * @param {?=} reset
         * @return {?}
         */
        function (listOfFilter, reset) {
            return listOfFilter.map((/**
             * @param {?} item
             * @return {?}
             */
            function (item) {
                /** @type {?} */
                var checked = reset ? false : !!item.byDefault;
                return { text: item.text, value: item.value, checked: checked };
            }));
        };
        /**
         * @param {?} listOfParsedFilter
         * @return {?}
         */
        DwTableFilterComponent.prototype.getCheckedStatus = /**
         * @param {?} listOfParsedFilter
         * @return {?}
         */
        function (listOfParsedFilter) {
            return listOfParsedFilter.some((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.checked; }));
        };
        /**
         * @return {?}
         */
        DwTableFilterComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.i18n.localeChange.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.locale = _this.i18n.getLocaleData('Table');
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTableFilterComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var listOfFilter = changes.listOfFilter;
            if (listOfFilter && this.listOfFilter && this.listOfFilter.length) {
                this.listOfParsedFilter = this.parseListOfFilter(this.listOfFilter);
                this.isChecked = this.getCheckedStatus(this.listOfParsedFilter);
            }
        };
        /**
         * @return {?}
         */
        DwTableFilterComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTableFilterComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-filter',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <span class=\"ant-table-filter-column-title\">\n      <ng-template [ngTemplateOutlet]=\"contentTemplate\"></ng-template>\n    </span>\n    <ng-container *ngIf=\"!customFilter; else extraTemplate\">\n      <dw-filter-trigger\n        [dwVisible]=\"isVisible\"\n        [dwActive]=\"isChecked\"\n        [dwDropdownMenu]=\"filterMenu\"\n        (dwVisibleChange)=\"onVisibleChange($event)\"\n      >\n        <i dw-icon dwType=\"filter\" dwTheme=\"fill\"></i>\n      </dw-filter-trigger>\n      <dw-dropdown-menu #filterMenu=\"dwDropdownMenu\">\n        <div class=\"ant-table-filter-dropdown\">\n          <ul dw-menu>\n            <li dw-menu-item [dwSelected]=\"f.checked\" *ngFor=\"let f of listOfParsedFilter; trackBy: trackByValue\" (click)=\"check(f)\">\n              <label dw-radio *ngIf=\"!filterMultiple\" [ngModel]=\"f.checked\" (ngModelChange)=\"check(f)\"></label>\n              <label dw-checkbox *ngIf=\"filterMultiple\" [ngModel]=\"f.checked\" (ngModelChange)=\"check(f)\"></label>\n              <span>{{ f.text }}</span>\n            </li>\n          </ul>\n          <div class=\"ant-table-filter-dropdown-btns\">\n            <button dw-button dwType=\"link\" dwSize=\"small\" (click)=\"reset()\" [disabled]=\"!isChecked\">{{ locale.filterReset }}</button>\n            <button dw-button dwType=\"primary\" dwSize=\"small\" (click)=\"confirm()\">{{ locale.filterConfirm }}</button>\n          </div>\n        </div>\n      </dw-dropdown-menu>\n    </ng-container>\n  ",
                        host: {
                            '[class.ant-table-filter-column]': 'true'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTableFilterComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: i18n.DwI18nService }
        ]; };
        DwTableFilterComponent.propDecorators = {
            contentTemplate: [{ type: core.Input }],
            customFilter: [{ type: core.Input }],
            extraTemplate: [{ type: core.Input }],
            filterMultiple: [{ type: core.Input }],
            listOfFilter: [{ type: core.Input }],
            filterChange: [{ type: core.Output }]
        };
        return DwTableFilterComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableFilterComponent.prototype.contentTemplate;
        /** @type {?} */
        DwTableFilterComponent.prototype.customFilter;
        /** @type {?} */
        DwTableFilterComponent.prototype.extraTemplate;
        /** @type {?} */
        DwTableFilterComponent.prototype.filterMultiple;
        /** @type {?} */
        DwTableFilterComponent.prototype.listOfFilter;
        /** @type {?} */
        DwTableFilterComponent.prototype.filterChange;
        /**
         * @type {?}
         * @private
         */
        DwTableFilterComponent.prototype.destroy$;
        /** @type {?} */
        DwTableFilterComponent.prototype.locale;
        /** @type {?} */
        DwTableFilterComponent.prototype.isChanged;
        /** @type {?} */
        DwTableFilterComponent.prototype.isChecked;
        /** @type {?} */
        DwTableFilterComponent.prototype.isVisible;
        /** @type {?} */
        DwTableFilterComponent.prototype.listOfParsedFilter;
        /**
         * @type {?}
         * @private
         */
        DwTableFilterComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwTableFilterComponent.prototype.i18n;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/row-expand-button.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwRowExpandButtonDirective = /** @class */ (function () {
        function DwRowExpandButtonDirective() {
            this.expand = false;
            this.spaceMode = false;
            this.expandChange = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        DwRowExpandButtonDirective.prototype.onHostClick = /**
         * @return {?}
         */
        function () {
            if (!this.spaceMode) {
                this.expand = !this.expand;
                this.expandChange.next(this.expand);
            }
        };
        DwRowExpandButtonDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'button[dw-row-expand-button]',
                        host: {
                            '[type]': "'button'",
                            '[class.ant-table-row-expand-icon]': 'true',
                            '[class.ant-table-row-expand-icon-expanded]': "!spaceMode && expand === true",
                            '[class.ant-table-row-expand-icon-collapsed]': "!spaceMode && expand === false",
                            '[class.ant-table-row-expand-icon-spaced]': 'spaceMode',
                            '(click)': 'onHostClick()'
                        }
                    },] }
        ];
        DwRowExpandButtonDirective.propDecorators = {
            expand: [{ type: core.Input }],
            spaceMode: [{ type: core.Input }],
            expandChange: [{ type: core.Output }]
        };
        return DwRowExpandButtonDirective;
    }());
    if (false) {
        /** @type {?} */
        DwRowExpandButtonDirective.prototype.expand;
        /** @type {?} */
        DwRowExpandButtonDirective.prototype.spaceMode;
        /** @type {?} */
        DwRowExpandButtonDirective.prototype.expandChange;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/row-indent.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwRowIndentDirective = /** @class */ (function () {
        function DwRowIndentDirective() {
            this.indentSize = 0;
        }
        DwRowIndentDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-row-indent',
                        host: {
                            '[class.ant-table-row-indent]': 'true',
                            '[style.padding-left.px]': 'indentSize'
                        }
                    },] }
        ];
        DwRowIndentDirective.propDecorators = {
            indentSize: [{ type: core.Input }]
        };
        return DwRowIndentDirective;
    }());
    if (false) {
        /** @type {?} */
        DwRowIndentDirective.prototype.indentSize;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/selection.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableSelectionComponent = /** @class */ (function () {
        function DwTableSelectionComponent() {
            this.listOfSelections = [];
            this.checked = false;
            this.disabled = false;
            this.indeterminate = false;
            this.showCheckbox = false;
            this.showRowSelection = false;
            this.checkedChange = new core.EventEmitter();
        }
        /**
         * @param {?} checked
         * @return {?}
         */
        DwTableSelectionComponent.prototype.onCheckedChange = /**
         * @param {?} checked
         * @return {?}
         */
        function (checked) {
            this.checked = checked;
            this.checkedChange.emit(checked);
        };
        DwTableSelectionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-selection',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <label\n      *ngIf=\"showCheckbox\"\n      dw-checkbox\n      [class.ant-table-selection-select-all-custom]=\"showRowSelection\"\n      [ngModel]=\"checked\"\n      [dwDisabled]=\"disabled\"\n      [dwIndeterminate]=\"indeterminate\"\n      (ngModelChange)=\"onCheckedChange($event)\"\n    >\n    </label>\n    <div class=\"ant-table-selection-extra\" *ngIf=\"showRowSelection\">\n      <span dw-dropdown class=\"ant-table-selection-down\" dwPlacement=\"bottomLeft\" [dwDropdownMenu]=\"selectionMenu\">\n        <i dw-icon dwType=\"down\"></i>\n      </span>\n      <dw-dropdown-menu #selectionMenu=\"dwDropdownMenu\">\n        <ul dw-menu class=\"ant-table-selection-menu\">\n          <li dw-menu-item *ngFor=\"let selection of listOfSelections\" (click)=\"selection.onSelect()\">\n            {{ selection.text }}\n          </li>\n        </ul>\n      </dw-dropdown-menu>\n    </div>\n  ",
                        host: {
                            '[class.ant-table-selection]': 'true'
                        }
                    }] }
        ];
        DwTableSelectionComponent.propDecorators = {
            listOfSelections: [{ type: core.Input }],
            checked: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            indeterminate: [{ type: core.Input }],
            showCheckbox: [{ type: core.Input }],
            showRowSelection: [{ type: core.Input }],
            checkedChange: [{ type: core.Output }]
        };
        return DwTableSelectionComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableSelectionComponent.prototype.listOfSelections;
        /** @type {?} */
        DwTableSelectionComponent.prototype.checked;
        /** @type {?} */
        DwTableSelectionComponent.prototype.disabled;
        /** @type {?} */
        DwTableSelectionComponent.prototype.indeterminate;
        /** @type {?} */
        DwTableSelectionComponent.prototype.showCheckbox;
        /** @type {?} */
        DwTableSelectionComponent.prototype.showRowSelection;
        /** @type {?} */
        DwTableSelectionComponent.prototype.checkedChange;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/addon/sorters.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableSortersComponent = /** @class */ (function () {
        function DwTableSortersComponent() {
            this.sortDirections = ['ascend', 'descend', null];
            this.sortOrder = null;
            this.contentTemplate = null;
            this.isUp = false;
            this.isDown = false;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTableSortersComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var sortDirections = changes.sortDirections;
            if (sortDirections) {
                this.isUp = this.sortDirections.indexOf('ascend') !== -1;
                this.isDown = this.sortDirections.indexOf('descend') !== -1;
            }
        };
        DwTableSortersComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-sorters',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <span><ng-template [ngTemplateOutlet]=\"contentTemplate\"></ng-template></span>\n    <span class=\"ant-table-column-sorter\" [class.ant-table-column-sorter-full]=\"isDown && isUp\">\n      <span class=\"ant-table-column-sorter-inner\">\n        <i dw-icon dwType=\"caret-up\" *ngIf=\"isUp\" class=\"ant-table-column-sorter-up\" [class.active]=\"sortOrder == 'ascend'\"></i>\n        <i dw-icon dwType=\"caret-down\" *ngIf=\"isDown\" class=\"ant-table-column-sorter-down\" [class.active]=\"sortOrder == 'descend'\"></i>\n      </span>\n    </span>\n  ",
                        host: {
                            '[class.ant-table-column-sorters]': 'true'
                        }
                    }] }
        ];
        DwTableSortersComponent.propDecorators = {
            sortDirections: [{ type: core.Input }],
            sortOrder: [{ type: core.Input }],
            contentTemplate: [{ type: core.Input }]
        };
        return DwTableSortersComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableSortersComponent.prototype.sortDirections;
        /** @type {?} */
        DwTableSortersComponent.prototype.sortOrder;
        /** @type {?} */
        DwTableSortersComponent.prototype.contentTemplate;
        /** @type {?} */
        DwTableSortersComponent.prototype.isUp;
        /** @type {?} */
        DwTableSortersComponent.prototype.isDown;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/cell-fixed.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwCellFixedDirective = /** @class */ (function () {
        function DwCellFixedDirective(renderer, elementRef) {
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.dwRight = false;
            this.dwLeft = false;
            this.colspan = null;
            this.colSpan = null;
            this.changes$ = new rxjs.Subject();
            this.isAutoLeft = false;
            this.isAutoRight = false;
            this.isFixedLeft = false;
            this.isFixedRight = false;
            this.isFixed = false;
        }
        /**
         * @param {?} autoLeft
         * @return {?}
         */
        DwCellFixedDirective.prototype.setAutoLeftWidth = /**
         * @param {?} autoLeft
         * @return {?}
         */
        function (autoLeft) {
            this.renderer.setStyle(this.elementRef.nativeElement, 'left', autoLeft);
        };
        /**
         * @param {?} autoRight
         * @return {?}
         */
        DwCellFixedDirective.prototype.setAutoRightWidth = /**
         * @param {?} autoRight
         * @return {?}
         */
        function (autoRight) {
            this.renderer.setStyle(this.elementRef.nativeElement, 'right', autoRight);
        };
        /**
         * @param {?} isFirstRight
         * @return {?}
         */
        DwCellFixedDirective.prototype.setIsFirstRight = /**
         * @param {?} isFirstRight
         * @return {?}
         */
        function (isFirstRight) {
            this.setFixClass(isFirstRight, 'ant-table-cell-fix-right-first');
        };
        /**
         * @param {?} isLastLeft
         * @return {?}
         */
        DwCellFixedDirective.prototype.setIsLastLeft = /**
         * @param {?} isLastLeft
         * @return {?}
         */
        function (isLastLeft) {
            this.setFixClass(isLastLeft, 'ant-table-cell-fix-left-last');
        };
        /**
         * @private
         * @param {?} flag
         * @param {?} className
         * @return {?}
         */
        DwCellFixedDirective.prototype.setFixClass = /**
         * @private
         * @param {?} flag
         * @param {?} className
         * @return {?}
         */
        function (flag, className) {
            // the setFixClass function may call many times, so remove it first.
            this.renderer.removeClass(this.elementRef.nativeElement, className);
            if (flag) {
                this.renderer.addClass(this.elementRef.nativeElement, className);
            }
        };
        /**
         * @return {?}
         */
        DwCellFixedDirective.prototype.ngOnChanges = /**
         * @return {?}
         */
        function () {
            this.setIsFirstRight(false);
            this.setIsLastLeft(false);
            this.isAutoLeft = this.dwLeft === '' || this.dwLeft === true;
            this.isAutoRight = this.dwRight === '' || this.dwRight === true;
            this.isFixedLeft = this.dwLeft !== false;
            this.isFixedRight = this.dwRight !== false;
            this.isFixed = this.isFixedLeft || this.isFixedRight;
            /** @type {?} */
            var validatePx = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (typeof value === 'string' && value !== '') {
                    return value;
                }
                else {
                    return null;
                }
            });
            this.setAutoLeftWidth(validatePx(this.dwLeft));
            this.setAutoRightWidth(validatePx(this.dwRight));
            this.changes$.next();
        };
        DwCellFixedDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'td[dwRight],th[dwRight],td[dwLeft],th[dwLeft]',
                        host: {
                            '[class.ant-table-cell-fix-right]': "isFixedRight",
                            '[class.ant-table-cell-fix-left]': "isFixedLeft",
                            '[style.position]': "isFixed? 'sticky' : null"
                        }
                    },] }
        ];
        /** @nocollapse */
        DwCellFixedDirective.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        DwCellFixedDirective.propDecorators = {
            dwRight: [{ type: core.Input }],
            dwLeft: [{ type: core.Input }],
            colspan: [{ type: core.Input }],
            colSpan: [{ type: core.Input }]
        };
        return DwCellFixedDirective;
    }());
    if (false) {
        /** @type {?} */
        DwCellFixedDirective.prototype.dwRight;
        /** @type {?} */
        DwCellFixedDirective.prototype.dwLeft;
        /** @type {?} */
        DwCellFixedDirective.prototype.colspan;
        /** @type {?} */
        DwCellFixedDirective.prototype.colSpan;
        /** @type {?} */
        DwCellFixedDirective.prototype.changes$;
        /** @type {?} */
        DwCellFixedDirective.prototype.isAutoLeft;
        /** @type {?} */
        DwCellFixedDirective.prototype.isAutoRight;
        /** @type {?} */
        DwCellFixedDirective.prototype.isFixedLeft;
        /** @type {?} */
        DwCellFixedDirective.prototype.isFixedRight;
        /** @type {?} */
        DwCellFixedDirective.prototype.isFixed;
        /**
         * @type {?}
         * @private
         */
        DwCellFixedDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwCellFixedDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table-style.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableStyleService = /** @class */ (function () {
        function DwTableStyleService() {
            this.theadTemplate$ = new rxjs.ReplaySubject(1);
            this.hasFixLeft$ = new rxjs.ReplaySubject(1);
            this.hasFixRight$ = new rxjs.ReplaySubject(1);
            this.hostWidth$ = new rxjs.ReplaySubject(1);
            this.columnCount$ = new rxjs.ReplaySubject(1);
            this.showEmpty$ = new rxjs.ReplaySubject(1);
            this.noResult$ = new rxjs.ReplaySubject(1);
            this.listOfThWidthConfigPx$ = new rxjs.BehaviorSubject([]);
            this.tableWidthConfigPx$ = new rxjs.BehaviorSubject([]);
            this.manualWidthConfigPx$ = rxjs.combineLatest([this.tableWidthConfigPx$, this.listOfThWidthConfigPx$]).pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), widthConfig = _b[0], listOfWidth = _b[1];
                return (widthConfig.length ? widthConfig : listOfWidth);
            })));
            this.listOfAutoWidthPx$ = new rxjs.ReplaySubject(1);
            this.listOfListOfThWidthPx$ = rxjs.merge(
            /** init with manual width **/
            this.manualWidthConfigPx$, rxjs.combineLatest([this.listOfAutoWidthPx$, this.manualWidthConfigPx$]).pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 2), autoWidth = _b[0], manualWidth = _b[1];
                /** use autoWidth until column length match **/
                if (autoWidth.length === manualWidth.length) {
                    return autoWidth.map((/**
                     * @param {?} width
                     * @param {?} index
                     * @return {?}
                     */
                    function (width, index) {
                        if (width === '0px') {
                            return manualWidth[index] || null;
                        }
                        else {
                            return manualWidth[index] || width;
                        }
                    }));
                }
                else {
                    return manualWidth;
                }
            }))));
            this.listOfMeasureColumn$ = new rxjs.ReplaySubject(1);
            this.listOfListOfThWidth$ = this.listOfAutoWidthPx$.pipe(operators.map((/**
             * @param {?} list
             * @return {?}
             */
            function (list) { return list.map((/**
             * @param {?} width
             * @return {?}
             */
            function (width) { return parseInt(width, 10); })); })));
            this.enableAutoMeasure$ = new rxjs.ReplaySubject(1);
        }
        /**
         * @param {?} template
         * @return {?}
         */
        DwTableStyleService.prototype.setTheadTemplate = /**
         * @param {?} template
         * @return {?}
         */
        function (template) {
            this.theadTemplate$.next(template);
        };
        /**
         * @param {?} hasFixLeft
         * @return {?}
         */
        DwTableStyleService.prototype.setHasFixLeft = /**
         * @param {?} hasFixLeft
         * @return {?}
         */
        function (hasFixLeft) {
            this.hasFixLeft$.next(hasFixLeft);
        };
        /**
         * @param {?} hasFixRight
         * @return {?}
         */
        DwTableStyleService.prototype.setHasFixRight = /**
         * @param {?} hasFixRight
         * @return {?}
         */
        function (hasFixRight) {
            this.hasFixRight$.next(hasFixRight);
        };
        /**
         * @param {?} widthConfig
         * @return {?}
         */
        DwTableStyleService.prototype.setTableWidthConfig = /**
         * @param {?} widthConfig
         * @return {?}
         */
        function (widthConfig) {
            this.tableWidthConfigPx$.next(widthConfig);
        };
        /**
         * @param {?} listOfTh
         * @return {?}
         */
        DwTableStyleService.prototype.setListOfTh = /**
         * @param {?} listOfTh
         * @return {?}
         */
        function (listOfTh) {
            /** @type {?} */
            var columnCount = 0;
            listOfTh.forEach((/**
             * @param {?} th
             * @return {?}
             */
            function (th) {
                columnCount += (th.colspan && +th.colspan) || (th.colSpan && +th.colSpan) || 1;
            }));
            /** @type {?} */
            var listOfThPx = listOfTh.map((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.dwWidth; }));
            this.columnCount$.next(columnCount);
            this.listOfThWidthConfigPx$.next(listOfThPx);
        };
        /**
         * @param {?} listOfTh
         * @return {?}
         */
        DwTableStyleService.prototype.setListOfMeasureColumn = /**
         * @param {?} listOfTh
         * @return {?}
         */
        function (listOfTh) {
            /** @type {?} */
            var listOfKeys = [];
            listOfTh.forEach((/**
             * @param {?} th
             * @return {?}
             */
            function (th) {
                /** @type {?} */
                var length = (th.colspan && +th.colspan) || (th.colSpan && +th.colSpan) || 1;
                for (var i = 0; i < length; i++) {
                    listOfKeys.push("measure_key_" + i);
                }
            }));
            this.listOfMeasureColumn$.next(listOfKeys);
        };
        /**
         * @param {?} listOfAutoWidth
         * @return {?}
         */
        DwTableStyleService.prototype.setListOfAutoWidth = /**
         * @param {?} listOfAutoWidth
         * @return {?}
         */
        function (listOfAutoWidth) {
            this.listOfAutoWidthPx$.next(listOfAutoWidth.map((/**
             * @param {?} width
             * @return {?}
             */
            function (width) { return width + "px"; })));
        };
        /**
         * @param {?} showEmpty
         * @return {?}
         */
        DwTableStyleService.prototype.setShowEmpty = /**
         * @param {?} showEmpty
         * @return {?}
         */
        function (showEmpty) {
            this.showEmpty$.next(showEmpty);
        };
        /**
         * @param {?} noResult
         * @return {?}
         */
        DwTableStyleService.prototype.setNoResult = /**
         * @param {?} noResult
         * @return {?}
         */
        function (noResult) {
            this.noResult$.next(noResult);
        };
        /**
         * @param {?} scrollX
         * @param {?} scrollY
         * @return {?}
         */
        DwTableStyleService.prototype.setScroll = /**
         * @param {?} scrollX
         * @param {?} scrollY
         * @return {?}
         */
        function (scrollX, scrollY) {
            /** @type {?} */
            var enableAutoMeasure = !!(scrollX || scrollY);
            if (!enableAutoMeasure) {
                this.setListOfAutoWidth([]);
            }
            this.enableAutoMeasure$.next(enableAutoMeasure);
        };
        DwTableStyleService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwTableStyleService.ctorParameters = function () { return []; };
        return DwTableStyleService;
    }());
    if (false) {
        /** @type {?} */
        DwTableStyleService.prototype.theadTemplate$;
        /** @type {?} */
        DwTableStyleService.prototype.hasFixLeft$;
        /** @type {?} */
        DwTableStyleService.prototype.hasFixRight$;
        /** @type {?} */
        DwTableStyleService.prototype.hostWidth$;
        /** @type {?} */
        DwTableStyleService.prototype.columnCount$;
        /** @type {?} */
        DwTableStyleService.prototype.showEmpty$;
        /** @type {?} */
        DwTableStyleService.prototype.noResult$;
        /**
         * @type {?}
         * @private
         */
        DwTableStyleService.prototype.listOfThWidthConfigPx$;
        /**
         * @type {?}
         * @private
         */
        DwTableStyleService.prototype.tableWidthConfigPx$;
        /** @type {?} */
        DwTableStyleService.prototype.manualWidthConfigPx$;
        /**
         * @type {?}
         * @private
         */
        DwTableStyleService.prototype.listOfAutoWidthPx$;
        /** @type {?} */
        DwTableStyleService.prototype.listOfListOfThWidthPx$;
        /** @type {?} */
        DwTableStyleService.prototype.listOfMeasureColumn$;
        /** @type {?} */
        DwTableStyleService.prototype.listOfListOfThWidth$;
        /** @type {?} */
        DwTableStyleService.prototype.enableAutoMeasure$;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/cell.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableCellDirective = /** @class */ (function () {
        function DwTableCellDirective(dwTableStyleService) {
            this.isInsideTable = false;
            this.isInsideTable = !!dwTableStyleService;
        }
        DwTableCellDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'th:not(.dw-disable-th):not([mat-cell]), td:not(.dw-disable-td):not([mat-cell])',
                        host: {
                            '[class.ant-table-cell]': 'isInsideTable'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwTableCellDirective.ctorParameters = function () { return [
            { type: DwTableStyleService, decorators: [{ type: core.Optional }] }
        ]; };
        return DwTableCellDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTableCellDirective.prototype.isInsideTable;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/td-addon.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTdAddOnComponent = /** @class */ (function () {
        function DwTdAddOnComponent() {
            this.dwChecked = false;
            this.dwDisabled = false;
            this.dwIndeterminate = false;
            this.dwIndentSize = 0;
            this.dwShowExpand = false;
            this.dwShowCheckbox = false;
            this.dwExpand = false;
            this.dwCheckedChange = new core.EventEmitter();
            this.dwExpandChange = new core.EventEmitter();
            this.isDwShowExpandChanged = false;
            this.isDwShowCheckboxChanged = false;
        }
        /**
         * @param {?} checked
         * @return {?}
         */
        DwTdAddOnComponent.prototype.onCheckedChange = /**
         * @param {?} checked
         * @return {?}
         */
        function (checked) {
            this.dwChecked = checked;
            this.dwCheckedChange.emit(checked);
        };
        /**
         * @param {?} expand
         * @return {?}
         */
        DwTdAddOnComponent.prototype.onExpandChange = /**
         * @param {?} expand
         * @return {?}
         */
        function (expand) {
            this.dwExpand = expand;
            this.dwExpandChange.emit(expand);
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTdAddOnComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            /** @type {?} */
            var isFirstChange = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) { return value && value.firstChange && value.currentValue !== undefined; });
            var dwExpand = changes.dwExpand, dwChecked = changes.dwChecked, dwShowExpand = changes.dwShowExpand, dwShowCheckbox = changes.dwShowCheckbox;
            if (dwShowExpand) {
                this.isDwShowExpandChanged = true;
            }
            if (dwShowCheckbox) {
                this.isDwShowCheckboxChanged = true;
            }
            if (isFirstChange(dwExpand) && !this.isDwShowExpandChanged) {
                this.dwShowExpand = true;
            }
            if (isFirstChange(dwChecked) && !this.isDwShowCheckboxChanged) {
                this.dwShowCheckbox = true;
            }
        };
        DwTdAddOnComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'td[dwChecked], td[dwDisabled], td[dwIndeterminate], td[dwIndentSize], td[dwExpand], td[dwShowExpand], td[dwShowCheckbox]',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <ng-container *ngIf=\"dwShowExpand || dwIndentSize > 0\">\n      <dw-row-indent [indentSize]=\"dwIndentSize\"></dw-row-indent>\n      <button dw-row-expand-button [expand]=\"dwExpand\" (expandChange)=\"onExpandChange($event)\" [spaceMode]=\"!dwShowExpand\"></button>\n    </ng-container>\n    <label\n      dw-checkbox\n      *ngIf=\"dwShowCheckbox\"\n      [dwDisabled]=\"dwDisabled\"\n      [ngModel]=\"dwChecked\"\n      [dwIndeterminate]=\"dwIndeterminate\"\n      (ngModelChange)=\"onCheckedChange($event)\"\n    >\n    </label>\n    <ng-content></ng-content>\n  ",
                        host: {
                            '[class.ant-table-cell-with-append]': "dwShowExpand || dwIndentSize > 0",
                            '[class.ant-table-selection-column]': "dwShowCheckbox"
                        }
                    }] }
        ];
        DwTdAddOnComponent.propDecorators = {
            dwChecked: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwIndeterminate: [{ type: core.Input }],
            dwIndentSize: [{ type: core.Input }],
            dwShowExpand: [{ type: core.Input }],
            dwShowCheckbox: [{ type: core.Input }],
            dwExpand: [{ type: core.Input }],
            dwCheckedChange: [{ type: core.Output }],
            dwExpandChange: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTdAddOnComponent.prototype, "dwShowExpand", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTdAddOnComponent.prototype, "dwShowCheckbox", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTdAddOnComponent.prototype, "dwExpand", void 0);
        return DwTdAddOnComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTdAddOnComponent.ngAcceptInputType_dwShowExpand;
        /** @type {?} */
        DwTdAddOnComponent.ngAcceptInputType_dwShowCheckbox;
        /** @type {?} */
        DwTdAddOnComponent.ngAcceptInputType_dwExpand;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwChecked;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwDisabled;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwIndeterminate;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwIndentSize;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwShowExpand;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwShowCheckbox;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwExpand;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwCheckedChange;
        /** @type {?} */
        DwTdAddOnComponent.prototype.dwExpandChange;
        /**
         * @type {?}
         * @private
         */
        DwTdAddOnComponent.prototype.isDwShowExpandChanged;
        /**
         * @type {?}
         * @private
         */
        DwTdAddOnComponent.prototype.isDwShowCheckboxChanged;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/th-addon.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwThAddOnComponent = /** @class */ (function () {
        function DwThAddOnComponent(cdr) {
            this.cdr = cdr;
            this.manualClickOrder$ = new rxjs.Subject();
            this.calcOperatorChange$ = new rxjs.Subject();
            this.dwFilterValue = null;
            this.sortOrder = null;
            this.sortDirections = ['ascend', 'descend', null];
            this.sortOrderChange$ = new rxjs.Subject();
            this.destroy$ = new rxjs.Subject();
            this.isDwShowSortChanged = false;
            this.isDwShowFilterChanged = false;
            this.dwFilterMultiple = true;
            this.dwSortOrder = null;
            this.dwSortPriority = false;
            this.dwSortDirections = ['ascend', 'descend', null];
            this.dwFilters = [];
            this.dwSortFn = null;
            this.dwFilterFn = null;
            this.dwShowSort = false;
            this.dwShowFilter = false;
            this.dwCustomFilter = false;
            this.dwCheckedChange = new core.EventEmitter();
            this.dwSortOrderChange = new core.EventEmitter();
            this.dwFilterChange = new core.EventEmitter();
            /**
             * @deprecated use dwSortOrder instead *
             */
            this.dwSort = null;
            /**
             * @deprecated use dwSortOrderChange instead *
             */
            this.dwSortChange = new core.EventEmitter();
        }
        /**
         * @param {?} sortDirections
         * @param {?} current
         * @return {?}
         */
        DwThAddOnComponent.prototype.getNextSortDirection = /**
         * @param {?} sortDirections
         * @param {?} current
         * @return {?}
         */
        function (sortDirections, current) {
            /** @type {?} */
            var index = sortDirections.indexOf(current);
            if (index === sortDirections.length - 1) {
                return sortDirections[0];
            }
            else {
                return sortDirections[index + 1];
            }
        };
        /**
         * @return {?}
         */
        DwThAddOnComponent.prototype.emitNextSortValue = /**
         * @return {?}
         */
        function () {
            if (this.dwShowSort) {
                /** @type {?} */
                var nextOrder = this.getNextSortDirection(this.sortDirections, (/** @type {?} */ (this.sortOrder)));
                this.setSortOrder(nextOrder);
                this.manualClickOrder$.next(this);
            }
        };
        /**
         * @param {?} order
         * @return {?}
         */
        DwThAddOnComponent.prototype.setSortOrder = /**
         * @param {?} order
         * @return {?}
         */
        function (order) {
            this.sortOrderChange$.next(order);
        };
        /**
         * @return {?}
         */
        DwThAddOnComponent.prototype.clearSortOrder = /**
         * @return {?}
         */
        function () {
            if (this.sortOrder !== null) {
                this.setSortOrder(null);
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwThAddOnComponent.prototype.onFilterValueChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.dwFilterChange.emit(value);
            this.dwFilterValue = value;
            this.updateCalcOperator();
        };
        /**
         * @return {?}
         */
        DwThAddOnComponent.prototype.updateCalcOperator = /**
         * @return {?}
         */
        function () {
            this.calcOperatorChange$.next();
        };
        /**
         * @return {?}
         */
        DwThAddOnComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.sortOrderChange$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} order
             * @return {?}
             */
            function (order) {
                if (_this.sortOrder !== order) {
                    _this.sortOrder = order;
                    _this.dwSortChange.emit(order);
                    _this.dwSortOrderChange.emit(order);
                }
                _this.updateCalcOperator();
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwThAddOnComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwSortKey = changes.dwSortKey, dwSort = changes.dwSort, dwSortDirections = changes.dwSortDirections, dwFilters = changes.dwFilters, dwSortOrder = changes.dwSortOrder, dwSortFn = changes.dwSortFn, dwFilterFn = changes.dwFilterFn, dwSortPriority = changes.dwSortPriority, dwFilterMultiple = changes.dwFilterMultiple, dwShowSort = changes.dwShowSort, dwShowFilter = changes.dwShowFilter;
            if (dwSortDirections) {
                if (this.dwSortDirections && this.dwSortDirections.length) {
                    this.sortDirections = this.dwSortDirections;
                }
            }
            if (dwSort) {
                this.sortOrder = this.dwSort;
                this.setSortOrder(this.dwSort);
                logger.warnDeprecation("'dwSort' and 'dwSortChange' is deprecated and will be removed in 10.0.0. Please use 'dwSortOrder' and 'dwSortOrderChange' instead.");
            }
            if (dwSortKey) {
                this.dwColumnKey = this.dwSortKey;
                logger.warnDeprecation("'dwSortKey' is deprecated and will be removed in 10.0.0. Please use 'dwColumnKey' instead.");
            }
            if (dwSortOrder) {
                this.sortOrder = this.dwSortOrder;
                this.setSortOrder(this.dwSortOrder);
            }
            if (dwShowSort) {
                this.isDwShowSortChanged = true;
            }
            if (dwShowFilter) {
                this.isDwShowFilterChanged = true;
            }
            /** @type {?} */
            var isFirstChange = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) { return value && value.firstChange && value.currentValue !== undefined; });
            if ((isFirstChange(dwSortKey) || isFirstChange(dwSort) || isFirstChange(dwSortOrder) || isFirstChange(dwSortFn)) &&
                !this.isDwShowSortChanged) {
                this.dwShowSort = true;
            }
            if (isFirstChange(dwFilters) && !this.isDwShowFilterChanged) {
                this.dwShowFilter = true;
            }
            if ((dwFilters || dwFilterMultiple) && this.dwShowFilter) {
                /** @type {?} */
                var listOfValue = this.dwFilters.filter((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.byDefault; })).map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.value; }));
                this.dwFilterValue = this.dwFilterMultiple ? listOfValue : listOfValue[0] || null;
            }
            if (dwSortFn || dwFilterFn || dwSortPriority || dwFilters) {
                this.updateCalcOperator();
            }
        };
        /**
         * @return {?}
         */
        DwThAddOnComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwThAddOnComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'th[dwSortKey], th[dwColumnKey], th[dwSort], th[dwSortFn], th[dwSortOrder], th[dwFilters], th[dwShowSort], th[dwShowFilter], th[dwCustomFilter]',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <dw-table-filter\n      *ngIf=\"dwShowFilter || dwCustomFilter; else notFilterTemplate\"\n      [contentTemplate]=\"notFilterTemplate\"\n      [extraTemplate]=\"extraTemplate\"\n      [customFilter]=\"dwCustomFilter\"\n      [filterMultiple]=\"dwFilterMultiple\"\n      [listOfFilter]=\"dwFilters\"\n      (filterChange)=\"onFilterValueChange($event)\"\n    ></dw-table-filter>\n    <ng-template #notFilterTemplate>\n      <ng-template [ngTemplateOutlet]=\"dwShowSort ? sortTemplate : contentTemplate\"></ng-template>\n    </ng-template>\n    <ng-template #extraTemplate>\n      <ng-content select=\"[dw-th-extra]\"></ng-content>\n      <ng-content select=\"dw-filter-trigger\"></ng-content>\n    </ng-template>\n    <ng-template #sortTemplate>\n      <dw-table-sorters [sortOrder]=\"sortOrder\" [sortDirections]=\"sortDirections\" [contentTemplate]=\"contentTemplate\"></dw-table-sorters>\n    </ng-template>\n    <ng-template #contentTemplate>\n      <ng-content></ng-content>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-table-column-has-sorters]': 'dwShowSort',
                            '[class.ant-table-column-sort]': "sortOrder === 'descend' || sortOrder === 'ascend'",
                            '(click)': 'emitNextSortValue()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwThAddOnComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef }
        ]; };
        DwThAddOnComponent.propDecorators = {
            dwColumnKey: [{ type: core.Input }],
            dwFilterMultiple: [{ type: core.Input }],
            dwSortOrder: [{ type: core.Input }],
            dwSortPriority: [{ type: core.Input }],
            dwSortDirections: [{ type: core.Input }],
            dwFilters: [{ type: core.Input }],
            dwSortFn: [{ type: core.Input }],
            dwFilterFn: [{ type: core.Input }],
            dwShowSort: [{ type: core.Input }],
            dwShowFilter: [{ type: core.Input }],
            dwCustomFilter: [{ type: core.Input }],
            dwCheckedChange: [{ type: core.Output }],
            dwSortOrderChange: [{ type: core.Output }],
            dwFilterChange: [{ type: core.Output }],
            dwSortKey: [{ type: core.Input }],
            dwSort: [{ type: core.Input }],
            dwSortChange: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwThAddOnComponent.prototype, "dwShowSort", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwThAddOnComponent.prototype, "dwShowFilter", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwThAddOnComponent.prototype, "dwCustomFilter", void 0);
        return DwThAddOnComponent;
    }());
    if (false) {
        /** @type {?} */
        DwThAddOnComponent.ngAcceptInputType_dwShowSort;
        /** @type {?} */
        DwThAddOnComponent.ngAcceptInputType_dwShowFilter;
        /** @type {?} */
        DwThAddOnComponent.ngAcceptInputType_dwCustomFilter;
        /** @type {?} */
        DwThAddOnComponent.prototype.manualClickOrder$;
        /** @type {?} */
        DwThAddOnComponent.prototype.calcOperatorChange$;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwFilterValue;
        /** @type {?} */
        DwThAddOnComponent.prototype.sortOrder;
        /** @type {?} */
        DwThAddOnComponent.prototype.sortDirections;
        /**
         * @type {?}
         * @private
         */
        DwThAddOnComponent.prototype.sortOrderChange$;
        /**
         * @type {?}
         * @private
         */
        DwThAddOnComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwThAddOnComponent.prototype.isDwShowSortChanged;
        /**
         * @type {?}
         * @private
         */
        DwThAddOnComponent.prototype.isDwShowFilterChanged;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwColumnKey;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwFilterMultiple;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwSortOrder;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwSortPriority;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwSortDirections;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwFilters;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwSortFn;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwFilterFn;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwShowSort;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwShowFilter;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwCustomFilter;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwCheckedChange;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwSortOrderChange;
        /** @type {?} */
        DwThAddOnComponent.prototype.dwFilterChange;
        /**
         * @deprecated use dwColumnKey instead *
         * @type {?}
         */
        DwThAddOnComponent.prototype.dwSortKey;
        /**
         * @deprecated use dwSortOrder instead *
         * @type {?}
         */
        DwThAddOnComponent.prototype.dwSort;
        /**
         * @deprecated use dwSortOrderChange instead *
         * @type {?}
         */
        DwThAddOnComponent.prototype.dwSortChange;
        /**
         * @type {?}
         * @private
         */
        DwThAddOnComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/th-measure.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwThMeasureDirective = /** @class */ (function () {
        function DwThMeasureDirective(renderer, elementRef) {
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.changes$ = new rxjs.Subject();
            this.dwWidth = null;
            this.colspan = null;
            this.colSpan = null;
            this.rowspan = null;
            this.rowSpan = null;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DwThMeasureDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwWidth = changes.dwWidth, colspan = changes.colspan, rowspan = changes.rowspan, colSpan = changes.colSpan, rowSpan = changes.rowSpan;
            if (colspan || colSpan) {
                /** @type {?} */
                var col = this.colspan || this.colSpan;
                if (!util.isNil(col)) {
                    this.renderer.setAttribute(this.elementRef.nativeElement, 'colspan', "" + col);
                }
                else {
                    this.renderer.removeAttribute(this.elementRef.nativeElement, 'colspan');
                }
            }
            if (rowspan || rowSpan) {
                /** @type {?} */
                var row = this.rowspan || this.rowSpan;
                if (!util.isNil(row)) {
                    this.renderer.setAttribute(this.elementRef.nativeElement, 'rowspan', "" + row);
                }
                else {
                    this.renderer.removeAttribute(this.elementRef.nativeElement, 'rowspan');
                }
            }
            if (dwWidth || colspan) {
                this.changes$.next();
            }
        };
        DwThMeasureDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'th'
                    },] }
        ];
        /** @nocollapse */
        DwThMeasureDirective.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        DwThMeasureDirective.propDecorators = {
            dwWidth: [{ type: core.Input }],
            colspan: [{ type: core.Input }],
            colSpan: [{ type: core.Input }],
            rowspan: [{ type: core.Input }],
            rowSpan: [{ type: core.Input }]
        };
        return DwThMeasureDirective;
    }());
    if (false) {
        /** @type {?} */
        DwThMeasureDirective.prototype.changes$;
        /** @type {?} */
        DwThMeasureDirective.prototype.dwWidth;
        /** @type {?} */
        DwThMeasureDirective.prototype.colspan;
        /** @type {?} */
        DwThMeasureDirective.prototype.colSpan;
        /** @type {?} */
        DwThMeasureDirective.prototype.rowspan;
        /** @type {?} */
        DwThMeasureDirective.prototype.rowSpan;
        /**
         * @type {?}
         * @private
         */
        DwThMeasureDirective.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwThMeasureDirective.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/cell/th-selection.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwThSelectionComponent = /** @class */ (function () {
        function DwThSelectionComponent() {
            this.dwSelections = [];
            this.dwChecked = false;
            this.dwDisabled = false;
            this.dwIndeterminate = false;
            this.dwShowCheckbox = false;
            this.dwShowRowSelection = false;
            this.dwCheckedChange = new core.EventEmitter();
            this.dwSortChangeWithKey = new core.EventEmitter();
            this.isDwShowExpandChanged = false;
            this.isDwShowCheckboxChanged = false;
        }
        /**
         * @param {?} checked
         * @return {?}
         */
        DwThSelectionComponent.prototype.onCheckedChange = /**
         * @param {?} checked
         * @return {?}
         */
        function (checked) {
            this.dwChecked = checked;
            this.dwCheckedChange.emit(checked);
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwThSelectionComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            /** @type {?} */
            var isFirstChange = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) { return value && value.firstChange && value.currentValue !== undefined; });
            var dwChecked = changes.dwChecked, dwSelections = changes.dwSelections, dwShowExpand = changes.dwShowExpand, dwShowCheckbox = changes.dwShowCheckbox;
            if (dwShowExpand) {
                this.isDwShowExpandChanged = true;
            }
            if (dwShowCheckbox) {
                this.isDwShowCheckboxChanged = true;
            }
            if (isFirstChange(dwSelections) && !this.isDwShowExpandChanged) {
                this.dwShowRowSelection = true;
            }
            if (isFirstChange(dwChecked) && !this.isDwShowCheckboxChanged) {
                this.dwShowCheckbox = true;
            }
        };
        DwThSelectionComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'th[dwSelections],th[dwChecked],th[dwShowCheckbox],th[dwShowRowSelection]',
                        preserveWhitespaces: false,
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "\n    <dw-table-selection\n      [checked]=\"dwChecked\"\n      [disabled]=\"dwDisabled\"\n      [indeterminate]=\"dwIndeterminate\"\n      [listOfSelections]=\"dwSelections\"\n      [showCheckbox]=\"dwShowCheckbox\"\n      [showRowSelection]=\"dwShowRowSelection\"\n      (checkedChange)=\"onCheckedChange($event)\"\n    ></dw-table-selection>\n    <ng-content></ng-content>\n  ",
                        host: {
                            '[class.ant-table-selection-column]': 'true'
                        }
                    }] }
        ];
        DwThSelectionComponent.propDecorators = {
            dwSelections: [{ type: core.Input }],
            dwChecked: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwIndeterminate: [{ type: core.Input }],
            dwShowCheckbox: [{ type: core.Input }],
            dwShowRowSelection: [{ type: core.Input }],
            dwCheckedChange: [{ type: core.Output }],
            dwSortChangeWithKey: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwThSelectionComponent.prototype, "dwShowCheckbox", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwThSelectionComponent.prototype, "dwShowRowSelection", void 0);
        return DwThSelectionComponent;
    }());
    if (false) {
        /** @type {?} */
        DwThSelectionComponent.ngAcceptInputType_dwShowCheckbox;
        /** @type {?} */
        DwThSelectionComponent.ngAcceptInputType_dwShowRowSelection;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwSelections;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwChecked;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwDisabled;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwIndeterminate;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwShowCheckbox;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwShowRowSelection;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwCheckedChange;
        /** @type {?} */
        DwThSelectionComponent.prototype.dwSortChangeWithKey;
        /**
         * @type {?}
         * @private
         */
        DwThSelectionComponent.prototype.isDwShowExpandChanged;
        /**
         * @type {?}
         * @private
         */
        DwThSelectionComponent.prototype.isDwShowCheckboxChanged;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/styled/align.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwCellAlignDirective = /** @class */ (function () {
        function DwCellAlignDirective() {
            this.dwAlign = null;
        }
        DwCellAlignDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'th[dwAlign],td[dwAlign]',
                        host: {
                            '[style.text-align]': 'dwAlign'
                        }
                    },] }
        ];
        DwCellAlignDirective.propDecorators = {
            dwAlign: [{ type: core.Input }]
        };
        return DwCellAlignDirective;
    }());
    if (false) {
        /** @type {?} */
        DwCellAlignDirective.prototype.dwAlign;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/styled/ellipsis.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwCellEllipsisDirective = /** @class */ (function () {
        function DwCellEllipsisDirective() {
            this.dwEllipsis = true;
        }
        DwCellEllipsisDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'th[dwEllipsis],td[dwEllipsis]',
                        host: {
                            '[class.ant-table-cell-ellipsis]': 'dwEllipsis'
                        }
                    },] }
        ];
        DwCellEllipsisDirective.propDecorators = {
            dwEllipsis: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwCellEllipsisDirective.prototype, "dwEllipsis", void 0);
        return DwCellEllipsisDirective;
    }());
    if (false) {
        /** @type {?} */
        DwCellEllipsisDirective.ngAcceptInputType_dwEllipsis;
        /** @type {?} */
        DwCellEllipsisDirective.prototype.dwEllipsis;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/styled/word-break.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwCellBreakWordDirective = /** @class */ (function () {
        function DwCellBreakWordDirective() {
            this.dwBreakWord = true;
        }
        DwCellBreakWordDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'th[dwBreakWord],td[dwBreakWord]',
                        host: {
                            '[style.word-break]': "dwBreakWord ? 'break-all' : ''"
                        }
                    },] }
        ];
        DwCellBreakWordDirective.propDecorators = {
            dwBreakWord: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwCellBreakWordDirective.prototype, "dwBreakWord", void 0);
        return DwCellBreakWordDirective;
    }());
    if (false) {
        /** @type {?} */
        DwCellBreakWordDirective.ngAcceptInputType_dwBreakWord;
        /** @type {?} */
        DwCellBreakWordDirective.prototype.dwBreakWord;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table-content.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableContentComponent = /** @class */ (function () {
        function DwTableContentComponent() {
            this.tableLayout = 'auto';
            this.theadTemplate = null;
            this.contentTemplate = null;
            this.listOfColWidth = [];
            this.scrollX = null;
        }
        DwTableContentComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'table[dw-table-content]',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <col [style.width]=\"width\" [style.minWidth]=\"width\" *ngFor=\"let width of listOfColWidth\" />\n    <thead class=\"ant-table-thead\" *ngIf=\"theadTemplate\">\n      <ng-template [ngTemplateOutlet]=\"theadTemplate\"></ng-template>\n    </thead>\n    <ng-template [ngTemplateOutlet]=\"contentTemplate\"></ng-template>\n    <ng-content></ng-content>\n  ",
                        host: {
                            '[style.table-layout]': 'tableLayout',
                            '[class.ant-table-fixed]': 'scrollX',
                            '[style.width]': 'scrollX',
                            '[style.min-width]': "scrollX ? '100%': null"
                        }
                    }] }
        ];
        DwTableContentComponent.propDecorators = {
            tableLayout: [{ type: core.Input }],
            theadTemplate: [{ type: core.Input }],
            contentTemplate: [{ type: core.Input }],
            listOfColWidth: [{ type: core.Input }],
            scrollX: [{ type: core.Input }]
        };
        return DwTableContentComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableContentComponent.prototype.tableLayout;
        /** @type {?} */
        DwTableContentComponent.prototype.theadTemplate;
        /** @type {?} */
        DwTableContentComponent.prototype.contentTemplate;
        /** @type {?} */
        DwTableContentComponent.prototype.listOfColWidth;
        /** @type {?} */
        DwTableContentComponent.prototype.scrollX;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table-fixed-row.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableFixedRowComponent = /** @class */ (function () {
        function DwTableFixedRowComponent(dwTableStyleService, renderer) {
            this.dwTableStyleService = dwTableStyleService;
            this.renderer = renderer;
            this.hostWidth$ = new rxjs.BehaviorSubject(null);
            this.enableAutoMeasure$ = new rxjs.BehaviorSubject(false);
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @return {?}
         */
        DwTableFixedRowComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            if (this.dwTableStyleService) {
                var _a = this.dwTableStyleService, enableAutoMeasure$ = _a.enableAutoMeasure$, hostWidth$ = _a.hostWidth$;
                enableAutoMeasure$.subscribe(this.enableAutoMeasure$);
                hostWidth$.subscribe(this.hostWidth$);
            }
        };
        /**
         * @return {?}
         */
        DwTableFixedRowComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.dwTableStyleService.columnCount$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} count
             * @return {?}
             */
            function (count) {
                _this.renderer.setAttribute(_this.tdElement.nativeElement, 'colspan', "" + count);
            }));
        };
        /**
         * @return {?}
         */
        DwTableFixedRowComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTableFixedRowComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'tr[dw-table-fixed-row], tr[dwExpand]',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <td class=\"dw-disable-td ant-table-cell\" #tdElement>\n      <div\n        class=\"ant-table-expanded-row-fixed\"\n        *ngIf=\"enableAutoMeasure$ | async; else contentTemplate\"\n        style=\"position: sticky; left: 0px; overflow: hidden;\"\n        [style.width.px]=\"hostWidth$ | async\"\n      >\n        <ng-template [ngTemplateOutlet]=\"contentTemplate\"></ng-template>\n      </div>\n    </td>\n    <ng-template #contentTemplate><ng-content></ng-content></ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwTableFixedRowComponent.ctorParameters = function () { return [
            { type: DwTableStyleService },
            { type: core.Renderer2 }
        ]; };
        DwTableFixedRowComponent.propDecorators = {
            tdElement: [{ type: core.ViewChild, args: ['tdElement',] }]
        };
        return DwTableFixedRowComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableFixedRowComponent.prototype.tdElement;
        /** @type {?} */
        DwTableFixedRowComponent.prototype.hostWidth$;
        /** @type {?} */
        DwTableFixedRowComponent.prototype.enableAutoMeasure$;
        /**
         * @type {?}
         * @private
         */
        DwTableFixedRowComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTableFixedRowComponent.prototype.dwTableStyleService;
        /**
         * @type {?}
         * @private
         */
        DwTableFixedRowComponent.prototype.renderer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table-inner-default.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableInnerDefaultComponent = /** @class */ (function () {
        function DwTableInnerDefaultComponent() {
            this.tableLayout = 'auto';
            this.listOfColWidth = [];
            this.theadTemplate = null;
            this.contentTemplate = null;
        }
        DwTableInnerDefaultComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-inner-default',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div class=\"ant-table-content\">\n      <table\n        dw-table-content\n        [contentTemplate]=\"contentTemplate\"\n        [tableLayout]=\"tableLayout\"\n        [listOfColWidth]=\"listOfColWidth\"\n        [theadTemplate]=\"theadTemplate\"\n      ></table>\n    </div>\n  ",
                        host: {
                            '[class.ant-table-container]': 'true'
                        }
                    }] }
        ];
        DwTableInnerDefaultComponent.propDecorators = {
            tableLayout: [{ type: core.Input }],
            listOfColWidth: [{ type: core.Input }],
            theadTemplate: [{ type: core.Input }],
            contentTemplate: [{ type: core.Input }]
        };
        return DwTableInnerDefaultComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableInnerDefaultComponent.prototype.tableLayout;
        /** @type {?} */
        DwTableInnerDefaultComponent.prototype.listOfColWidth;
        /** @type {?} */
        DwTableInnerDefaultComponent.prototype.theadTemplate;
        /** @type {?} */
        DwTableInnerDefaultComponent.prototype.contentTemplate;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table-inner-scroll.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableInnerScrollComponent = /** @class */ (function () {
        function DwTableInnerScrollComponent(renderer, ngZone, platform, resizeService) {
            this.renderer = renderer;
            this.ngZone = ngZone;
            this.platform = platform;
            this.resizeService = resizeService;
            this.data = [];
            this.scrollX = null;
            this.scrollY = null;
            this.contentTemplate = null;
            this.widthConfig = [];
            this.listOfColWidth = [];
            this.theadTemplate = null;
            this.virtualTemplate = null;
            this.virtualItemSize = 0;
            this.virtualMaxBufferPx = 200;
            this.virtualMinBufferPx = 100;
            this.virtualForTrackBy = (/**
             * @param {?} index
             * @return {?}
             */
            function (index) { return index; });
            this.headerStyleMap = {};
            this.bodyStyleMap = {};
            this.verticalScrollBarWidth = 0;
            this.noDateVirtualHeight = '182px';
            this.data$ = new rxjs.Subject();
            this.scroll$ = new rxjs.Subject();
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @param {?=} clear
         * @return {?}
         */
        DwTableInnerScrollComponent.prototype.setScrollPositionClassName = /**
         * @param {?=} clear
         * @return {?}
         */
        function (clear) {
            if (clear === void 0) { clear = false; }
            var _a = this.tableBodyElement.nativeElement, scrollWidth = _a.scrollWidth, scrollLeft = _a.scrollLeft, clientWidth = _a.clientWidth;
            /** @type {?} */
            var leftClassName = 'ant-table-ping-left';
            /** @type {?} */
            var rightClassName = 'ant-table-ping-right';
            if ((scrollWidth === clientWidth && scrollWidth !== 0) || clear) {
                this.renderer.removeClass(this.tableMainElement, leftClassName);
                this.renderer.removeClass(this.tableMainElement, rightClassName);
            }
            else if (scrollLeft === 0) {
                this.renderer.removeClass(this.tableMainElement, leftClassName);
                this.renderer.addClass(this.tableMainElement, rightClassName);
            }
            else if (scrollWidth === scrollLeft + clientWidth) {
                this.renderer.removeClass(this.tableMainElement, rightClassName);
                this.renderer.addClass(this.tableMainElement, leftClassName);
            }
            else {
                this.renderer.addClass(this.tableMainElement, leftClassName);
                this.renderer.addClass(this.tableMainElement, rightClassName);
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTableInnerScrollComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var scrollX = changes.scrollX, scrollY = changes.scrollY, data = changes.data;
            if (scrollX || scrollY) {
                /** @type {?} */
                var hasVerticalScrollBar = this.verticalScrollBarWidth !== 0;
                this.headerStyleMap = {
                    overflowX: 'hidden',
                    overflowY: this.scrollY && hasVerticalScrollBar ? 'scroll' : 'hidden'
                };
                this.bodyStyleMap = {
                    overflowY: this.scrollY ? 'scroll' : null,
                    overflowX: this.scrollX ? 'scroll' : null,
                    maxHeight: this.scrollY
                };
                this.scroll$.next();
            }
            if (data) {
                this.data$.next();
            }
        };
        /**
         * @return {?}
         */
        DwTableInnerScrollComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.platform.isBrowser) {
                this.ngZone.runOutsideAngular((/**
                 * @return {?}
                 */
                function () {
                    /** @type {?} */
                    var scrollEvent$ = rxjs.fromEvent(_this.tableBodyElement.nativeElement, 'scroll').pipe(operators.takeUntil(_this.destroy$));
                    /** @type {?} */
                    var scrollX$ = scrollEvent$.pipe(operators.filter((/**
                     * @return {?}
                     */
                    function () { return !!_this.scrollX; })));
                    /** @type {?} */
                    var scrollY$ = scrollEvent$.pipe(operators.filter((/**
                     * @return {?}
                     */
                    function () { return !!_this.scrollY; })));
                    /** @type {?} */
                    var resize$ = _this.resizeService.subscribe().pipe(operators.takeUntil(_this.destroy$));
                    /** @type {?} */
                    var data$ = _this.data$.pipe(operators.takeUntil(_this.destroy$));
                    /** @type {?} */
                    var setClassName$ = rxjs.merge(scrollX$, resize$, data$, _this.scroll$).pipe(operators.startWith(true), operators.delay(0));
                    setClassName$.subscribe((/**
                     * @return {?}
                     */
                    function () { return _this.setScrollPositionClassName(); }));
                    scrollY$.subscribe((/**
                     * @return {?}
                     */
                    function () { return (_this.tableHeaderElement.nativeElement.scrollLeft = _this.tableBodyElement.nativeElement.scrollLeft); }));
                }));
            }
        };
        /**
         * @return {?}
         */
        DwTableInnerScrollComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.setScrollPositionClassName(true);
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTableInnerScrollComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-inner-scroll',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <div class=\"ant-table-content\">\n      <div *ngIf=\"scrollY\" #tableHeaderElement [ngStyle]=\"headerStyleMap\" class=\"ant-table-header dw-table-hide-scrollbar\">\n        <table\n          dw-table-content\n          tableLayout=\"fixed\"\n          [scrollX]=\"scrollX\"\n          [listOfColWidth]=\"listOfColWidth\"\n          [theadTemplate]=\"theadTemplate\"\n        ></table>\n      </div>\n      <div #tableBodyElement *ngIf=\"!virtualTemplate\" class=\"ant-table-body\" [ngStyle]=\"bodyStyleMap\">\n        <table\n          dw-table-content\n          [scrollX]=\"scrollX\"\n          tableLayout=\"fixed\"\n          [listOfColWidth]=\"listOfColWidth\"\n          [theadTemplate]=\"scrollY ? null : theadTemplate\"\n          [contentTemplate]=\"contentTemplate\"\n        ></table>\n      </div>\n      <cdk-virtual-scroll-viewport\n        #tableBodyElement\n        *ngIf=\"virtualTemplate\"\n        [itemSize]=\"virtualItemSize\"\n        [maxBufferPx]=\"virtualMaxBufferPx\"\n        [minBufferPx]=\"virtualMinBufferPx\"\n        [style.height]=\"data.length ? scrollY : noDateVirtualHeight\"\n      >\n        <table dw-table-content tableLayout=\"fixed\" [scrollX]=\"scrollX\" [listOfColWidth]=\"listOfColWidth\">\n          <tbody>\n            <ng-container *cdkVirtualFor=\"let item of data; let i = index; trackBy: virtualForTrackBy\">\n              <ng-template [ngTemplateOutlet]=\"virtualTemplate\" [ngTemplateOutletContext]=\"{ $implicit: item, index: i }\"></ng-template>\n            </ng-container>\n          </tbody>\n        </table>\n      </cdk-virtual-scroll-viewport>\n    </div>\n  ",
                        host: {
                            '[class.ant-table-container]': 'true'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTableInnerScrollComponent.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.NgZone },
            { type: platform.Platform },
            { type: services.DwResizeService }
        ]; };
        DwTableInnerScrollComponent.propDecorators = {
            data: [{ type: core.Input }],
            scrollX: [{ type: core.Input }],
            scrollY: [{ type: core.Input }],
            contentTemplate: [{ type: core.Input }],
            widthConfig: [{ type: core.Input }],
            listOfColWidth: [{ type: core.Input }],
            theadTemplate: [{ type: core.Input }],
            virtualTemplate: [{ type: core.Input }],
            virtualItemSize: [{ type: core.Input }],
            virtualMaxBufferPx: [{ type: core.Input }],
            virtualMinBufferPx: [{ type: core.Input }],
            tableMainElement: [{ type: core.Input }],
            virtualForTrackBy: [{ type: core.Input }],
            tableHeaderElement: [{ type: core.ViewChild, args: ['tableHeaderElement', { read: core.ElementRef },] }],
            tableBodyElement: [{ type: core.ViewChild, args: ['tableBodyElement', { read: core.ElementRef },] }],
            cdkVirtualScrollViewport: [{ type: core.ViewChild, args: [scrolling.CdkVirtualScrollViewport, { read: scrolling.CdkVirtualScrollViewport },] }],
            verticalScrollBarWidth: [{ type: core.Input }]
        };
        return DwTableInnerScrollComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.data;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.scrollX;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.scrollY;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.contentTemplate;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.widthConfig;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.listOfColWidth;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.theadTemplate;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.virtualTemplate;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.virtualItemSize;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.virtualMaxBufferPx;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.virtualMinBufferPx;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.tableMainElement;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.virtualForTrackBy;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.tableHeaderElement;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.tableBodyElement;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.cdkVirtualScrollViewport;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.headerStyleMap;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.bodyStyleMap;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.verticalScrollBarWidth;
        /** @type {?} */
        DwTableInnerScrollComponent.prototype.noDateVirtualHeight;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.data$;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.scroll$;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.ngZone;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.platform;
        /**
         * @type {?}
         * @private
         */
        DwTableInnerScrollComponent.prototype.resizeService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table-virtual-scroll.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableVirtualScrollDirective = /** @class */ (function () {
        function DwTableVirtualScrollDirective(templateRef) {
            this.templateRef = templateRef;
        }
        DwTableVirtualScrollDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[dw-virtual-scroll]',
                        exportAs: 'dwVirtualScroll'
                    },] }
        ];
        /** @nocollapse */
        DwTableVirtualScrollDirective.ctorParameters = function () { return [
            { type: core.TemplateRef }
        ]; };
        return DwTableVirtualScrollDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTableVirtualScrollDirective.prototype.templateRef;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table-data.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableDataService = /** @class */ (function () {
        function DwTableDataService() {
            var _this = this;
            this.destroy$ = new rxjs.Subject();
            this.pageIndex$ = new rxjs.BehaviorSubject(1);
            this.frontPagination$ = new rxjs.BehaviorSubject(true);
            this.pageSize$ = new rxjs.BehaviorSubject(10);
            this.listOfData$ = new rxjs.BehaviorSubject([]);
            this.pageIndexDistinct$ = this.pageIndex$.pipe(operators.distinctUntilChanged());
            this.pageSizeDistinct$ = this.pageSize$.pipe(operators.distinctUntilChanged());
            this.listOfCalcOperator$ = new rxjs.BehaviorSubject([]);
            this.queryParams$ = rxjs.combineLatest([
                this.pageIndexDistinct$,
                this.pageSizeDistinct$,
                this.listOfCalcOperator$
            ]).pipe(operators.debounceTime(0), operators.skip(1), operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 3), pageIndex = _b[0], pageSize = _b[1], listOfCalc = _b[2];
                return {
                    pageIndex: pageIndex,
                    pageSize: pageSize,
                    sort: listOfCalc
                        .filter((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return item.sortFn; }))
                        .map((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) {
                        return {
                            key: (/** @type {?} */ (item.key)),
                            value: item.sortOrder
                        };
                    })),
                    filter: listOfCalc
                        .filter((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return item.filterFn; }))
                        .map((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) {
                        return {
                            key: (/** @type {?} */ (item.key)),
                            value: item.filterValue
                        };
                    }))
                };
            })));
            this.listOfDataAfterCalc$ = rxjs.combineLatest([this.listOfData$, this.listOfCalcOperator$]).pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var e_1, _b;
                var _c = __read(_a, 2), listOfData = _c[0], listOfCalcOperator = _c[1];
                /** @type {?} */
                var listOfDataAfterCalc = __spread(listOfData);
                /** @type {?} */
                var listOfFilterOperator = listOfCalcOperator.filter((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    var filterValue = item.filterValue, filterFn = item.filterFn;
                    /** @type {?} */
                    var isReset = filterValue === null || filterValue === undefined || (Array.isArray(filterValue) && (/** @type {?} */ (filterValue)).length === 0);
                    return !isReset && typeof filterFn === 'function';
                }));
                var _loop_1 = function (item) {
                    var filterFn = item.filterFn, filterValue = item.filterValue;
                    listOfDataAfterCalc = listOfDataAfterCalc.filter((/**
                     * @param {?} data
                     * @return {?}
                     */
                    function (data) { return ((/** @type {?} */ (filterFn)))(filterValue, data); }));
                };
                try {
                    for (var listOfFilterOperator_1 = __values(listOfFilterOperator), listOfFilterOperator_1_1 = listOfFilterOperator_1.next(); !listOfFilterOperator_1_1.done; listOfFilterOperator_1_1 = listOfFilterOperator_1.next()) {
                        var item = listOfFilterOperator_1_1.value;
                        _loop_1(item);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (listOfFilterOperator_1_1 && !listOfFilterOperator_1_1.done && (_b = listOfFilterOperator_1.return)) _b.call(listOfFilterOperator_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                /** @type {?} */
                var listOfSortOperator = listOfCalcOperator
                    .filter((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item.sortOrder !== null && typeof item.sortFn === 'function'; }))
                    .sort((/**
                 * @param {?} a
                 * @param {?} b
                 * @return {?}
                 */
                function (a, b) { return +b.sortPriority - +a.sortPriority; }));
                if (listOfCalcOperator.length) {
                    listOfDataAfterCalc.sort((/**
                     * @param {?} record1
                     * @param {?} record2
                     * @return {?}
                     */
                    function (record1, record2) {
                        var e_2, _a;
                        try {
                            for (var listOfSortOperator_1 = __values(listOfSortOperator), listOfSortOperator_1_1 = listOfSortOperator_1.next(); !listOfSortOperator_1_1.done; listOfSortOperator_1_1 = listOfSortOperator_1.next()) {
                                var item = listOfSortOperator_1_1.value;
                                var sortFn = item.sortFn, sortOrder = item.sortOrder;
                                if (sortFn && sortOrder) {
                                    /** @type {?} */
                                    var compareResult = ((/** @type {?} */ (sortFn)))(record1, record2, sortOrder);
                                    if (compareResult !== 0) {
                                        return sortOrder === 'ascend' ? compareResult : -compareResult;
                                    }
                                }
                            }
                        }
                        catch (e_2_1) { e_2 = { error: e_2_1 }; }
                        finally {
                            try {
                                if (listOfSortOperator_1_1 && !listOfSortOperator_1_1.done && (_a = listOfSortOperator_1.return)) _a.call(listOfSortOperator_1);
                            }
                            finally { if (e_2) throw e_2.error; }
                        }
                        return 0;
                    }));
                }
                return listOfDataAfterCalc;
            })));
            this.listOfFrontEndCurrentPageData$ = rxjs.combineLatest([this.pageIndexDistinct$, this.pageSizeDistinct$, this.listOfDataAfterCalc$]).pipe(operators.takeUntil(this.destroy$), operators.filter((/**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                var _a = __read(value, 3), pageIndex = _a[0], pageSize = _a[1], listOfData = _a[2];
                /** @type {?} */
                var maxPageIndex = Math.ceil(listOfData.length / pageSize) || 1;
                return pageIndex <= maxPageIndex;
            })), operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 3), pageIndex = _b[0], pageSize = _b[1], listOfData = _b[2];
                return listOfData.slice((pageIndex - 1) * pageSize, pageIndex * pageSize);
            })));
            this.listOfCurrentPageData$ = this.frontPagination$.pipe(operators.switchMap((/**
             * @param {?} pagination
             * @return {?}
             */
            function (pagination) { return (pagination ? _this.listOfFrontEndCurrentPageData$ : _this.listOfData$); })));
            this.total$ = this.frontPagination$.pipe(operators.switchMap((/**
             * @param {?} pagination
             * @return {?}
             */
            function (pagination) { return (pagination ? _this.listOfDataAfterCalc$ : _this.listOfData$); })), operators.map((/**
             * @param {?} list
             * @return {?}
             */
            function (list) { return list.length; })), operators.distinctUntilChanged());
        }
        /**
         * @param {?} size
         * @return {?}
         */
        DwTableDataService.prototype.updatePageSize = /**
         * @param {?} size
         * @return {?}
         */
        function (size) {
            this.pageSize$.next(size);
        };
        /**
         * @param {?} pagination
         * @return {?}
         */
        DwTableDataService.prototype.updateFrontPagination = /**
         * @param {?} pagination
         * @return {?}
         */
        function (pagination) {
            this.frontPagination$.next(pagination);
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwTableDataService.prototype.updatePageIndex = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.pageIndex$.next(index);
        };
        /**
         * @param {?} list
         * @return {?}
         */
        DwTableDataService.prototype.updateListOfData = /**
         * @param {?} list
         * @return {?}
         */
        function (list) {
            this.listOfData$.next(list);
        };
        /**
         * @return {?}
         */
        DwTableDataService.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTableDataService.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        DwTableDataService.ctorParameters = function () { return []; };
        return DwTableDataService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.pageIndex$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.frontPagination$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.pageSize$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.listOfData$;
        /** @type {?} */
        DwTableDataService.prototype.pageIndexDistinct$;
        /** @type {?} */
        DwTableDataService.prototype.pageSizeDistinct$;
        /** @type {?} */
        DwTableDataService.prototype.listOfCalcOperator$;
        /** @type {?} */
        DwTableDataService.prototype.queryParams$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.listOfDataAfterCalc$;
        /**
         * @type {?}
         * @private
         */
        DwTableDataService.prototype.listOfFrontEndCurrentPageData$;
        /** @type {?} */
        DwTableDataService.prototype.listOfCurrentPageData$;
        /** @type {?} */
        DwTableDataService.prototype.total$;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/table.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'table';
    /**
     * @template T
     */
    var DwTableComponent = /** @class */ (function () {
        function DwTableComponent(elementRef, dwResizeObserver, dwConfigService, cdr, dwTableStyleService, dwTableDataService) {
            var _this = this;
            this.elementRef = elementRef;
            this.dwResizeObserver = dwResizeObserver;
            this.dwConfigService = dwConfigService;
            this.cdr = cdr;
            this.dwTableStyleService = dwTableStyleService;
            this.dwTableDataService = dwTableDataService;
            this.dwTableLayout = 'auto';
            this.dwShowTotal = null;
            this.dwItemRender = null;
            this.dwTitle = null;
            this.dwFooter = null;
            this.dwNoResult = undefined;
            this.dwPageSizeOptions = [10, 20, 30, 40, 50];
            this.dwVirtualItemSize = 0;
            this.dwVirtualMaxBufferPx = 200;
            this.dwVirtualMinBufferPx = 100;
            this.dwVirtualForTrackBy = (/**
             * @param {?} index
             * @return {?}
             */
            function (index) { return index; });
            this.dwLoadingDelay = 0;
            this.dwPageIndex = 1;
            this.dwPageSize = 10;
            this.dwTotal = 0;
            this.dwWidthConfig = [];
            this.dwData = [];
            this.dwPaginationPosition = 'bottom';
            this.dwScroll = { x: null, y: null };
            this.dwFrontPagination = true;
            this.dwTemplateMode = false;
            this.dwShowPagination = true;
            this.dwLoading = false;
            this.dwLoadingIndicator = null;
            this.dwBordered = false;
            this.dwSize = 'default';
            this.dwShowSizeChanger = false;
            this.dwHideOnSinglePage = false;
            this.dwShowQuickJumper = false;
            this.dwSimple = false;
            this.dwPageSizeChange = new core.EventEmitter();
            this.dwPageIndexChange = new core.EventEmitter();
            this.dwQueryParams = new core.EventEmitter();
            this.dwCurrentPageDataChange = new core.EventEmitter();
            /**
             * public data for ngFor tr
             */
            this.data = [];
            this.scrollX = null;
            this.scrollY = null;
            this.theadTemplate = null;
            this.listOfAutoColWidth = [];
            this.listOfManualColWidth = [];
            this.hasFixLeft = false;
            this.hasFixRight = false;
            this.destroy$ = new rxjs.Subject();
            this.loading$ = new rxjs.BehaviorSubject(false);
            this.templateMode$ = new rxjs.BehaviorSubject(false);
            this.verticalScrollBarWidth = 0;
            this.dwConfigService
                .getConfigChangeEventForComponent(DW_CONFIG_COMPONENT_NAME)
                .pipe(operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @return {?}
             */
            function () {
                _this.cdr.markForCheck();
            }));
        }
        /**
         * @param {?} size
         * @return {?}
         */
        DwTableComponent.prototype.onPageSizeChange = /**
         * @param {?} size
         * @return {?}
         */
        function (size) {
            this.dwTableDataService.updatePageSize(size);
        };
        /**
         * @param {?} index
         * @return {?}
         */
        DwTableComponent.prototype.onPageIndexChange = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            this.dwTableDataService.updatePageIndex(index);
        };
        /**
         * @return {?}
         */
        DwTableComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            var _a = this.dwTableDataService, pageIndexDistinct$ = _a.pageIndexDistinct$, pageSizeDistinct$ = _a.pageSizeDistinct$, listOfCurrentPageData$ = _a.listOfCurrentPageData$, total$ = _a.total$, queryParams$ = _a.queryParams$;
            var _b = this.dwTableStyleService, theadTemplate$ = _b.theadTemplate$, hasFixLeft$ = _b.hasFixLeft$, hasFixRight$ = _b.hasFixRight$;
            queryParams$.pipe(operators.takeUntil(this.destroy$)).subscribe(this.dwQueryParams);
            pageIndexDistinct$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} pageIndex
             * @return {?}
             */
            function (pageIndex) {
                if (pageIndex !== _this.dwPageIndex) {
                    _this.dwPageIndex = pageIndex;
                    _this.dwPageIndexChange.next(pageIndex);
                }
            }));
            pageSizeDistinct$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} pageSize
             * @return {?}
             */
            function (pageSize) {
                if (pageSize !== _this.dwPageSize) {
                    _this.dwPageSize = pageSize;
                    _this.dwPageSizeChange.next(pageSize);
                }
            }));
            total$
                .pipe(operators.takeUntil(this.destroy$), operators.filter((/**
             * @return {?}
             */
            function () { return _this.dwFrontPagination; })))
                .subscribe((/**
             * @param {?} total
             * @return {?}
             */
            function (total) {
                if (total !== _this.dwTotal) {
                    _this.dwTotal = total;
                    _this.cdr.markForCheck();
                }
            }));
            listOfCurrentPageData$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                _this.data = data;
                _this.dwCurrentPageDataChange.next(data);
                _this.cdr.markForCheck();
            }));
            theadTemplate$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} theadTemplate
             * @return {?}
             */
            function (theadTemplate) {
                _this.theadTemplate = theadTemplate;
                _this.cdr.markForCheck();
            }));
            hasFixLeft$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} hasFixLeft
             * @return {?}
             */
            function (hasFixLeft) {
                _this.hasFixLeft = hasFixLeft;
                _this.cdr.markForCheck();
            }));
            hasFixRight$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} hasFixRight
             * @return {?}
             */
            function (hasFixRight) {
                _this.hasFixRight = hasFixRight;
                _this.cdr.markForCheck();
            }));
            rxjs.combineLatest([total$, this.loading$, this.templateMode$])
                .pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 3), total = _b[0], loading = _b[1], templateMode = _b[2];
                return total === 0 && !loading && !templateMode;
            })), operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} empty
             * @return {?}
             */
            function (empty) {
                _this.dwTableStyleService.setShowEmpty(empty);
            }));
            this.verticalScrollBarWidth = util.measureScrollbar('vertical');
            this.dwTableStyleService.listOfListOfThWidthPx$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} listOfWidth
             * @return {?}
             */
            function (listOfWidth) {
                _this.listOfAutoColWidth = listOfWidth;
                _this.cdr.markForCheck();
            }));
            this.dwTableStyleService.manualWidthConfigPx$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} listOfWidth
             * @return {?}
             */
            function (listOfWidth) {
                _this.listOfManualColWidth = listOfWidth;
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTableComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwScroll = changes.dwScroll, dwPageIndex = changes.dwPageIndex, dwPageSize = changes.dwPageSize, dwFrontPagination = changes.dwFrontPagination, dwData = changes.dwData, dwWidthConfig = changes.dwWidthConfig, dwNoResult = changes.dwNoResult, dwLoading = changes.dwLoading, dwTemplateMode = changes.dwTemplateMode;
            if (dwPageIndex) {
                this.dwTableDataService.updatePageIndex(this.dwPageIndex);
            }
            if (dwPageSize) {
                this.dwTableDataService.updatePageSize(this.dwPageSize);
            }
            if (dwData) {
                this.dwData = this.dwData || [];
                this.dwTableDataService.updateListOfData(this.dwData);
            }
            if (dwFrontPagination) {
                this.dwTableDataService.updateFrontPagination(this.dwFrontPagination);
            }
            if (dwScroll) {
                this.scrollX = (this.dwScroll && this.dwScroll.x) || null;
                this.scrollY = (this.dwScroll && this.dwScroll.y) || null;
                this.dwTableStyleService.setScroll(this.scrollX, this.scrollY);
            }
            if (dwWidthConfig) {
                this.dwTableStyleService.setTableWidthConfig(this.dwWidthConfig);
            }
            if (dwLoading) {
                this.loading$.next(this.dwLoading);
            }
            if (dwTemplateMode) {
                this.templateMode$.next(this.dwTemplateMode);
            }
            if (dwNoResult) {
                this.dwTableStyleService.setNoResult(this.dwNoResult);
            }
        };
        /**
         * @return {?}
         */
        DwTableComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.dwResizeObserver
                .observe(this.elementRef)
                .pipe(operators.map((/**
             * @param {?} __0
             * @return {?}
             */
            function (_a) {
                var _b = __read(_a, 1), entry = _b[0];
                var width = entry.target.getBoundingClientRect().width;
                /** @type {?} */
                var scrollBarWidth = _this.scrollY ? _this.verticalScrollBarWidth : 0;
                return Math.floor(width - scrollBarWidth);
            })), operators.takeUntil(this.destroy$))
                .subscribe(this.dwTableStyleService.hostWidth$);
            if (this.dwTableInnerScrollComponent && this.dwTableInnerScrollComponent.cdkVirtualScrollViewport) {
                this.cdkVirtualScrollViewport = this.dwTableInnerScrollComponent.cdkVirtualScrollViewport;
            }
        };
        /**
         * @return {?}
         */
        DwTableComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTableComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table',
                        exportAs: 'dwTable',
                        providers: [DwTableStyleService, DwTableDataService],
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <dw-spin [dwDelay]=\"dwLoadingDelay\" [dwSpinning]=\"dwLoading\" [dwIndicator]=\"dwLoadingIndicator\">\n      <ng-container *ngIf=\"dwPaginationPosition === 'both' || dwPaginationPosition === 'top'\">\n        <ng-template [ngTemplateOutlet]=\"paginationTemplate\"></ng-template>\n      </ng-container>\n      <div\n        #tableMainElement\n        class=\"ant-table\"\n        [class.ant-table-fixed-header]=\"dwData.length && scrollY\"\n        [class.ant-table-fixed-column]=\"scrollX\"\n        [class.ant-table-has-fix-left]=\"hasFixLeft\"\n        [class.ant-table-has-fix-right]=\"hasFixRight\"\n        [class.ant-table-bordered]=\"dwBordered\"\n        [class.ant-table-middle]=\"dwSize === 'middle'\"\n        [class.ant-table-small]=\"dwSize === 'small'\"\n      >\n        <dw-table-title-footer [title]=\"dwTitle\" *ngIf=\"dwTitle\"></dw-table-title-footer>\n        <dw-table-inner-scroll\n          *ngIf=\"scrollY || scrollX; else defaultTemplate\"\n          [data]=\"data\"\n          [scrollX]=\"scrollX\"\n          [scrollY]=\"scrollY\"\n          [contentTemplate]=\"contentTemplate\"\n          [listOfColWidth]=\"listOfAutoColWidth\"\n          [theadTemplate]=\"theadTemplate\"\n          [verticalScrollBarWidth]=\"verticalScrollBarWidth\"\n          [virtualTemplate]=\"dwVirtualScrollDirective ? dwVirtualScrollDirective.templateRef : null\"\n          [virtualItemSize]=\"dwVirtualItemSize\"\n          [virtualMaxBufferPx]=\"dwVirtualMaxBufferPx\"\n          [virtualMinBufferPx]=\"dwVirtualMinBufferPx\"\n          [tableMainElement]=\"tableMainElement\"\n          [virtualForTrackBy]=\"dwVirtualForTrackBy\"\n        ></dw-table-inner-scroll>\n        <ng-template #defaultTemplate>\n          <dw-table-inner-default\n            [tableLayout]=\"dwTableLayout\"\n            [listOfColWidth]=\"listOfManualColWidth\"\n            [theadTemplate]=\"theadTemplate\"\n            [contentTemplate]=\"contentTemplate\"\n          ></dw-table-inner-default>\n        </ng-template>\n        <dw-table-title-footer [footer]=\"dwFooter\" *ngIf=\"dwFooter\"></dw-table-title-footer>\n      </div>\n      <ng-container *ngIf=\"dwPaginationPosition === 'both' || dwPaginationPosition === 'bottom'\">\n        <ng-template [ngTemplateOutlet]=\"paginationTemplate\"></ng-template>\n      </ng-container>\n    </dw-spin>\n    <ng-template #paginationTemplate>\n      <dw-pagination\n        *ngIf=\"dwShowPagination && data.length\"\n        class=\"ant-table-pagination ant-table-pagination-right\"\n        [dwShowSizeChanger]=\"dwShowSizeChanger\"\n        [dwPageSizeOptions]=\"dwPageSizeOptions\"\n        [dwItemRender]=\"dwItemRender!\"\n        [dwShowQuickJumper]=\"dwShowQuickJumper\"\n        [dwHideOnSinglePage]=\"dwHideOnSinglePage\"\n        [dwShowTotal]=\"dwShowTotal\"\n        [dwSize]=\"dwSize === 'default' ? 'default' : 'small'\"\n        [dwPageSize]=\"dwPageSize\"\n        [dwTotal]=\"dwTotal\"\n        [dwSimple]=\"dwSimple\"\n        [dwPageIndex]=\"dwPageIndex\"\n        (dwPageSizeChange)=\"onPageSizeChange($event)\"\n        (dwPageIndexChange)=\"onPageIndexChange($event)\"\n      >\n      </dw-pagination>\n    </ng-template>\n    <ng-template #contentTemplate>\n      <ng-content></ng-content>\n    </ng-template>\n  ",
                        host: {
                            '[class.ant-table-wrapper]': 'true'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTableComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: resizeObservers.DwResizeObserver },
            { type: config.DwConfigService },
            { type: core.ChangeDetectorRef },
            { type: DwTableStyleService },
            { type: DwTableDataService }
        ]; };
        DwTableComponent.propDecorators = {
            dwTableLayout: [{ type: core.Input }],
            dwShowTotal: [{ type: core.Input }],
            dwItemRender: [{ type: core.Input }],
            dwTitle: [{ type: core.Input }],
            dwFooter: [{ type: core.Input }],
            dwNoResult: [{ type: core.Input }],
            dwPageSizeOptions: [{ type: core.Input }],
            dwVirtualItemSize: [{ type: core.Input }],
            dwVirtualMaxBufferPx: [{ type: core.Input }],
            dwVirtualMinBufferPx: [{ type: core.Input }],
            dwVirtualForTrackBy: [{ type: core.Input }],
            dwLoadingDelay: [{ type: core.Input }],
            dwPageIndex: [{ type: core.Input }],
            dwPageSize: [{ type: core.Input }],
            dwTotal: [{ type: core.Input }],
            dwWidthConfig: [{ type: core.Input }],
            dwData: [{ type: core.Input }],
            dwPaginationPosition: [{ type: core.Input }],
            dwScroll: [{ type: core.Input }],
            dwFrontPagination: [{ type: core.Input }],
            dwTemplateMode: [{ type: core.Input }],
            dwShowPagination: [{ type: core.Input }],
            dwLoading: [{ type: core.Input }],
            dwLoadingIndicator: [{ type: core.Input }],
            dwBordered: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwShowSizeChanger: [{ type: core.Input }],
            dwHideOnSinglePage: [{ type: core.Input }],
            dwShowQuickJumper: [{ type: core.Input }],
            dwSimple: [{ type: core.Input }],
            dwPageSizeChange: [{ type: core.Output }],
            dwPageIndexChange: [{ type: core.Output }],
            dwQueryParams: [{ type: core.Output }],
            dwCurrentPageDataChange: [{ type: core.Output }],
            dwVirtualScrollDirective: [{ type: core.ContentChild, args: [DwTableVirtualScrollDirective, { static: false },] }],
            dwTableInnerScrollComponent: [{ type: core.ViewChild, args: [DwTableInnerScrollComponent,] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTableComponent.prototype, "dwFrontPagination", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTableComponent.prototype, "dwTemplateMode", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTableComponent.prototype, "dwShowPagination", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTableComponent.prototype, "dwLoading", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Object)
        ], DwTableComponent.prototype, "dwLoadingIndicator", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTableComponent.prototype, "dwBordered", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTableComponent.prototype, "dwSize", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTableComponent.prototype, "dwShowSizeChanger", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTableComponent.prototype, "dwHideOnSinglePage", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTableComponent.prototype, "dwShowQuickJumper", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME), util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTableComponent.prototype, "dwSimple", void 0);
        return DwTableComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwFrontPagination;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwTemplateMode;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwShowPagination;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwLoading;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwBordered;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwShowSizeChanger;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwHideOnSinglePage;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwShowQuickJumper;
        /** @type {?} */
        DwTableComponent.ngAcceptInputType_dwSimple;
        /** @type {?} */
        DwTableComponent.prototype.dwTableLayout;
        /** @type {?} */
        DwTableComponent.prototype.dwShowTotal;
        /** @type {?} */
        DwTableComponent.prototype.dwItemRender;
        /** @type {?} */
        DwTableComponent.prototype.dwTitle;
        /** @type {?} */
        DwTableComponent.prototype.dwFooter;
        /** @type {?} */
        DwTableComponent.prototype.dwNoResult;
        /** @type {?} */
        DwTableComponent.prototype.dwPageSizeOptions;
        /** @type {?} */
        DwTableComponent.prototype.dwVirtualItemSize;
        /** @type {?} */
        DwTableComponent.prototype.dwVirtualMaxBufferPx;
        /** @type {?} */
        DwTableComponent.prototype.dwVirtualMinBufferPx;
        /** @type {?} */
        DwTableComponent.prototype.dwVirtualForTrackBy;
        /** @type {?} */
        DwTableComponent.prototype.dwLoadingDelay;
        /** @type {?} */
        DwTableComponent.prototype.dwPageIndex;
        /** @type {?} */
        DwTableComponent.prototype.dwPageSize;
        /** @type {?} */
        DwTableComponent.prototype.dwTotal;
        /** @type {?} */
        DwTableComponent.prototype.dwWidthConfig;
        /** @type {?} */
        DwTableComponent.prototype.dwData;
        /** @type {?} */
        DwTableComponent.prototype.dwPaginationPosition;
        /** @type {?} */
        DwTableComponent.prototype.dwScroll;
        /** @type {?} */
        DwTableComponent.prototype.dwFrontPagination;
        /** @type {?} */
        DwTableComponent.prototype.dwTemplateMode;
        /** @type {?} */
        DwTableComponent.prototype.dwShowPagination;
        /** @type {?} */
        DwTableComponent.prototype.dwLoading;
        /** @type {?} */
        DwTableComponent.prototype.dwLoadingIndicator;
        /** @type {?} */
        DwTableComponent.prototype.dwBordered;
        /** @type {?} */
        DwTableComponent.prototype.dwSize;
        /** @type {?} */
        DwTableComponent.prototype.dwShowSizeChanger;
        /** @type {?} */
        DwTableComponent.prototype.dwHideOnSinglePage;
        /** @type {?} */
        DwTableComponent.prototype.dwShowQuickJumper;
        /** @type {?} */
        DwTableComponent.prototype.dwSimple;
        /** @type {?} */
        DwTableComponent.prototype.dwPageSizeChange;
        /** @type {?} */
        DwTableComponent.prototype.dwPageIndexChange;
        /** @type {?} */
        DwTableComponent.prototype.dwQueryParams;
        /** @type {?} */
        DwTableComponent.prototype.dwCurrentPageDataChange;
        /**
         * public data for ngFor tr
         * @type {?}
         */
        DwTableComponent.prototype.data;
        /** @type {?} */
        DwTableComponent.prototype.cdkVirtualScrollViewport;
        /** @type {?} */
        DwTableComponent.prototype.scrollX;
        /** @type {?} */
        DwTableComponent.prototype.scrollY;
        /** @type {?} */
        DwTableComponent.prototype.theadTemplate;
        /** @type {?} */
        DwTableComponent.prototype.listOfAutoColWidth;
        /** @type {?} */
        DwTableComponent.prototype.listOfManualColWidth;
        /** @type {?} */
        DwTableComponent.prototype.hasFixLeft;
        /** @type {?} */
        DwTableComponent.prototype.hasFixRight;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.loading$;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.templateMode$;
        /** @type {?} */
        DwTableComponent.prototype.dwVirtualScrollDirective;
        /** @type {?} */
        DwTableComponent.prototype.dwTableInnerScrollComponent;
        /** @type {?} */
        DwTableComponent.prototype.verticalScrollBarWidth;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.dwResizeObserver;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.dwTableStyleService;
        /**
         * @type {?}
         * @private
         */
        DwTableComponent.prototype.dwTableDataService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/tbody.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTbodyComponent = /** @class */ (function () {
        function DwTbodyComponent(dwTableStyleService) {
            this.dwTableStyleService = dwTableStyleService;
            this.isInsideTable = false;
            this.showEmpty$ = new rxjs.BehaviorSubject(false);
            this.noResult$ = new rxjs.BehaviorSubject(undefined);
            this.listOfMeasureColumn$ = new rxjs.BehaviorSubject([]);
            this.isInsideTable = !!this.dwTableStyleService;
            if (this.dwTableStyleService) {
                var _a = this.dwTableStyleService, showEmpty$ = _a.showEmpty$, noResult$ = _a.noResult$, listOfMeasureColumn$ = _a.listOfMeasureColumn$;
                noResult$.subscribe(this.noResult$);
                listOfMeasureColumn$.subscribe(this.listOfMeasureColumn$);
                showEmpty$.subscribe(this.showEmpty$);
            }
        }
        /**
         * @param {?} listOfAutoWidth
         * @return {?}
         */
        DwTbodyComponent.prototype.onListOfAutoWidthChange = /**
         * @param {?} listOfAutoWidth
         * @return {?}
         */
        function (listOfAutoWidth) {
            this.dwTableStyleService.setListOfAutoWidth(listOfAutoWidth);
        };
        DwTbodyComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'tbody',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <ng-container *ngIf=\"listOfMeasureColumn$ | async as listOfMeasureColumn\">\n      <tr\n        dw-table-measure-row\n        *ngIf=\"isInsideTable && listOfMeasureColumn.length\"\n        [listOfMeasureColumn]=\"listOfMeasureColumn\"\n        (listOfAutoWidth)=\"onListOfAutoWidthChange($event)\"\n      ></tr>\n    </ng-container>\n    <ng-content></ng-content>\n    <tr class=\"ant-table-placeholder\" dw-table-fixed-row *ngIf=\"showEmpty$ | async\">\n      <dw-embed-empty dwComponentName=\"table\" [specificContent]=\"(noResult$ | async)!\"></dw-embed-empty>\n    </tr>\n  ",
                        host: {
                            '[class.ant-table-tbody]': 'isInsideTable'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTbodyComponent.ctorParameters = function () { return [
            { type: DwTableStyleService, decorators: [{ type: core.Optional }] }
        ]; };
        return DwTbodyComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTbodyComponent.prototype.isInsideTable;
        /** @type {?} */
        DwTbodyComponent.prototype.showEmpty$;
        /** @type {?} */
        DwTbodyComponent.prototype.noResult$;
        /** @type {?} */
        DwTbodyComponent.prototype.listOfMeasureColumn$;
        /**
         * @type {?}
         * @private
         */
        DwTbodyComponent.prototype.dwTableStyleService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/tr.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTrDirective = /** @class */ (function () {
        function DwTrDirective(dwTableStyleService) {
            var _this = this;
            this.dwTableStyleService = dwTableStyleService;
            this.destroy$ = new rxjs.Subject();
            this.listOfFixedColumns$ = new rxjs.ReplaySubject(1);
            this.listOfColumns$ = new rxjs.ReplaySubject(1);
            this.listOfFixedColumnsChanges$ = this.listOfFixedColumns$.pipe(operators.switchMap((/**
             * @param {?} list
             * @return {?}
             */
            function (list) {
                return rxjs.merge.apply(void 0, __spread([_this.listOfFixedColumns$], list.map((/**
                 * @param {?} c
                 * @return {?}
                 */
                function (c) { return c.changes$; })))).pipe(operators.flatMap((/**
                 * @return {?}
                 */
                function () { return _this.listOfFixedColumns$; })));
            })), operators.takeUntil(this.destroy$));
            this.listOfFixedLeftColumnChanges$ = this.listOfFixedColumnsChanges$.pipe(operators.map((/**
             * @param {?} list
             * @return {?}
             */
            function (list) { return list.filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.dwLeft !== false; })); })));
            this.listOfFixedRightColumnChanges$ = this.listOfFixedColumnsChanges$.pipe(operators.map((/**
             * @param {?} list
             * @return {?}
             */
            function (list) { return list.filter((/**
             * @param {?} item
             * @return {?}
             */
            function (item) { return item.dwRight !== false; })); })));
            this.listOfColumnsChanges$ = this.listOfColumns$.pipe(operators.switchMap((/**
             * @param {?} list
             * @return {?}
             */
            function (list) {
                return rxjs.merge.apply(void 0, __spread([_this.listOfColumns$], list.map((/**
                 * @param {?} c
                 * @return {?}
                 */
                function (c) { return c.changes$; })))).pipe(operators.flatMap((/**
                 * @return {?}
                 */
                function () { return _this.listOfColumns$; })));
            })), operators.takeUntil(this.destroy$));
            this.isInsideTable = false;
            this.isInsideTable = !!dwTableStyleService;
        }
        /**
         * @return {?}
         */
        DwTrDirective.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            if (this.dwTableStyleService) {
                this.listOfCellFixedDirective.changes
                    .pipe(operators.startWith(this.listOfCellFixedDirective), operators.takeUntil(this.destroy$))
                    .subscribe(this.listOfFixedColumns$);
                this.listOfDwThDirective.changes.pipe(operators.startWith(this.listOfDwThDirective), operators.takeUntil(this.destroy$)).subscribe(this.listOfColumns$);
                /** set last left and first right **/
                this.listOfFixedLeftColumnChanges$.subscribe((/**
                 * @param {?} listOfFixedLeft
                 * @return {?}
                 */
                function (listOfFixedLeft) {
                    listOfFixedLeft.forEach((/**
                     * @param {?} cell
                     * @return {?}
                     */
                    function (cell) { return cell.setIsLastLeft(cell === listOfFixedLeft[listOfFixedLeft.length - 1]); }));
                }));
                this.listOfFixedRightColumnChanges$.subscribe((/**
                 * @param {?} listOfFixedRight
                 * @return {?}
                 */
                function (listOfFixedRight) {
                    listOfFixedRight.forEach((/**
                     * @param {?} cell
                     * @return {?}
                     */
                    function (cell) { return cell.setIsFirstRight(cell === listOfFixedRight[0]); }));
                }));
                /** calculate fixed dwLeft and dwRight **/
                rxjs.combineLatest([this.dwTableStyleService.listOfListOfThWidth$, this.listOfFixedLeftColumnChanges$]).subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                function (_a) {
                    var _b = __read(_a, 2), listOfAutoWidth = _b[0], listOfLeftCell = _b[1];
                    listOfLeftCell.forEach((/**
                     * @param {?} cell
                     * @param {?} index
                     * @return {?}
                     */
                    function (cell, index) {
                        if (cell.isAutoLeft) {
                            /** @type {?} */
                            var currentArray = listOfLeftCell.slice(0, index);
                            /** @type {?} */
                            var count = currentArray.reduce((/**
                             * @param {?} pre
                             * @param {?} cur
                             * @return {?}
                             */
                            function (pre, cur) { return pre + (cur.colspan || cur.colSpan || 1); }), 0);
                            /** @type {?} */
                            var width = listOfAutoWidth.slice(0, count).reduce((/**
                             * @param {?} pre
                             * @param {?} cur
                             * @return {?}
                             */
                            function (pre, cur) { return pre + cur; }), 0);
                            cell.setAutoLeftWidth(width + "px");
                        }
                    }));
                }));
                rxjs.combineLatest([this.dwTableStyleService.listOfListOfThWidth$, this.listOfFixedRightColumnChanges$]).subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                function (_a) {
                    var _b = __read(_a, 2), listOfAutoWidth = _b[0], listOfRightCell = _b[1];
                    listOfRightCell.forEach((/**
                     * @param {?} _
                     * @param {?} index
                     * @return {?}
                     */
                    function (_, index) {
                        /** @type {?} */
                        var cell = listOfRightCell[listOfRightCell.length - index - 1];
                        if (cell.isAutoRight) {
                            /** @type {?} */
                            var currentArray = listOfRightCell.slice(listOfRightCell.length - index, listOfRightCell.length);
                            /** @type {?} */
                            var count = currentArray.reduce((/**
                             * @param {?} pre
                             * @param {?} cur
                             * @return {?}
                             */
                            function (pre, cur) { return pre + (cur.colspan || cur.colSpan || 1); }), 0);
                            /** @type {?} */
                            var width = listOfAutoWidth
                                .slice(listOfAutoWidth.length - count, listOfAutoWidth.length)
                                .reduce((/**
                             * @param {?} pre
                             * @param {?} cur
                             * @return {?}
                             */
                            function (pre, cur) { return pre + cur; }), 0);
                            cell.setAutoRightWidth(width + "px");
                        }
                    }));
                }));
            }
        };
        /**
         * @return {?}
         */
        DwTrDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTrDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'tr:not([mat-row]):not([mat-header-row]):not([dw-table-measure-row]):not([dwExpand]):not([dw-table-fixed-row])',
                        host: {
                            '[class.ant-table-row]': 'isInsideTable'
                        }
                    },] }
        ];
        /** @nocollapse */
        DwTrDirective.ctorParameters = function () { return [
            { type: DwTableStyleService, decorators: [{ type: core.Optional }] }
        ]; };
        DwTrDirective.propDecorators = {
            listOfDwThDirective: [{ type: core.ContentChildren, args: [DwThMeasureDirective,] }],
            listOfCellFixedDirective: [{ type: core.ContentChildren, args: [DwCellFixedDirective,] }]
        };
        return DwTrDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTrDirective.prototype.listOfDwThDirective;
        /** @type {?} */
        DwTrDirective.prototype.listOfCellFixedDirective;
        /**
         * @type {?}
         * @private
         */
        DwTrDirective.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTrDirective.prototype.listOfFixedColumns$;
        /**
         * @type {?}
         * @private
         */
        DwTrDirective.prototype.listOfColumns$;
        /** @type {?} */
        DwTrDirective.prototype.listOfFixedColumnsChanges$;
        /** @type {?} */
        DwTrDirective.prototype.listOfFixedLeftColumnChanges$;
        /** @type {?} */
        DwTrDirective.prototype.listOfFixedRightColumnChanges$;
        /** @type {?} */
        DwTrDirective.prototype.listOfColumnsChanges$;
        /** @type {?} */
        DwTrDirective.prototype.isInsideTable;
        /**
         * @type {?}
         * @private
         */
        DwTrDirective.prototype.dwTableStyleService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/thead.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTheadComponent = /** @class */ (function () {
        function DwTheadComponent(elementRef, renderer, dwTableStyleService, dwTableDataService) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.dwTableStyleService = dwTableStyleService;
            this.dwTableDataService = dwTableDataService;
            this.destroy$ = new rxjs.Subject();
            this.isInsideTable = false;
            /**
             * @deprecated use dwSortFn and dwSortPriority instead *
             */
            this.dwSingleSort = false;
            /**
             * @deprecated use dwSortOrderChange instead *
             */
            this.dwSortChange = new core.EventEmitter();
            this.dwSortOrderChange = new core.EventEmitter();
            this.isInsideTable = !!this.dwTableStyleService;
        }
        /**
         * @return {?}
         */
        DwTheadComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            if (this.dwTableStyleService) {
                this.dwTableStyleService.setTheadTemplate(this.templateRef);
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTheadComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwSingleSort = changes.dwSingleSort;
            if (dwSingleSort) {
                logger.warnDeprecation("'dwSingleSort' is deprecated and will be removed in 10.0.0. Please use 'dwSortFn' and 'dwSortPriority' instead.");
            }
        };
        /**
         * @return {?}
         */
        DwTheadComponent.prototype.ngAfterContentInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.dwTableStyleService) {
                /** @type {?} */
                var firstTableRow$ = (/** @type {?} */ (this.listOfDwTrDirective.changes.pipe(operators.startWith(this.listOfDwTrDirective), operators.map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) { return item && item.first; })))));
                /** @type {?} */
                var listOfColumnsChanges$_1 = firstTableRow$.pipe(operators.switchMap((/**
                 * @param {?} firstTableRow
                 * @return {?}
                 */
                function (firstTableRow) { return (firstTableRow ? firstTableRow.listOfColumnsChanges$ : rxjs.EMPTY); })), operators.takeUntil(this.destroy$));
                listOfColumnsChanges$_1.subscribe((/**
                 * @param {?} data
                 * @return {?}
                 */
                function (data) { return _this.dwTableStyleService.setListOfTh(data); }));
                /** TODO: need reset the measure row when scrollX change **/
                this.dwTableStyleService.enableAutoMeasure$
                    .pipe(operators.switchMap((/**
                 * @param {?} enable
                 * @return {?}
                 */
                function (enable) { return (enable ? listOfColumnsChanges$_1 : rxjs.of([])); })))
                    .pipe(operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @param {?} data
                 * @return {?}
                 */
                function (data) { return _this.dwTableStyleService.setListOfMeasureColumn(data); }));
                /** @type {?} */
                var listOfFixedLeftColumnChanges$ = firstTableRow$.pipe(operators.switchMap((/**
                 * @param {?} firstTr
                 * @return {?}
                 */
                function (firstTr) { return (firstTr ? firstTr.listOfFixedLeftColumnChanges$ : rxjs.EMPTY); })), operators.takeUntil(this.destroy$));
                /** @type {?} */
                var listOfFixedRightColumnChanges$ = firstTableRow$.pipe(operators.switchMap((/**
                 * @param {?} firstTr
                 * @return {?}
                 */
                function (firstTr) { return (firstTr ? firstTr.listOfFixedRightColumnChanges$ : rxjs.EMPTY); })), operators.takeUntil(this.destroy$));
                listOfFixedLeftColumnChanges$.subscribe((/**
                 * @param {?} listOfFixedLeftColumn
                 * @return {?}
                 */
                function (listOfFixedLeftColumn) {
                    _this.dwTableStyleService.setHasFixLeft(listOfFixedLeftColumn.length !== 0);
                }));
                listOfFixedRightColumnChanges$.subscribe((/**
                 * @param {?} listOfFixedRightColumn
                 * @return {?}
                 */
                function (listOfFixedRightColumn) {
                    _this.dwTableStyleService.setHasFixRight(listOfFixedRightColumn.length !== 0);
                }));
            }
            if (this.dwTableDataService) {
                /** @type {?} */
                var listOfColumn$_1 = (/** @type {?} */ (this.listOfDwThAddOnComponent.changes.pipe(operators.startWith(this.listOfDwThAddOnComponent))));
                /** @type {?} */
                var manualSort$ = listOfColumn$_1.pipe(operators.switchMap((/**
                 * @return {?}
                 */
                function () { return rxjs.merge.apply(void 0, __spread(_this.listOfDwThAddOnComponent.map((/**
                 * @param {?} th
                 * @return {?}
                 */
                function (th) { return th.manualClickOrder$; })))); })), operators.takeUntil(this.destroy$));
                manualSort$.subscribe((/**
                 * @param {?} data
                 * @return {?}
                 */
                function (data) {
                    /** @type {?} */
                    var emitValue = { key: data.dwColumnKey, value: data.sortOrder };
                    _this.dwSortChange.emit(emitValue);
                    _this.dwSortOrderChange.emit(emitValue);
                    if (_this.dwSingleSort || (data.dwSortFn && data.dwSortPriority === false)) {
                        _this.listOfDwThAddOnComponent.filter((/**
                         * @param {?} th
                         * @return {?}
                         */
                        function (th) { return th !== data; })).forEach((/**
                         * @param {?} th
                         * @return {?}
                         */
                        function (th) { return th.clearSortOrder(); }));
                    }
                }));
                /** @type {?} */
                var listOfCalcOperator$ = listOfColumn$_1.pipe(operators.switchMap((/**
                 * @param {?} list
                 * @return {?}
                 */
                function (list) {
                    return rxjs.merge.apply(void 0, __spread([listOfColumn$_1], list.map((/**
                     * @param {?} c
                     * @return {?}
                     */
                    function (c) { return c.calcOperatorChange$; })))).pipe(operators.flatMap((/**
                     * @return {?}
                     */
                    function () { return listOfColumn$_1; })));
                })), operators.map((/**
                 * @param {?} list
                 * @return {?}
                 */
                function (list) {
                    return list
                        .filter((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) { return !!item.dwSortFn || !!item.dwFilterFn; }))
                        .map((/**
                     * @param {?} item
                     * @return {?}
                     */
                    function (item) {
                        var dwSortFn = item.dwSortFn, sortOrder = item.sortOrder, dwFilterFn = item.dwFilterFn, dwFilterValue = item.dwFilterValue, dwSortPriority = item.dwSortPriority, dwColumnKey = item.dwColumnKey;
                        return {
                            key: dwColumnKey,
                            sortFn: dwSortFn,
                            sortPriority: dwSortPriority,
                            sortOrder: (/** @type {?} */ (sortOrder)),
                            filterFn: (/** @type {?} */ (dwFilterFn)),
                            filterValue: dwFilterValue
                        };
                    }));
                })), 
                // TODO: after checked error here
                operators.delay(0));
                listOfCalcOperator$.subscribe((/**
                 * @param {?} list
                 * @return {?}
                 */
                function (list) {
                    _this.dwTableDataService.listOfCalcOperator$.next(list);
                }));
            }
        };
        /**
         * @return {?}
         */
        DwTheadComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            if (this.dwTableStyleService) {
                this.renderer.removeChild(this.renderer.parentNode(this.elementRef.nativeElement), this.elementRef.nativeElement);
            }
        };
        /**
         * @return {?}
         */
        DwTheadComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTheadComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'thead:not(.ant-table-thead)',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <ng-template #contentTemplate>\n      <ng-content></ng-content>\n    </ng-template>\n    <ng-container *ngIf=\"!isInsideTable\">\n      <ng-template [ngTemplateOutlet]=\"contentTemplate\"></ng-template>\n    </ng-container>\n  "
                    }] }
        ];
        /** @nocollapse */
        DwTheadComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: core.Renderer2 },
            { type: DwTableStyleService, decorators: [{ type: core.Optional }] },
            { type: DwTableDataService, decorators: [{ type: core.Optional }] }
        ]; };
        DwTheadComponent.propDecorators = {
            templateRef: [{ type: core.ViewChild, args: ['contentTemplate', { static: true },] }],
            listOfDwTrDirective: [{ type: core.ContentChildren, args: [DwTrDirective, { descendants: true },] }],
            listOfDwThAddOnComponent: [{ type: core.ContentChildren, args: [DwThAddOnComponent, { descendants: true },] }],
            dwSingleSort: [{ type: core.Input }],
            dwSortChange: [{ type: core.Output }],
            dwSortOrderChange: [{ type: core.Output }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTheadComponent.prototype, "dwSingleSort", void 0);
        return DwTheadComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTheadComponent.ngAcceptInputType_dwSingleSort;
        /**
         * @type {?}
         * @private
         */
        DwTheadComponent.prototype.destroy$;
        /** @type {?} */
        DwTheadComponent.prototype.isInsideTable;
        /** @type {?} */
        DwTheadComponent.prototype.templateRef;
        /** @type {?} */
        DwTheadComponent.prototype.listOfDwTrDirective;
        /** @type {?} */
        DwTheadComponent.prototype.listOfDwThAddOnComponent;
        /**
         * @deprecated use dwSortFn and dwSortPriority instead *
         * @type {?}
         */
        DwTheadComponent.prototype.dwSingleSort;
        /**
         * @deprecated use dwSortOrderChange instead *
         * @type {?}
         */
        DwTheadComponent.prototype.dwSortChange;
        /** @type {?} */
        DwTheadComponent.prototype.dwSortOrderChange;
        /**
         * @type {?}
         * @private
         */
        DwTheadComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwTheadComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTheadComponent.prototype.dwTableStyleService;
        /**
         * @type {?}
         * @private
         */
        DwTheadComponent.prototype.dwTableDataService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/title-footer.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableTitleFooterComponent = /** @class */ (function () {
        function DwTableTitleFooterComponent() {
            this.title = null;
            this.footer = null;
        }
        DwTableTitleFooterComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-table-title-footer',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <ng-container *dwStringTemplateOutlet=\"title\">{{ title }}</ng-container>\n    <ng-container *dwStringTemplateOutlet=\"footer\">{{ footer }}</ng-container>\n  ",
                        host: {
                            '[class.ant-table-title]': "title !== null",
                            '[class.ant-table-footer]': "footer !== null"
                        }
                    }] }
        ];
        DwTableTitleFooterComponent.propDecorators = {
            title: [{ type: core.Input }],
            footer: [{ type: core.Input }]
        };
        return DwTableTitleFooterComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTableTitleFooterComponent.prototype.title;
        /** @type {?} */
        DwTableTitleFooterComponent.prototype.footer;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/tr-expand.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTrExpandDirective = /** @class */ (function () {
        function DwTrExpandDirective() {
            this.dwExpand = true;
        }
        DwTrExpandDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'tr[dwExpand]',
                        host: {
                            '[class.ant-table-expanded-row]': 'true',
                            '[hidden]': "!dwExpand"
                        }
                    },] }
        ];
        DwTrExpandDirective.propDecorators = {
            dwExpand: [{ type: core.Input }]
        };
        return DwTrExpandDirective;
    }());
    if (false) {
        /** @type {?} */
        DwTrExpandDirective.prototype.dwExpand;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table/tr-measure.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTrMeasureComponent = /** @class */ (function () {
        function DwTrMeasureComponent(dwResizeObserver, ngZone) {
            this.dwResizeObserver = dwResizeObserver;
            this.ngZone = ngZone;
            this.listOfMeasureColumn = [];
            this.listOfAutoWidth = new core.EventEmitter();
            this.destroy$ = new rxjs.Subject();
        }
        /**
         * @param {?} _
         * @param {?} key
         * @return {?}
         */
        DwTrMeasureComponent.prototype.trackByFunc = /**
         * @param {?} _
         * @param {?} key
         * @return {?}
         */
        function (_, key) {
            return key;
        };
        /**
         * @return {?}
         */
        DwTrMeasureComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.listOfTdElement.changes
                .pipe(operators.startWith(this.listOfTdElement))
                .pipe(operators.switchMap((/**
             * @param {?} list
             * @return {?}
             */
            function (list) {
                return (/** @type {?} */ (rxjs.combineLatest(list.toArray().map((/**
                 * @param {?} item
                 * @return {?}
                 */
                function (item) {
                    return _this.dwResizeObserver.observe(item).pipe(operators.map((/**
                     * @param {?} __0
                     * @return {?}
                     */
                    function (_a) {
                        var _b = __read(_a, 1), entry = _b[0];
                        var width = entry.target.getBoundingClientRect().width;
                        return Math.floor(width);
                    })));
                })))));
            })), operators.debounceTime(16), operators.takeUntil(this.destroy$))
                .subscribe((/**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                _this.ngZone.run((/**
                 * @return {?}
                 */
                function () {
                    _this.listOfAutoWidth.next(data);
                }));
            }));
        };
        /**
         * @return {?}
         */
        DwTrMeasureComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        DwTrMeasureComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'tr[dw-table-measure-row]',
                        preserveWhitespaces: false,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        template: "\n    <td\n      #tdElement\n      class=\"dw-disable-td\"\n      style=\"padding: 0px; border: 0px; height: 0px;\"\n      *ngFor=\"let th of listOfMeasureColumn; trackBy: trackByFunc\"\n    ></td>\n  ",
                        host: {
                            '[class.ant-table-measure-now]': 'true'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTrMeasureComponent.ctorParameters = function () { return [
            { type: resizeObservers.DwResizeObserver },
            { type: core.NgZone }
        ]; };
        DwTrMeasureComponent.propDecorators = {
            listOfMeasureColumn: [{ type: core.Input }],
            listOfAutoWidth: [{ type: core.Output }],
            listOfTdElement: [{ type: core.ViewChildren, args: ['tdElement',] }]
        };
        return DwTrMeasureComponent;
    }());
    if (false) {
        /** @type {?} */
        DwTrMeasureComponent.prototype.listOfMeasureColumn;
        /** @type {?} */
        DwTrMeasureComponent.prototype.listOfAutoWidth;
        /** @type {?} */
        DwTrMeasureComponent.prototype.listOfTdElement;
        /**
         * @type {?}
         * @private
         */
        DwTrMeasureComponent.prototype.destroy$;
        /**
         * @type {?}
         * @private
         */
        DwTrMeasureComponent.prototype.dwResizeObserver;
        /**
         * @type {?}
         * @private
         */
        DwTrMeasureComponent.prototype.ngZone;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTableModule = /** @class */ (function () {
        function DwTableModule() {
        }
        DwTableModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [
                            DwTableComponent,
                            DwThAddOnComponent,
                            DwTableCellDirective,
                            DwThMeasureDirective,
                            DwTdAddOnComponent,
                            DwTheadComponent,
                            DwTbodyComponent,
                            DwTrDirective,
                            DwTrExpandDirective,
                            DwTableVirtualScrollDirective,
                            DwCellFixedDirective,
                            DwTableContentComponent,
                            DwTableTitleFooterComponent,
                            DwTableInnerDefaultComponent,
                            DwTableInnerScrollComponent,
                            DwTrMeasureComponent,
                            DwRowIndentDirective,
                            DwRowExpandButtonDirective,
                            DwCellBreakWordDirective,
                            DwCellAlignDirective,
                            DwTableSortersComponent,
                            DwTableFilterComponent,
                            DwTableSelectionComponent,
                            DwCellEllipsisDirective,
                            DwFilterTriggerComponent,
                            DwTableFixedRowComponent,
                            DwThSelectionComponent
                        ],
                        exports: [
                            DwTableComponent,
                            DwThAddOnComponent,
                            DwTableCellDirective,
                            DwThMeasureDirective,
                            DwTdAddOnComponent,
                            DwTheadComponent,
                            DwTbodyComponent,
                            DwTrDirective,
                            DwTableVirtualScrollDirective,
                            DwCellFixedDirective,
                            DwFilterTriggerComponent,
                            DwTrExpandDirective,
                            DwCellBreakWordDirective,
                            DwCellAlignDirective,
                            DwCellEllipsisDirective,
                            DwTableFixedRowComponent,
                            DwThSelectionComponent
                        ],
                        imports: [
                            menu.DwMenuModule,
                            forms.FormsModule,
                            outlet.DwOutletModule,
                            radio.DwRadioModule,
                            checkbox.DwCheckboxModule,
                            dropdown.DwDropDownModule,
                            button.DwButtonModule,
                            common.CommonModule,
                            platform.PlatformModule,
                            pagination.DwPaginationModule,
                            resizeObservers.DwResizeObserversModule,
                            spin.DwSpinModule,
                            i18n.DwI18nModule,
                            icon.DwIconModule,
                            empty.DwEmptyModule,
                            scrolling.ScrollingModule
                        ]
                    },] }
        ];
        return DwTableModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: src/table.types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function DwTableQueryParams() { }
    if (false) {
        /** @type {?} */
        DwTableQueryParams.prototype.pageIndex;
        /** @type {?} */
        DwTableQueryParams.prototype.pageSize;
        /** @type {?} */
        DwTableQueryParams.prototype.sort;
        /** @type {?} */
        DwTableQueryParams.prototype.filter;
    }

    exports.DwCellAlignDirective = DwCellAlignDirective;
    exports.DwCellBreakWordDirective = DwCellBreakWordDirective;
    exports.DwCellEllipsisDirective = DwCellEllipsisDirective;
    exports.DwCellFixedDirective = DwCellFixedDirective;
    exports.DwFilterTriggerComponent = DwFilterTriggerComponent;
    exports.DwRowExpandButtonDirective = DwRowExpandButtonDirective;
    exports.DwRowIndentDirective = DwRowIndentDirective;
    exports.DwTableCellDirective = DwTableCellDirective;
    exports.DwTableComponent = DwTableComponent;
    exports.DwTableContentComponent = DwTableContentComponent;
    exports.DwTableDataService = DwTableDataService;
    exports.DwTableFilterComponent = DwTableFilterComponent;
    exports.DwTableFixedRowComponent = DwTableFixedRowComponent;
    exports.DwTableInnerDefaultComponent = DwTableInnerDefaultComponent;
    exports.DwTableInnerScrollComponent = DwTableInnerScrollComponent;
    exports.DwTableModule = DwTableModule;
    exports.DwTableSelectionComponent = DwTableSelectionComponent;
    exports.DwTableSortersComponent = DwTableSortersComponent;
    exports.DwTableStyleService = DwTableStyleService;
    exports.DwTableTitleFooterComponent = DwTableTitleFooterComponent;
    exports.DwTableVirtualScrollDirective = DwTableVirtualScrollDirective;
    exports.DwTbodyComponent = DwTbodyComponent;
    exports.DwTdAddOnComponent = DwTdAddOnComponent;
    exports.DwThAddOnComponent = DwThAddOnComponent;
    exports.DwThMeasureDirective = DwThMeasureDirective;
    exports.DwThSelectionComponent = DwThSelectionComponent;
    exports.DwTheadComponent = DwTheadComponent;
    exports.DwTrDirective = DwTrDirective;
    exports.DwTrExpandDirective = DwTrExpandDirective;
    exports.DwTrMeasureComponent = DwTrMeasureComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-table.umd.js.map
