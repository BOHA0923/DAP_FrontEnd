(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/overlay'), require('@angular/common'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/button'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/outlet'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/icon'), require('ng-quicksilver/time-picker'), require('ng-quicksilver/core/time'), require('ng-quicksilver/core/util'), require('ng-quicksilver/i18n'), require('ng-quicksilver/core/logger'), require('rxjs'), require('rxjs/operators'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/animation')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/date-picker', ['exports', '@angular/cdk/overlay', '@angular/common', '@angular/core', '@angular/forms', 'ng-quicksilver/button', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/outlet', 'ng-quicksilver/core/overlay', 'ng-quicksilver/icon', 'ng-quicksilver/time-picker', 'ng-quicksilver/core/time', 'ng-quicksilver/core/util', 'ng-quicksilver/i18n', 'ng-quicksilver/core/logger', 'rxjs', 'rxjs/operators', 'ng-quicksilver/core/config', 'ng-quicksilver/core/animation'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver']['date-picker'] = {}), global.ng.cdk.overlay, global.ng.common, global.ng.core, global.ng.forms, global['ng-quicksilver'].button, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.outlet, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].icon, global['ng-quicksilver']['time-picker'], global['ng-quicksilver'].core.time, global['ng-quicksilver'].core.util, global['ng-quicksilver'].i18n, global['ng-quicksilver'].core.logger, global.rxjs, global.rxjs.operators, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core.animation));
}(this, (function (exports, overlay, common, core, forms, button, noAnimation, outlet, overlay$1, icon, timePicker, time, util, i18n, logger, rxjs, operators, config, animation) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: standard-types.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * @record
     */
    function DisabledTimeConfig() { }
    if (false) {
        /**
         * @return {?}
         */
        DisabledTimeConfig.prototype.dwDisabledHours = function () { };
        /**
         * @param {?} hour
         * @return {?}
         */
        DisabledTimeConfig.prototype.dwDisabledMinutes = function (hour) { };
        /**
         * @param {?} hour
         * @param {?} minute
         * @return {?}
         */
        DisabledTimeConfig.prototype.dwDisabledSeconds = function (hour, minute) { };
    }
    /**
     * @record
     */
    function SupportTimeOptions() { }
    if (false) {
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwFormat;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwHourStep;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwMinuteStep;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwSecondStep;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwHideDisabledOptions;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwDefaultOpenValue;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwAddOn;
        /** @type {?|undefined} */
        SupportTimeOptions.prototype.dwUse12Hours;
        /**
         * @return {?}
         */
        SupportTimeOptions.prototype.dwDisabledHours = function () { };
        /**
         * @param {?} hour
         * @return {?}
         */
        SupportTimeOptions.prototype.dwDisabledMinutes = function (hour) { };
        /**
         * @param {?} hour
         * @param {?} minute
         * @return {?}
         */
        SupportTimeOptions.prototype.dwDisabledSeconds = function (hour, minute) { };
    }
    /**
     * @record
     */
    function PresetRanges() { }

    /**
     * @fileoverview added by tsickle
     * Generated from: util.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /** @type {?} */
    var PREFIX_CLASS = 'ant-picker';
    /** @type {?} */
    var defaultDisabledTime = {
        dwDisabledHours: /**
         * @return {?}
         */
        function () {
            return [];
        },
        dwDisabledMinutes: /**
         * @return {?}
         */
        function () {
            return [];
        },
        dwDisabledSeconds: /**
         * @return {?}
         */
        function () {
            return [];
        }
    };
    /**
     * @param {?} value
     * @param {?=} disabledTime
     * @return {?}
     */
    function getTimeConfig(value, disabledTime) {
        /** @type {?} */
        var disabledTimeConfig = disabledTime ? disabledTime(value && value.nativeDate) : ((/** @type {?} */ ({})));
        disabledTimeConfig = __assign(__assign({}, defaultDisabledTime), disabledTimeConfig);
        return disabledTimeConfig;
    }
    /**
     * @param {?} value
     * @param {?} disabledTimeConfig
     * @return {?}
     */
    function isTimeValidByConfig(value, disabledTimeConfig) {
        /** @type {?} */
        var invalidTime = false;
        if (value) {
            /** @type {?} */
            var hour = value.getHours();
            /** @type {?} */
            var minutes = value.getMinutes();
            /** @type {?} */
            var seconds = value.getSeconds();
            /** @type {?} */
            var disabledHours = disabledTimeConfig.dwDisabledHours();
            if (disabledHours.indexOf(hour) === -1) {
                /** @type {?} */
                var disabledMinutes = disabledTimeConfig.dwDisabledMinutes(hour);
                if (disabledMinutes.indexOf(minutes) === -1) {
                    /** @type {?} */
                    var disabledSeconds = disabledTimeConfig.dwDisabledSeconds(hour, minutes);
                    invalidTime = disabledSeconds.indexOf(seconds) !== -1;
                }
                else {
                    invalidTime = true;
                }
            }
            else {
                invalidTime = true;
            }
        }
        return !invalidTime;
    }
    /**
     * @param {?} value
     * @param {?} disabledTime
     * @return {?}
     */
    function isTimeValid(value, disabledTime) {
        /** @type {?} */
        var disabledTimeConfig = getTimeConfig(value, disabledTime);
        return isTimeValidByConfig(value, disabledTimeConfig);
    }
    /**
     * @param {?} value
     * @param {?=} disabledDate
     * @param {?=} disabledTime
     * @return {?}
     */
    function isAllowedDate(value, disabledDate, disabledTime) {
        if (!value) {
            return false;
        }
        if (disabledDate) {
            if (disabledDate(value.nativeDate)) {
                return false;
            }
        }
        if (disabledTime) {
            if (!isTimeValid(value, disabledTime)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/util.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
     */
    /**
     * Compatible translate the moment-like format pattern to angular's pattern
     * Why? For now, we need to support the existing language formats in AntD, and AntD uses the default temporal syntax.
     *
     * TODO: compare and complete all format patterns
     * Each format docs as below:
     * @link https://momentjs.com/docs/#/displaying/format/ / https://angular.io/api/common/DatePipe#description
     * @param {?} format input format pattern
     * @return {?}
     */
    function transCompatFormat(format) {
        return (format &&
            format
                .replace(/Y/g, 'y') // only support y, yy, yyy, yyyy
                .replace(/D/g, 'd')); // d, dd represent of D, DD for momentjs, others are not support
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: calendar-footer.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var CalendarFooterComponent = /** @class */ (function () {
        function CalendarFooterComponent(dateHelper) {
            this.dateHelper = dateHelper;
            this.showToday = false;
            this.hasTimePicker = false;
            this.isRange = false;
            this.okDisabled = false;
            this.rangeQuickSelector = null;
            this.clickOk = new core.EventEmitter();
            this.clickToday = new core.EventEmitter();
            this.prefixCls = PREFIX_CLASS;
            this.isTemplateRef = util.isTemplateRef;
            this.isNonEmptyString = util.isNonEmptyString;
            this.isTodayDisabled = false;
            this.todayTitle = '';
            this.now = new time.CandyDate();
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        CalendarFooterComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.disabledDate) {
                this.isTodayDisabled = !!(this.disabledDate && this.disabledDate(this.now.nativeDate));
            }
            if (changes.locale) {
                // NOTE: Compat for DatePipe formatting rules
                /** @type {?} */
                var dateFormat = transCompatFormat(this.locale.dateFormat);
                this.todayTitle = this.dateHelper.format(this.now.nativeDate, dateFormat);
            }
        };
        /**
         * @return {?}
         */
        CalendarFooterComponent.prototype.onClickToday = /**
         * @return {?}
         */
        function () {
            this.clickToday.emit(this.now.clone()); // To prevent the "now" being modified from outside, we use clone
        };
        CalendarFooterComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'calendar-footer',
                        exportAs: 'calendarFooter',
                        template: "\n    <div class=\"{{ prefixCls }}-footer\">\n      <div *ngIf=\"extraFooter\" class=\"{{ prefixCls }}-footer-extra\">\n        <ng-container [ngSwitch]=\"true\">\n          <ng-container *ngSwitchCase=\"isTemplateRef(extraFooter)\">\n            <ng-container *ngTemplateOutlet=\"$any(extraFooter)\"></ng-container>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"isNonEmptyString(extraFooter)\">\n            <span [innerHTML]=\"extraFooter\"></span>\n          </ng-container>\n        </ng-container>\n      </div>\n      <a\n        *ngIf=\"showToday && !hasTimePicker\"\n        class=\"{{ prefixCls }}-today-btn {{ isTodayDisabled ? prefixCls + '-today-btn-disabled' : '' }}\"\n        role=\"button\"\n        (click)=\"isTodayDisabled ? null : onClickToday()\"\n        title=\"{{ todayTitle }}\"\n      >\n        {{ locale.today }}\n      </a>\n      <ul *ngIf=\"hasTimePicker || rangeQuickSelector\" class=\"{{ prefixCls }}-ranges\">\n        <ng-container *ngTemplateOutlet=\"rangeQuickSelector\"></ng-container>\n        <li *ngIf=\"hasTimePicker && !isRange\" class=\"{{ prefixCls }}-now\">\n          <a class=\"{{ prefixCls }}-now-btn\" (click)=\"isTodayDisabled ? null : onClickToday()\">\n            {{ locale.now }}\n          </a>\n        </li>\n        <li *ngIf=\"hasTimePicker\" class=\"{{ prefixCls }}-ok\">\n          <button\n            dw-button\n            type=\"button\"\n            dwType=\"primary\"\n            dwSize=\"small\"\n            [disabled]=\"okDisabled\"\n            (click)=\"okDisabled ? null : clickOk.emit()\"\n          >\n            {{ locale.ok }}\n          </button>\n        </li>\n      </ul>\n    </div>\n  "
                    }] }
        ];
        /** @nocollapse */
        CalendarFooterComponent.ctorParameters = function () { return [
            { type: i18n.DateHelperService }
        ]; };
        CalendarFooterComponent.propDecorators = {
            locale: [{ type: core.Input }],
            showToday: [{ type: core.Input }],
            hasTimePicker: [{ type: core.Input }],
            isRange: [{ type: core.Input }],
            okDisabled: [{ type: core.Input }],
            disabledDate: [{ type: core.Input }],
            extraFooter: [{ type: core.Input }],
            rangeQuickSelector: [{ type: core.Input }],
            clickOk: [{ type: core.Output }],
            clickToday: [{ type: core.Output }]
        };
        return CalendarFooterComponent;
    }());
    if (false) {
        /** @type {?} */
        CalendarFooterComponent.prototype.locale;
        /** @type {?} */
        CalendarFooterComponent.prototype.showToday;
        /** @type {?} */
        CalendarFooterComponent.prototype.hasTimePicker;
        /** @type {?} */
        CalendarFooterComponent.prototype.isRange;
        /** @type {?} */
        CalendarFooterComponent.prototype.okDisabled;
        /** @type {?} */
        CalendarFooterComponent.prototype.disabledDate;
        /** @type {?} */
        CalendarFooterComponent.prototype.extraFooter;
        /** @type {?} */
        CalendarFooterComponent.prototype.rangeQuickSelector;
        /** @type {?} */
        CalendarFooterComponent.prototype.clickOk;
        /** @type {?} */
        CalendarFooterComponent.prototype.clickToday;
        /** @type {?} */
        CalendarFooterComponent.prototype.prefixCls;
        /** @type {?} */
        CalendarFooterComponent.prototype.isTemplateRef;
        /** @type {?} */
        CalendarFooterComponent.prototype.isNonEmptyString;
        /** @type {?} */
        CalendarFooterComponent.prototype.isTodayDisabled;
        /** @type {?} */
        CalendarFooterComponent.prototype.todayTitle;
        /**
         * @type {?}
         * @private
         */
        CalendarFooterComponent.prototype.now;
        /**
         * @type {?}
         * @private
         */
        CalendarFooterComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: date-picker.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DatePickerService = /** @class */ (function () {
        function DatePickerService() {
            this.activeInput = 'left';
            this.arrowPositionStyle = {};
            this.isRange = false;
            this.valueChange$ = new rxjs.ReplaySubject(1);
            this.emitValue$ = new rxjs.Subject();
            this.inputPartChange$ = new rxjs.Subject();
        }
        /**
         * @return {?}
         */
        DatePickerService.prototype.initValue = /**
         * @return {?}
         */
        function () {
            if (this.isRange) {
                this.setActiveDate([]);
                this.value = this.initialValue = [];
            }
            else {
                this.value = this.initialValue = null;
            }
        };
        /**
         * @param {?=} value
         * @return {?}
         */
        DatePickerService.prototype.hasValue = /**
         * @param {?=} value
         * @return {?}
         */
        function (value) {
            if (value === void 0) { value = this.value; }
            if (Array.isArray(value)) {
                return !!value[0] && !!value[1];
            }
            else {
                return !!value;
            }
        };
        /**
         * @param {?=} value
         * @return {?}
         */
        DatePickerService.prototype.makeValue = /**
         * @param {?=} value
         * @return {?}
         */
        function (value) {
            if (this.isRange) {
                return value ? ((/** @type {?} */ (value))).map((/**
                 * @param {?} val
                 * @return {?}
                 */
                function (val) { return new time.CandyDate(val); })) : [];
            }
            else {
                return value ? new time.CandyDate((/** @type {?} */ (value))) : null;
            }
        };
        /**
         * @param {?} value
         * @param {?=} normalize
         * @return {?}
         */
        DatePickerService.prototype.setActiveDate = /**
         * @param {?} value
         * @param {?=} normalize
         * @return {?}
         */
        function (value, normalize) {
            if (normalize === void 0) { normalize = false; }
            if (this.isRange) {
                this.activeDate = normalize ? time.normalizeRangeValue((/** @type {?} */ (value))) : value;
            }
            else {
                this.activeDate = time.cloneDate(value);
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DatePickerService.prototype.setValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.value = value;
            this.valueChange$.next(this.value);
        };
        /**
         * @param {?=} part
         * @return {?}
         */
        DatePickerService.prototype.getActiveIndex = /**
         * @param {?=} part
         * @return {?}
         */
        function (part) {
            if (part === void 0) { part = this.activeInput; }
            return { left: 0, right: 1 }[part];
        };
        /**
         * @return {?}
         */
        DatePickerService.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.valueChange$.complete();
            this.emitValue$.complete();
            this.inputPartChange$.complete();
        };
        DatePickerService.decorators = [
            { type: core.Injectable }
        ];
        return DatePickerService;
    }());
    if (false) {
        /** @type {?} */
        DatePickerService.prototype.initialValue;
        /** @type {?} */
        DatePickerService.prototype.value;
        /** @type {?} */
        DatePickerService.prototype.activeDate;
        /** @type {?} */
        DatePickerService.prototype.activeInput;
        /** @type {?} */
        DatePickerService.prototype.arrowPositionStyle;
        /** @type {?} */
        DatePickerService.prototype.isRange;
        /** @type {?} */
        DatePickerService.prototype.valueChange$;
        /** @type {?} */
        DatePickerService.prototype.emitValue$;
        /** @type {?} */
        DatePickerService.prototype.inputPartChange$;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: date-range-popup.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DateRangePopupComponent = /** @class */ (function () {
        function DateRangePopupComponent(datePickerService, cdr) {
            var _this = this;
            this.datePickerService = datePickerService;
            this.cdr = cdr;
            this.panelModeChange = new core.EventEmitter();
            this.calendarChange = new core.EventEmitter();
            this.resultOk = new core.EventEmitter(); // Emitted when done with date selecting
            // Emitted when done with date selecting
            this.prefixCls = PREFIX_CLASS;
            this.endPanelMode = 'date';
            this.timeOptions = null;
            this.hoverValue = []; // Range ONLY
            // Range ONLY
            this.destroy$ = new rxjs.Subject();
            this.disabledStartTime = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                return _this.disabledTime && _this.disabledTime(value, 'start');
            });
            this.disabledEndTime = (/**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                return _this.disabledTime && _this.disabledTime(value, 'end');
            });
        }
        Object.defineProperty(DateRangePopupComponent.prototype, "hasTimePicker", {
            get: /**
             * @return {?}
             */
            function () {
                return !!this.showTime;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DateRangePopupComponent.prototype, "hasFooter", {
            get: /**
             * @return {?}
             */
            function () {
                return this.showToday || this.hasTimePicker || !!this.extraFooter || !!this.ranges;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DateRangePopupComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.datePickerService.valueChange$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.initActiveDate();
                _this.cdr.markForCheck();
            }));
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DateRangePopupComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            // Parse showTime options
            if (changes.showTime || changes.disabledTime) {
                if (this.showTime) {
                    this.buildTimeOptions();
                }
            }
            if (changes.panelMode) {
                this.endPanelMode = this.panelMode;
            }
        };
        /**
         * @return {?}
         */
        DateRangePopupComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @return {?}
         */
        DateRangePopupComponent.prototype.initActiveDate = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var activeDate = this.datePickerService.hasValue()
                ? this.datePickerService.value
                : this.datePickerService.makeValue((/** @type {?} */ (this.defaultPickerValue)));
            this.datePickerService.setActiveDate(activeDate, !this.showTime);
        };
        /**
         * @return {?}
         */
        DateRangePopupComponent.prototype.onClickOk = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var otherPart = this.datePickerService.activeInput === 'left' ? 'right' : 'left';
            /** @type {?} */
            var selectedValue = this.datePickerService.value;
            if (this.isAllowed(selectedValue, true)) {
                this.resultOk.emit();
            }
            else {
                if (this.isRange && this.isOneAllowed((/** @type {?} */ (selectedValue)))) {
                    this.datePickerService.inputPartChange$.next(otherPart);
                }
                else {
                    this.datePickerService.inputPartChange$.next();
                }
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DateRangePopupComponent.prototype.onClickToday = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.changeValueFromSelect(value, !this.showTime);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DateRangePopupComponent.prototype.onDayHover = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (!this.isRange) {
                return;
            }
            /** @type {?} */
            var otherInputIndex = { left: 1, right: 0 }[this.datePickerService.activeInput];
            /** @type {?} */
            var base = (/** @type {?} */ (((/** @type {?} */ (this.datePickerService.value)))[otherInputIndex]));
            if (base) {
                if (base.isBeforeDay(value)) {
                    this.hoverValue = [base, value];
                }
                else {
                    this.hoverValue = [value, base];
                }
            }
        };
        /**
         * @param {?} mode
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.onPanelModeChange = /**
         * @param {?} mode
         * @param {?=} partType
         * @return {?}
         */
        function (mode, partType) {
            if (this.isRange) {
                /** @type {?} */
                var index = this.datePickerService.getActiveIndex(partType);
                if (index === 0) {
                    this.panelMode = (/** @type {?} */ ([mode, this.panelMode[1]]));
                }
                else {
                    this.panelMode = (/** @type {?} */ ([this.panelMode[0], mode]));
                }
            }
            else {
                this.panelMode = mode;
            }
            // this.cdr.markForCheck();
            this.panelModeChange.emit(this.panelMode);
        };
        /**
         * @param {?} value
         * @param {?} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.onActiveDateChange = /**
         * @param {?} value
         * @param {?} partType
         * @return {?}
         */
        function (value, partType) {
            if (this.isRange) {
                if (partType === 'left') {
                    this.datePickerService.activeDate = [value, value.addMonths(1)];
                }
                else {
                    this.datePickerService.activeDate = [value.addMonths(-1), value];
                }
            }
            else {
                this.datePickerService.activeDate = value;
            }
        };
        /**
         * @param {?} value
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.onSelectTime = /**
         * @param {?} value
         * @param {?=} partType
         * @return {?}
         */
        function (value, partType) {
            if (this.isRange) {
                /** @type {?} */
                var newValue = (/** @type {?} */ (time.cloneDate(this.datePickerService.value)));
                /** @type {?} */
                var index = this.datePickerService.getActiveIndex(partType);
                newValue[index] = this.overrideHms(value, newValue[index]);
                this.datePickerService.setValue(newValue);
            }
            else {
                /** @type {?} */
                var newValue = this.overrideHms(value, (/** @type {?} */ (this.datePickerService.value)));
                this.datePickerService.setValue(newValue); // If not select a date currently, use today
            }
            this.datePickerService.inputPartChange$.next();
            this.buildTimeOptions();
        };
        /**
         * @param {?} value
         * @param {?=} emitValue
         * @return {?}
         */
        DateRangePopupComponent.prototype.changeValueFromSelect = /**
         * @param {?} value
         * @param {?=} emitValue
         * @return {?}
         */
        function (value, emitValue) {
            if (emitValue === void 0) { emitValue = true; }
            if (this.isRange) {
                /** @type {?} */
                var selectedValue = (/** @type {?} */ (time.cloneDate(this.datePickerService.value)));
                /** @type {?} */
                var otherPart = void 0;
                if (this.datePickerService.activeInput === 'left') {
                    otherPart = 'right';
                    selectedValue[0] = value;
                }
                else {
                    otherPart = 'left';
                    selectedValue[1] = value;
                }
                selectedValue = time.sortRangeValue(selectedValue);
                this.hoverValue = selectedValue;
                this.datePickerService.setValue(selectedValue);
                this.datePickerService.setActiveDate(selectedValue, !this.showTime);
                this.datePickerService.inputPartChange$.next();
                if (!this.isAllowed(selectedValue)) {
                    return;
                }
                if (emitValue) {
                    // If the other input has value
                    if (this.isBothAllowed(selectedValue)) {
                        this.calendarChange.emit(selectedValue);
                        this.clearHoverValue();
                        this.datePickerService.emitValue$.next();
                    }
                    else {
                        this.calendarChange.emit([value.clone()]);
                        this.datePickerService.inputPartChange$.next((/** @type {?} */ (otherPart)));
                    }
                }
            }
            else {
                this.datePickerService.setValue(value);
                this.datePickerService.setActiveDate(value, !this.showTime);
                this.datePickerService.inputPartChange$.next();
                if (!this.isAllowed(value)) {
                    return;
                }
                if (emitValue) {
                    this.datePickerService.emitValue$.next();
                }
            }
        };
        /**
         * @param {?} panelMode
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.getPanelMode = /**
         * @param {?} panelMode
         * @param {?=} partType
         * @return {?}
         */
        function (panelMode, partType) {
            if (this.isRange) {
                return (/** @type {?} */ (panelMode[this.datePickerService.getActiveIndex(partType)]));
            }
            else {
                return (/** @type {?} */ (panelMode));
            }
        };
        // Get single value or part value of a range
        // Get single value or part value of a range
        /**
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.getValue = 
        // Get single value or part value of a range
        /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            if (this.isRange) {
                return (((/** @type {?} */ (this.datePickerService.value))) || [])[this.datePickerService.getActiveIndex(partType)];
            }
            else {
                return (/** @type {?} */ (this.datePickerService.value));
            }
        };
        /**
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.getActiveDate = /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            if (this.isRange) {
                return ((/** @type {?} */ (this.datePickerService.activeDate)))[this.datePickerService.getActiveIndex(partType)];
            }
            else {
                return (/** @type {?} */ (this.datePickerService.activeDate));
            }
        };
        /**
         * @param {?} selectedValue
         * @return {?}
         */
        DateRangePopupComponent.prototype.isOneAllowed = /**
         * @param {?} selectedValue
         * @return {?}
         */
        function (selectedValue) {
            /** @type {?} */
            var index = this.datePickerService.getActiveIndex();
            /** @type {?} */
            var disabledTimeArr = [this.disabledStartTime, this.disabledEndTime];
            return isAllowedDate((/** @type {?} */ (selectedValue[index])), this.disabledDate, disabledTimeArr[index]);
        };
        /**
         * @param {?} selectedValue
         * @return {?}
         */
        DateRangePopupComponent.prototype.isBothAllowed = /**
         * @param {?} selectedValue
         * @return {?}
         */
        function (selectedValue) {
            return (isAllowedDate((/** @type {?} */ (selectedValue[0])), this.disabledDate, this.disabledStartTime) &&
                isAllowedDate((/** @type {?} */ (selectedValue[1])), this.disabledDate, this.disabledEndTime));
        };
        /**
         * @param {?} value
         * @param {?=} isBoth
         * @return {?}
         */
        DateRangePopupComponent.prototype.isAllowed = /**
         * @param {?} value
         * @param {?=} isBoth
         * @return {?}
         */
        function (value, isBoth) {
            if (isBoth === void 0) { isBoth = false; }
            if (this.isRange) {
                return isBoth ? this.isBothAllowed((/** @type {?} */ (value))) : this.isOneAllowed((/** @type {?} */ (value)));
            }
            else {
                return isAllowedDate((/** @type {?} */ (value)), this.disabledDate, this.disabledTime);
            }
        };
        /**
         * @param {?=} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.getTimeOptions = /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            if (this.showTime && this.timeOptions) {
                return this.timeOptions instanceof Array ? this.timeOptions[this.datePickerService.getActiveIndex(partType)] : this.timeOptions;
            }
            return null;
        };
        /**
         * @param {?} val
         * @return {?}
         */
        DateRangePopupComponent.prototype.onClickPresetRange = /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            /** @type {?} */
            var value = typeof val === 'function' ? val() : val;
            if (value) {
                this.datePickerService.setValue([new time.CandyDate(value[0]), new time.CandyDate(value[1])]);
                this.resultOk.emit();
            }
        };
        /**
         * @return {?}
         */
        DateRangePopupComponent.prototype.onPresetRangeMouseLeave = /**
         * @return {?}
         */
        function () {
            this.clearHoverValue();
        };
        /**
         * @param {?} val
         * @return {?}
         */
        DateRangePopupComponent.prototype.onHoverPresetRange = /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            if (typeof val !== 'function') {
                this.hoverValue = [new time.CandyDate(val[0]), new time.CandyDate(val[1])];
            }
        };
        /**
         * @param {?=} obj
         * @return {?}
         */
        DateRangePopupComponent.prototype.getObjectKeys = /**
         * @param {?=} obj
         * @return {?}
         */
        function (obj) {
            return obj ? Object.keys(obj) : [];
        };
        /**
         * @param {?} partType
         * @return {?}
         */
        DateRangePopupComponent.prototype.show = /**
         * @param {?} partType
         * @return {?}
         */
        function (partType) {
            /** @type {?} */
            var hide = this.showTime && this.isRange && this.datePickerService.activeInput !== partType;
            return !hide;
        };
        /**
         * @private
         * @return {?}
         */
        DateRangePopupComponent.prototype.clearHoverValue = /**
         * @private
         * @return {?}
         */
        function () {
            this.hoverValue = [];
        };
        /**
         * @private
         * @return {?}
         */
        DateRangePopupComponent.prototype.buildTimeOptions = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.showTime) {
                /** @type {?} */
                var showTime = typeof this.showTime === 'object' ? this.showTime : {};
                if (this.isRange) {
                    /** @type {?} */
                    var value = (/** @type {?} */ (this.datePickerService.value));
                    this.timeOptions = [this.overrideTimeOptions(showTime, value[0], 'start'), this.overrideTimeOptions(showTime, value[1], 'end')];
                }
                else {
                    this.timeOptions = this.overrideTimeOptions(showTime, (/** @type {?} */ (this.datePickerService.value)));
                }
            }
            else {
                this.timeOptions = null;
            }
        };
        /**
         * @private
         * @param {?} origin
         * @param {?} value
         * @param {?=} partial
         * @return {?}
         */
        DateRangePopupComponent.prototype.overrideTimeOptions = /**
         * @private
         * @param {?} origin
         * @param {?} value
         * @param {?=} partial
         * @return {?}
         */
        function (origin, value, partial) {
            /** @type {?} */
            var disabledTimeFn;
            if (partial) {
                disabledTimeFn = partial === 'start' ? this.disabledStartTime : this.disabledEndTime;
            }
            else {
                disabledTimeFn = this.disabledTime;
            }
            return __assign(__assign({}, origin), getTimeConfig(value, disabledTimeFn));
        };
        /**
         * @private
         * @param {?} newValue
         * @param {?} oldValue
         * @return {?}
         */
        DateRangePopupComponent.prototype.overrideHms = /**
         * @private
         * @param {?} newValue
         * @param {?} oldValue
         * @return {?}
         */
        function (newValue, oldValue) {
            // tslint:disable-next-line:no-parameter-reassignment
            newValue = newValue || new time.CandyDate();
            // tslint:disable-next-line:no-parameter-reassignment
            oldValue = oldValue || new time.CandyDate();
            return oldValue.setHms(newValue.getHours(), newValue.getMinutes(), newValue.getSeconds());
        };
        DateRangePopupComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'date-range-popup',
                        exportAs: 'dateRangePopup',
                        template: "\n    <ng-container *ngIf=\"isRange; else singlePanel\">\n      <div class=\"{{ prefixCls }}-range-wrapper {{ prefixCls }}-date-range-wrapper\">\n        <div class=\"{{ prefixCls }}-range-arrow\" [ngStyle]=\"datePickerService?.arrowPositionStyle!\"></div>\n        <div class=\"{{ prefixCls }}-panel-container\">\n          <div class=\"{{ prefixCls }}-panels\">\n            <ng-container *ngTemplateOutlet=\"tplRangePart; context: { partType: 'left' }\"></ng-container>\n            <ng-container *ngTemplateOutlet=\"tplRangePart; context: { partType: 'right' }\"></ng-container>\n          </div>\n          <ng-container *ngTemplateOutlet=\"tplFooter\"></ng-container>\n        </div>\n      </div>\n    </ng-container>\n    <ng-template #singlePanel>\n      <div\n        class=\"{{ prefixCls }}-panel-container {{ showWeek ? prefixCls + '-week-number' : '' }} {{\n          hasTimePicker ? prefixCls + '-time' : ''\n        }} {{ isRange ? prefixCls + '-range' : '' }}\"\n      >\n        <div class=\"{{ prefixCls }}-panel\" tabindex=\"-1\">\n          <!-- Single ONLY -->\n          <ng-container *ngTemplateOutlet=\"tplInnerPopup\"></ng-container>\n          <ng-container *ngTemplateOutlet=\"tplFooter\"></ng-container>\n        </div>\n      </div>\n    </ng-template>\n\n    <ng-template #tplInnerPopup let-partType=\"partType\">\n      <!-- TODO(@wenqi73) [selectedValue] [hoverValue] types-->\n      <inner-popup\n        *ngIf=\"show(partType)\"\n        [showWeek]=\"showWeek\"\n        [endPanelMode]=\"getPanelMode(endPanelMode, partType)\"\n        [partType]=\"partType\"\n        [locale]=\"locale!\"\n        [showTimePicker]=\"hasTimePicker\"\n        [timeOptions]=\"getTimeOptions(partType)\"\n        [panelMode]=\"getPanelMode(panelMode, partType)\"\n        (panelModeChange)=\"onPanelModeChange($event, partType)\"\n        [activeDate]=\"getActiveDate(partType)\"\n        [value]=\"getValue(partType)\"\n        [disabledDate]=\"disabledDate\"\n        [dateRender]=\"dateRender\"\n        [selectedValue]=\"$any(datePickerService?.value)\"\n        [hoverValue]=\"$any(hoverValue)\"\n        (dayHover)=\"onDayHover($event)\"\n        (selectDate)=\"changeValueFromSelect($event, !showTime)\"\n        (selectTime)=\"onSelectTime($event, partType)\"\n        (headerChange)=\"onActiveDateChange($event, partType)\"\n      ></inner-popup>\n    </ng-template>\n\n    <ng-template #tplFooter>\n      <calendar-footer\n        *ngIf=\"hasFooter\"\n        [locale]=\"locale!\"\n        [isRange]=\"isRange\"\n        [showToday]=\"showToday\"\n        [hasTimePicker]=\"hasTimePicker\"\n        [okDisabled]=\"!isAllowed($any(datePickerService?.value))\"\n        [extraFooter]=\"extraFooter\"\n        [rangeQuickSelector]=\"ranges ? tplRangeQuickSelector : null\"\n        (clickOk)=\"onClickOk()\"\n        (clickToday)=\"onClickToday($event)\"\n      ></calendar-footer>\n    </ng-template>\n\n    <ng-template #tplRangePart let-partType=\"partType\">\n      <div class=\"{{ prefixCls }}-panel\">\n        <ng-container *ngTemplateOutlet=\"tplInnerPopup; context: { partType: partType }\"></ng-container>\n      </div>\n    </ng-template>\n\n    <!-- Range ONLY: Range Quick Selector -->\n    <ng-template #tplRangeQuickSelector>\n      <li\n        *ngFor=\"let name of getObjectKeys(ranges)\"\n        class=\"{{ prefixCls }}-preset\"\n        (click)=\"onClickPresetRange(ranges![name])\"\n        (mouseenter)=\"onHoverPresetRange(ranges![name])\"\n        (mouseleave)=\"onPresetRangeMouseLeave()\"\n      >\n        <span class=\"ant-tag ant-tag-blue\">{{ name }}</span>\n      </li>\n    </ng-template>\n  "
                    }] }
        ];
        /** @nocollapse */
        DateRangePopupComponent.ctorParameters = function () { return [
            { type: DatePickerService },
            { type: core.ChangeDetectorRef }
        ]; };
        DateRangePopupComponent.propDecorators = {
            isRange: [{ type: core.Input }],
            showWeek: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            format: [{ type: core.Input }],
            placeholder: [{ type: core.Input }],
            disabledDate: [{ type: core.Input }],
            disabledTime: [{ type: core.Input }],
            showToday: [{ type: core.Input }],
            showTime: [{ type: core.Input }],
            extraFooter: [{ type: core.Input }],
            ranges: [{ type: core.Input }],
            dateRender: [{ type: core.Input }],
            panelMode: [{ type: core.Input }],
            defaultPickerValue: [{ type: core.Input }],
            panelModeChange: [{ type: core.Output }],
            calendarChange: [{ type: core.Output }],
            resultOk: [{ type: core.Output }]
        };
        return DateRangePopupComponent;
    }());
    if (false) {
        /** @type {?} */
        DateRangePopupComponent.prototype.isRange;
        /** @type {?} */
        DateRangePopupComponent.prototype.showWeek;
        /** @type {?} */
        DateRangePopupComponent.prototype.locale;
        /** @type {?} */
        DateRangePopupComponent.prototype.format;
        /** @type {?} */
        DateRangePopupComponent.prototype.placeholder;
        /** @type {?} */
        DateRangePopupComponent.prototype.disabledDate;
        /** @type {?} */
        DateRangePopupComponent.prototype.disabledTime;
        /** @type {?} */
        DateRangePopupComponent.prototype.showToday;
        /** @type {?} */
        DateRangePopupComponent.prototype.showTime;
        /** @type {?} */
        DateRangePopupComponent.prototype.extraFooter;
        /** @type {?} */
        DateRangePopupComponent.prototype.ranges;
        /** @type {?} */
        DateRangePopupComponent.prototype.dateRender;
        /** @type {?} */
        DateRangePopupComponent.prototype.panelMode;
        /** @type {?} */
        DateRangePopupComponent.prototype.defaultPickerValue;
        /** @type {?} */
        DateRangePopupComponent.prototype.panelModeChange;
        /** @type {?} */
        DateRangePopupComponent.prototype.calendarChange;
        /** @type {?} */
        DateRangePopupComponent.prototype.resultOk;
        /** @type {?} */
        DateRangePopupComponent.prototype.prefixCls;
        /** @type {?} */
        DateRangePopupComponent.prototype.endPanelMode;
        /** @type {?} */
        DateRangePopupComponent.prototype.timeOptions;
        /** @type {?} */
        DateRangePopupComponent.prototype.hoverValue;
        /** @type {?} */
        DateRangePopupComponent.prototype.destroy$;
        /** @type {?} */
        DateRangePopupComponent.prototype.disabledStartTime;
        /** @type {?} */
        DateRangePopupComponent.prototype.disabledEndTime;
        /** @type {?} */
        DateRangePopupComponent.prototype.datePickerService;
        /** @type {?} */
        DateRangePopupComponent.prototype.cdr;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwPickerComponent = /** @class */ (function () {
        function DwPickerComponent(elementRef, dateHelper, changeDetector, datePickerService, doc) {
            this.elementRef = elementRef;
            this.dateHelper = dateHelper;
            this.changeDetector = changeDetector;
            this.datePickerService = datePickerService;
            this.noAnimation = false;
            this.isRange = false;
            this.open = undefined;
            this.disabled = false;
            this.inputReadOnly = false;
            this.popupStyle = null;
            this.focusChange = new core.EventEmitter();
            this.valueChange = new core.EventEmitter();
            this.openChange = new core.EventEmitter(); // Emitted when overlay's open state change
            this.destroy$ = new rxjs.Subject();
            this.prefixCls = PREFIX_CLASS;
            this.activeBarStyle = { position: 'absolute' };
            this.animationOpenState = false;
            this.overlayOpen = false; // Available when "open"=undefined
            // Available when "open"=undefined
            this.overlayPositions = (/** @type {?} */ ([
                {
                    offsetX: -12,
                    offsetY: 8,
                    originX: 'start',
                    originY: 'bottom',
                    overlayX: 'start',
                    overlayY: 'top'
                },
                {
                    offsetX: -12,
                    offsetY: -8,
                    originX: 'start',
                    originY: 'top',
                    overlayX: 'start',
                    overlayY: 'bottom'
                },
                {
                    offsetX: 12,
                    offsetY: 8,
                    originX: 'end',
                    originY: 'bottom',
                    overlayX: 'end',
                    overlayY: 'top'
                },
                {
                    offsetX: 12,
                    offsetY: -8,
                    originX: 'end',
                    originY: 'top',
                    overlayX: 'end',
                    overlayY: 'bottom'
                }
            ]));
            this.currentPositionX = 'start';
            this.currentPositionY = 'bottom';
            this.document = doc;
            this.origin = new overlay.CdkOverlayOrigin(this.elementRef);
            this.updateInputValue();
        }
        Object.defineProperty(DwPickerComponent.prototype, "realOpenState", {
            get: /**
             * @return {?}
             */
            function () {
                // The value that really decide the open state of overlay
                return this.isOpenHandledByUser() ? !!this.open : this.overlayOpen;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.inputSize = Math.max(10, this.format.length) + 2;
            this.datePickerService.valueChange$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @return {?}
             */
            function () {
                _this.updateInputValue();
                _this.changeDetector.markForCheck();
            }));
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (this.autoFocus) {
                this.focus();
            }
            if (this.isRange) {
                rxjs.fromEvent(window, 'resize')
                    .pipe(operators.takeUntil(this.destroy$))
                    .subscribe((/**
                 * @return {?}
                 */
                function () {
                    _this.resetInputWidthAndArrowLeft();
                }));
            }
            this.datePickerService.inputPartChange$.pipe(operators.takeUntil(this.destroy$)).subscribe((/**
             * @param {?} partType
             * @return {?}
             */
            function (partType) {
                var _a;
                if (partType) {
                    _this.datePickerService.activeInput = partType;
                }
                _this.datePickerService.arrowPositionStyle = {
                    left: _this.datePickerService.activeInput === 'left' ? '0px' : _this.arrowLeft + "px"
                };
                _this.activeBarStyle = __assign(__assign(__assign({}, _this.activeBarStyle), _this.datePickerService.arrowPositionStyle), { width: _this.inputWidth + "px" });
                if (_this.document.activeElement !== _this.getInput(_this.datePickerService.activeInput)) {
                    _this.focus();
                }
                (_a = _this.panel) === null || _a === void 0 ? void 0 : _a.cdr.markForCheck();
                _this.changeDetector.markForCheck();
            }));
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroy$.next();
            this.destroy$.complete();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwPickerComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.open) {
                this.animationStart();
            }
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.resetInputWidthAndArrowLeft = /**
         * @return {?}
         */
        function () {
            var _a, _b, _c;
            this.inputWidth = ((_b = (_a = this.rangePickerInputs) === null || _a === void 0 ? void 0 : _a.first) === null || _b === void 0 ? void 0 : _b.nativeElement.offsetWidth) || 0;
            this.arrowLeft = this.inputWidth + ((_c = this.separatorElement) === null || _c === void 0 ? void 0 : _c.nativeElement.offsetWidth) || 0;
        };
        /**
         * @param {?=} partType
         * @return {?}
         */
        DwPickerComponent.prototype.getInput = /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            return this.isRange
                ? partType === 'left'
                    ? this.rangePickerInputs.first.nativeElement
                    : this.rangePickerInputs.last.nativeElement
                : (/** @type {?} */ (this.pickerInput)).nativeElement;
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.focus = /**
         * @return {?}
         */
        function () {
            this.getInput(this.datePickerService.activeInput).focus(); // Focus on the first input
        };
        /**
         * @param {?=} partType
         * @return {?}
         */
        DwPickerComponent.prototype.onFocus = /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            if (partType) {
                this.datePickerService.inputPartChange$.next(partType);
            }
            this.focusChange.emit(true);
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.onBlur = /**
         * @return {?}
         */
        function () {
            this.focusChange.emit(false);
        };
        // Show overlay content
        // Show overlay content
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.showOverlay = 
        // Show overlay content
        /**
         * @return {?}
         */
        function () {
            if (!this.realOpenState) {
                this.resetInputWidthAndArrowLeft();
                this.overlayOpen = true;
                this.animationStart();
                this.focus();
                this.openChange.emit(true);
            }
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.hideOverlay = /**
         * @return {?}
         */
        function () {
            if (this.realOpenState) {
                this.overlayOpen = false;
                this.openChange.emit(false);
                this.focus();
            }
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.showClear = /**
         * @return {?}
         */
        function () {
            return !this.disabled && !this.isEmptyValue(this.datePickerService.value) && !!this.allowClear;
        };
        /**
         * @param {?} event
         * @param {?=} partType
         * @return {?}
         */
        DwPickerComponent.prototype.onClickInputBox = /**
         * @param {?} event
         * @param {?=} partType
         * @return {?}
         */
        function (event, partType) {
            event.stopPropagation();
            if (!this.disabled && !this.isOpenHandledByUser()) {
                this.showOverlay();
            }
            this.onFocus(partType);
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.onClickBackdrop = /**
         * @return {?}
         */
        function () {
            if (this.panel.isAllowed((/** @type {?} */ (this.datePickerService.value)), true)) {
                this.updateInputValue();
                this.datePickerService.emitValue$.next();
            }
            else {
                this.datePickerService.setValue((/** @type {?} */ (this.datePickerService.initialValue)));
                this.hideOverlay();
            }
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.onOverlayDetach = /**
         * @return {?}
         */
        function () {
            this.hideOverlay();
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwPickerComponent.prototype.onOverlayKeydown = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            if (event.key === 'Escape') {
                this.datePickerService.setValue((/** @type {?} */ (this.datePickerService.initialValue)));
            }
        };
        // NOTE: A issue here, the first time position change, the animation will not be triggered.
        // Because the overlay's "positionChange" event is emitted after the content's full shown up.
        // All other components like "dw-dropdown" which depends on overlay also has the same issue.
        // See: https://github.com/NG-ZORRO/ng-zorro-antd/issues/1429
        // NOTE: A issue here, the first time position change, the animation will not be triggered.
        // Because the overlay's "positionChange" event is emitted after the content's full shown up.
        // All other components like "dw-dropdown" which depends on overlay also has the same issue.
        // See: https://github.com/NG-ZORRO/ng-zorro-antd/issues/1429
        /**
         * @param {?} position
         * @return {?}
         */
        DwPickerComponent.prototype.onPositionChange = 
        // NOTE: A issue here, the first time position change, the animation will not be triggered.
        // Because the overlay's "positionChange" event is emitted after the content's full shown up.
        // All other components like "dw-dropdown" which depends on overlay also has the same issue.
        // See: https://github.com/NG-ZORRO/ng-zorro-antd/issues/1429
        /**
         * @param {?} position
         * @return {?}
         */
        function (position) {
            this.currentPositionX = position.connectionPair.originX;
            this.currentPositionY = position.connectionPair.originY;
            this.changeDetector.detectChanges(); // Take side-effects to position styles
        };
        /**
         * @param {?} event
         * @return {?}
         */
        DwPickerComponent.prototype.onClickClear = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            event.preventDefault();
            event.stopPropagation();
            this.datePickerService.setValue(this.isRange ? [] : null);
            this.datePickerService.emitValue$.next();
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.updateInputValue = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var newValue = this.datePickerService.value;
            if (this.isRange) {
                this.inputValue = newValue ? ((/** @type {?} */ (newValue))).map((/**
                 * @param {?} v
                 * @return {?}
                 */
                function (v) { return _this.formatValue(v); })) : ['', ''];
            }
            else {
                this.inputValue = this.formatValue((/** @type {?} */ (newValue)));
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwPickerComponent.prototype.formatValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            return this.dateHelper.format(value && ((/** @type {?} */ (value))).nativeDate, this.format);
        };
        /**
         * @param {?} event
         * @param {?=} emitValue
         * @return {?}
         */
        DwPickerComponent.prototype.onInputKeyup = /**
         * @param {?} event
         * @param {?=} emitValue
         * @return {?}
         */
        function (event, emitValue) {
            if (emitValue === void 0) { emitValue = false; }
            if (!this.realOpenState) {
                this.showOverlay();
                return;
            }
            /** @type {?} */
            var date = this.checkValidInputDate((/** @type {?} */ (((/** @type {?} */ (event))).target)));
            if (this.panel && date) {
                this.panel.changeValueFromSelect(date, emitValue);
            }
        };
        /**
         * @private
         * @param {?} inputTarget
         * @return {?}
         */
        DwPickerComponent.prototype.checkValidInputDate = /**
         * @private
         * @param {?} inputTarget
         * @return {?}
         */
        function (inputTarget) {
            /** @type {?} */
            var input = ((/** @type {?} */ (inputTarget))).value;
            /** @type {?} */
            var date = new time.CandyDate(this.dateHelper.parseDate(input, this.format));
            if (!date.isValid() || input !== this.dateHelper.format(date.nativeDate, this.format)) {
                return null;
            }
            return date;
        };
        /**
         * @param {?=} partType
         * @return {?}
         */
        DwPickerComponent.prototype.getPlaceholder = /**
         * @param {?=} partType
         * @return {?}
         */
        function (partType) {
            return this.isRange ? this.placeholder[this.datePickerService.getActiveIndex((/** @type {?} */ (partType)))] : ((/** @type {?} */ (this.placeholder)));
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwPickerComponent.prototype.isEmptyValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (value === null) {
                return true;
            }
            else if (this.isRange) {
                return !value || !Array.isArray(value) || value.every((/**
                 * @param {?} val
                 * @return {?}
                 */
                function (val) { return !val; }));
            }
            else {
                return !value;
            }
        };
        // Whether open state is permanently controlled by user himself
        // Whether open state is permanently controlled by user himself
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.isOpenHandledByUser = 
        // Whether open state is permanently controlled by user himself
        /**
         * @return {?}
         */
        function () {
            return this.open !== undefined;
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.animationStart = /**
         * @return {?}
         */
        function () {
            if (this.realOpenState) {
                this.animationOpenState = true;
            }
        };
        /**
         * @return {?}
         */
        DwPickerComponent.prototype.animationDone = /**
         * @return {?}
         */
        function () {
            if (!this.realOpenState) {
                this.animationOpenState = false;
                this.changeDetector.markForCheck();
            }
        };
        DwPickerComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        selector: '[dw-picker]',
                        exportAs: 'dwPicker',
                        template: "\n    <!-- Content of single picker -->\n    <div *ngIf=\"!isRange\" class=\"{{ prefixCls }}-input\">\n      <input\n        #pickerInput\n        [class.ant-input-disabled]=\"disabled\"\n        [disabled]=\"disabled\"\n        [readOnly]=\"inputReadOnly\"\n        [(ngModel)]=\"inputValue\"\n        placeholder=\"{{ getPlaceholder() }}\"\n        [size]=\"inputSize\"\n        (focus)=\"onFocus()\"\n        (blur)=\"onBlur()\"\n        (input)=\"onInputKeyup($event)\"\n        (keyup.enter)=\"onInputKeyup($event, true)\"\n      />\n      <ng-container *ngTemplateOutlet=\"tplRightRest\"></ng-container>\n    </div>\n\n    <!-- Content of range picker -->\n    <ng-container *ngIf=\"isRange\">\n      <div class=\"{{ prefixCls }}-input\">\n        <ng-container *ngTemplateOutlet=\"tplRangeInput; context: { partType: 'left' }\"></ng-container>\n      </div>\n      <div #separatorElement class=\"{{ prefixCls }}-range-separator\">\n        <span class=\"{{ prefixCls }}-separator\">\n          <ng-container *ngIf=\"separator; else defaultSeparator\">{{ separator }}</ng-container>\n        </span>\n        <ng-template #defaultSeparator>\n          <i dw-icon dwType=\"swap-right\" dwTheme=\"outline\"></i>\n        </ng-template>\n      </div>\n      <div class=\"{{ prefixCls }}-input\">\n        <ng-container *ngTemplateOutlet=\"tplRangeInput; context: { partType: 'right' }\"></ng-container>\n      </div>\n      <ng-container *ngTemplateOutlet=\"tplRightRest\"></ng-container>\n    </ng-container>\n    <!-- Input for Range ONLY -->\n    <ng-template #tplRangeInput let-partType=\"partType\">\n      <input\n        #rangePickerInput\n        [disabled]=\"disabled\"\n        [readOnly]=\"inputReadOnly\"\n        [size]=\"inputSize\"\n        (click)=\"onClickInputBox($event, partType)\"\n        (blur)=\"onBlur()\"\n        (input)=\"onInputKeyup($event)\"\n        (focus)=\"onFocus(partType)\"\n        (keyup.enter)=\"onInputKeyup($event, true)\"\n        [(ngModel)]=\"inputValue[datePickerService.getActiveIndex(partType)]\"\n        placeholder=\"{{ getPlaceholder(partType) }}\"\n      />\n    </ng-template>\n\n    <!-- Right operator icons -->\n    <ng-template #tplRightRest>\n      <div class=\"{{ prefixCls }}-active-bar\" [ngStyle]=\"activeBarStyle\"></div>\n      <span *ngIf=\"showClear()\" class=\"{{ prefixCls }}-clear\" (click)=\"onClickClear($event)\">\n        <i dw-icon dwType=\"close-circle\" dwTheme=\"fill\"></i>\n      </span>\n      <span class=\"{{ prefixCls }}-suffix\">\n        <ng-container *dwStringTemplateOutlet=\"suffixIcon; let suffixIcon\">\n          <i dw-icon [dwType]=\"suffixIcon\"></i>\n        </ng-container>\n      </span>\n    </ng-template>\n\n    <!-- Overlay -->\n    <ng-template\n      cdkConnectedOverlay\n      dwConnectedOverlay\n      [cdkConnectedOverlayOrigin]=\"origin\"\n      [cdkConnectedOverlayOpen]=\"realOpenState\"\n      [cdkConnectedOverlayHasBackdrop]=\"!isOpenHandledByUser()\"\n      [cdkConnectedOverlayPositions]=\"overlayPositions\"\n      [cdkConnectedOverlayTransformOriginOn]=\"'.ant-picker-wrapper'\"\n      (positionChange)=\"onPositionChange($event)\"\n      (backdropClick)=\"onClickBackdrop()\"\n      (detach)=\"onOverlayDetach()\"\n      (overlayKeydown)=\"onOverlayKeydown($event)\"\n    >\n      <div\n        class=\"ant-picker-wrapper\"\n        [dwNoAnimation]=\"noAnimation\"\n        [@slideMotion]=\"'enter'\"\n        (@slideMotion.done)=\"animationDone()\"\n        style=\"position: relative;\"\n      >\n        <div\n          class=\"{{ prefixCls }}-dropdown {{ dropdownClassName }}\"\n          [class.ant-picker-dropdown-placement-bottomLeft]=\"currentPositionY === 'bottom' && currentPositionX === 'start'\"\n          [class.ant-picker-dropdown-placement-topLeft]=\"currentPositionY === 'top' && currentPositionX === 'start'\"\n          [class.ant-picker-dropdown-placement-bottomRight]=\"currentPositionY === 'bottom' && currentPositionX === 'end'\"\n          [class.ant-picker-dropdown-placement-topRight]=\"currentPositionY === 'top' && currentPositionX === 'end'\"\n          [class.ant-picker-dropdown-range]=\"isRange\"\n          [ngStyle]=\"popupStyle\"\n        >\n          <!-- Compatible for overlay that not support offset dynamically and immediately -->\n          <ng-content></ng-content>\n        </div>\n      </div>\n    </ng-template>\n  ",
                        animations: [animation.slideMotion],
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    }] }
        ];
        /** @nocollapse */
        DwPickerComponent.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: i18n.DateHelperService },
            { type: core.ChangeDetectorRef },
            { type: DatePickerService },
            { type: undefined, decorators: [{ type: core.Inject, args: [common.DOCUMENT,] }] }
        ]; };
        DwPickerComponent.propDecorators = {
            noAnimation: [{ type: core.Input }],
            isRange: [{ type: core.Input }],
            open: [{ type: core.Input }],
            disabled: [{ type: core.Input }],
            inputReadOnly: [{ type: core.Input }],
            placeholder: [{ type: core.Input }],
            allowClear: [{ type: core.Input }],
            autoFocus: [{ type: core.Input }],
            format: [{ type: core.Input }],
            separator: [{ type: core.Input }],
            popupStyle: [{ type: core.Input }],
            dropdownClassName: [{ type: core.Input }],
            suffixIcon: [{ type: core.Input }],
            focusChange: [{ type: core.Output }],
            valueChange: [{ type: core.Output }],
            openChange: [{ type: core.Output }],
            cdkConnectedOverlay: [{ type: core.ViewChild, args: [overlay.CdkConnectedOverlay, { static: false },] }],
            separatorElement: [{ type: core.ViewChild, args: ['separatorElement', { static: false },] }],
            pickerInput: [{ type: core.ViewChild, args: ['pickerInput', { static: false },] }],
            rangePickerInputs: [{ type: core.ViewChildren, args: ['rangePickerInput',] }],
            panel: [{ type: core.ContentChild, args: [DateRangePopupComponent,] }]
        };
        return DwPickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwPickerComponent.prototype.noAnimation;
        /** @type {?} */
        DwPickerComponent.prototype.isRange;
        /** @type {?} */
        DwPickerComponent.prototype.open;
        /** @type {?} */
        DwPickerComponent.prototype.disabled;
        /** @type {?} */
        DwPickerComponent.prototype.inputReadOnly;
        /** @type {?} */
        DwPickerComponent.prototype.placeholder;
        /** @type {?} */
        DwPickerComponent.prototype.allowClear;
        /** @type {?} */
        DwPickerComponent.prototype.autoFocus;
        /** @type {?} */
        DwPickerComponent.prototype.format;
        /** @type {?} */
        DwPickerComponent.prototype.separator;
        /** @type {?} */
        DwPickerComponent.prototype.popupStyle;
        /** @type {?} */
        DwPickerComponent.prototype.dropdownClassName;
        /** @type {?} */
        DwPickerComponent.prototype.suffixIcon;
        /** @type {?} */
        DwPickerComponent.prototype.focusChange;
        /** @type {?} */
        DwPickerComponent.prototype.valueChange;
        /** @type {?} */
        DwPickerComponent.prototype.openChange;
        /** @type {?} */
        DwPickerComponent.prototype.cdkConnectedOverlay;
        /** @type {?} */
        DwPickerComponent.prototype.separatorElement;
        /** @type {?} */
        DwPickerComponent.prototype.pickerInput;
        /** @type {?} */
        DwPickerComponent.prototype.rangePickerInputs;
        /** @type {?} */
        DwPickerComponent.prototype.panel;
        /** @type {?} */
        DwPickerComponent.prototype.origin;
        /** @type {?} */
        DwPickerComponent.prototype.document;
        /** @type {?} */
        DwPickerComponent.prototype.inputSize;
        /** @type {?} */
        DwPickerComponent.prototype.inputWidth;
        /** @type {?} */
        DwPickerComponent.prototype.arrowLeft;
        /** @type {?} */
        DwPickerComponent.prototype.destroy$;
        /** @type {?} */
        DwPickerComponent.prototype.prefixCls;
        /** @type {?} */
        DwPickerComponent.prototype.inputValue;
        /** @type {?} */
        DwPickerComponent.prototype.activeBarStyle;
        /** @type {?} */
        DwPickerComponent.prototype.animationOpenState;
        /** @type {?} */
        DwPickerComponent.prototype.overlayOpen;
        /** @type {?} */
        DwPickerComponent.prototype.overlayPositions;
        /** @type {?} */
        DwPickerComponent.prototype.currentPositionX;
        /** @type {?} */
        DwPickerComponent.prototype.currentPositionY;
        /**
         * @type {?}
         * @private
         */
        DwPickerComponent.prototype.elementRef;
        /**
         * @type {?}
         * @private
         */
        DwPickerComponent.prototype.dateHelper;
        /**
         * @type {?}
         * @private
         */
        DwPickerComponent.prototype.changeDetector;
        /** @type {?} */
        DwPickerComponent.prototype.datePickerService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: date-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var POPUP_STYLE_PATCH = { position: 'relative' };
    // Aim to override antd's style to support overlay's position strategy (position:absolute will cause it not working beacuse the overlay can't get the height/width of it's content)
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'datePicker';
    /**
     * The base picker for all common APIs
     */
    var DwDatePickerComponent = /** @class */ (function () {
        function DwDatePickerComponent(dwConfigService, datePickerService, i18n, cdr, renderer, elementRef, dateHelper, noAnimation) {
            this.dwConfigService = dwConfigService;
            this.datePickerService = datePickerService;
            this.i18n = i18n;
            this.cdr = cdr;
            this.renderer = renderer;
            this.elementRef = elementRef;
            this.dateHelper = dateHelper;
            this.noAnimation = noAnimation;
            this.isRange = false; // Indicate whether the value is a range value
            // Indicate whether the value is a range value
            this.showWeek = false; // Should show as week picker
            // Should show as week picker
            this.focused = false;
            this.destroyed$ = new rxjs.Subject();
            this.isCustomPlaceHolder = false;
            this.showTime = false;
            // --- Common API
            this.dwAllowClear = true;
            this.dwAutoFocus = false;
            this.dwDisabled = false;
            this.dwInputReadOnly = false;
            /**
             * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
             */
            this.dwClassName = '';
            this.dwPlaceHolder = '';
            this.dwPopupStyle = POPUP_STYLE_PATCH;
            this.dwSize = 'default';
            /**
             * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
             */
            this.dwStyle = null;
            this.dwShowToday = true;
            this.dwMode = 'date';
            this.dwDefaultPickerValue = null;
            this.dwSeparator = undefined;
            this.dwSuffixIcon = 'calendar';
            // TODO(@wenqi73) The PanelMode need named for each pickers and export
            this.dwOnPanelChange = new core.EventEmitter();
            this.dwOnCalendarChange = new core.EventEmitter();
            this.dwOnOk = new core.EventEmitter();
            this.dwOnOpenChange = new core.EventEmitter();
            // ------------------------------------------------------------------------
            // | Control value accessor implements
            // ------------------------------------------------------------------------
            // NOTE: onChangeFn/onTouchedFn will not be assigned if user not use as ngModel
            this.onChangeFn = (/**
             * @return {?}
             */
            function () { return void 0; });
            this.onTouchedFn = (/**
             * @return {?}
             */
            function () { return void 0; });
        }
        Object.defineProperty(DwDatePickerComponent.prototype, "dwShowTime", {
            get: /**
             * @return {?}
             */
            function () {
                return this.showTime;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.showTime = typeof value === 'object' ? value : util.toBoolean(value);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwDatePickerComponent.prototype, "realOpenState", {
            get: /**
             * @return {?}
             */
            function () {
                return this.picker.animationOpenState;
            } // Use picker's real open state to let re-render the picker's content when shown up
            ,
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwDatePickerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            // Subscribe the every locale change if the dwLocale is not handled by user
            if (!this.dwLocale) {
                this.i18n.localeChange.pipe(operators.takeUntil(this.destroyed$)).subscribe((/**
                 * @return {?}
                 */
                function () { return _this.setLocale(); }));
            }
            // Default value
            this.datePickerService.isRange = this.isRange;
            this.datePickerService.initValue();
            this.datePickerService.emitValue$.pipe(operators.takeUntil(this.destroyed$)).subscribe((/**
             * @param {?} _
             * @return {?}
             */
            function (_) {
                /** @type {?} */
                var value = _this.datePickerService.value;
                _this.datePickerService.initialValue = time.cloneDate(value);
                if (_this.isRange) {
                    /** @type {?} */
                    var vAsRange = (/** @type {?} */ (value));
                    if (vAsRange.length) {
                        _this.onChangeFn([vAsRange[0].nativeDate, vAsRange[1].nativeDate]);
                    }
                    else {
                        _this.onChangeFn([]);
                    }
                }
                else {
                    if (value) {
                        _this.onChangeFn(((/** @type {?} */ (value))).nativeDate);
                    }
                    else {
                        _this.onChangeFn(null);
                    }
                }
                _this.onTouchedFn();
                // When value emitted, overlay will be closed
                _this.picker.hideOverlay();
            }));
            // Default format when it's empty
            if (!this.dwFormat) {
                if (this.showWeek) {
                    this.dwFormat = 'yyyy-ww'; // Format for week
                }
                else {
                    this.dwFormat = this.dwShowTime ? 'yyyy-MM-dd HH:mm:ss' : 'yyyy-MM-dd';
                }
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwDatePickerComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.dwPopupStyle) {
                // Always assign the popup style patch
                this.dwPopupStyle = this.dwPopupStyle ? __assign(__assign({}, this.dwPopupStyle), POPUP_STYLE_PATCH) : POPUP_STYLE_PATCH;
            }
            // Mark as customized placeholder by user once dwPlaceHolder assigned at the first time
            if (changes.dwPlaceHolder && changes.dwPlaceHolder.firstChange && typeof this.dwPlaceHolder !== 'undefined') {
                this.isCustomPlaceHolder = true;
            }
            if (changes.dwLocale) {
                // The dwLocale is currently handled by user
                this.setDefaultPlaceHolder();
            }
            if (changes.dwRenderExtraFooter) {
                this.extraFooter = util.valueFunctionProp((/** @type {?} */ (this.dwRenderExtraFooter)));
            }
            if (changes.dwStyle) {
                logger.warnDeprecation("'dwStyle' in DatePicker is going to be removed in 10.0.0. Please use CSS style attribute like <dw-date-picker style=\"...\"></dw-date-picker> instead.");
            }
            if (changes.dwClassName) {
                logger.warnDeprecation("'dwClassName' in DatePicker is going to be removed in 10.0.0. Please use CSS class attribute like <dw-date-picker class=\"...\"></dw-date-picker> instead.");
            }
            if (changes.dwMode) {
                this.setPanelMode();
            }
        };
        /**
         * @return {?}
         */
        DwDatePickerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.destroyed$.next();
            this.destroyed$.complete();
        };
        /**
         * @return {?}
         */
        DwDatePickerComponent.prototype.setPanelMode = /**
         * @return {?}
         */
        function () {
            if (!this.dwMode) {
                this.dwMode = this.isRange ? ['date', 'date'] : 'date';
            }
        };
        /**
         * Triggered when overlayOpen changes (different with realOpenState)
         * @param open The overlayOpen in picker component
         */
        /**
         * Triggered when overlayOpen changes (different with realOpenState)
         * @param {?} open The overlayOpen in picker component
         * @return {?}
         */
        DwDatePickerComponent.prototype.onOpenChange = /**
         * Triggered when overlayOpen changes (different with realOpenState)
         * @param {?} open The overlayOpen in picker component
         * @return {?}
         */
        function (open) {
            this.dwOnOpenChange.emit(open);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwDatePickerComponent.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.setValue(value);
            this.cdr.markForCheck();
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwDatePickerComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChangeFn = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwDatePickerComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouchedFn = fn;
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwDatePickerComponent.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            this.dwDisabled = isDisabled;
            this.cdr.markForCheck();
        };
        // ------------------------------------------------------------------------
        // | Internal methods
        // ------------------------------------------------------------------------
        // Reload locale from i18n with side effects
        // ------------------------------------------------------------------------
        // | Internal methods
        // ------------------------------------------------------------------------
        // Reload locale from i18n with side effects
        /**
         * @private
         * @return {?}
         */
        DwDatePickerComponent.prototype.setLocale = 
        // ------------------------------------------------------------------------
        // | Internal methods
        // ------------------------------------------------------------------------
        // Reload locale from i18n with side effects
        /**
         * @private
         * @return {?}
         */
        function () {
            this.dwLocale = this.i18n.getLocaleData('DatePicker', {});
            this.setDefaultPlaceHolder();
            this.cdr.markForCheck();
        };
        /**
         * @private
         * @return {?}
         */
        DwDatePickerComponent.prototype.setDefaultPlaceHolder = /**
         * @private
         * @return {?}
         */
        function () {
            if (!this.isCustomPlaceHolder && this.dwLocale) {
                this.dwPlaceHolder = this.isRange ? ((/** @type {?} */ (this.dwLocale.lang.rangePlaceholder))) : (/** @type {?} */ (this.dwLocale.lang.placeholder));
            }
        };
        // Safe way of setting value with default
        // Safe way of setting value with default
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DwDatePickerComponent.prototype.setValue = 
        // Safe way of setting value with default
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            /** @type {?} */
            var newValue = this.datePickerService.makeValue(value);
            this.datePickerService.setValue(newValue);
            this.datePickerService.initialValue = newValue;
        };
        Object.defineProperty(DwDatePickerComponent.prototype, "realShowToday", {
            get: /**
             * @return {?}
             */
            function () {
                // Range only support in single date picker
                return this.dwMode === 'date' && this.dwShowToday;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} value
         * @return {?}
         */
        DwDatePickerComponent.prototype.onFocusChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.focused = value;
            // TODO: avoid autoFocus cause change after checked error
            if (this.focused) {
                this.renderer.addClass(this.elementRef.nativeElement, 'ant-picker-focused');
            }
            else {
                this.renderer.removeClass(this.elementRef.nativeElement, 'ant-picker-focused');
            }
        };
        /**
         * @param {?} panelMode
         * @return {?}
         */
        DwDatePickerComponent.prototype.onPanelModeChange = /**
         * @param {?} panelMode
         * @return {?}
         */
        function (panelMode) {
            // this.dwMode = panelMode;
            this.dwOnPanelChange.emit(panelMode);
        };
        // Emit dwOnCalendarChange when select date by dw-range-picker
        // Emit dwOnCalendarChange when select date by dw-range-picker
        /**
         * @param {?} value
         * @return {?}
         */
        DwDatePickerComponent.prototype.onCalendarChange = 
        // Emit dwOnCalendarChange when select date by dw-range-picker
        /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (this.isRange && Array.isArray(value)) {
                /** @type {?} */
                var rangeValue = value.filter((/**
                 * @param {?} x
                 * @return {?}
                 */
                function (x) { return x instanceof time.CandyDate; })).map((/**
                 * @param {?} x
                 * @return {?}
                 */
                function (x) { return (/** @type {?} */ (x)).nativeDate; }));
                this.dwOnCalendarChange.emit(rangeValue);
            }
        };
        // Emitted when done with date selecting
        // Emitted when done with date selecting
        /**
         * @return {?}
         */
        DwDatePickerComponent.prototype.onResultOk = 
        // Emitted when done with date selecting
        /**
         * @return {?}
         */
        function () {
            if (this.isRange) {
                /** @type {?} */
                var value = (/** @type {?} */ (this.datePickerService.value));
                if (value.length) {
                    this.dwOnOk.emit([value[0].nativeDate, value[1].nativeDate]);
                }
                else {
                    this.dwOnOk.emit([]);
                }
            }
            else {
                if (this.datePickerService.value) {
                    this.dwOnOk.emit(((/** @type {?} */ (this.datePickerService.value))).nativeDate);
                }
                else {
                    this.dwOnOk.emit(null);
                }
            }
            this.datePickerService.emitValue$.next();
        };
        DwDatePickerComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'dw-date-picker,dw-week-picker,dw-month-picker,dw-year-picker,dw-range-picker',
                        exportAs: 'dwDatePicker',
                        template: "\n    <div\n      dw-picker\n      [isRange]=\"isRange\"\n      [open]=\"dwOpen\"\n      [separator]=\"dwSeparator\"\n      [disabled]=\"dwDisabled\"\n      [inputReadOnly]=\"dwInputReadOnly\"\n      [format]=\"dwFormat\"\n      [allowClear]=\"dwAllowClear\"\n      [autoFocus]=\"dwAutoFocus\"\n      [placeholder]=\"dwPlaceHolder\"\n      [ngClass]=\"dwClassName\"\n      style=\"display: inherit; align-items: center; width: 100%;\"\n      [ngStyle]=\"dwStyle\"\n      [dropdownClassName]=\"dwDropdownClassName\"\n      [popupStyle]=\"dwPopupStyle\"\n      [noAnimation]=\"!!noAnimation?.dwNoAnimation\"\n      [suffixIcon]=\"dwSuffixIcon\"\n      (openChange)=\"onOpenChange($event)\"\n      (focusChange)=\"onFocusChange($event)\"\n    >\n      <date-range-popup\n        *ngIf=\"realOpenState\"\n        [isRange]=\"isRange\"\n        [defaultPickerValue]=\"dwDefaultPickerValue\"\n        [showWeek]=\"showWeek\"\n        [panelMode]=\"dwMode\"\n        (panelModeChange)=\"onPanelModeChange($event)\"\n        (calendarChange)=\"onCalendarChange($event)\"\n        [locale]=\"dwLocale?.lang!\"\n        [showToday]=\"realShowToday\"\n        [showTime]=\"dwShowTime\"\n        [format]=\"dwFormat\"\n        [dateRender]=\"dwDateRender\"\n        [disabledDate]=\"dwDisabledDate\"\n        [disabledTime]=\"dwDisabledTime\"\n        [placeholder]=\"dwPlaceHolder\"\n        [extraFooter]=\"extraFooter\"\n        [ranges]=\"dwRanges\"\n        (resultOk)=\"onResultOk()\"\n      ></date-range-popup>\n    </div>\n  ",
                        host: {
                            '[class.ant-picker]': "true",
                            '[class.ant-picker-range]': "isRange",
                            '[class.ant-picker-large]': "dwSize === 'large'",
                            '[class.ant-picker-small]': "dwSize === 'small'",
                            '[class.ant-picker-disabled]': "dwDisabled",
                            '(click)': 'picker.onClickInputBox($event)'
                        },
                        providers: [
                            DatePickerService,
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                multi: true,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwDatePickerComponent; }))
                            }
                        ]
                    }] }
        ];
        /** @nocollapse */
        DwDatePickerComponent.ctorParameters = function () { return [
            { type: config.DwConfigService },
            { type: DatePickerService },
            { type: i18n.DwI18nService },
            { type: core.ChangeDetectorRef },
            { type: core.Renderer2 },
            { type: core.ElementRef },
            { type: i18n.DateHelperService },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwDatePickerComponent.propDecorators = {
            dwAllowClear: [{ type: core.Input }],
            dwAutoFocus: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwInputReadOnly: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            dwClassName: [{ type: core.Input }],
            dwDisabledDate: [{ type: core.Input }],
            dwLocale: [{ type: core.Input }],
            dwPlaceHolder: [{ type: core.Input }],
            dwPopupStyle: [{ type: core.Input }],
            dwDropdownClassName: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwStyle: [{ type: core.Input }],
            dwFormat: [{ type: core.Input }],
            dwDateRender: [{ type: core.Input }],
            dwDisabledTime: [{ type: core.Input }],
            dwRenderExtraFooter: [{ type: core.Input }],
            dwShowToday: [{ type: core.Input }],
            dwMode: [{ type: core.Input }],
            dwRanges: [{ type: core.Input }],
            dwDefaultPickerValue: [{ type: core.Input }],
            dwSeparator: [{ type: core.Input }],
            dwSuffixIcon: [{ type: core.Input }],
            dwOnPanelChange: [{ type: core.Output }],
            dwOnCalendarChange: [{ type: core.Output }],
            dwOnOk: [{ type: core.Output }],
            dwOnOpenChange: [{ type: core.Output }],
            picker: [{ type: core.ViewChild, args: [DwPickerComponent, { static: true },] }],
            dwShowTime: [{ type: core.Input }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwAllowClear", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwAutoFocus", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwInputReadOnly", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwOpen", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwDatePickerComponent.prototype, "dwShowToday", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwDatePickerComponent.prototype, "dwSeparator", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Object)
        ], DwDatePickerComponent.prototype, "dwSuffixIcon", void 0);
        return DwDatePickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwAllowClear;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwAutoFocus;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwInputReadOnly;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwOpen;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwShowToday;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwMode;
        /** @type {?} */
        DwDatePickerComponent.ngAcceptInputType_dwShowTime;
        /** @type {?} */
        DwDatePickerComponent.prototype.isRange;
        /** @type {?} */
        DwDatePickerComponent.prototype.showWeek;
        /** @type {?} */
        DwDatePickerComponent.prototype.focused;
        /** @type {?} */
        DwDatePickerComponent.prototype.extraFooter;
        /**
         * @type {?}
         * @protected
         */
        DwDatePickerComponent.prototype.destroyed$;
        /**
         * @type {?}
         * @protected
         */
        DwDatePickerComponent.prototype.isCustomPlaceHolder;
        /**
         * @type {?}
         * @private
         */
        DwDatePickerComponent.prototype.showTime;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwAllowClear;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwAutoFocus;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDisabled;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwInputReadOnly;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwOpen;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * @type {?}
         */
        DwDatePickerComponent.prototype.dwClassName;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDisabledDate;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwLocale;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwPlaceHolder;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwPopupStyle;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDropdownClassName;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwSize;
        /**
         * @deprecated 10.0.0. This is deprecated and going to be removed in 10.0.0.
         * @type {?}
         */
        DwDatePickerComponent.prototype.dwStyle;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwFormat;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDateRender;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDisabledTime;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwRenderExtraFooter;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwShowToday;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwMode;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwRanges;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwDefaultPickerValue;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwSeparator;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwSuffixIcon;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwOnPanelChange;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwOnCalendarChange;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwOnOk;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwOnOpenChange;
        /** @type {?} */
        DwDatePickerComponent.prototype.picker;
        /** @type {?} */
        DwDatePickerComponent.prototype.onChangeFn;
        /** @type {?} */
        DwDatePickerComponent.prototype.onTouchedFn;
        /** @type {?} */
        DwDatePickerComponent.prototype.dwConfigService;
        /** @type {?} */
        DwDatePickerComponent.prototype.datePickerService;
        /**
         * @type {?}
         * @protected
         */
        DwDatePickerComponent.prototype.i18n;
        /**
         * @type {?}
         * @protected
         */
        DwDatePickerComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwDatePickerComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwDatePickerComponent.prototype.elementRef;
        /**
         * @type {?}
         * @protected
         */
        DwDatePickerComponent.prototype.dateHelper;
        /** @type {?} */
        DwDatePickerComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: inner-popup.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var InnerPopupComponent = /** @class */ (function () {
        function InnerPopupComponent() {
            this.panelModeChange = new core.EventEmitter();
            // TODO: name is not proper
            this.headerChange = new core.EventEmitter(); // Emitted when user changed the header's value
            // Emitted when user changed the header's value
            this.selectDate = new core.EventEmitter(); // Emitted when the date is selected by click the date panel
            // Emitted when the date is selected by click the date panel
            this.selectTime = new core.EventEmitter();
            this.dayHover = new core.EventEmitter(); // Emitted when hover on a day by mouse enter
            // Emitted when hover on a day by mouse enter
            this.prefixCls = PREFIX_CLASS;
        }
        /**
         * Hide "next" arrow in left panel,
         * hide "prev" arrow in right panel
         * @param direction
         * @param panelMode
         */
        /**
         * Hide "next" arrow in left panel,
         * hide "prev" arrow in right panel
         * @param {?} direction
         * @param {?} panelMode
         * @return {?}
         */
        InnerPopupComponent.prototype.enablePrevNext = /**
         * Hide "next" arrow in left panel,
         * hide "prev" arrow in right panel
         * @param {?} direction
         * @param {?} panelMode
         * @return {?}
         */
        function (direction, panelMode) {
            if (!this.showTimePicker &&
                panelMode === this.endPanelMode &&
                ((this.partType === 'left' && direction === 'next') || (this.partType === 'right' && direction === 'prev'))) {
                return false;
            }
            return true;
        };
        /**
         * @param {?} date
         * @return {?}
         */
        InnerPopupComponent.prototype.onSelectTime = /**
         * @param {?} date
         * @return {?}
         */
        function (date) {
            this.selectTime.emit(new time.CandyDate(date));
        };
        // The value real changed to outside
        // The value real changed to outside
        /**
         * @param {?} date
         * @return {?}
         */
        InnerPopupComponent.prototype.onSelectDate = 
        // The value real changed to outside
        /**
         * @param {?} date
         * @return {?}
         */
        function (date) {
            /** @type {?} */
            var value = date instanceof time.CandyDate ? date : new time.CandyDate(date);
            /** @type {?} */
            var timeValue = this.timeOptions && this.timeOptions.dwDefaultOpenValue;
            // Display timeValue when value is null
            if (!this.value && timeValue) {
                value.setHms(timeValue.getHours(), timeValue.getMinutes(), timeValue.getSeconds());
            }
            this.selectDate.emit(value);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        InnerPopupComponent.prototype.onChooseMonth = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.activeDate = this.activeDate.setMonth(value.getMonth());
            if (this.endPanelMode === 'month') {
                this.value = value;
                this.selectDate.emit(value);
            }
            else {
                this.headerChange.emit(value);
                this.panelModeChange.emit(this.endPanelMode);
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        InnerPopupComponent.prototype.onChooseYear = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.activeDate = this.activeDate.setYear(value.getYear());
            if (this.endPanelMode === 'year') {
                this.value = value;
                this.selectDate.emit(value);
            }
            else {
                this.headerChange.emit(value);
                this.panelModeChange.emit(this.endPanelMode);
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        InnerPopupComponent.prototype.onChooseDecade = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.activeDate = this.activeDate.setYear(value.getYear());
            if (this.endPanelMode === 'decade') {
                this.value = value;
                this.selectDate.emit(value);
            }
            else {
                this.headerChange.emit(value);
                this.panelModeChange.emit('year');
            }
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        InnerPopupComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.activeDate && !changes.activeDate.currentValue) {
                this.activeDate = new time.CandyDate();
            }
            // New Antd vesion has merged 'date' ant 'time' to one panel,
            // So there is not 'time' panel
            if (changes.panelMode && changes.panelMode.currentValue === 'time') {
                this.panelMode = 'date';
            }
        };
        InnerPopupComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'inner-popup',
                        exportAs: 'innerPopup',
                        template: "\n    <div [class.ant-picker-datetime-panel]=\"showTimePicker\">\n      <div class=\"{{ prefixCls }}-{{ panelMode }}-panel\">\n        <ng-container [ngSwitch]=\"panelMode\">\n          <ng-container *ngSwitchCase=\"'decade'\">\n            <decade-header\n              [(value)]=\"activeDate\"\n              [locale]=\"locale!\"\n              [showSuperPreBtn]=\"enablePrevNext('prev', 'decade')\"\n              [showSuperNextBtn]=\"enablePrevNext('next', 'decade')\"\n              [showNextBtn]=\"false\"\n              [showPreBtn]=\"false\"\n              (panelModeChange)=\"panelModeChange.emit($event)\"\n              (valueChange)=\"headerChange.emit($event)\"\n            >\n            </decade-header>\n            <div class=\"{{ prefixCls }}-body\">\n              <decade-table\n                [showWeek]=\"showWeek\"\n                [activeDate]=\"activeDate\"\n                [value]=\"value\"\n                (valueChange)=\"onChooseDecade($event)\"\n                [disabledDate]=\"disabledDate\"\n              ></decade-table>\n            </div>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'year'\">\n            <year-header\n              [(value)]=\"activeDate\"\n              [locale]=\"locale!\"\n              [showSuperPreBtn]=\"enablePrevNext('prev', 'year')\"\n              [showSuperNextBtn]=\"enablePrevNext('next', 'year')\"\n              [showNextBtn]=\"false\"\n              [showPreBtn]=\"false\"\n              (panelModeChange)=\"panelModeChange.emit($event)\"\n              (valueChange)=\"headerChange.emit($event)\"\n            >\n            </year-header>\n            <div class=\"{{ prefixCls }}-body\">\n              <year-table\n                [showWeek]=\"showWeek\"\n                [activeDate]=\"activeDate\"\n                [value]=\"value\"\n                (valueChange)=\"onChooseYear($event)\"\n                [disabledDate]=\"disabledDate\"\n              ></year-table>\n            </div>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'month'\">\n            <month-header\n              [(value)]=\"activeDate\"\n              [locale]=\"locale!\"\n              [showNextBtn]=\"false\"\n              [showPreBtn]=\"false\"\n              (panelModeChange)=\"panelModeChange.emit($event)\"\n              (valueChange)=\"headerChange.emit($event)\"\n            >\n            </month-header>\n            <div class=\"{{ prefixCls }}-body\">\n              <month-table\n                [showWeek]=\"showWeek\"\n                [value]=\"value\"\n                [activeDate]=\"activeDate\"\n                [disabledDate]=\"disabledDate\"\n                (valueChange)=\"onChooseMonth($event)\"\n              ></month-table>\n            </div>\n          </ng-container>\n\n          <ng-container *ngSwitchDefault>\n            <date-header\n              [(value)]=\"activeDate\"\n              [locale]=\"locale!\"\n              [showSuperPreBtn]=\"enablePrevNext('prev', 'date')\"\n              [showSuperNextBtn]=\"enablePrevNext('next', 'date')\"\n              [showPreBtn]=\"enablePrevNext('prev', 'date')\"\n              [showNextBtn]=\"enablePrevNext('next', 'date')\"\n              (panelModeChange)=\"panelModeChange.emit($event)\"\n              (valueChange)=\"headerChange.emit($event)\"\n            >\n            </date-header>\n            <div class=\"{{ prefixCls }}-body\">\n              <date-table\n                [locale]=\"locale!\"\n                [showWeek]=\"showWeek\"\n                [value]=\"value\"\n                [activeDate]=\"activeDate\"\n                (valueChange)=\"onSelectDate($event)\"\n                [disabledDate]=\"disabledDate\"\n                [cellRender]=\"dateRender\"\n                [selectedValue]=\"selectedValue\"\n                [hoverValue]=\"hoverValue\"\n                (dayHover)=\"dayHover.emit($event)\"\n              ></date-table>\n            </div>\n          </ng-container>\n        </ng-container>\n      </div>\n      <ng-container *ngIf=\"showTimePicker && timeOptions\">\n        <dw-time-picker-panel\n          [dwInDatePicker]=\"true\"\n          [ngModel]=\"value?.nativeDate\"\n          (ngModelChange)=\"onSelectTime($event)\"\n          [format]=\"$any(timeOptions.dwFormat)\"\n          [dwHourStep]=\"$any(timeOptions.dwHourStep)\"\n          [dwMinuteStep]=\"$any(timeOptions.dwMinuteStep)\"\n          [dwSecondStep]=\"$any(timeOptions.dwSecondStep)\"\n          [dwDisabledHours]=\"$any(timeOptions.dwDisabledHours)\"\n          [dwDisabledMinutes]=\"$any(timeOptions.dwDisabledMinutes)\"\n          [dwDisabledSeconds]=\"$any(timeOptions.dwDisabledSeconds)\"\n          [dwHideDisabledOptions]=\"!!timeOptions.dwHideDisabledOptions\"\n          [dwDefaultOpenValue]=\"$any(timeOptions.dwDefaultOpenValue)\"\n          [dwUse12Hours]=\"!!timeOptions.dwUse12Hours\"\n          [dwAddOn]=\"$any(timeOptions.dwAddOn)\"\n        ></dw-time-picker-panel>\n        <!-- use [opened] to trigger time panel `initPosition()` -->\n      </ng-container>\n    </div>\n  "
                    }] }
        ];
        InnerPopupComponent.propDecorators = {
            activeDate: [{ type: core.Input }],
            endPanelMode: [{ type: core.Input }],
            panelMode: [{ type: core.Input }],
            showWeek: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            showTimePicker: [{ type: core.Input }],
            timeOptions: [{ type: core.Input }],
            disabledDate: [{ type: core.Input }],
            dateRender: [{ type: core.Input }],
            selectedValue: [{ type: core.Input }],
            hoverValue: [{ type: core.Input }],
            value: [{ type: core.Input }],
            partType: [{ type: core.Input }],
            panelModeChange: [{ type: core.Output }],
            headerChange: [{ type: core.Output }],
            selectDate: [{ type: core.Output }],
            selectTime: [{ type: core.Output }],
            dayHover: [{ type: core.Output }]
        };
        return InnerPopupComponent;
    }());
    if (false) {
        /** @type {?} */
        InnerPopupComponent.prototype.activeDate;
        /** @type {?} */
        InnerPopupComponent.prototype.endPanelMode;
        /** @type {?} */
        InnerPopupComponent.prototype.panelMode;
        /** @type {?} */
        InnerPopupComponent.prototype.showWeek;
        /** @type {?} */
        InnerPopupComponent.prototype.locale;
        /** @type {?} */
        InnerPopupComponent.prototype.showTimePicker;
        /** @type {?} */
        InnerPopupComponent.prototype.timeOptions;
        /** @type {?} */
        InnerPopupComponent.prototype.disabledDate;
        /** @type {?} */
        InnerPopupComponent.prototype.dateRender;
        /** @type {?} */
        InnerPopupComponent.prototype.selectedValue;
        /** @type {?} */
        InnerPopupComponent.prototype.hoverValue;
        /** @type {?} */
        InnerPopupComponent.prototype.value;
        /** @type {?} */
        InnerPopupComponent.prototype.partType;
        /** @type {?} */
        InnerPopupComponent.prototype.panelModeChange;
        /** @type {?} */
        InnerPopupComponent.prototype.headerChange;
        /** @type {?} */
        InnerPopupComponent.prototype.selectDate;
        /** @type {?} */
        InnerPopupComponent.prototype.selectTime;
        /** @type {?} */
        InnerPopupComponent.prototype.dayHover;
        /** @type {?} */
        InnerPopupComponent.prototype.prefixCls;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/abstract-panel-header.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @abstract
     */
    var AbstractPanelHeader = /** @class */ (function () {
        function AbstractPanelHeader() {
            this.prefixCls = "ant-picker-header";
            this.selectors = [];
            this.showSuperPreBtn = true;
            this.showSuperNextBtn = true;
            this.showPreBtn = true;
            this.showNextBtn = true;
            this.panelModeChange = new core.EventEmitter();
            this.valueChange = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.superPreviousTitle = /**
         * @return {?}
         */
        function () {
            return this.locale.previousYear;
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.previousTitle = /**
         * @return {?}
         */
        function () {
            return this.locale.previousMonth;
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.superNextTitle = /**
         * @return {?}
         */
        function () {
            return this.locale.nextYear;
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.nextTitle = /**
         * @return {?}
         */
        function () {
            return this.locale.nextMonth;
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.superPrevious = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(-1));
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.superNext = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(1));
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.previous = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addMonths(-1));
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.next = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addMonths(1));
        };
        /**
         * @param {?} value
         * @return {?}
         */
        AbstractPanelHeader.prototype.changeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (this.value !== value) {
                this.value = value;
                this.valueChange.emit(this.value);
                this.render();
            }
        };
        /**
         * @param {?} mode
         * @return {?}
         */
        AbstractPanelHeader.prototype.changeMode = /**
         * @param {?} mode
         * @return {?}
         */
        function (mode) {
            this.panelModeChange.emit(mode);
        };
        /**
         * @private
         * @return {?}
         */
        AbstractPanelHeader.prototype.render = /**
         * @private
         * @return {?}
         */
        function () {
            if (this.value) {
                this.selectors = this.getSelectors();
            }
        };
        /**
         * @return {?}
         */
        AbstractPanelHeader.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            if (!this.value) {
                this.value = new time.CandyDate(); // Show today by default
            }
            this.selectors = this.getSelectors();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        AbstractPanelHeader.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.value || changes.locale) {
                this.render();
            }
        };
        AbstractPanelHeader.decorators = [
            { type: core.Directive }
        ];
        AbstractPanelHeader.propDecorators = {
            value: [{ type: core.Input }],
            locale: [{ type: core.Input }],
            showSuperPreBtn: [{ type: core.Input }],
            showSuperNextBtn: [{ type: core.Input }],
            showPreBtn: [{ type: core.Input }],
            showNextBtn: [{ type: core.Input }],
            panelModeChange: [{ type: core.Output }],
            valueChange: [{ type: core.Output }]
        };
        return AbstractPanelHeader;
    }());
    if (false) {
        /** @type {?} */
        AbstractPanelHeader.prototype.prefixCls;
        /** @type {?} */
        AbstractPanelHeader.prototype.selectors;
        /** @type {?} */
        AbstractPanelHeader.prototype.value;
        /** @type {?} */
        AbstractPanelHeader.prototype.locale;
        /** @type {?} */
        AbstractPanelHeader.prototype.showSuperPreBtn;
        /** @type {?} */
        AbstractPanelHeader.prototype.showSuperNextBtn;
        /** @type {?} */
        AbstractPanelHeader.prototype.showPreBtn;
        /** @type {?} */
        AbstractPanelHeader.prototype.showNextBtn;
        /** @type {?} */
        AbstractPanelHeader.prototype.panelModeChange;
        /** @type {?} */
        AbstractPanelHeader.prototype.valueChange;
        /**
         * @abstract
         * @return {?}
         */
        AbstractPanelHeader.prototype.getSelectors = function () { };
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/date-header.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DateHeaderComponent = /** @class */ (function (_super) {
        __extends(DateHeaderComponent, _super);
        function DateHeaderComponent(dateHelper) {
            var _this = _super.call(this) || this;
            _this.dateHelper = dateHelper;
            return _this;
        }
        /**
         * @return {?}
         */
        DateHeaderComponent.prototype.getSelectors = /**
         * @return {?}
         */
        function () {
            var _this = this;
            return [
                {
                    className: this.prefixCls + "-year-btn",
                    title: this.locale.yearSelect,
                    onClick: (/**
                     * @return {?}
                     */
                    function () { return _this.changeMode('year'); }),
                    label: this.dateHelper.format(this.value.nativeDate, transCompatFormat(this.locale.yearFormat))
                },
                {
                    className: this.prefixCls + "-month-btn",
                    title: this.locale.monthSelect,
                    onClick: (/**
                     * @return {?}
                     */
                    function () { return _this.changeMode('month'); }),
                    label: this.dateHelper.format(this.value.nativeDate, this.locale.monthFormat || 'MMM')
                }
            ];
        };
        DateHeaderComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'date-header',
                        // tslint:disable-line:component-selector
                        exportAs: 'dateHeader',
                        template: "<div class=\"{{ prefixCls }}\">\n  <button\n    [style.visibility]=\"showSuperPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-prev-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superPreviousTitle() }}\"\n    (click)=\"superPrevious()\"\n  >\n    <span class=\"ant-picker-super-prev-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-prev-btn\"\n    role=\"button\"\n    title=\"{{ previousTitle() }}\"\n    tabindex=\"-1\"\n    (click)=\"previous()\"\n  >\n    <span class=\"ant-picker-prev-icon\"></span>\n  </button>\n\n  <div class=\"{{ prefixCls }}-view\">\n    <ng-container *ngFor=\"let selector of selectors\">\n      <button\n        class=\"{{ selector.className }}\"\n        role=\"button\"\n        type=\"button\"\n        title=\"{{ selector.title || null }}\"\n        (click)=\"selector.onClick()\"\n      >\n        {{ selector.label }}\n      </button>\n    </ng-container>\n  </div>\n  <button\n    [style.visibility]=\"showNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ nextTitle() }}\"\n    (click)=\"next()\"\n  >\n    <span class=\"ant-picker-next-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showSuperNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superNextTitle() }}\"\n    (click)=\"superNext()\"\n  >\n    <span class=\"ant-picker-super-next-icon\"></span>\n  </button>\n</div>\n"
                    }] }
        ];
        /** @nocollapse */
        DateHeaderComponent.ctorParameters = function () { return [
            { type: i18n.DateHelperService }
        ]; };
        return DateHeaderComponent;
    }(AbstractPanelHeader));
    if (false) {
        /**
         * @type {?}
         * @private
         */
        DateHeaderComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/abstract-table.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @abstract
     */
    var AbstractTable = /** @class */ (function () {
        function AbstractTable() {
            this.isTemplateRef = util.isTemplateRef;
            this.isNonEmptyString = util.isNonEmptyString;
            this.headRow = [];
            this.bodyRows = [];
            this.MAX_ROW = 6;
            this.MAX_COL = 7;
            this.prefixCls = 'ant-picker';
            this.activeDate = new time.CandyDate();
            this.showWeek = false;
            this.valueChange = new core.EventEmitter();
        }
        /**
         * @protected
         * @return {?}
         */
        AbstractTable.prototype.render = /**
         * @protected
         * @return {?}
         */
        function () {
            if (this.activeDate) {
                this.headRow = this.makeHeadRow();
                this.bodyRows = this.makeBodyRows();
            }
        };
        /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        AbstractTable.prototype.trackByBodyRow = /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        function (_index, item) {
            return item;
        };
        // Item usually is an object, so trackby has no use by default.
        // Item usually is an object, so trackby has no use by default.
        /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        AbstractTable.prototype.trackByBodyColumn = 
        // Item usually is an object, so trackby has no use by default.
        /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        function (_index, item) {
            return item;
        };
        /**
         * @return {?}
         */
        AbstractTable.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.render();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        AbstractTable.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.activeDate && !changes.activeDate.currentValue) {
                this.activeDate = new time.CandyDate();
            }
        };
        AbstractTable.decorators = [
            { type: core.Directive }
        ];
        AbstractTable.propDecorators = {
            prefixCls: [{ type: core.Input }],
            value: [{ type: core.Input }],
            activeDate: [{ type: core.Input }],
            showWeek: [{ type: core.Input }],
            disabledDate: [{ type: core.Input }],
            cellRender: [{ type: core.Input }],
            fullCellRender: [{ type: core.Input }],
            valueChange: [{ type: core.Output }]
        };
        return AbstractTable;
    }());
    if (false) {
        /** @type {?} */
        AbstractTable.prototype.isTemplateRef;
        /** @type {?} */
        AbstractTable.prototype.isNonEmptyString;
        /** @type {?} */
        AbstractTable.prototype.headRow;
        /** @type {?} */
        AbstractTable.prototype.bodyRows;
        /** @type {?} */
        AbstractTable.prototype.MAX_ROW;
        /** @type {?} */
        AbstractTable.prototype.MAX_COL;
        /** @type {?} */
        AbstractTable.prototype.prefixCls;
        /** @type {?} */
        AbstractTable.prototype.value;
        /** @type {?} */
        AbstractTable.prototype.activeDate;
        /** @type {?} */
        AbstractTable.prototype.showWeek;
        /** @type {?} */
        AbstractTable.prototype.disabledDate;
        /** @type {?} */
        AbstractTable.prototype.cellRender;
        /** @type {?} */
        AbstractTable.prototype.fullCellRender;
        /** @type {?} */
        AbstractTable.prototype.valueChange;
        /**
         * @abstract
         * @return {?}
         */
        AbstractTable.prototype.makeHeadRow = function () { };
        /**
         * @abstract
         * @return {?}
         */
        AbstractTable.prototype.makeBodyRows = function () { };
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/date-table.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DateTableComponent = /** @class */ (function (_super) {
        __extends(DateTableComponent, _super);
        function DateTableComponent(i18n, dateHelper) {
            var _this = _super.call(this) || this;
            _this.i18n = i18n;
            _this.dateHelper = dateHelper;
            _this.selectedValue = []; // Range ONLY
            // Range ONLY
            _this.hoverValue = []; // Range ONLY
            // Range ONLY
            _this.dayHover = new core.EventEmitter(); // Emitted when hover on a day by mouse enter
            return _this;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DateTableComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            _super.prototype.ngOnChanges.call(this, changes);
            if (this.isDateRealChange(changes.activeDate) ||
                this.isDateRealChange(changes.value) ||
                this.isDateRealChange(changes.selectedValue) ||
                this.isDateRealChange(changes.hoverValue)) {
                this.render();
            }
        };
        /**
         * @private
         * @param {?} change
         * @return {?}
         */
        DateTableComponent.prototype.isDateRealChange = /**
         * @private
         * @param {?} change
         * @return {?}
         */
        function (change) {
            if (change) {
                /** @type {?} */
                var previousValue_1 = change.previousValue;
                /** @type {?} */
                var currentValue = change.currentValue;
                if (Array.isArray(currentValue)) {
                    return (!Array.isArray(previousValue_1) ||
                        currentValue.length !== previousValue_1.length ||
                        currentValue.some((/**
                         * @param {?} value
                         * @param {?} index
                         * @return {?}
                         */
                        function (value, index) {
                            /** @type {?} */
                            var previousCandyDate = previousValue_1[index];
                            return previousCandyDate instanceof time.CandyDate ? previousCandyDate.isSameDay(value) : previousCandyDate !== value;
                        })));
                }
                else {
                    return !this.isSameDate((/** @type {?} */ (previousValue_1)), currentValue);
                }
            }
            return false;
        };
        /**
         * @private
         * @param {?} left
         * @param {?} right
         * @return {?}
         */
        DateTableComponent.prototype.isSameDate = /**
         * @private
         * @param {?} left
         * @param {?} right
         * @return {?}
         */
        function (left, right) {
            return (!left && !right) || (left && right && right.isSameDay(left));
        };
        /**
         * @private
         * @param {?} value
         * @return {?}
         */
        DateTableComponent.prototype.changeValueFromInside = /**
         * @private
         * @param {?} value
         * @return {?}
         */
        function (value) {
            // Only change date not change time
            this.activeDate = this.activeDate.setYear(value.getYear()).setMonth(value.getMonth()).setDate(value.getDate());
            this.valueChange.emit(this.activeDate);
            if (!this.activeDate.isSameMonth(this.value)) {
                this.render();
            }
        };
        /**
         * @return {?}
         */
        DateTableComponent.prototype.makeHeadRow = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var weekDays = [];
            /** @type {?} */
            var start = this.activeDate.calendarStart({ weekStartsOn: this.dateHelper.getFirstDayOfWeek() });
            for (var colIndex = 0; colIndex < this.MAX_COL; colIndex++) {
                /** @type {?} */
                var day = start.addDays(colIndex);
                weekDays.push({
                    value: day.nativeDate,
                    title: this.dateHelper.format(day.nativeDate, 'E'),
                    // eg. Tue
                    content: this.dateHelper.format(day.nativeDate, this.getVeryShortWeekFormat()),
                    // eg. Tu,
                    isSelected: false,
                    isDisabled: false,
                    onClick: /**
                     * @return {?}
                     */
                    function () { },
                    onMouseEnter: /**
                     * @return {?}
                     */
                    function () { }
                });
            }
            return weekDays;
        };
        /**
         * @private
         * @return {?}
         */
        DateTableComponent.prototype.getVeryShortWeekFormat = /**
         * @private
         * @return {?}
         */
        function () {
            return this.i18n.getLocaleId().toLowerCase().indexOf('zh') === 0 ? 'EEEEE' : 'EEEEEE'; // Use extreme short for chinese
        };
        /**
         * @return {?}
         */
        DateTableComponent.prototype.makeBodyRows = /**
         * @return {?}
         */
        function () {
            var _a;
            var _this = this;
            var _b;
            /** @type {?} */
            var weekRows = [];
            /** @type {?} */
            var firstDayOfMonth = this.activeDate.calendarStart({ weekStartsOn: this.dateHelper.getFirstDayOfWeek() });
            for (var week = 0; week < this.MAX_ROW; week++) {
                /** @type {?} */
                var weekStart = firstDayOfMonth.addDays(week * 7);
                /** @type {?} */
                var row = {
                    isActive: false,
                    isCurrent: false,
                    dateCells: [],
                    year: weekStart.getYear()
                };
                var _loop_1 = function (day) {
                    /** @type {?} */
                    var date = weekStart.addDays(day);
                    /** @type {?} */
                    var dateFormat = transCompatFormat(this_1.i18n.getLocaleData('DatePicker.lang.dateFormat', 'YYYY-MM-DD'));
                    /** @type {?} */
                    var title = this_1.dateHelper.format(date.nativeDate, dateFormat);
                    /** @type {?} */
                    var label = this_1.dateHelper.format(date.nativeDate, 'dd');
                    /** @type {?} */
                    var cell = {
                        value: date.nativeDate,
                        label: label,
                        isSelected: false,
                        isDisabled: false,
                        isToday: false,
                        title: title,
                        cellRender: util.valueFunctionProp((/** @type {?} */ (this_1.cellRender)), date),
                        // Customized content
                        fullCellRender: util.valueFunctionProp((/** @type {?} */ (this_1.fullCellRender)), date),
                        content: "" + date.getDate(),
                        onClick: (/**
                         * @return {?}
                         */
                        function () { return _this.changeValueFromInside(date); }),
                        onMouseEnter: (/**
                         * @return {?}
                         */
                        function () { return _this.dayHover.emit(date); })
                    };
                    if (this_1.showWeek && !row.weekNum) {
                        row.weekNum = this_1.dateHelper.getISOWeek(date.nativeDate);
                    }
                    if (date.isToday()) {
                        cell.isToday = true;
                        row.isCurrent = true;
                    }
                    if (((Array.isArray(this_1.selectedValue) && this_1.selectedValue.length > 0) || (this_1.hoverValue && this_1.hoverValue.length > 0)) &&
                        date.isSameMonth(this_1.activeDate)) {
                        var _a = __read(this_1.hoverValue, 2), startHover = _a[0], endHover = _a[1];
                        var _b = __read(this_1.selectedValue, 2), startSelected = _b[0], endSelected = _b[1];
                        // Selected
                        if (startSelected && startSelected.isSameDay(date)) {
                            cell.isSelectedStartDate = true;
                            cell.isSelected = true;
                            row.isActive = true;
                        }
                        if (endSelected && endSelected.isSameDay(date)) {
                            cell.isSelectedEndDate = true;
                            cell.isSelected = true;
                            row.isActive = true;
                        }
                        else if (date.isAfterDay(startSelected) && date.isBeforeDay(endSelected)) {
                            cell.isInSelectedRange = true;
                        }
                        if (startHover && endHover) {
                            // Hover
                            if (startHover.isSameDay(date)) {
                                cell.isHoverStartDate = true;
                            }
                            if (endHover.isSameDay(date)) {
                                cell.isHoverEndDate = true;
                            }
                            if (date.isLastDayOfMonth()) {
                                cell.isLastDayOfMonth = true;
                            }
                            if (date.isFirstDayOfMonth()) {
                                cell.isFirstDayOfMonth = true;
                            }
                        }
                        if (startSelected && !endSelected) {
                            cell.isStartSingle = true;
                        }
                        if (!startSelected && endSelected) {
                            cell.isEndSingle = true;
                        }
                        if (date.isAfterDay(startHover) && date.isBeforeDay(endHover)) {
                            cell.isInHoverRange = true;
                        }
                    }
                    else if (date.isSameDay(this_1.value)) {
                        cell.isSelected = true;
                        row.isActive = true;
                    }
                    if ((_b = this_1.disabledDate) === null || _b === void 0 ? void 0 : _b.call(this_1, date.nativeDate)) {
                        cell.isDisabled = true;
                    }
                    cell.classMap = this_1.getClassMap(cell);
                    row.dateCells.push(cell);
                };
                var this_1 = this;
                for (var day = 0; day < 7; day++) {
                    _loop_1(day);
                }
                row.classMap = (_a = {},
                    _a[this.prefixCls + "-week-panel-row"] = this.showWeek,
                    _a[this.prefixCls + "-week-panel-row-selected"] = this.showWeek && row.isActive,
                    _a);
                weekRows.push(row);
            }
            return weekRows;
        };
        /**
         * @param {?} cell
         * @return {?}
         */
        DateTableComponent.prototype.getClassMap = /**
         * @param {?} cell
         * @return {?}
         */
        function (cell) {
            var _a;
            /** @type {?} */
            var date = new time.CandyDate(cell.value);
            return _a = {},
                _a["ant-picker-cell"] = true,
                _a["ant-picker-cell-today"] = !!cell.isToday,
                _a["ant-picker-cell-in-view"] = date.isSameMonth(this.activeDate),
                _a["ant-picker-cell-selected"] = cell.isSelected,
                _a["ant-picker-cell-disabled"] = cell.isDisabled,
                _a["ant-picker-cell-in-range"] = !!cell.isInSelectedRange,
                _a["ant-picker-cell-range-start"] = !!cell.isSelectedStartDate,
                _a["ant-picker-cell-range-end"] = !!cell.isSelectedEndDate,
                _a["ant-picker-cell-range-start-single"] = !!cell.isStartSingle,
                _a["ant-picker-cell-range-end-single"] = !!cell.isEndSingle,
                _a["ant-picker-cell-range-hover"] = !!cell.isInHoverRange,
                _a["ant-picker-cell-range-hover-start"] = !!cell.isHoverStartDate,
                _a["ant-picker-cell-range-hover-end"] = !!cell.isHoverEndDate,
                _a["ant-picker-cell-range-hover-edge-start"] = !!cell.isFirstDayOfMonth,
                _a["ant-picker-cell-range-hover-edge-end"] = !!cell.isLastDayOfMonth,
                _a;
        };
        /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        DateTableComponent.prototype.trackByBodyRow = /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        function (_index, item) {
            return item.year + "-" + item.weekNum;
        };
        /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        DateTableComponent.prototype.trackByBodyColumn = /**
         * @param {?} _index
         * @param {?} item
         * @return {?}
         */
        function (_index, item) {
            return (/** @type {?} */ (item.title));
        };
        DateTableComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'date-table',
                        exportAs: 'dateTable',
                        template: "<table class=\"ant-picker-content\" cellspacing=\"0\" role=\"grid\">\n  <thead *ngIf=\"headRow && headRow.length > 0\">\n    <tr role=\"row\">\n      <th *ngIf=\"showWeek\" role=\"columnheader\"></th>\n      <th *ngFor=\"let cell of headRow\" role=\"columnheader\" title=\"{{ cell.title }}\">\n        {{ cell.content }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let row of bodyRows; trackBy: trackByBodyRow\" [ngClass]=\"row.classMap!\" role=\"row\">\n      <td *ngIf=\"row.weekNum\" role=\"gridcell\" class=\"{{ prefixCls }}-cell-week\">\n        {{ row.weekNum }}\n      </td>\n      <td\n        *ngFor=\"let cell of row.dateCells; trackBy: trackByBodyColumn\"\n        title=\"{{ cell.title }}\"\n        role=\"gridcell\"\n        [ngClass]=\"cell.classMap!\"\n        (click)=\"cell.isDisabled ? null : cell.onClick()\"\n        (mouseenter)=\"cell.onMouseEnter()\"\n      >\n        <ng-container [ngSwitch]=\"prefixCls\">\n          <ng-container *ngSwitchCase=\"'ant-picker'\">\n            <ng-container [ngSwitch]=\"true\">\n              <ng-container *ngSwitchCase=\"isTemplateRef(cell.cellRender)\">\n                <!--           *ngSwitchCase not has type assertion support, the cellRender type here is TemplateRef -->\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                ></ng-container>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"isNonEmptyString(cell.cellRender)\">\n                <span [innerHTML]=\"cell.cellRender\"></span>\n              </ng-container>\n              <ng-container *ngSwitchDefault>\n                <div\n                  class=\"{{ prefixCls }}-cell-inner\"\n                  [attr.aria-selected]=\"cell.isSelected\"\n                  [attr.aria-disabled]=\"cell.isDisabled\"\n                >\n                  {{ cell.content }}\n                </div>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'ant-picker-calendar'\">\n            <div\n              class=\"{{ prefixCls }}-date ant-picker-cell-inner\"\n              [class.ant-picker-calendar-date-today]=\"cell.isToday\"\n            >\n              <ng-container *ngIf=\"cell.fullCellRender; else defaultCell\">\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.fullCellRender); context: { $implicit: cell.value }\"\n                >\n                </ng-container>\n              </ng-container>\n              <ng-template #defaultCell>\n                <div class=\"{{ prefixCls }}-date-value\">{{ cell.content }}</div>\n                <div class=\"{{ prefixCls }}-date-content\">\n                  <ng-container\n                    *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                  >\n                  </ng-container>\n                </div>\n              </ng-template>\n            </div>\n          </ng-container>\n        </ng-container>\n      </td>\n    </tr>\n  </tbody>\n</table>\n"
                    }] }
        ];
        /** @nocollapse */
        DateTableComponent.ctorParameters = function () { return [
            { type: i18n.DwI18nService },
            { type: i18n.DateHelperService }
        ]; };
        DateTableComponent.propDecorators = {
            locale: [{ type: core.Input }],
            selectedValue: [{ type: core.Input }],
            hoverValue: [{ type: core.Input }],
            dayHover: [{ type: core.Output }]
        };
        return DateTableComponent;
    }(AbstractTable));
    if (false) {
        /** @type {?} */
        DateTableComponent.prototype.locale;
        /** @type {?} */
        DateTableComponent.prototype.selectedValue;
        /** @type {?} */
        DateTableComponent.prototype.hoverValue;
        /** @type {?} */
        DateTableComponent.prototype.dayHover;
        /**
         * @type {?}
         * @private
         */
        DateTableComponent.prototype.i18n;
        /**
         * @type {?}
         * @private
         */
        DateTableComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/decade-header.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DecadeHeaderComponent = /** @class */ (function (_super) {
        __extends(DecadeHeaderComponent, _super);
        function DecadeHeaderComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * @return {?}
         */
        DecadeHeaderComponent.prototype.previous = /**
         * @return {?}
         */
        function () { };
        /**
         * @return {?}
         */
        DecadeHeaderComponent.prototype.next = /**
         * @return {?}
         */
        function () { };
        Object.defineProperty(DecadeHeaderComponent.prototype, "startYear", {
            get: /**
             * @return {?}
             */
            function () {
                return parseInt("" + this.value.getYear() / 100, 10) * 100;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DecadeHeaderComponent.prototype, "endYear", {
            get: /**
             * @return {?}
             */
            function () {
                return this.startYear + 99;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DecadeHeaderComponent.prototype.superPrevious = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(-100));
        };
        /**
         * @return {?}
         */
        DecadeHeaderComponent.prototype.superNext = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(100));
        };
        /**
         * @return {?}
         */
        DecadeHeaderComponent.prototype.getSelectors = /**
         * @return {?}
         */
        function () {
            return [
                {
                    className: this.prefixCls + "-decade-btn",
                    title: '',
                    onClick: (/**
                     * @return {?}
                     */
                    function () {
                        // noop
                    }),
                    label: this.startYear + "-" + this.endYear
                }
            ];
        };
        DecadeHeaderComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'decade-header',
                        // tslint:disable-line:component-selector
                        exportAs: 'decadeHeader',
                        template: "<div class=\"{{ prefixCls }}\">\n  <button\n    [style.visibility]=\"showSuperPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-prev-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superPreviousTitle() }}\"\n    (click)=\"superPrevious()\"\n  >\n    <span class=\"ant-picker-super-prev-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-prev-btn\"\n    role=\"button\"\n    title=\"{{ previousTitle() }}\"\n    tabindex=\"-1\"\n    (click)=\"previous()\"\n  >\n    <span class=\"ant-picker-prev-icon\"></span>\n  </button>\n\n  <div class=\"{{ prefixCls }}-view\">\n    <ng-container *ngFor=\"let selector of selectors\">\n      <button\n        class=\"{{ selector.className }}\"\n        role=\"button\"\n        type=\"button\"\n        title=\"{{ selector.title || null }}\"\n        (click)=\"selector.onClick()\"\n      >\n        {{ selector.label }}\n      </button>\n    </ng-container>\n  </div>\n  <button\n    [style.visibility]=\"showNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ nextTitle() }}\"\n    (click)=\"next()\"\n  >\n    <span class=\"ant-picker-next-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showSuperNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superNextTitle() }}\"\n    (click)=\"superNext()\"\n  >\n    <span class=\"ant-picker-super-next-icon\"></span>\n  </button>\n</div>\n"
                    }] }
        ];
        return DecadeHeaderComponent;
    }(AbstractPanelHeader));

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/decade-table.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var MAX_ROW = 4;
    /** @type {?} */
    var MAX_COL = 3;
    var DecadeTableComponent = /** @class */ (function (_super) {
        __extends(DecadeTableComponent, _super);
        function DecadeTableComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        DecadeTableComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes.value || changes.disabledDate || changes.activeDate) {
                this.render();
            }
        };
        Object.defineProperty(DecadeTableComponent.prototype, "startYear", {
            get: /**
             * @return {?}
             */
            function () {
                return parseInt("" + this.activeDate.getYear() / 100, 10) * 100;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DecadeTableComponent.prototype, "endYear", {
            get: /**
             * @return {?}
             */
            function () {
                return this.startYear + 99;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DecadeTableComponent.prototype.makeHeadRow = /**
         * @return {?}
         */
        function () {
            return [];
        };
        /**
         * @return {?}
         */
        DecadeTableComponent.prototype.makeBodyRows = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var decades = [];
            /** @type {?} */
            var currentYear = this.value && this.value.getYear();
            /** @type {?} */
            var startYear = this.startYear;
            /** @type {?} */
            var endYear = this.endYear;
            /** @type {?} */
            var previousYear = startYear - 10;
            /** @type {?} */
            var index = 0;
            for (var rowIndex = 0; rowIndex < MAX_ROW; rowIndex++) {
                /** @type {?} */
                var row = [];
                var _loop_1 = function (colIndex) {
                    /** @type {?} */
                    var start = previousYear + index * 10;
                    /** @type {?} */
                    var end = previousYear + index * 10 + 9;
                    /** @type {?} */
                    var content = start + "-" + end;
                    /** @type {?} */
                    var cell = {
                        value: this_1.activeDate.setYear(start).nativeDate,
                        content: content,
                        title: content,
                        isDisabled: false,
                        isSelected: currentYear >= start && currentYear <= end,
                        isLowerThanStart: end < startYear,
                        isBiggerThanEnd: start > endYear,
                        classMap: {},
                        onClick: /**
                         * @return {?}
                         */
                        function () { },
                        onMouseEnter: /**
                         * @return {?}
                         */
                        function () { }
                    };
                    cell.classMap = this_1.getClassMap(cell);
                    cell.onClick = (/**
                     * @return {?}
                     */
                    function () { return _this.chooseDecade(start); });
                    index++;
                    row.push(cell);
                };
                var this_1 = this;
                for (var colIndex = 0; colIndex < MAX_COL; colIndex++) {
                    _loop_1(colIndex);
                }
                decades.push({ dateCells: row });
            }
            return decades;
        };
        /**
         * @param {?} cell
         * @return {?}
         */
        DecadeTableComponent.prototype.getClassMap = /**
         * @param {?} cell
         * @return {?}
         */
        function (cell) {
            var _a;
            return _a = {},
                _a[this.prefixCls + "-cell"] = true,
                _a[this.prefixCls + "-cell-in-view"] = !cell.isBiggerThanEnd && !cell.isLowerThanStart,
                _a[this.prefixCls + "-cell-selected"] = cell.isSelected,
                _a[this.prefixCls + "-cell-disabled"] = cell.isDisabled,
                _a;
        };
        /**
         * @private
         * @param {?} year
         * @return {?}
         */
        DecadeTableComponent.prototype.chooseDecade = /**
         * @private
         * @param {?} year
         * @return {?}
         */
        function (year) {
            this.value = this.activeDate.setYear(year);
            this.valueChange.emit(this.value);
        };
        DecadeTableComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'decade-table',
                        exportAs: 'decadeTable',
                        template: "<table class=\"ant-picker-content\" cellspacing=\"0\" role=\"grid\">\n  <thead *ngIf=\"headRow && headRow.length > 0\">\n    <tr role=\"row\">\n      <th *ngIf=\"showWeek\" role=\"columnheader\"></th>\n      <th *ngFor=\"let cell of headRow\" role=\"columnheader\" title=\"{{ cell.title }}\">\n        {{ cell.content }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let row of bodyRows; trackBy: trackByBodyRow\" [ngClass]=\"row.classMap!\" role=\"row\">\n      <td *ngIf=\"row.weekNum\" role=\"gridcell\" class=\"{{ prefixCls }}-cell-week\">\n        {{ row.weekNum }}\n      </td>\n      <td\n        *ngFor=\"let cell of row.dateCells; trackBy: trackByBodyColumn\"\n        title=\"{{ cell.title }}\"\n        role=\"gridcell\"\n        [ngClass]=\"cell.classMap!\"\n        (click)=\"cell.isDisabled ? null : cell.onClick()\"\n        (mouseenter)=\"cell.onMouseEnter()\"\n      >\n        <ng-container [ngSwitch]=\"prefixCls\">\n          <ng-container *ngSwitchCase=\"'ant-picker'\">\n            <ng-container [ngSwitch]=\"true\">\n              <ng-container *ngSwitchCase=\"isTemplateRef(cell.cellRender)\">\n                <!--           *ngSwitchCase not has type assertion support, the cellRender type here is TemplateRef -->\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                ></ng-container>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"isNonEmptyString(cell.cellRender)\">\n                <span [innerHTML]=\"cell.cellRender\"></span>\n              </ng-container>\n              <ng-container *ngSwitchDefault>\n                <div\n                  class=\"{{ prefixCls }}-cell-inner\"\n                  [attr.aria-selected]=\"cell.isSelected\"\n                  [attr.aria-disabled]=\"cell.isDisabled\"\n                >\n                  {{ cell.content }}\n                </div>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'ant-picker-calendar'\">\n            <div\n              class=\"{{ prefixCls }}-date ant-picker-cell-inner\"\n              [class.ant-picker-calendar-date-today]=\"cell.isToday\"\n            >\n              <ng-container *ngIf=\"cell.fullCellRender; else defaultCell\">\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.fullCellRender); context: { $implicit: cell.value }\"\n                >\n                </ng-container>\n              </ng-container>\n              <ng-template #defaultCell>\n                <div class=\"{{ prefixCls }}-date-value\">{{ cell.content }}</div>\n                <div class=\"{{ prefixCls }}-date-content\">\n                  <ng-container\n                    *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                  >\n                  </ng-container>\n                </div>\n              </ng-template>\n            </div>\n          </ng-container>\n        </ng-container>\n      </td>\n    </tr>\n  </tbody>\n</table>\n"
                    }] }
        ];
        return DecadeTableComponent;
    }(AbstractTable));

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/month-header.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var MonthHeaderComponent = /** @class */ (function (_super) {
        __extends(MonthHeaderComponent, _super);
        function MonthHeaderComponent(dateHelper) {
            var _this = _super.call(this) || this;
            _this.dateHelper = dateHelper;
            return _this;
        }
        /**
         * @return {?}
         */
        MonthHeaderComponent.prototype.getSelectors = /**
         * @return {?}
         */
        function () {
            var _this = this;
            return [
                {
                    className: this.prefixCls + "-month-btn",
                    title: this.locale.yearSelect,
                    onClick: (/**
                     * @return {?}
                     */
                    function () { return _this.changeMode('year'); }),
                    label: this.dateHelper.format(this.value.nativeDate, transCompatFormat(this.locale.yearFormat))
                }
            ];
        };
        MonthHeaderComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'month-header',
                        // tslint:disable-line:component-selector
                        exportAs: 'monthHeader',
                        template: "<div class=\"{{ prefixCls }}\">\n  <button\n    [style.visibility]=\"showSuperPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-prev-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superPreviousTitle() }}\"\n    (click)=\"superPrevious()\"\n  >\n    <span class=\"ant-picker-super-prev-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-prev-btn\"\n    role=\"button\"\n    title=\"{{ previousTitle() }}\"\n    tabindex=\"-1\"\n    (click)=\"previous()\"\n  >\n    <span class=\"ant-picker-prev-icon\"></span>\n  </button>\n\n  <div class=\"{{ prefixCls }}-view\">\n    <ng-container *ngFor=\"let selector of selectors\">\n      <button\n        class=\"{{ selector.className }}\"\n        role=\"button\"\n        type=\"button\"\n        title=\"{{ selector.title || null }}\"\n        (click)=\"selector.onClick()\"\n      >\n        {{ selector.label }}\n      </button>\n    </ng-container>\n  </div>\n  <button\n    [style.visibility]=\"showNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ nextTitle() }}\"\n    (click)=\"next()\"\n  >\n    <span class=\"ant-picker-next-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showSuperNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superNextTitle() }}\"\n    (click)=\"superNext()\"\n  >\n    <span class=\"ant-picker-super-next-icon\"></span>\n  </button>\n</div>\n"
                    }] }
        ];
        /** @nocollapse */
        MonthHeaderComponent.ctorParameters = function () { return [
            { type: i18n.DateHelperService }
        ]; };
        return MonthHeaderComponent;
    }(AbstractPanelHeader));
    if (false) {
        /**
         * @type {?}
         * @private
         */
        MonthHeaderComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/month-table.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var MonthTableComponent = /** @class */ (function (_super) {
        __extends(MonthTableComponent, _super);
        function MonthTableComponent(dateHelper) {
            var _this = _super.call(this) || this;
            _this.dateHelper = dateHelper;
            _this.MAX_ROW = 4;
            _this.MAX_COL = 3;
            return _this;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        MonthTableComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            _super.prototype.ngOnChanges.call(this, changes);
            if (changes.value || changes.disabledDate || changes.activeDate) {
                this.render();
            }
        };
        /**
         * @return {?}
         */
        MonthTableComponent.prototype.makeHeadRow = /**
         * @return {?}
         */
        function () {
            return [];
        };
        /**
         * @return {?}
         */
        MonthTableComponent.prototype.makeBodyRows = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var months = [];
            /** @type {?} */
            var currentMonth = this.value && this.value.getMonth();
            /** @type {?} */
            var monthValue = 0;
            for (var rowIndex = 0; rowIndex < this.MAX_ROW; rowIndex++) {
                /** @type {?} */
                var row = [];
                var _loop_1 = function (colIndex) {
                    /** @type {?} */
                    var month = this_1.activeDate.setMonth(monthValue);
                    /** @type {?} */
                    var isDisabled = this_1.disabledDate ? this_1.disabledDate(month.nativeDate) : false;
                    /** @type {?} */
                    var content = this_1.dateHelper.format(month.nativeDate, 'MMM');
                    /** @type {?} */
                    var cell = {
                        value: month.nativeDate,
                        isDisabled: isDisabled,
                        isSelected: monthValue === currentMonth,
                        content: content,
                        title: content,
                        classMap: {},
                        cellRender: util.valueFunctionProp((/** @type {?} */ (this_1.cellRender)), month),
                        // Customized content
                        fullCellRender: util.valueFunctionProp((/** @type {?} */ (this_1.fullCellRender)), month),
                        onClick: (/**
                         * @return {?}
                         */
                        function () { return _this.chooseMonth(cell.value.getMonth()); }),
                        // don't use monthValue here,
                        onMouseEnter: (/**
                         * @return {?}
                         */
                        function () { return null; })
                    };
                    cell.classMap = this_1.getClassMap(cell);
                    row.push(cell);
                    monthValue++;
                };
                var this_1 = this;
                for (var colIndex = 0; colIndex < this.MAX_COL; colIndex++) {
                    _loop_1(colIndex);
                }
                months.push({ dateCells: row });
            }
            return months;
        };
        /**
         * @param {?} cell
         * @return {?}
         */
        MonthTableComponent.prototype.getClassMap = /**
         * @param {?} cell
         * @return {?}
         */
        function (cell) {
            var _a;
            return _a = {},
                _a["ant-picker-cell"] = true,
                _a["ant-picker-cell-in-view"] = true,
                _a["ant-picker-cell-selected"] = cell.isSelected,
                _a["ant-picker-cell-disabled"] = cell.isDisabled,
                _a;
        };
        /**
         * @private
         * @param {?} month
         * @return {?}
         */
        MonthTableComponent.prototype.chooseMonth = /**
         * @private
         * @param {?} month
         * @return {?}
         */
        function (month) {
            this.value = this.activeDate.setMonth(month);
            this.valueChange.emit(this.value);
        };
        MonthTableComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'month-table',
                        exportAs: 'monthTable',
                        template: "<table class=\"ant-picker-content\" cellspacing=\"0\" role=\"grid\">\n  <thead *ngIf=\"headRow && headRow.length > 0\">\n    <tr role=\"row\">\n      <th *ngIf=\"showWeek\" role=\"columnheader\"></th>\n      <th *ngFor=\"let cell of headRow\" role=\"columnheader\" title=\"{{ cell.title }}\">\n        {{ cell.content }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let row of bodyRows; trackBy: trackByBodyRow\" [ngClass]=\"row.classMap!\" role=\"row\">\n      <td *ngIf=\"row.weekNum\" role=\"gridcell\" class=\"{{ prefixCls }}-cell-week\">\n        {{ row.weekNum }}\n      </td>\n      <td\n        *ngFor=\"let cell of row.dateCells; trackBy: trackByBodyColumn\"\n        title=\"{{ cell.title }}\"\n        role=\"gridcell\"\n        [ngClass]=\"cell.classMap!\"\n        (click)=\"cell.isDisabled ? null : cell.onClick()\"\n        (mouseenter)=\"cell.onMouseEnter()\"\n      >\n        <ng-container [ngSwitch]=\"prefixCls\">\n          <ng-container *ngSwitchCase=\"'ant-picker'\">\n            <ng-container [ngSwitch]=\"true\">\n              <ng-container *ngSwitchCase=\"isTemplateRef(cell.cellRender)\">\n                <!--           *ngSwitchCase not has type assertion support, the cellRender type here is TemplateRef -->\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                ></ng-container>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"isNonEmptyString(cell.cellRender)\">\n                <span [innerHTML]=\"cell.cellRender\"></span>\n              </ng-container>\n              <ng-container *ngSwitchDefault>\n                <div\n                  class=\"{{ prefixCls }}-cell-inner\"\n                  [attr.aria-selected]=\"cell.isSelected\"\n                  [attr.aria-disabled]=\"cell.isDisabled\"\n                >\n                  {{ cell.content }}\n                </div>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'ant-picker-calendar'\">\n            <div\n              class=\"{{ prefixCls }}-date ant-picker-cell-inner\"\n              [class.ant-picker-calendar-date-today]=\"cell.isToday\"\n            >\n              <ng-container *ngIf=\"cell.fullCellRender; else defaultCell\">\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.fullCellRender); context: { $implicit: cell.value }\"\n                >\n                </ng-container>\n              </ng-container>\n              <ng-template #defaultCell>\n                <div class=\"{{ prefixCls }}-date-value\">{{ cell.content }}</div>\n                <div class=\"{{ prefixCls }}-date-content\">\n                  <ng-container\n                    *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                  >\n                  </ng-container>\n                </div>\n              </ng-template>\n            </div>\n          </ng-container>\n        </ng-container>\n      </td>\n    </tr>\n  </tbody>\n</table>\n"
                    }] }
        ];
        /** @nocollapse */
        MonthTableComponent.ctorParameters = function () { return [
            { type: i18n.DateHelperService }
        ]; };
        return MonthTableComponent;
    }(AbstractTable));
    if (false) {
        /** @type {?} */
        MonthTableComponent.prototype.MAX_ROW;
        /** @type {?} */
        MonthTableComponent.prototype.MAX_COL;
        /**
         * @type {?}
         * @private
         */
        MonthTableComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/year-header.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var YearHeaderComponent = /** @class */ (function (_super) {
        __extends(YearHeaderComponent, _super);
        function YearHeaderComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(YearHeaderComponent.prototype, "startYear", {
            get: /**
             * @return {?}
             */
            function () {
                return parseInt("" + this.value.getYear() / 10, 10) * 10;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(YearHeaderComponent.prototype, "endYear", {
            get: /**
             * @return {?}
             */
            function () {
                return this.startYear + 9;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        YearHeaderComponent.prototype.superPrevious = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(-10));
        };
        /**
         * @return {?}
         */
        YearHeaderComponent.prototype.superNext = /**
         * @return {?}
         */
        function () {
            this.changeValue(this.value.addYears(10));
        };
        /**
         * @return {?}
         */
        YearHeaderComponent.prototype.getSelectors = /**
         * @return {?}
         */
        function () {
            var _this = this;
            return [
                {
                    className: this.prefixCls + "-year-btn",
                    title: '',
                    onClick: (/**
                     * @return {?}
                     */
                    function () { return _this.changeMode('decade'); }),
                    label: this.startYear + "-" + this.endYear
                }
            ];
        };
        YearHeaderComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        selector: 'year-header',
                        // tslint:disable-line:component-selector
                        exportAs: 'yearHeader',
                        template: "<div class=\"{{ prefixCls }}\">\n  <button\n    [style.visibility]=\"showSuperPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-prev-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superPreviousTitle() }}\"\n    (click)=\"superPrevious()\"\n  >\n    <span class=\"ant-picker-super-prev-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showPreBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-prev-btn\"\n    role=\"button\"\n    title=\"{{ previousTitle() }}\"\n    tabindex=\"-1\"\n    (click)=\"previous()\"\n  >\n    <span class=\"ant-picker-prev-icon\"></span>\n  </button>\n\n  <div class=\"{{ prefixCls }}-view\">\n    <ng-container *ngFor=\"let selector of selectors\">\n      <button\n        class=\"{{ selector.className }}\"\n        role=\"button\"\n        type=\"button\"\n        title=\"{{ selector.title || null }}\"\n        (click)=\"selector.onClick()\"\n      >\n        {{ selector.label }}\n      </button>\n    </ng-container>\n  </div>\n  <button\n    [style.visibility]=\"showNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ nextTitle() }}\"\n    (click)=\"next()\"\n  >\n    <span class=\"ant-picker-next-icon\"></span>\n  </button>\n  <button\n    [style.visibility]=\"showSuperNextBtn ? 'visible' : 'hidden'\"\n    class=\"{{ prefixCls }}-super-next-btn\"\n    role=\"button\"\n    tabindex=\"-1\"\n    title=\"{{ superNextTitle() }}\"\n    (click)=\"superNext()\"\n  >\n    <span class=\"ant-picker-super-next-icon\"></span>\n  </button>\n</div>\n"
                    }] }
        ];
        return YearHeaderComponent;
    }(AbstractPanelHeader));

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/year-table.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var YearTableComponent = /** @class */ (function (_super) {
        __extends(YearTableComponent, _super);
        function YearTableComponent(dateHelper) {
            var _this = _super.call(this) || this;
            _this.dateHelper = dateHelper;
            _this.MAX_ROW = 4;
            _this.MAX_COL = 3;
            return _this;
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        YearTableComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            _super.prototype.ngOnChanges.call(this, changes);
            if (changes.value || changes.disabledDate || changes.activeDate) {
                this.render();
            }
        };
        /**
         * @return {?}
         */
        YearTableComponent.prototype.makeHeadRow = /**
         * @return {?}
         */
        function () {
            return [];
        };
        /**
         * @return {?}
         */
        YearTableComponent.prototype.makeBodyRows = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var currentYear = this.activeDate && this.activeDate.getYear();
            /** @type {?} */
            var startYear = parseInt("" + currentYear / 10, 10) * 10;
            /** @type {?} */
            var endYear = startYear + 9;
            /** @type {?} */
            var previousYear = startYear - 1;
            /** @type {?} */
            var years = [];
            /** @type {?} */
            var yearValue = 0;
            for (var rowIndex = 0; rowIndex < this.MAX_ROW; rowIndex++) {
                /** @type {?} */
                var row = [];
                var _loop_1 = function (colIndex) {
                    /** @type {?} */
                    var yearNum = previousYear + yearValue;
                    /** @type {?} */
                    var year = this_1.activeDate.setYear(yearNum);
                    /** @type {?} */
                    var content = this_1.dateHelper.format(year.nativeDate, 'yyyy');
                    /** @type {?} */
                    var isDisabled = this_1.disabledDate ? this_1.disabledDate(year.nativeDate) : false;
                    /** @type {?} */
                    var cell = {
                        value: year.nativeDate,
                        isDisabled: isDisabled,
                        isSameDecade: yearNum >= startYear && yearNum <= endYear,
                        isSelected: yearNum === (this_1.value && this_1.value.getYear()),
                        content: content,
                        title: content,
                        classMap: {},
                        cellRender: util.valueFunctionProp((/** @type {?} */ (this_1.cellRender)), year),
                        // Customized content
                        fullCellRender: util.valueFunctionProp((/** @type {?} */ (this_1.fullCellRender)), year),
                        onClick: (/**
                         * @return {?}
                         */
                        function () { return _this.chooseYear(cell.value.getFullYear()); }),
                        // don't use yearValue here,
                        onMouseEnter: (/**
                         * @return {?}
                         */
                        function () { return null; })
                    };
                    cell.classMap = this_1.getClassMap(cell);
                    row.push(cell);
                    yearValue++;
                };
                var this_1 = this;
                for (var colIndex = 0; colIndex < this.MAX_COL; colIndex++) {
                    _loop_1(colIndex);
                }
                years.push({ dateCells: row });
            }
            return years;
        };
        /**
         * @param {?} cell
         * @return {?}
         */
        YearTableComponent.prototype.getClassMap = /**
         * @param {?} cell
         * @return {?}
         */
        function (cell) {
            var _a;
            return _a = {},
                _a[this.prefixCls + "-cell"] = true,
                _a[this.prefixCls + "-cell-in-view"] = !!cell.isSameDecade,
                _a[this.prefixCls + "-cell-selected"] = cell.isSelected,
                _a[this.prefixCls + "-cell-disabled"] = cell.isDisabled,
                _a;
        };
        /**
         * @private
         * @param {?} year
         * @return {?}
         */
        YearTableComponent.prototype.chooseYear = /**
         * @private
         * @param {?} year
         * @return {?}
         */
        function (year) {
            this.value = this.activeDate.setYear(year);
            this.valueChange.emit(this.value);
            this.render();
        };
        YearTableComponent.decorators = [
            { type: core.Component, args: [{
                        encapsulation: core.ViewEncapsulation.None,
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        // tslint:disable-next-line:component-selector
                        selector: 'year-table',
                        exportAs: 'yearTable',
                        template: "<table class=\"ant-picker-content\" cellspacing=\"0\" role=\"grid\">\n  <thead *ngIf=\"headRow && headRow.length > 0\">\n    <tr role=\"row\">\n      <th *ngIf=\"showWeek\" role=\"columnheader\"></th>\n      <th *ngFor=\"let cell of headRow\" role=\"columnheader\" title=\"{{ cell.title }}\">\n        {{ cell.content }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let row of bodyRows; trackBy: trackByBodyRow\" [ngClass]=\"row.classMap!\" role=\"row\">\n      <td *ngIf=\"row.weekNum\" role=\"gridcell\" class=\"{{ prefixCls }}-cell-week\">\n        {{ row.weekNum }}\n      </td>\n      <td\n        *ngFor=\"let cell of row.dateCells; trackBy: trackByBodyColumn\"\n        title=\"{{ cell.title }}\"\n        role=\"gridcell\"\n        [ngClass]=\"cell.classMap!\"\n        (click)=\"cell.isDisabled ? null : cell.onClick()\"\n        (mouseenter)=\"cell.onMouseEnter()\"\n      >\n        <ng-container [ngSwitch]=\"prefixCls\">\n          <ng-container *ngSwitchCase=\"'ant-picker'\">\n            <ng-container [ngSwitch]=\"true\">\n              <ng-container *ngSwitchCase=\"isTemplateRef(cell.cellRender)\">\n                <!--           *ngSwitchCase not has type assertion support, the cellRender type here is TemplateRef -->\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                ></ng-container>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"isNonEmptyString(cell.cellRender)\">\n                <span [innerHTML]=\"cell.cellRender\"></span>\n              </ng-container>\n              <ng-container *ngSwitchDefault>\n                <div\n                  class=\"{{ prefixCls }}-cell-inner\"\n                  [attr.aria-selected]=\"cell.isSelected\"\n                  [attr.aria-disabled]=\"cell.isDisabled\"\n                >\n                  {{ cell.content }}\n                </div>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"'ant-picker-calendar'\">\n            <div\n              class=\"{{ prefixCls }}-date ant-picker-cell-inner\"\n              [class.ant-picker-calendar-date-today]=\"cell.isToday\"\n            >\n              <ng-container *ngIf=\"cell.fullCellRender; else defaultCell\">\n                <ng-container\n                  *ngTemplateOutlet=\"$any(cell.fullCellRender); context: { $implicit: cell.value }\"\n                >\n                </ng-container>\n              </ng-container>\n              <ng-template #defaultCell>\n                <div class=\"{{ prefixCls }}-date-value\">{{ cell.content }}</div>\n                <div class=\"{{ prefixCls }}-date-content\">\n                  <ng-container\n                    *ngTemplateOutlet=\"$any(cell.cellRender); context: { $implicit: cell.value }\"\n                  >\n                  </ng-container>\n                </div>\n              </ng-template>\n            </div>\n          </ng-container>\n        </ng-container>\n      </td>\n    </tr>\n  </tbody>\n</table>\n"
                    }] }
        ];
        /** @nocollapse */
        YearTableComponent.ctorParameters = function () { return [
            { type: i18n.DateHelperService }
        ]; };
        return YearTableComponent;
    }(AbstractTable));
    if (false) {
        /** @type {?} */
        YearTableComponent.prototype.MAX_ROW;
        /** @type {?} */
        YearTableComponent.prototype.MAX_COL;
        /**
         * @type {?}
         * @private
         */
        YearTableComponent.prototype.dateHelper;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/lib-packer.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var LibPackerModule = /** @class */ (function () {
        function LibPackerModule() {
        }
        LibPackerModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule, forms.FormsModule, i18n.DwI18nModule, timePicker.DwTimePickerModule, outlet.DwOutletModule],
                        exports: [
                            DateHeaderComponent,
                            DateTableComponent,
                            DecadeHeaderComponent,
                            DecadeTableComponent,
                            MonthHeaderComponent,
                            MonthTableComponent,
                            YearHeaderComponent,
                            YearTableComponent
                        ],
                        declarations: [
                            DateHeaderComponent,
                            DateTableComponent,
                            DecadeHeaderComponent,
                            DecadeTableComponent,
                            MonthHeaderComponent,
                            MonthTableComponent,
                            YearHeaderComponent,
                            YearTableComponent
                        ]
                    },] }
        ];
        return LibPackerModule;
    }());

    /**
     * @fileoverview added by tsickle
     * Generated from: month-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwMonthPickerComponent = /** @class */ (function () {
        function DwMonthPickerComponent(datePicker) {
            this.datePicker = datePicker;
            this.datePicker.dwMode = 'month';
            this.datePicker.dwFormat = 'yyyy-MM';
        }
        DwMonthPickerComponent.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-month-picker',
                        exportAs: 'dwMonthPicker'
                    },] }
        ];
        /** @nocollapse */
        DwMonthPickerComponent.ctorParameters = function () { return [
            { type: DwDatePickerComponent, decorators: [{ type: core.Optional }, { type: core.Host }] }
        ]; };
        return DwMonthPickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwMonthPickerComponent.prototype.datePicker;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: range-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwRangePickerComponent = /** @class */ (function () {
        function DwRangePickerComponent(datePicker) {
            this.datePicker = datePicker;
            this.datePicker.isRange = true;
            this.datePicker.dwMode = ['date', 'date'];
        }
        DwRangePickerComponent.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-range-picker',
                        exportAs: 'dwRangePicker'
                    },] }
        ];
        /** @nocollapse */
        DwRangePickerComponent.ctorParameters = function () { return [
            { type: DwDatePickerComponent, decorators: [{ type: core.Optional }, { type: core.Host }] }
        ]; };
        return DwRangePickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwRangePickerComponent.prototype.datePicker;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: week-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwWeekPickerComponent = /** @class */ (function () {
        function DwWeekPickerComponent(datePicker) {
            this.datePicker = datePicker;
            this.datePicker.showWeek = true;
            this.datePicker.dwMode = 'week';
            this.datePicker.dwFormat = 'yyyy-ww';
        }
        DwWeekPickerComponent.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-week-picker',
                        exportAs: 'dwWeekPicker'
                    },] }
        ];
        /** @nocollapse */
        DwWeekPickerComponent.ctorParameters = function () { return [
            { type: DwDatePickerComponent, decorators: [{ type: core.Optional }, { type: core.Host }] }
        ]; };
        return DwWeekPickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwWeekPickerComponent.prototype.datePicker;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: year-picker.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwYearPickerComponent = /** @class */ (function () {
        function DwYearPickerComponent(datePicker) {
            this.datePicker = datePicker;
            this.datePicker.dwMode = 'year';
            this.datePicker.dwFormat = 'yyyy';
        }
        DwYearPickerComponent.decorators = [
            { type: core.Directive, args: [{
                        selector: 'dw-year-picker',
                        exportAs: 'dwYearPicker'
                    },] }
        ];
        /** @nocollapse */
        DwYearPickerComponent.ctorParameters = function () { return [
            { type: DwDatePickerComponent, decorators: [{ type: core.Optional }, { type: core.Host }] }
        ]; };
        return DwYearPickerComponent;
    }());
    if (false) {
        /** @type {?} */
        DwYearPickerComponent.prototype.datePicker;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: date-picker.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwDatePickerModule = /** @class */ (function () {
        function DwDatePickerModule() {
        }
        DwDatePickerModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            forms.FormsModule,
                            overlay.OverlayModule,
                            LibPackerModule,
                            icon.DwIconModule,
                            overlay$1.DwOverlayModule,
                            noAnimation.DwNoAnimationModule,
                            outlet.DwOutletModule,
                            timePicker.DwTimePickerModule,
                            button.DwButtonModule,
                            LibPackerModule
                        ],
                        exports: [DwDatePickerComponent, DwRangePickerComponent, DwMonthPickerComponent, DwYearPickerComponent, DwWeekPickerComponent],
                        declarations: [
                            DwPickerComponent,
                            DwDatePickerComponent,
                            DwMonthPickerComponent,
                            DwYearPickerComponent,
                            DwWeekPickerComponent,
                            DwRangePickerComponent,
                            CalendarFooterComponent,
                            InnerPopupComponent,
                            DateRangePopupComponent
                        ]
                    },] }
        ];
        return DwDatePickerModule;
    }());

    exports.DwDatePickerComponent = DwDatePickerComponent;
    exports.DwDatePickerModule = DwDatePickerModule;
    exports.DwMonthPickerComponent = DwMonthPickerComponent;
    exports.DwRangePickerComponent = DwRangePickerComponent;
    exports.DwWeekPickerComponent = DwWeekPickerComponent;
    exports.DwYearPickerComponent = DwYearPickerComponent;
    exports.LibPackerModule = LibPackerModule;
    exports.PREFIX_CLASS = PREFIX_CLASS;
    exports.getTimeConfig = getTimeConfig;
    exports.isAllowedDate = isAllowedDate;
    exports.isTimeValid = isTimeValid;
    exports.isTimeValidByConfig = isTimeValidByConfig;
    exports.transCompatFormat = transCompatFormat;
    exports.ɵAbstractPanelHeader = AbstractPanelHeader;
    exports.ɵAbstractTable = AbstractTable;
    exports.ɵCalendarFooterComponent = CalendarFooterComponent;
    exports.ɵDateHeaderComponent = DateHeaderComponent;
    exports.ɵDatePickerService = DatePickerService;
    exports.ɵDateRangePopupComponent = DateRangePopupComponent;
    exports.ɵDateTableComponent = DateTableComponent;
    exports.ɵDecadeHeaderComponent = DecadeHeaderComponent;
    exports.ɵDecadeTableComponent = DecadeTableComponent;
    exports.ɵDwPickerComponent = DwPickerComponent;
    exports.ɵInnerPopupComponent = InnerPopupComponent;
    exports.ɵMonthHeaderComponent = MonthHeaderComponent;
    exports.ɵMonthTableComponent = MonthTableComponent;
    exports.ɵYearHeaderComponent = YearHeaderComponent;
    exports.ɵYearTableComponent = YearTableComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-date-picker.umd.js.map
