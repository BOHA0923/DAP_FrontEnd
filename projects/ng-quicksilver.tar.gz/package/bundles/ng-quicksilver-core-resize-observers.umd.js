(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/cdk/coercion'), require('resize-observer-polyfill'), require('rxjs')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/core/resize-observers', ['exports', '@angular/core', '@angular/cdk/coercion', 'resize-observer-polyfill', 'rxjs'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].core = global['ng-quicksilver'].core || {}, global['ng-quicksilver'].core['resize-observers'] = {}), global.ng.core, global.ng.cdk.coercion, global.ResizeObserver, global.rxjs));
}(this, (function (exports, core, coercion, ResizeObserver, rxjs) { 'use strict';

    ResizeObserver = ResizeObserver && Object.prototype.hasOwnProperty.call(ResizeObserver, 'default') ? ResizeObserver['default'] : ResizeObserver;

    /**
     * @fileoverview added by tsickle
     * Generated from: resize-observers.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Factory that creates a new ResizeObserver and allows us to stub it out in unit tests.
     */
    var DwResizeObserverFactory = /** @class */ (function () {
        function DwResizeObserverFactory() {
        }
        /**
         * @param {?} callback
         * @return {?}
         */
        DwResizeObserverFactory.prototype.create = /**
         * @param {?} callback
         * @return {?}
         */
        function (callback) {
            return typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(callback);
        };
        DwResizeObserverFactory.decorators = [
            { type: core.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */ DwResizeObserverFactory.ɵprov = core.ɵɵdefineInjectable({ factory: function DwResizeObserverFactory_Factory() { return new DwResizeObserverFactory(); }, token: DwResizeObserverFactory, providedIn: "root" });
        return DwResizeObserverFactory;
    }());
    /**
     * An injectable service that allows watching elements for changes to their content.
     */
    var DwResizeObserver = /** @class */ (function () {
        function DwResizeObserver(dwResizeObserverFactory) {
            this.dwResizeObserverFactory = dwResizeObserverFactory;
            /**
             * Keeps track of the existing ResizeObservers so they can be reused.
             */
            this.observedElements = new Map();
        }
        /**
         * @return {?}
         */
        DwResizeObserver.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.observedElements.forEach((/**
             * @param {?} _
             * @param {?} element
             * @return {?}
             */
            function (_, element) { return _this.cleanupObserver(element); }));
        };
        /**
         * @param {?} elementOrRef
         * @return {?}
         */
        DwResizeObserver.prototype.observe = /**
         * @param {?} elementOrRef
         * @return {?}
         */
        function (elementOrRef) {
            var _this = this;
            /** @type {?} */
            var element = coercion.coerceElement(elementOrRef);
            return new rxjs.Observable((/**
             * @param {?} observer
             * @return {?}
             */
            function (observer) {
                /** @type {?} */
                var stream = _this.observeElement(element);
                /** @type {?} */
                var subscription = stream.subscribe(observer);
                return (/**
                 * @return {?}
                 */
                function () {
                    subscription.unsubscribe();
                    _this.unobserveElement(element);
                });
            }));
        };
        /**
         * Observes the given element by using the existing ResizeObserver if available, or creating a
         * new one if not.
         */
        /**
         * Observes the given element by using the existing ResizeObserver if available, or creating a
         * new one if not.
         * @private
         * @param {?} element
         * @return {?}
         */
        DwResizeObserver.prototype.observeElement = /**
         * Observes the given element by using the existing ResizeObserver if available, or creating a
         * new one if not.
         * @private
         * @param {?} element
         * @return {?}
         */
        function (element) {
            if (!this.observedElements.has(element)) {
                /** @type {?} */
                var stream_1 = new rxjs.Subject();
                /** @type {?} */
                var observer = this.dwResizeObserverFactory.create((/**
                 * @param {?} mutations
                 * @return {?}
                 */
                function (mutations) { return stream_1.next(mutations); }));
                if (observer) {
                    observer.observe(element);
                }
                this.observedElements.set(element, { observer: observer, stream: stream_1, count: 1 });
            }
            else {
                (/** @type {?} */ (this.observedElements.get(element))).count++;
            }
            return (/** @type {?} */ (this.observedElements.get(element))).stream;
        };
        /**
         * Un-observes the given element and cleans up the underlying ResizeObserver if nobody else is
         * observing this element.
         */
        /**
         * Un-observes the given element and cleans up the underlying ResizeObserver if nobody else is
         * observing this element.
         * @private
         * @param {?} element
         * @return {?}
         */
        DwResizeObserver.prototype.unobserveElement = /**
         * Un-observes the given element and cleans up the underlying ResizeObserver if nobody else is
         * observing this element.
         * @private
         * @param {?} element
         * @return {?}
         */
        function (element) {
            if (this.observedElements.has(element)) {
                (/** @type {?} */ (this.observedElements.get(element))).count--;
                if (!(/** @type {?} */ (this.observedElements.get(element))).count) {
                    this.cleanupObserver(element);
                }
            }
        };
        /** Clean up the underlying ResizeObserver for the specified element. */
        /**
         * Clean up the underlying ResizeObserver for the specified element.
         * @private
         * @param {?} element
         * @return {?}
         */
        DwResizeObserver.prototype.cleanupObserver = /**
         * Clean up the underlying ResizeObserver for the specified element.
         * @private
         * @param {?} element
         * @return {?}
         */
        function (element) {
            if (this.observedElements.has(element)) {
                var _a = (/** @type {?} */ (this.observedElements.get(element))), observer = _a.observer, stream = _a.stream;
                if (observer) {
                    observer.disconnect();
                }
                stream.complete();
                this.observedElements.delete(element);
            }
        };
        DwResizeObserver.decorators = [
            { type: core.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */
        DwResizeObserver.ctorParameters = function () { return [
            { type: DwResizeObserverFactory }
        ]; };
        /** @nocollapse */ DwResizeObserver.ɵprov = core.ɵɵdefineInjectable({ factory: function DwResizeObserver_Factory() { return new DwResizeObserver(core.ɵɵinject(DwResizeObserverFactory)); }, token: DwResizeObserver, providedIn: "root" });
        return DwResizeObserver;
    }());
    if (false) {
        /**
         * Keeps track of the existing ResizeObservers so they can be reused.
         * @type {?}
         * @private
         */
        DwResizeObserver.prototype.observedElements;
        /**
         * @type {?}
         * @private
         */
        DwResizeObserver.prototype.dwResizeObserverFactory;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: resize-observers.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwResizeObserversModule = /** @class */ (function () {
        function DwResizeObserversModule() {
        }
        DwResizeObserversModule.decorators = [
            { type: core.NgModule, args: [{
                        providers: [DwResizeObserverFactory]
                    },] }
        ];
        return DwResizeObserversModule;
    }());

    exports.DwResizeObserver = DwResizeObserver;
    exports.DwResizeObserversModule = DwResizeObserversModule;
    exports.ɵa = DwResizeObserverFactory;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-core-resize-observers.umd.js.map
