(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/cdk/keycodes'), require('@angular/cdk/overlay'), require('@angular/core'), require('@angular/forms'), require('ng-quicksilver/core/animation'), require('ng-quicksilver/core/config'), require('ng-quicksilver/core/no-animation'), require('ng-quicksilver/core/tree'), require('ng-quicksilver/core/util'), require('ng-quicksilver/select'), require('ng-quicksilver/tree'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('ng-quicksilver/core/overlay'), require('ng-quicksilver/empty'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/tree-select', ['exports', '@angular/cdk/keycodes', '@angular/cdk/overlay', '@angular/core', '@angular/forms', 'ng-quicksilver/core/animation', 'ng-quicksilver/core/config', 'ng-quicksilver/core/no-animation', 'ng-quicksilver/core/tree', 'ng-quicksilver/core/util', 'ng-quicksilver/select', 'ng-quicksilver/tree', 'rxjs', 'rxjs/operators', '@angular/common', 'ng-quicksilver/core/overlay', 'ng-quicksilver/empty', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver']['tree-select'] = {}), global.ng.cdk.keycodes, global.ng.cdk.overlay, global.ng.core, global.ng.forms, global['ng-quicksilver'].core.animation, global['ng-quicksilver'].core.config, global['ng-quicksilver'].core['no-animation'], global['ng-quicksilver'].core.tree, global['ng-quicksilver'].core.util, global['ng-quicksilver'].select, global['ng-quicksilver'].tree, global.rxjs, global.rxjs.operators, global.ng.common, global['ng-quicksilver'].core.overlay, global['ng-quicksilver'].empty, global['ng-quicksilver'].icon));
}(this, (function (exports, keycodes, overlay, core, forms, animation, config, noAnimation, tree, util, select, tree$1, rxjs, operators, common, overlay$1, empty, icon) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-select.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeSelectService = /** @class */ (function (_super) {
        __extends(DwTreeSelectService, _super);
        function DwTreeSelectService() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DwTreeSelectService.decorators = [
            { type: core.Injectable }
        ];
        return DwTreeSelectService;
    }(tree.DwTreeBaseService));

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-select.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @param {?} injector
     * @return {?}
     */
    function higherOrderServiceFactory(injector) {
        return injector.get(DwTreeSelectService);
    }
    /** @type {?} */
    var DW_CONFIG_COMPONENT_NAME = 'treeSelect';
    /** @type {?} */
    var TREE_SELECT_DEFAULT_CLASS = 'ant-select-dropdown ant-select-tree-dropdown';
    var DwTreeSelectComponent = /** @class */ (function (_super) {
        __extends(DwTreeSelectComponent, _super);
        function DwTreeSelectComponent(dwTreeService, dwConfigService, renderer, cdr, elementRef, noAnimation) {
            var _this = _super.call(this, dwTreeService) || this;
            _this.dwConfigService = dwConfigService;
            _this.renderer = renderer;
            _this.cdr = cdr;
            _this.elementRef = elementRef;
            _this.noAnimation = noAnimation;
            _this.dwAllowClear = true;
            _this.dwShowExpand = true;
            _this.dwShowLine = false;
            _this.dwDropdownMatchSelectWidth = true;
            _this.dwCheckable = false;
            _this.dwHideUnMatched = false;
            _this.dwShowIcon = false;
            _this.dwShowSearch = false;
            _this.dwDisabled = false;
            _this.dwAsyncData = false;
            _this.dwMultiple = false;
            _this.dwDefaultExpandAll = false;
            _this.dwCheckStrictly = false;
            _this.dwNodes = [];
            _this.dwOpen = false;
            _this.dwSize = 'default';
            _this.dwPlaceHolder = '';
            _this.dwDropdownStyle = null;
            _this.dwDisplayWith = (/**
             * @param {?} node
             * @return {?}
             */
            function (node) { return node.title; });
            _this.dwMaxTagPlaceholder = null;
            _this.dwOpenChange = new core.EventEmitter();
            _this.dwCleared = new core.EventEmitter();
            _this.dwRemoved = new core.EventEmitter();
            _this.dwExpandChange = new core.EventEmitter();
            _this.dwTreeClick = new core.EventEmitter();
            _this.dwTreeCheckBoxChange = new core.EventEmitter();
            _this.dropdownClassName = TREE_SELECT_DEFAULT_CLASS;
            _this.isComposing = false;
            _this.isDestroy = true;
            _this.isNotFound = false;
            _this.inputValue = '';
            _this.dropDownPosition = 'bottom';
            _this.selectedNodes = [];
            _this.expandedKeys = [];
            _this.value = [];
            _this.onChange = (/**
             * @param {?} _value
             * @return {?}
             */
            function (_value) { });
            _this.onTouched = (/**
             * @return {?}
             */
            function () { });
            _this.renderer.addClass(_this.elementRef.nativeElement, 'ant-select');
            _this.renderer.addClass(_this.elementRef.nativeElement, 'ant-tree-select');
            return _this;
        }
        Object.defineProperty(DwTreeSelectComponent.prototype, "dwExpandedKeys", {
            get: /**
             * @return {?}
             */
            function () {
                return this.expandedKeys;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.expandedKeys = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeSelectComponent.prototype, "treeTemplate", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwTreeTemplate || this.dwTreeTemplateChild;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeSelectComponent.prototype, "placeHolderDisplay", {
            get: /**
             * @return {?}
             */
            function () {
                return this.inputValue || this.isComposing || this.selectedNodes.length ? 'none' : 'block';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DwTreeSelectComponent.prototype, "isMultiple", {
            get: /**
             * @return {?}
             */
            function () {
                return this.dwMultiple || this.dwCheckable;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.isDestroy = false;
            this.selectionChangeSubscription = this.subscribeSelectionChange();
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.isDestroy = true;
            this.closeDropDown();
            this.selectionChangeSubscription.unsubscribe();
        };
        /**
         * @param {?} isDisabled
         * @return {?}
         */
        DwTreeSelectComponent.prototype.setDisabledState = /**
         * @param {?} isDisabled
         * @return {?}
         */
        function (isDisabled) {
            this.dwDisabled = isDisabled;
            this.closeDropDown();
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        DwTreeSelectComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            var dwNodes = changes.dwNodes, dwDropdownClassName = changes.dwDropdownClassName;
            if (dwNodes) {
                this.updateSelectedNodes(true);
            }
            if (dwDropdownClassName) {
                /** @type {?} */
                var className = this.dwDropdownClassName && this.dwDropdownClassName.trim();
                this.dropdownClassName = className ? TREE_SELECT_DEFAULT_CLASS + " " + className : TREE_SELECT_DEFAULT_CLASS;
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTreeSelectComponent.prototype.writeValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            var _this = this;
            if (util.isNotNil(value)) {
                if (this.isMultiple && Array.isArray(value)) {
                    this.value = value;
                }
                else {
                    this.value = [(/** @type {?} */ (value))];
                }
                this.updateSelectedNodes(true);
            }
            else {
                this.value = [];
                this.selectedNodes.forEach((/**
                 * @param {?} node
                 * @return {?}
                 */
                function (node) {
                    _this.removeSelected(node, false);
                }));
                this.selectedNodes = [];
            }
            this.cdr.markForCheck();
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTreeSelectComponent.prototype.registerOnChange = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onChange = fn;
        };
        /**
         * @param {?} fn
         * @return {?}
         */
        DwTreeSelectComponent.prototype.registerOnTouched = /**
         * @param {?} fn
         * @return {?}
         */
        function (fn) {
            this.onTouched = fn;
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.trigger = /**
         * @return {?}
         */
        function () {
            if (this.dwDisabled || (!this.dwDisabled && this.dwOpen)) {
                this.closeDropDown();
            }
            else {
                this.openDropdown();
                if (this.dwShowSearch || this.isMultiple) {
                    this.focusOnInput();
                }
            }
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.openDropdown = /**
         * @return {?}
         */
        function () {
            if (!this.dwDisabled) {
                this.dwOpen = true;
                this.dwOpenChange.emit(this.dwOpen);
                this.updateCdkConnectedOverlayStatus();
            }
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.closeDropDown = /**
         * @return {?}
         */
        function () {
            this.onTouched();
            this.dwOpen = false;
            this.inputValue = '';
            this.dwOpenChange.emit(this.dwOpen);
            this.cdr.markForCheck();
        };
        /**
         * @param {?} e
         * @return {?}
         */
        DwTreeSelectComponent.prototype.onKeyDownInput = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            /** @type {?} */
            var keyCode = e.keyCode;
            /** @type {?} */
            var eventTarget = (/** @type {?} */ (e.target));
            if (this.isMultiple && !eventTarget.value && keyCode === keycodes.BACKSPACE) {
                e.preventDefault();
                if (this.selectedNodes.length) {
                    /** @type {?} */
                    var removeNode = this.selectedNodes[this.selectedNodes.length - 1];
                    this.removeSelected(removeNode);
                }
            }
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTreeSelectComponent.prototype.onExpandedKeysChange = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.dwExpandChange.emit(value);
            this.expandedKeys = __spread((/** @type {?} */ (value.keys)));
        };
        /**
         * @param {?} value
         * @return {?}
         */
        DwTreeSelectComponent.prototype.setInputValue = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.inputValue = value;
            this.updatePosition();
        };
        /**
         * @param {?} node
         * @param {?=} emit
         * @return {?}
         */
        DwTreeSelectComponent.prototype.removeSelected = /**
         * @param {?} node
         * @param {?=} emit
         * @return {?}
         */
        function (node, emit) {
            if (emit === void 0) { emit = true; }
            node.isSelected = false;
            node.isChecked = false;
            if (this.dwCheckable) {
                this.dwTreeService.conduct(node, this.dwCheckStrictly);
            }
            else {
                this.dwTreeService.setSelectedNodeList(node, this.dwMultiple);
            }
            if (emit) {
                this.dwRemoved.emit(node);
            }
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.focusOnInput = /**
         * @return {?}
         */
        function () {
            if (this.dwSelectSearchComponent) {
                this.dwSelectSearchComponent.focus();
            }
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.subscribeSelectionChange = /**
         * @return {?}
         */
        function () {
            var _this = this;
            return rxjs.merge(this.dwTreeClick.pipe(operators.tap((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                /** @type {?} */
                var node = (/** @type {?} */ (event.node));
                if (_this.dwCheckable && !node.isDisabled && !node.isDisableCheckbox) {
                    node.isChecked = !node.isChecked;
                    node.isHalfChecked = false;
                    if (!_this.dwCheckStrictly) {
                        _this.dwTreeService.conduct(node);
                    }
                }
                if (_this.dwCheckable) {
                    node.isSelected = false;
                }
            })), operators.filter((/**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                /** @type {?} */
                var node = (/** @type {?} */ (event.node));
                return _this.dwCheckable ? !node.isDisabled && !node.isDisableCheckbox : !node.isDisabled && node.isSelectable;
            }))), this.dwCheckable ? this.dwTreeCheckBoxChange : rxjs.of(), this.dwCleared, this.dwRemoved).subscribe((/**
             * @return {?}
             */
            function () {
                _this.updateSelectedNodes();
                /** @type {?} */
                var value = _this.selectedNodes.map((/**
                 * @param {?} node
                 * @return {?}
                 */
                function (node) { return (/** @type {?} */ (node.key)); }));
                _this.value = __spread(value);
                if (_this.dwShowSearch || _this.isMultiple) {
                    _this.inputValue = '';
                    _this.isNotFound = false;
                }
                if (_this.isMultiple) {
                    _this.onChange(value);
                    _this.focusOnInput();
                    _this.updatePosition();
                }
                else {
                    _this.closeDropDown();
                    _this.onChange(value.length ? value[0] : null);
                }
            }));
        };
        /**
         * @param {?=} init
         * @return {?}
         */
        DwTreeSelectComponent.prototype.updateSelectedNodes = /**
         * @param {?=} init
         * @return {?}
         */
        function (init) {
            if (init === void 0) { init = false; }
            if (init) {
                /** @type {?} */
                var nodes = this.coerceTreeNodes(this.dwNodes);
                this.dwTreeService.isMultiple = this.isMultiple;
                this.dwTreeService.isCheckStrictly = this.dwCheckStrictly;
                this.dwTreeService.initTree(nodes);
                if (this.dwCheckable) {
                    this.dwTreeService.conductCheck(this.value, this.dwCheckStrictly);
                }
                else {
                    this.dwTreeService.conductSelectedKeys(this.value, this.isMultiple);
                }
            }
            this.selectedNodes = __spread((this.dwCheckable ? this.getCheckedNodeList() : this.getSelectedNodeList()));
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.updatePosition = /**
         * @return {?}
         */
        function () {
            var _this = this;
            setTimeout((/**
             * @return {?}
             */
            function () {
                if (_this.cdkConnectedOverlay && _this.cdkConnectedOverlay.overlayRef) {
                    _this.cdkConnectedOverlay.overlayRef.updatePosition();
                }
            }));
        };
        /**
         * @param {?} position
         * @return {?}
         */
        DwTreeSelectComponent.prototype.onPositionChange = /**
         * @param {?} position
         * @return {?}
         */
        function (position) {
            this.dropDownPosition = position.connectionPair.originY;
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.onClearSelection = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.selectedNodes.forEach((/**
             * @param {?} node
             * @return {?}
             */
            function (node) {
                _this.removeSelected(node, false);
            }));
            this.dwCleared.emit();
        };
        /**
         * @param {?} $event
         * @return {?}
         */
        DwTreeSelectComponent.prototype.setSearchValues = /**
         * @param {?} $event
         * @return {?}
         */
        function ($event) {
            var _this = this;
            Promise.resolve().then((/**
             * @return {?}
             */
            function () {
                _this.isNotFound = (_this.dwShowSearch || _this.isMultiple) && !!_this.inputValue && (/** @type {?} */ ($event.matchedKeys)).length === 0;
            }));
        };
        /**
         * @return {?}
         */
        DwTreeSelectComponent.prototype.updateCdkConnectedOverlayStatus = /**
         * @return {?}
         */
        function () {
            this.triggerWidth = this.cdkOverlayOrigin.elementRef.nativeElement.getBoundingClientRect().width;
        };
        /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        DwTreeSelectComponent.prototype.trackValue = /**
         * @param {?} _index
         * @param {?} option
         * @return {?}
         */
        function (_index, option) {
            return (/** @type {?} */ (option.key));
        };
        DwTreeSelectComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'dw-tree-select',
                        exportAs: 'dwTreeSelect',
                        animations: [animation.slideMotion, animation.zoomMotion],
                        template: "\n    <ng-template\n      cdkConnectedOverlay\n      dwConnectedOverlay\n      [cdkConnectedOverlayOrigin]=\"cdkOverlayOrigin\"\n      [cdkConnectedOverlayOpen]=\"dwOpen\"\n      [cdkConnectedOverlayHasBackdrop]=\"true\"\n      [cdkConnectedOverlayTransformOriginOn]=\"'.ant-select-tree-dropdown'\"\n      [cdkConnectedOverlayMinWidth]=\"$any(dwDropdownMatchSelectWidth ? null : triggerWidth)\"\n      [cdkConnectedOverlayWidth]=\"$any(dwDropdownMatchSelectWidth ? triggerWidth : null)\"\n      (backdropClick)=\"closeDropDown()\"\n      (detach)=\"closeDropDown()\"\n      (positionChange)=\"onPositionChange($event)\"\n    >\n      <div\n        [@slideMotion]=\"'enter'\"\n        [ngClass]=\"dropdownClassName\"\n        [@.disabled]=\"noAnimation?.dwNoAnimation\"\n        [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n        [class.ant-select-dropdown-placement-bottomLeft]=\"dropDownPosition === 'bottom'\"\n        [class.ant-select-dropdown-placement-topLeft]=\"dropDownPosition === 'top'\"\n        [ngStyle]=\"dwDropdownStyle\"\n      >\n        <dw-tree\n          #treeRef\n          [hidden]=\"isNotFound\"\n          dwNoAnimation\n          dwSelectMode\n          [dwData]=\"dwNodes\"\n          [dwMultiple]=\"dwMultiple\"\n          [dwSearchValue]=\"inputValue\"\n          [dwHideUnMatched]=\"dwHideUnMatched\"\n          [dwShowIcon]=\"dwShowIcon\"\n          [dwCheckable]=\"dwCheckable\"\n          [dwAsyncData]=\"dwAsyncData\"\n          [dwShowExpand]=\"dwShowExpand\"\n          [dwShowLine]=\"dwShowLine\"\n          [dwExpandedIcon]=\"dwExpandedIcon\"\n          [dwExpandAll]=\"dwDefaultExpandAll\"\n          [dwExpandedKeys]=\"expandedKeys\"\n          [dwCheckedKeys]=\"dwCheckable ? value : []\"\n          [dwSelectedKeys]=\"!dwCheckable ? value : []\"\n          [dwTreeTemplate]=\"treeTemplate\"\n          [dwCheckStrictly]=\"dwCheckStrictly\"\n          (dwExpandChange)=\"onExpandedKeysChange($event)\"\n          (dwClick)=\"dwTreeClick.emit($event)\"\n          (dwCheckedKeysChange)=\"updateSelectedNodes()\"\n          (dwSelectedKeysChange)=\"updateSelectedNodes()\"\n          (dwCheckBoxChange)=\"dwTreeCheckBoxChange.emit($event)\"\n          (dwSearchValueChange)=\"setSearchValues($event)\"\n        >\n        </dw-tree>\n        <span *ngIf=\"dwNodes.length === 0 || isNotFound\" class=\"ant-select-not-found\">\n          <dw-embed-empty [dwComponentName]=\"'tree-select'\" [specificContent]=\"dwNotFoundContent\"></dw-embed-empty>\n        </span>\n      </div>\n    </ng-template>\n\n    <div cdkOverlayOrigin class=\"ant-select-selector\">\n      <ng-container *ngIf=\"isMultiple\">\n        <dw-select-item\n          *ngFor=\"let node of selectedNodes | slice: 0:dwMaxTagCount; trackBy: trackValue\"\n          [@zoomMotion]\n          [@.disabled]=\"noAnimation?.dwNoAnimation\"\n          [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n          [deletable]=\"true\"\n          [disabled]=\"node.isDisabled || dwDisabled\"\n          [label]=\"dwDisplayWith(node)\"\n          (@zoomMotion.done)=\"updatePosition()\"\n          (delete)=\"removeSelected(node, true)\"\n        ></dw-select-item>\n\n        <dw-select-item\n          *ngIf=\"selectedNodes.length > dwMaxTagCount\"\n          [@zoomMotion]\n          (@zoomMotion.done)=\"updatePosition()\"\n          [@.disabled]=\"noAnimation?.dwNoAnimation\"\n          [dwNoAnimation]=\"noAnimation?.dwNoAnimation\"\n          [contentTemplateOutlet]=\"dwMaxTagPlaceholder\"\n          [contentTemplateOutletContext]=\"selectedNodes | slice: dwMaxTagCount\"\n          [deletable]=\"false\"\n          [disabled]=\"false\"\n          [label]=\"'+ ' + (selectedNodes.length - dwMaxTagCount) + ' ...'\"\n        ></dw-select-item>\n      </ng-container>\n\n      <dw-select-search\n        *ngIf=\"dwShowSearch\"\n        (keydown)=\"onKeyDownInput($event)\"\n        (isComposingChange)=\"isComposing = $event\"\n        (valueChange)=\"setInputValue($event)\"\n        [value]=\"inputValue\"\n        [mirrorSync]=\"isMultiple\"\n        [disabled]=\"dwDisabled\"\n        [showInput]=\"dwOpen\"\n      >\n      </dw-select-search>\n\n      <dw-select-placeholder\n        *ngIf=\"dwPlaceHolder && selectedNodes.length === 0\"\n        [placeholder]=\"dwPlaceHolder\"\n        [style.display]=\"placeHolderDisplay\"\n      >\n      </dw-select-placeholder>\n\n      <dw-select-item\n        *ngIf=\"!isMultiple && selectedNodes.length === 1\"\n        [deletable]=\"false\"\n        [disabled]=\"false\"\n        [label]=\"dwDisplayWith(selectedNodes[0])\"\n      ></dw-select-item>\n\n      <dw-select-arrow *ngIf=\"!isMultiple\"></dw-select-arrow>\n\n      <dw-select-clear *ngIf=\"dwAllowClear\" (clear)=\"onClearSelection()\"></dw-select-clear>\n    </div>\n  ",
                        providers: [
                            DwTreeSelectService,
                            {
                                provide: tree.DwTreeHigherOrderServiceToken,
                                useFactory: higherOrderServiceFactory,
                                deps: [[new core.Self(), core.Injector]]
                            },
                            {
                                provide: forms.NG_VALUE_ACCESSOR,
                                useExisting: core.forwardRef((/**
                                 * @return {?}
                                 */
                                function () { return DwTreeSelectComponent; })),
                                multi: true
                            }
                        ],
                        host: {
                            '[class.ant-select-lg]': 'dwSize==="large"',
                            '[class.ant-select-sm]': 'dwSize==="small"',
                            '[class.ant-select-enabled]': '!dwDisabled',
                            '[class.ant-select-disabled]': 'dwDisabled',
                            '[class.ant-select-single]': '!isMultiple',
                            '[class.ant-select-show-arrow]': '!isMultiple',
                            '[class.ant-select-show-search]': '!isMultiple',
                            '[class.ant-select-multiple]': 'isMultiple',
                            '[class.ant-select-allow-clear]': 'dwAllowClear',
                            '[class.ant-select-open]': 'dwOpen',
                            '(click)': 'trigger()'
                        }
                    }] }
        ];
        /** @nocollapse */
        DwTreeSelectComponent.ctorParameters = function () { return [
            { type: DwTreeSelectService },
            { type: config.DwConfigService },
            { type: core.Renderer2 },
            { type: core.ChangeDetectorRef },
            { type: core.ElementRef },
            { type: noAnimation.DwNoAnimationDirective, decorators: [{ type: core.Host }, { type: core.Optional }] }
        ]; };
        DwTreeSelectComponent.propDecorators = {
            dwAllowClear: [{ type: core.Input }],
            dwShowExpand: [{ type: core.Input }],
            dwShowLine: [{ type: core.Input }],
            dwDropdownMatchSelectWidth: [{ type: core.Input }],
            dwCheckable: [{ type: core.Input }],
            dwHideUnMatched: [{ type: core.Input }],
            dwShowIcon: [{ type: core.Input }],
            dwShowSearch: [{ type: core.Input }],
            dwDisabled: [{ type: core.Input }],
            dwAsyncData: [{ type: core.Input }],
            dwMultiple: [{ type: core.Input }],
            dwDefaultExpandAll: [{ type: core.Input }],
            dwCheckStrictly: [{ type: core.Input }],
            dwExpandedIcon: [{ type: core.Input }],
            dwNotFoundContent: [{ type: core.Input }],
            dwNodes: [{ type: core.Input }],
            dwOpen: [{ type: core.Input }],
            dwSize: [{ type: core.Input }],
            dwPlaceHolder: [{ type: core.Input }],
            dwDropdownStyle: [{ type: core.Input }],
            dwDropdownClassName: [{ type: core.Input }],
            dwExpandedKeys: [{ type: core.Input }],
            dwDisplayWith: [{ type: core.Input }],
            dwMaxTagCount: [{ type: core.Input }],
            dwMaxTagPlaceholder: [{ type: core.Input }],
            dwOpenChange: [{ type: core.Output }],
            dwCleared: [{ type: core.Output }],
            dwRemoved: [{ type: core.Output }],
            dwExpandChange: [{ type: core.Output }],
            dwTreeClick: [{ type: core.Output }],
            dwTreeCheckBoxChange: [{ type: core.Output }],
            dwSelectSearchComponent: [{ type: core.ViewChild, args: [select.DwSelectSearchComponent, { static: false },] }],
            treeRef: [{ type: core.ViewChild, args: ['treeRef', { static: false },] }],
            cdkOverlayOrigin: [{ type: core.ViewChild, args: [overlay.CdkOverlayOrigin, { static: true },] }],
            cdkConnectedOverlay: [{ type: core.ViewChild, args: [overlay.CdkConnectedOverlay, { static: false },] }],
            dwTreeTemplate: [{ type: core.Input }],
            dwTreeTemplateChild: [{ type: core.ContentChild, args: ['dwTreeTemplate', { static: true },] }]
        };
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwAllowClear", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwShowExpand", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwShowLine", void 0);
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwDropdownMatchSelectWidth", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwCheckable", void 0);
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwHideUnMatched", void 0);
        __decorate([
            util.InputBoolean(), config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwShowIcon", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Boolean)
        ], DwTreeSelectComponent.prototype, "dwShowSearch", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeSelectComponent.prototype, "dwDisabled", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeSelectComponent.prototype, "dwAsyncData", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeSelectComponent.prototype, "dwMultiple", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeSelectComponent.prototype, "dwDefaultExpandAll", void 0);
        __decorate([
            util.InputBoolean(),
            __metadata("design:type", Object)
        ], DwTreeSelectComponent.prototype, "dwCheckStrictly", void 0);
        __decorate([
            config.WithConfig(DW_CONFIG_COMPONENT_NAME),
            __metadata("design:type", String)
        ], DwTreeSelectComponent.prototype, "dwSize", void 0);
        return DwTreeSelectComponent;
    }(tree.DwTreeBase));
    if (false) {
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwAllowClear;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwShowExpand;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwShowLine;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwDropdownMatchSelectWidth;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwCheckable;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwHideUnMatched;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwShowIcon;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwShowSearch;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwDisabled;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwAsyncData;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwMultiple;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwDefaultExpandAll;
        /** @type {?} */
        DwTreeSelectComponent.ngAcceptInputType_dwCheckStrictly;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwAllowClear;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwShowExpand;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwShowLine;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDropdownMatchSelectWidth;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwCheckable;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwHideUnMatched;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwShowIcon;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwShowSearch;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDisabled;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwAsyncData;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwMultiple;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDefaultExpandAll;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwCheckStrictly;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwExpandedIcon;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwNotFoundContent;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwNodes;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwOpen;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwSize;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwPlaceHolder;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDropdownStyle;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDropdownClassName;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwDisplayWith;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwMaxTagCount;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwMaxTagPlaceholder;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwOpenChange;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwCleared;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwRemoved;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwExpandChange;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwTreeClick;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwTreeCheckBoxChange;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwSelectSearchComponent;
        /** @type {?} */
        DwTreeSelectComponent.prototype.treeRef;
        /** @type {?} */
        DwTreeSelectComponent.prototype.cdkOverlayOrigin;
        /** @type {?} */
        DwTreeSelectComponent.prototype.cdkConnectedOverlay;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwTreeTemplate;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwTreeTemplateChild;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dropdownClassName;
        /** @type {?} */
        DwTreeSelectComponent.prototype.triggerWidth;
        /** @type {?} */
        DwTreeSelectComponent.prototype.isComposing;
        /** @type {?} */
        DwTreeSelectComponent.prototype.isDestroy;
        /** @type {?} */
        DwTreeSelectComponent.prototype.isNotFound;
        /** @type {?} */
        DwTreeSelectComponent.prototype.inputValue;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dropDownPosition;
        /** @type {?} */
        DwTreeSelectComponent.prototype.selectionChangeSubscription;
        /** @type {?} */
        DwTreeSelectComponent.prototype.selectedNodes;
        /** @type {?} */
        DwTreeSelectComponent.prototype.expandedKeys;
        /** @type {?} */
        DwTreeSelectComponent.prototype.value;
        /** @type {?} */
        DwTreeSelectComponent.prototype.onChange;
        /** @type {?} */
        DwTreeSelectComponent.prototype.onTouched;
        /** @type {?} */
        DwTreeSelectComponent.prototype.dwConfigService;
        /**
         * @type {?}
         * @private
         */
        DwTreeSelectComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        DwTreeSelectComponent.prototype.cdr;
        /**
         * @type {?}
         * @private
         */
        DwTreeSelectComponent.prototype.elementRef;
        /** @type {?} */
        DwTreeSelectComponent.prototype.noAnimation;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: tree-select.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var DwTreeSelectModule = /** @class */ (function () {
        function DwTreeSelectModule() {
        }
        DwTreeSelectModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            overlay.OverlayModule,
                            forms.FormsModule,
                            select.DwSelectModule,
                            tree$1.DwTreeModule,
                            icon.DwIconModule,
                            empty.DwEmptyModule,
                            overlay$1.DwOverlayModule,
                            noAnimation.DwNoAnimationModule
                        ],
                        declarations: [DwTreeSelectComponent],
                        exports: [DwTreeSelectComponent]
                    },] }
        ];
        return DwTreeSelectModule;
    }());

    exports.DwTreeSelectComponent = DwTreeSelectComponent;
    exports.DwTreeSelectModule = DwTreeSelectModule;
    exports.DwTreeSelectService = DwTreeSelectService;
    exports.higherOrderServiceFactory = higherOrderServiceFactory;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-tree-select.umd.js.map
