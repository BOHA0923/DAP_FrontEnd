(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@ant-design/icons-angular/icons'), require('ng-quicksilver/icon')) :
    typeof define === 'function' && define.amd ? define('ng-quicksilver/icon/testing', ['exports', '@angular/core', '@ant-design/icons-angular/icons', 'ng-quicksilver/icon'], factory) :
    (global = global || self, factory((global['ng-quicksilver'] = global['ng-quicksilver'] || {}, global['ng-quicksilver'].icon = global['ng-quicksilver'].icon || {}, global['ng-quicksilver'].icon.testing = {}), global.ng.core, global.AllIcons, global['ng-quicksilver'].icon));
}(this, (function (exports, core, AllIcons, icon) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: dw-icon-test.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var antDesignIcons = (/** @type {?} */ (AllIcons));
    var ɵ0 = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        /** @type {?} */
        var i = antDesignIcons[key];
        return i;
    };
    /** @type {?} */
    var icons = Object.keys(antDesignIcons).map((ɵ0));
    var ɵ1 = icons;
    /**
     * Include this module in every testing spec, except `icon.spec.ts`.
     */
    // @dynamic
    var DwIconTestModule = /** @class */ (function () {
        function DwIconTestModule() {
        }
        DwIconTestModule.decorators = [
            { type: core.NgModule, args: [{
                        exports: [icon.DwIconModule],
                        providers: [
                            {
                                provide: icon.DW_ICONS,
                                useValue: ɵ1
                            }
                        ]
                    },] }
        ];
        return DwIconTestModule;
    }());

    exports.DwIconTestModule = DwIconTestModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-quicksilver-icon-testing.umd.js.map
