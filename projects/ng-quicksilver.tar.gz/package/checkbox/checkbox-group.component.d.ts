/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { FocusMonitor } from '@angular/cdk/a11y';
import { ChangeDetectorRef, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { BooleanInput, OnChangeType, OnTouchedType } from 'ng-quicksilver/core/types';
export interface DwCheckBoxOptionInterface {
    label: string;
    value: string;
    checked?: boolean;
    disabled?: boolean;
}
export declare class DwCheckboxGroupComponent implements ControlValueAccessor, OnInit, OnDestroy {
    private elementRef;
    private focusMonitor;
    private cdr;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    onChange: OnChangeType;
    onTouched: OnTouchedType;
    options: DwCheckBoxOptionInterface[];
    dwDisabled: boolean;
    trackByOption(_: number, option: DwCheckBoxOptionInterface): string;
    onCheckedChange(option: DwCheckBoxOptionInterface, checked: boolean): void;
    constructor(elementRef: ElementRef, focusMonitor: FocusMonitor, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    writeValue(value: DwCheckBoxOptionInterface[]): void;
    registerOnChange(fn: OnChangeType): void;
    registerOnTouched(fn: OnTouchedType): void;
    setDisabledState(disabled: boolean): void;
}
