/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { FocusMonitor } from '@angular/cdk/a11y';
import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { BooleanInput, DwSafeAny, OnChangeType, OnTouchedType } from 'ng-quicksilver/core/types';
import { DwCheckboxWrapperComponent } from './checkbox-wrapper.component';
export declare class DwCheckboxComponent implements OnInit, ControlValueAccessor, OnDestroy, AfterViewInit {
    private elementRef;
    private dwCheckboxWrapperComponent;
    private cdr;
    private focusMonitor;
    static ngAcceptInputType_dwAutoFocus: BooleanInput;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    static ngAcceptInputType_dwIndeterminate: BooleanInput;
    static ngAcceptInputType_dwChecked: BooleanInput;
    onChange: OnChangeType;
    onTouched: OnTouchedType;
    private inputElement;
    readonly dwCheckedChange: EventEmitter<boolean>;
    dwValue: DwSafeAny | null;
    dwAutoFocus: boolean;
    dwDisabled: boolean;
    dwIndeterminate: boolean;
    dwChecked: boolean;
    hostClick(e: MouseEvent): void;
    innerCheckedChange(checked: boolean): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: OnChangeType): void;
    registerOnTouched(fn: OnTouchedType): void;
    setDisabledState(disabled: boolean): void;
    focus(): void;
    blur(): void;
    constructor(elementRef: ElementRef<HTMLElement>, dwCheckboxWrapperComponent: DwCheckboxWrapperComponent, cdr: ChangeDetectorRef, focusMonitor: FocusMonitor);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
}
