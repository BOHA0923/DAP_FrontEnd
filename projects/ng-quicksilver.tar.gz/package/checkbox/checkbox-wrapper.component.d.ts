/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import { DwCheckboxComponent } from './checkbox.component';
export declare class DwCheckboxWrapperComponent {
    readonly dwOnChange: EventEmitter<any[]>;
    private checkboxList;
    addCheckbox(value: DwCheckboxComponent): void;
    removeCheckbox(value: DwCheckboxComponent): void;
    onChange(): void;
    constructor(renderer: Renderer2, elementRef: ElementRef);
}
