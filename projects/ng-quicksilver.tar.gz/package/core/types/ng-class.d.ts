/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwSafeAny } from './any';
export declare type NgClassType = string | string[] | Set<string> | NgClassInterface;
export interface NgClassInterface {
    [klass: string]: DwSafeAny;
}
export interface NgStyleInterface {
    [klass: string]: DwSafeAny;
}
