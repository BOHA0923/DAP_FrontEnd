/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { DwResizeObserverFactory as ɵa } from './resize-observers.service';
