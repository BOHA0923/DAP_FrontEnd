/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ElementRef, InjectionToken, NgZone, OnDestroy, OnInit } from '@angular/core';
import { DwWaveRenderer } from './dw-wave-renderer';
export interface DwWaveConfig {
    disabled?: boolean;
}
export declare const DW_WAVE_GLOBAL_DEFAULT_CONFIG: DwWaveConfig;
export declare const DW_WAVE_GLOBAL_CONFIG: InjectionToken<DwWaveConfig>;
export declare function DW_WAVE_GLOBAL_CONFIG_FACTORY(): DwWaveConfig;
export declare class DwWaveDirective implements OnInit, OnDestroy {
    private ngZone;
    private elementRef;
    private config;
    private animationType;
    dwWaveExtraNode: boolean;
    private waveRenderer?;
    private waveDisabled;
    get disabled(): boolean;
    get rendererRef(): DwWaveRenderer | undefined;
    constructor(ngZone: NgZone, elementRef: ElementRef, config: DwWaveConfig, animationType: string);
    isConfigDisabled(): boolean;
    ngOnDestroy(): void;
    ngOnInit(): void;
    renderWaveIfEnabled(): void;
    disable(): void;
    enable(): void;
}
