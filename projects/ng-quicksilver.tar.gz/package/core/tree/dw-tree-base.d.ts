/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwSafeAny } from 'ng-quicksilver/core/types';
import { DwTreeNode } from './dw-tree-base-node';
import { DwTreeBaseService } from './dw-tree-base.service';
export declare class DwTreeBase {
    dwTreeService: DwTreeBaseService;
    constructor(dwTreeService: DwTreeBaseService);
    /**
     * Coerces a value({@link any[]}) to a TreeNodes({@link DwTreeNode[]})
     */
    coerceTreeNodes(value: DwSafeAny[]): DwTreeNode[];
    /**
     * Get all nodes({@link DwTreeNode})
     */
    getTreeNodes(): DwTreeNode[];
    /**
     * Get {@link DwTreeNode} with key
     */
    getTreeNodeByKey(key: string): DwTreeNode | null;
    /**
     * Get checked nodes(merged)
     */
    getCheckedNodeList(): DwTreeNode[];
    /**
     * Get selected nodes
     */
    getSelectedNodeList(): DwTreeNode[];
    /**
     * Get half checked nodes
     */
    getHalfCheckedNodeList(): DwTreeNode[];
    /**
     * Get expanded nodes
     */
    getExpandedNodeList(): DwTreeNode[];
    /**
     * Get matched nodes(if dwSearchValue is not null)
     */
    getMatchedNodeList(): DwTreeNode[];
}
