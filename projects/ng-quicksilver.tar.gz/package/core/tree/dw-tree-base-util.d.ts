/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwSafeAny } from 'ng-quicksilver/core/types';
import { FlattenNode, DwTreeNode, DwTreeNodeKey } from './dw-tree-base-node';
export declare function isCheckDisabled(node: DwTreeNode): boolean;
export declare function isInArray(needle: DwSafeAny, haystack: DwSafeAny[]): boolean;
export declare function getPosition(level: string | number, index: number): string;
export declare function getKey(key: DwTreeNodeKey, pos: string): DwTreeNodeKey;
/**
 * Flat nest tree data into flatten list. This is used for virtual list render.
 * @param treeNodeList Origin data node list
 * @param expandedKeys
 * need expanded keys, provides `true` means all expanded (used in `rc-tree-select`).
 */
export declare function flattenTreeData(treeNodeList?: DwTreeNode[], expandedKeys?: DwTreeNodeKey[] | true): FlattenNode[];
