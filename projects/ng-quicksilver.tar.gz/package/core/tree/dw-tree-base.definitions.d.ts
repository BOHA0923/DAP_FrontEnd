/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwTreeNode } from './dw-tree-base-node';
export interface DwFormatEmitEvent {
    eventName: string;
    node?: DwTreeNode | null;
    event?: MouseEvent | DragEvent | null;
    dragNode?: DwTreeNode;
    selectedKeys?: DwTreeNode[];
    checkedKeys?: DwTreeNode[];
    matchedKeys?: DwTreeNode[];
    nodes?: DwTreeNode[];
    keys?: string[];
}
export interface DwFormatBeforeDropEvent {
    dragNode: DwTreeNode;
    node: DwTreeNode;
    pos: number;
}
export interface DwTreeNodeBaseComponent {
    markForCheck(): void;
}
