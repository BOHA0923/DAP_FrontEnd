/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { DwSafeAny } from 'ng-quicksilver/core/types';
import { BehaviorSubject } from 'rxjs';
import { DwTreeNode, DwTreeNodeKey } from './dw-tree-base-node';
import { DwFormatEmitEvent } from './dw-tree-base.definitions';
export declare class DwTreeBaseService {
    DRAG_SIDE_RANGE: number;
    DRAG_MIN_GAP: number;
    isCheckStrictly: boolean;
    isMultiple: boolean;
    selectedNode: DwTreeNode;
    rootNodes: DwTreeNode[];
    flattenNodes$: BehaviorSubject<DwTreeNode[]>;
    selectedNodeList: DwTreeNode[];
    expandedNodeList: DwTreeNode[];
    checkedNodeList: DwTreeNode[];
    halfCheckedNodeList: DwTreeNode[];
    matchedNodeList: DwTreeNode[];
    /**
     * reset tree nodes will clear default node list
     */
    initTree(dwNodes: DwTreeNode[]): void;
    flattenTreeData(dwNodes: DwTreeNode[], expandedKeys?: DwTreeNodeKey[] | true): void;
    getSelectedNode(): DwTreeNode | null;
    /**
     * get some list
     */
    getSelectedNodeList(): DwTreeNode[];
    /**
     * return checked nodes
     */
    getCheckedNodeList(): DwTreeNode[];
    getHalfCheckedNodeList(): DwTreeNode[];
    /**
     * return expanded nodes
     */
    getExpandedNodeList(): DwTreeNode[];
    /**
     * return search matched nodes
     */
    getMatchedNodeList(): DwTreeNode[];
    isArrayOfDwTreeNode(value: DwSafeAny[]): boolean;
    /**
     * set drag node
     */
    setSelectedNode(node: DwTreeNode): void;
    /**
     * set node selected status
     */
    setNodeActive(node: DwTreeNode): void;
    /**
     * add or remove node to selectedNodeList
     */
    setSelectedNodeList(node: DwTreeNode, isMultiple?: boolean): void;
    /**
     * merge checked nodes
     */
    setHalfCheckedNodeList(node: DwTreeNode): void;
    setCheckedNodeList(node: DwTreeNode): void;
    /**
     * conduct checked/selected/expanded keys
     */
    conductNodeState(type?: string): DwTreeNode[];
    /**
     * set expanded nodes
     */
    setExpandedNodeList(node: DwTreeNode): void;
    setMatchedNodeList(node: DwTreeNode): void;
    /**
     * check state
     * @param isCheckStrictly
     */
    refreshCheckState(isCheckStrictly?: boolean): void;
    conduct(node: DwTreeNode, isCheckStrictly?: boolean): void;
    /**
     * 1、children half checked
     * 2、children all checked, parent checked
     * 3、no children checked
     */
    conductUp(node: DwTreeNode): void;
    /**
     * reset child check state
     */
    conductDown(node: DwTreeNode, value: boolean): void;
    /**
     * flush after delete node
     */
    afterRemove(nodes: DwTreeNode[]): void;
    /**
     * drag event
     */
    refreshDragNode(node: DwTreeNode): void;
    resetNodeLevel(node: DwTreeNode): void;
    calcDropPosition(event: DragEvent): number;
    /**
     * drop
     * 0: inner -1: pre 1: next
     */
    dropAndApply(targetNode: DwTreeNode, dragPos?: number): void;
    /**
     * emit Structure
     * eventName
     * node
     * event: MouseEvent / DragEvent
     * dragNode
     */
    formatEvent(eventName: string, node: DwTreeNode | null, event: MouseEvent | DragEvent | null): DwFormatEmitEvent;
    /**
     * New functions for flatten nodes
     */
    getIndexOfArray(list: DwTreeNode[], key: string): number;
    /**
     * Render by dwCheckedKeys
     * When keys equals null, just render with checkStrictly
     * @param keys
     * @param checkStrictly
     */
    conductCheck(keys: DwTreeNodeKey[] | null, checkStrictly: boolean): void;
    conductExpandedKeys(keys?: DwTreeNodeKey[] | true): void;
    conductSelectedKeys(keys: DwTreeNodeKey[], isMulti: boolean): void;
    /**
     * Expand parent nodes by child node
     * @param node
     */
    expandNodeAllParentBySearch(node: DwTreeNode): void;
}
