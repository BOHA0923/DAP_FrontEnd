/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { AnimationTriggerMetadata } from '@angular/animations';
export declare const zoomMotion: AnimationTriggerMetadata;
export declare const zoomBigMotion: AnimationTriggerMetadata;
export declare const zoomBadgeMotion: AnimationTriggerMetadata;
