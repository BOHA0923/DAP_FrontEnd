/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { MediaMatcher } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { DwResizeService } from './resize';
export declare enum DwBreakpointEnum {
    xxl = "xxl",
    xl = "xl",
    lg = "lg",
    md = "md",
    sm = "sm",
    xs = "xs"
}
export declare type BreakpointMap = {
    [key in DwBreakpointEnum]: string;
};
export declare type BreakpointBooleanMap = {
    [key in DwBreakpointEnum]: boolean;
};
export declare type DwBreakpointKey = keyof typeof DwBreakpointEnum;
export declare const gridResponsiveMap: BreakpointMap;
export declare const siderResponsiveMap: BreakpointMap;
export declare class DwBreakpointService {
    private resizeService;
    private mediaMatcher;
    constructor(resizeService: DwResizeService, mediaMatcher: MediaMatcher);
    subscribe(breakpointMap: BreakpointMap): Observable<DwBreakpointEnum>;
    subscribe(breakpointMap: BreakpointMap, fullMap: true): Observable<BreakpointBooleanMap>;
    private matchMedia;
}
