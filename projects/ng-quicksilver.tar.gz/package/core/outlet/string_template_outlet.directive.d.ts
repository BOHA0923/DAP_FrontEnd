/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { OnChanges, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import { DwSafeAny } from 'ng-quicksilver/core/types';
export declare class DwStringTemplateOutletDirective<_T = unknown> implements OnChanges {
    private viewContainer;
    private templateRef;
    private embeddedViewRef;
    private context;
    dwStringTemplateOutletContext: DwSafeAny | null;
    dwStringTemplateOutlet: DwSafeAny | TemplateRef<DwSafeAny>;
    static ngTemplateContextGuard<T>(_dir: DwStringTemplateOutletDirective<T>, _ctx: DwSafeAny): _ctx is DwStringTemplateOutletContext;
    private recreateView;
    private updateContext;
    constructor(viewContainer: ViewContainerRef, templateRef: TemplateRef<DwSafeAny>);
    ngOnChanges(changes: SimpleChanges): void;
}
export declare class DwStringTemplateOutletContext {
    $implicit: DwSafeAny;
}
