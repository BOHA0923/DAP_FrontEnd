export declare function measureScrollbar(direction?: 'vertical' | 'horizontal', prefix?: string): number;
