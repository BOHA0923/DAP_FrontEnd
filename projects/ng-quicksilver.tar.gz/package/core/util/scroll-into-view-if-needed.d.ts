export declare function scrollIntoView(node: HTMLElement): void;
