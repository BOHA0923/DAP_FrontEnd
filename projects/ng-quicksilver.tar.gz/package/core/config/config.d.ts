/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { InjectionToken, TemplateRef, Type } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { DwBreakpointEnum } from 'ng-quicksilver/core/services';
import { DwSafeAny, DwShapeSCType, DwSizeDSType, DwSizeLDSType, DwSizeMDSType } from 'ng-quicksilver/core/types';
export interface DwConfig {
    affix?: AffixConfig;
    select?: SelectConfig;
    alert?: AlertConfig;
    anchor?: AnchorConfig;
    avatar?: AvatarConfig;
    backTop?: BackTopConfig;
    badge?: BadgeConfig;
    button?: ButtonConfig;
    card?: CardConfig;
    carousel?: CarouselConfig;
    cascader?: CascaderConfig;
    codeEditor?: CodeEditorConfig;
    collapse?: CollapseConfig;
    collapsePanel?: CollapsePanelConfig;
    datePicker?: DatePickerConfig;
    descriptions?: DescriptionsConfig;
    drawer?: DrawerConfig;
    empty?: EmptyConfig;
    form?: FormConfig;
    icon?: IconConfig;
    message?: MessageConfig;
    modal?: ModalConfig;
    notification?: NotificationConfig;
    pageHeader?: PageHeaderConfig;
    progress?: ProgressConfig;
    rate?: RateConfig;
    space?: SpaceConfig;
    spin?: SpinConfig;
    switch?: SwitchConfig;
    table?: TableConfig;
    tabs?: TabsConfig;
    timePicker?: TimePickerConfig;
    tree?: TreeConfig;
    treeSelect?: TreeSelectConfig;
    typography?: TypographyConfig;
}
export interface SelectConfig {
    dwBorderless?: boolean;
    dwSuffixIcon?: TemplateRef<DwSafeAny> | string | null;
}
export interface AffixConfig {
    dwOffsetBottom?: number;
    dwOffsetTop?: number;
}
export interface AlertConfig {
    dwCloseable?: boolean;
    dwShowIcon?: boolean;
}
export interface AvatarConfig {
    dwShape?: DwShapeSCType;
    dwSize?: DwSizeLDSType | number;
}
export interface AnchorConfig {
    dwBounds?: number;
    dwOffsetBottom?: number;
    dwOffsetTop?: number;
    dwShowInkInFixed?: boolean;
}
export interface BackTopConfig {
    dwVisibilityHeight?: number;
}
export interface BadgeConfig {
    dwColor?: number;
    dwOverflowCount?: number;
    dwShowZero?: number;
}
export interface ButtonConfig {
    dwSize?: 'large' | 'default' | 'small';
}
export interface CodeEditorConfig {
    assetsRoot?: string | SafeUrl;
    defaultEditorOption?: DwSafeAny;
    useStaticLoading?: boolean;
    onLoad?(): void;
    onFirstEditorInit?(): void;
    onInit?(): void;
}
export interface CardConfig {
    dwSize?: DwSizeDSType;
    dwHoverable?: boolean;
    dwBordered?: boolean;
}
export interface CarouselConfig {
    dwAutoPlay?: boolean;
    dwAutoPlaySpeed?: boolean;
    dwDots?: boolean;
    dwEffect?: 'scrollx' | 'fade' | string;
    dwEnableSwipe?: boolean;
    dwVertical?: boolean;
}
export interface CascaderConfig {
    dwSize?: string;
}
export interface CollapseConfig {
    dwAccordion?: boolean;
    dwBordered?: boolean;
}
export interface CollapsePanelConfig {
    dwShowArrow?: boolean;
}
export interface DatePickerConfig {
    dwSeparator?: string;
    dwSuffixIcon?: string | TemplateRef<DwSafeAny>;
}
export interface DescriptionsConfig {
    dwBorder?: boolean;
    dwColumn?: {
        [key in DwBreakpointEnum]?: number;
    } | number;
    dwSize?: 'default' | 'middle' | 'small';
    dwColon?: boolean;
}
export interface DrawerConfig {
    dwMask?: boolean;
    dwMaskClosable?: boolean;
    dwCloseOnNavigation?: boolean;
}
export interface EmptyConfig {
    dwDefaultEmptyContent?: Type<DwSafeAny> | TemplateRef<string> | string | undefined;
}
export interface FormConfig {
    dwNoColon?: boolean;
    dwAutoTips?: Record<string, Record<string, string>>;
}
export interface IconConfig {
    dwTheme?: 'fill' | 'outline' | 'twotone';
    dwTwotoneColor?: string;
}
export interface MessageConfig {
    dwAnimate?: boolean;
    dwDuration?: number;
    dwMaxStack?: number;
    dwPauseOnHover?: boolean;
    dwTop?: number | string;
}
export interface ModalConfig {
    dwMask?: boolean;
    dwMaskClosable?: boolean;
    dwCloseOnNavigation?: boolean;
}
export interface NotificationConfig extends MessageConfig {
    dwTop?: string | number;
    dwBottom?: string | number;
    dwPlacement?: 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight';
}
export interface PageHeaderConfig {
    dwGhost: boolean;
}
export interface ProgressConfig {
    dwGapDegree?: number;
    dwGapPosition?: 'top' | 'right' | 'bottom' | 'left';
    dwShowInfo?: boolean;
    dwStrokeSwitch?: number;
    dwStrokeWidth?: number;
    dwSize?: 'default' | 'small';
    dwStrokeLinecap?: 'round' | 'square';
    dwStrokeColor?: string;
}
export interface RateConfig {
    dwAllowClear?: boolean;
    dwAllowHalf?: boolean;
}
export interface SpaceConfig {
    dwSize?: 'small' | 'middle' | 'large' | number;
}
export interface SpinConfig {
    dwIndicator?: TemplateRef<DwSafeAny>;
}
export interface SwitchConfig {
    dwSize: DwSizeDSType;
}
export interface TableConfig {
    dwBordered?: boolean;
    dwSize?: DwSizeMDSType;
    dwShowQuickJumper?: boolean;
    dwLoadingIndicator?: TemplateRef<DwSafeAny>;
    dwShowSizeChanger?: boolean;
    dwSimple?: boolean;
    dwHideOnSinglePage?: boolean;
}
export interface TabsConfig {
    dwAnimated?: boolean | {
        inkBar: boolean;
        tabPane: boolean;
    };
    dwSize?: DwSizeLDSType;
    dwType?: 'line' | 'card';
    dwTabBarGutter?: number;
    dwShowPagination?: boolean;
}
export interface TimePickerConfig {
    dwAllowEmpty?: boolean;
    dwClearText?: string;
    dwFormat?: string;
    dwHourStep?: number;
    dwMinuteStep?: number;
    dwSecondStep?: number;
    dwPopupClassName?: string;
    dwUse12Hours?: string;
    dwSuffixIcon?: string | TemplateRef<DwSafeAny>;
}
export interface TreeConfig {
    dwBlockNode?: boolean;
    dwShowIcon?: boolean;
    dwHideUnMatched?: boolean;
}
export interface TreeSelectConfig {
    dwShowIcon?: string;
    dwShowLine?: boolean;
    dwDropdownMatchSelectWidth?: boolean;
    dwHideUnMatched?: boolean;
    dwSize?: 'large' | 'small' | 'default';
}
export interface TypographyConfig {
    dwEllipsisRows?: number;
}
export declare type DwConfigKey = keyof DwConfig;
/**
 * User should provide an object implements this interface to set global configurations.
 */
export declare const DW_CONFIG: InjectionToken<DwConfig>;
