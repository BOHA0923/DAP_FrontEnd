/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Observable } from 'rxjs';
import { DwConfig, DwConfigKey } from './config';
export declare class DwConfigService {
    private configUpdated$;
    /** Global config holding property. */
    private config;
    constructor(defaultConfig?: DwConfig);
    getConfigForComponent<T extends DwConfigKey>(componentName: T): DwConfig[T];
    getConfigChangeEventForComponent(componentName: DwConfigKey): Observable<void>;
    set<T extends DwConfigKey>(componentName: T, value: DwConfig[T]): void;
}
/**
 * This decorator is used to decorate properties. If a property is decorated, it would try to load default value from
 * config.
 */
export declare function WithConfig<T>(componentName: DwConfigKey): (target: any, propName: any, originalDescriptor?: TypedPropertyDescriptor<T> | undefined) => any;
