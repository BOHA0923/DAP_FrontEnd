/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
export { DwNoAnimationModule } from './dw-no-animation.module';
export { DwNoAnimationDirective } from './dw-no-animation.directive';
