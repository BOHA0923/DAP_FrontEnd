/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Overlay } from '@angular/cdk/overlay';
import { ElementRef, ExistingProvider, OnDestroy, ViewContainerRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { DwSafeAny, OnChangeType, OnTouchedType } from 'ng-quicksilver/core/types';
import { DwInputGroupWhitSuffixOrPrefixDirective } from 'ng-quicksilver/input';
import { DwAutocompleteOptionComponent } from './autocomplete-option.component';
import { DwAutocompleteComponent } from './autocomplete.component';
export declare const DW_AUTOCOMPLETE_VALUE_ACCESSOR: ExistingProvider;
export declare function getDwAutocompleteMissingPanelError(): Error;
export declare class DwAutocompleteTriggerDirective implements ControlValueAccessor, OnDestroy {
    private elementRef;
    private overlay;
    private viewContainerRef;
    private dwInputGroupWhitSuffixOrPrefixDirective;
    private document;
    /** Bind dwAutocomplete component */
    dwAutocomplete: DwAutocompleteComponent;
    onChange: OnChangeType;
    onTouched: OnTouchedType;
    panelOpen: boolean;
    /** Current active option */
    get activeOption(): DwAutocompleteOptionComponent | void;
    private destroy$;
    private overlayRef;
    private portal;
    private positionStrategy;
    private previousValue;
    private selectionChangeSubscription;
    private optionsChangeSubscription;
    private overlayBackdropClickSubscription;
    constructor(elementRef: ElementRef, overlay: Overlay, viewContainerRef: ViewContainerRef, dwInputGroupWhitSuffixOrPrefixDirective: DwInputGroupWhitSuffixOrPrefixDirective, document: DwSafeAny);
    ngOnDestroy(): void;
    writeValue(value: DwSafeAny): void;
    registerOnChange(fn: (value: {}) => {}): void;
    registerOnTouched(fn: () => {}): void;
    setDisabledState(isDisabled: boolean): void;
    openPanel(): void;
    closePanel(): void;
    handleKeydown(event: KeyboardEvent): void;
    handleInput(event: KeyboardEvent): void;
    handleFocus(): void;
    handleBlur(): void;
    /**
     * Subscription data source changes event
     */
    private subscribeOptionsChange;
    /**
     * Subscription option changes event and set the value
     */
    private subscribeSelectionChange;
    /**
     * Subscription external click and close panel
     */
    private subscribeOverlayBackdropClick;
    private attachOverlay;
    private updateStatus;
    private destroyPanel;
    private getOverlayConfig;
    private getConnectedElement;
    private getHostWidth;
    private getOverlayPosition;
    private resetActiveItem;
    private setValueAndClose;
    private setTriggerValue;
    private doBackfill;
    private canOpen;
}
