/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, ElementRef, EventEmitter } from '@angular/core';
import { BooleanInput, DwSafeAny } from 'ng-quicksilver/core/types';
import { DwAutocompleteOptgroupComponent } from './autocomplete-optgroup.component';
export declare class DwOptionSelectionChange {
    source: DwAutocompleteOptionComponent;
    isUserInput: boolean;
    constructor(source: DwAutocompleteOptionComponent, isUserInput?: boolean);
}
export declare class DwAutocompleteOptionComponent {
    private changeDetectorRef;
    private element;
    dwAutocompleteOptgroupComponent: DwAutocompleteOptgroupComponent;
    static ngAcceptInputType_dwDisabled: BooleanInput;
    dwValue: DwSafeAny;
    dwLabel?: string;
    dwDisabled: boolean;
    readonly selectionChange: EventEmitter<DwOptionSelectionChange>;
    readonly mouseEntered: EventEmitter<DwAutocompleteOptionComponent>;
    active: boolean;
    selected: boolean;
    constructor(changeDetectorRef: ChangeDetectorRef, element: ElementRef, dwAutocompleteOptgroupComponent: DwAutocompleteOptgroupComponent);
    select(emit?: boolean): void;
    onMouseEnter(): void;
    deselect(): void;
    /** Git display label */
    getLabel(): string;
    /** Set active (only styles) */
    setActiveStyles(): void;
    /** Unset active (only styles) */
    setInactiveStyles(): void;
    scrollIntoViewIfNeeded(): void;
    selectViaInteraction(): void;
    private emitSelectionChangeEvent;
}
