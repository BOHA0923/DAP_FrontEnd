/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, NgZone, OnDestroy, QueryList, TemplateRef } from '@angular/core';
import { DwNoAnimationDirective } from 'ng-quicksilver/core/no-animation';
import { BooleanInput, CompareWith, DwSafeAny } from 'ng-quicksilver/core/types';
import { Observable } from 'rxjs';
import { DwAutocompleteOptionComponent, DwOptionSelectionChange } from './autocomplete-option.component';
export interface AutocompleteDataSourceItem {
    value: string;
    label: string;
}
export declare type AutocompleteDataSource = Array<AutocompleteDataSourceItem | string | number>;
export declare class DwAutocompleteComponent implements AfterContentInit, AfterViewInit, OnDestroy {
    private changeDetectorRef;
    private ngZone;
    noAnimation?: DwNoAnimationDirective | undefined;
    static ngAcceptInputType_dwDefaultActiveFirstOption: BooleanInput;
    static ngAcceptInputType_dwBackfill: BooleanInput;
    dwWidth?: number;
    dwOverlayClassName: string;
    dwOverlayStyle: {
        [key: string]: string;
    };
    dwDefaultActiveFirstOption: boolean;
    dwBackfill: boolean;
    compareWith: CompareWith;
    dwDataSource?: AutocompleteDataSource;
    readonly selectionChange: EventEmitter<DwAutocompleteOptionComponent>;
    showPanel: boolean;
    isOpen: boolean;
    activeItem: DwAutocompleteOptionComponent;
    /**
     * Options accessor, its source may be content or dataSource
     */
    get options(): QueryList<DwAutocompleteOptionComponent>;
    /** Provided by content */
    fromContentOptions: QueryList<DwAutocompleteOptionComponent>;
    /** Provided by dataSource */
    fromDataSourceOptions: QueryList<DwAutocompleteOptionComponent>;
    /** cdk-overlay */
    template?: TemplateRef<{}>;
    panel?: ElementRef;
    content?: ElementRef;
    private activeItemIndex;
    private selectionChangeSubscription;
    private optionMouseEnterSubscription;
    private dataSourceChangeSubscription;
    /** Options changes listener */
    readonly optionSelectionChanges: Observable<DwOptionSelectionChange>;
    readonly optionMouseEnter: Observable<DwAutocompleteOptionComponent>;
    constructor(changeDetectorRef: ChangeDetectorRef, ngZone: NgZone, noAnimation?: DwNoAnimationDirective | undefined);
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    setVisibility(): void;
    setActiveItem(index: number): void;
    setNextItemActive(): void;
    setPreviousItemActive(): void;
    getOptionIndex(value: DwSafeAny): number;
    getOption(value: DwSafeAny): DwAutocompleteOptionComponent | null;
    private optionsInit;
    /**
     * Clear the status of options
     */
    clearSelectedOptions(skip?: DwAutocompleteOptionComponent | null, deselect?: boolean): void;
    private subscribeOptionChanges;
}
